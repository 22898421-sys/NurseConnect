# G001 Role-Based Access Sign-Off Evidence

Date: 2026-06-16

Gate: `G001` - Role-based access tests pass for client, clinician, and system admin users.

## Result

Passed.

## Evidence

Command run:

```bash
npm run test:g001:local
```

Result:

```text
G001 role-based access rules validation passed.
```

The script validates the following Firestore rules behaviour:

- unauthenticated users cannot read restricted patient, clinical, encounter, summary, or compliance records
- client/carer users can read their own client record
- client/carer users cannot read another client's record
- client/carer users can read their own plain-language patient summary and portal documents
- client/carer users cannot read another client's patient summary or portal documents
- client/carer users cannot read clinician-only clinical chart records
- client/carer users cannot read clinician encounter records
- clinicians can read patient records in their own practice
- clinicians cannot read patient records outside their practice
- clinicians can query patients only when scoped to their practice
- clinicians cannot run an unscoped patient collection query
- clinicians can read clinical records, patient summaries, portal documents, and encounters in their own practice
- clinicians cannot read clinical records, patient summaries, portal documents, or encounters outside their practice
- clinicians can update patient records only within their practice and cannot change the patient `practiceId`
- system admins cannot browse client records, clinical records, patient summaries, or encounters by default
- system admins can access system-admin governance collections such as compliance provider records
- clinicians cannot access system-admin compliance provider records

## Files

- `scripts/testG001RoleAccessRules.mjs`
- `firestore.rules`
- `src/components/PatientListPage.tsx`
- `src/components/NurseBillingPage.tsx`

## Residual Scope

This gate covers the primary role-based access boundary for public, client/carer, clinician/nurse, and system-admin users. It does not sign off legal/privacy review, incident/complaint SOPs, credential/provider verification SOPs, pilot readiness, or final production cutover.
