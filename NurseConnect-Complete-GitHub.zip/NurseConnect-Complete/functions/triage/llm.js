function fallbackSummary(summary, ruleResult) {
  const parts = [];
  if (summary.presentingProblem) parts.push(`Presenting problem: ${summary.presentingProblem}.`);
  if (summary.onset) parts.push(`Onset: ${summary.onset}.`);
  if (summary.severity) parts.push(`Severity: ${summary.severity}.`);
  if (summary.worsening != null) parts.push(`Worsening: ${summary.worsening}.`);
  if (summary.breathless != null) parts.push(`Short of breath: ${summary.breathless}.`);
  if (summary.radiation != null) parts.push(`Pain spreading: ${summary.radiation}.`);
  if (summary.collapse != null) parts.push(`Collapse/near collapse: ${summary.collapse}.`);
  parts.push(`Urgency: ${ruleResult.urgencyTier}.`);
  if (ruleResult.redFlagCodes.length) parts.push(`Red flags: ${ruleResult.redFlagCodes.join(", ")}.`);
  return parts.join(" ");
}

async function generateClinicianSummary(summary, ruleResult) {
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
  const fallback = fallbackSummary(summary, ruleResult);
  if (!apiKey) return { text: fallback, modelVersion: null };

  const prompt = [
    "You are generating a concise clinician-facing intake snapshot.",
    "Do not diagnose. Do not offer patient reassurance. Do not mention AI.",
    "Write 3 to 5 short clinical summary sentences.",
    `Structured intake: ${JSON.stringify(summary)}`,
    `Urgency result: ${JSON.stringify(ruleResult)}`,
  ].join("\n");

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 7000);
    const res = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        input: prompt,
        max_output_tokens: 180,
      }),
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return { text: fallback, modelVersion: null };
    const data = await res.json();
    const text = (data?.output_text || "").toString().trim();
    return { text: text || fallback, modelVersion: model };
  } catch {
    return { text: fallback, modelVersion: null };
  }
}

module.exports = {
  generateClinicianSummary,
};
