const { computeCallbackTargetMinutes } = require("./sla");
const { generateClinicianSummary } = require("./llm");

function asText(value) {
  return (value || "").toString().trim().toLowerCase();
}

function asYes(value) {
  const v = asText(value);
  return v === "yes" || v === "true";
}

function computeUrgency({ domain, answers }) {
  const presentingProblem = asText(answers?.presentingProblem?.value || answers?.presentingProblem);
  const severity = asText(answers?.severity?.value || answers?.severity);
  const worsening = asYes(answers?.worsening?.value || answers?.worsening);
  const breathless = asYes(answers?.breathless?.value || answers?.breathless);
  const radiation = asYes(answers?.radiation?.value || answers?.radiation);
  const collapse = asYes(answers?.collapse?.value || answers?.collapse);
  const atRest = asYes(answers?.atRest?.value || answers?.atRest);
  const chestPain = asYes(answers?.chestPain?.value || answers?.chestPain);
  const blueOrFaint = asYes(answers?.blueOrFaint?.value || answers?.blueOrFaint);
  const suddenWorst = asYes(answers?.suddenWorst?.value || answers?.suddenWorst);
  const weaknessSpeech = asYes(answers?.weaknessSpeech?.value || answers?.weaknessSpeech);
  const vomiting = asYes(answers?.vomiting?.value || answers?.vomiting);
  const bleeding = asYes(answers?.bleeding?.value || answers?.bleeding);
  const pregnancy = asYes(answers?.pregnancy?.value || answers?.pregnancy);
  const canWait = asText(answers?.canWait?.value || answers?.canWait);

  const redFlagCodes = [];
  let urgencyTier = "routine";
  let recommendedAction = "keep_booking";

  if (domain === "chest_pain" || /chest/.test(presentingProblem)) {
    if ((severity === "severe" && breathless) || collapse || (breathless && radiation)) {
      urgencyTier = "emergency_now";
      recommendedAction = "seek_emergency_care";
      if (breathless) redFlagCodes.push("chest_pain_breathless");
      if (radiation) redFlagCodes.push("chest_pain_radiation");
      if (collapse) redFlagCodes.push("collapse");
    } else if (severity === "severe" || breathless || worsening) {
      urgencyTier = "urgent_callback";
      recommendedAction = "clinician_callback";
      if (breathless) redFlagCodes.push("breathless");
      if (worsening) redFlagCodes.push("worsening");
    } else {
      urgencyTier = "priority_review";
      recommendedAction = "review_for_earlier_slot";
    }
  } else if (domain === "shortness_of_breath" || /breath|breathing/.test(presentingProblem)) {
    if ((severity === "severe" && atRest) || blueOrFaint || (atRest && chestPain)) {
      urgencyTier = "emergency_now";
      recommendedAction = "seek_emergency_care";
      if (atRest) redFlagCodes.push("breathless_at_rest");
      if (chestPain) redFlagCodes.push("breathless_with_chest_pain");
      if (blueOrFaint) redFlagCodes.push("blue_or_faint");
    } else if (severity === "severe" || atRest || worsening) {
      urgencyTier = "urgent_callback";
      recommendedAction = "clinician_callback";
      if (worsening) redFlagCodes.push("worsening_breathing");
    } else {
      urgencyTier = "priority_review";
      recommendedAction = "review_for_earlier_slot";
    }
  } else if (domain === "headache_neuro" || /headache|weakness|speech|numb/.test(presentingProblem)) {
    if (suddenWorst || weaknessSpeech || collapse) {
      urgencyTier = "emergency_now";
      recommendedAction = "seek_emergency_care";
      if (suddenWorst) redFlagCodes.push("sudden_worst_headache");
      if (weaknessSpeech) redFlagCodes.push("neurological_deficit");
      if (collapse) redFlagCodes.push("collapse");
    } else if (severity === "severe" || worsening) {
      urgencyTier = "urgent_callback";
      recommendedAction = "clinician_callback";
    } else {
      urgencyTier = "priority_review";
      recommendedAction = "review_for_earlier_slot";
    }
  } else if (domain === "abdominal_pain" || /abdominal|stomach|belly|vomit|diarr/.test(presentingProblem)) {
    if (bleeding || (pregnancy && severity === "severe")) {
      urgencyTier = "emergency_now";
      recommendedAction = "seek_emergency_care";
      if (bleeding) redFlagCodes.push("gastrointestinal_or_heavy_bleeding");
      if (pregnancy) redFlagCodes.push("pregnancy_with_severe_pain");
    } else if ((severity === "severe" && vomiting) || vomiting || worsening) {
      urgencyTier = "urgent_callback";
      recommendedAction = "clinician_callback";
      if (vomiting) redFlagCodes.push("persistent_vomiting");
    } else {
      urgencyTier = "priority_review";
      recommendedAction = "review_for_earlier_slot";
    }
  } else if (severity === "severe" && worsening) {
    urgencyTier = "urgent_callback";
    recommendedAction = "clinician_callback";
    redFlagCodes.push("severe_worsening_symptoms");
  } else if (worsening || severity === "moderate") {
    urgencyTier = "priority_review";
    recommendedAction = "review_for_earlier_slot";
  }

  if (urgencyTier === "routine" && canWait === "prefer_earlier") {
    urgencyTier = "priority_review";
    recommendedAction = "review_for_earlier_slot";
  }

  return {
    urgencyTier,
    redFlagCodes,
    recommendedAction,
    callbackTargetMinutes: computeCallbackTargetMinutes(urgencyTier),
  };
}

function buildStructuredSummary(session) {
  const answers = session?.answers || {};
  const read = (key) => {
    const raw = answers[key];
    if (raw && typeof raw === "object" && Object.prototype.hasOwnProperty.call(raw, "value")) return raw.value;
    return raw ?? null;
  };
  const presentingProblem = read("presentingProblem");
  const onset = read("onset");
  const severity = read("severity");
  const worsening = read("worsening");
  const breathless = read("breathless");
  const radiation = read("radiation");
  const collapse = read("collapse");
  const atRest = read("atRest");
  const chestPain = read("chestPain");
  const blueOrFaint = read("blueOrFaint");
  const suddenWorst = read("suddenWorst");
  const weaknessSpeech = read("weaknessSpeech");
  const vomiting = read("vomiting");
  const bleeding = read("bleeding");
  const pregnancy = read("pregnancy");
  const canWait = read("canWait");
  return {
    presentingProblem: presentingProblem || null,
    onset: onset || null,
    severity: severity || null,
    worsening: worsening || null,
    breathless: breathless || null,
    radiation: radiation || null,
    collapse: collapse || null,
    atRest: atRest || null,
    chestPain: chestPain || null,
    blueOrFaint: blueOrFaint || null,
    suddenWorst: suddenWorst || null,
    weaknessSpeech: weaknessSpeech || null,
    vomiting: vomiting || null,
    bleeding: bleeding || null,
    pregnancy: pregnancy || null,
    canWait: canWait || null,
  };
}

async function buildClinicianSummary(session, ruleResult) {
  const summary = buildStructuredSummary(session);
  const llm = await generateClinicianSummary(summary, ruleResult);
  return {
    structuredSummary: summary,
    llmSummaryText: llm.text,
    modelVersion: llm.modelVersion,
  };
}

module.exports = {
  buildClinicianSummary,
  computeUrgency,
};
