function computeCallbackTargetMinutes(urgencyTier) {
  if (urgencyTier === "urgent_callback") return 30;
  if (urgencyTier === "priority_review") return 120;
  return null;
}

module.exports = { computeCallbackTargetMinutes };
