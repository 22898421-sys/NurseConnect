function renderPatientMessage(params) {
  const urgencyTier = (params?.urgencyTier || "routine").toString();
  const callbackTargetMinutes = Number(params?.callbackTargetMinutes || 0);
  const practiceOpen = params?.practiceOpen !== false;

  if (urgencyTier === "emergency_now") {
    return {
      templateId: "emergency_now",
      message:
        "Your answers suggest you may need urgent emergency assessment now. Please seek emergency care immediately. If symptoms worsen, do not wait for the booked appointment.",
    };
  }
  if (urgencyTier === "urgent_callback") {
    if (practiceOpen && callbackTargetMinutes > 0) {
      return {
        templateId: "urgent_callback_open",
        message: `Your answers suggest a clinician should review this sooner. A member of the practice will contact you within ${callbackTargetMinutes} minutes.`,
      };
    }
    return {
      templateId: "urgent_callback_closed",
      message:
        "Your answers suggest earlier review may be needed. The practice will contact you when it reopens. If symptoms worsen, seek urgent care.",
    };
  }
  if (urgencyTier === "priority_review") {
    return {
      templateId: "priority_review",
      message:
        "Thank you. We have sent your answers to the practice for review. If your appointment needs to be brought forward, the team will contact you.",
    };
  }
  return {
    templateId: "routine_keep_booking",
    message:
      "Your symptoms have been recorded for the clinician. We will see you at your booked appointment.",
  };
}

module.exports = { renderPatientMessage };
