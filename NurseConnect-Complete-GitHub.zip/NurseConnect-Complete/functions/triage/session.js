const admin = require("firebase-admin");
const functions = require("firebase-functions");
const { detectSymptomDomain, loadBank, nextQuestion, getQuestionMap } = require("./questions");
const { computeUrgency, buildClinicianSummary } = require("./rules");
const { renderPatientMessage } = require("./messages");

function asFirestoreDate(value) {
  return value instanceof Date ? value : new Date(value);
}

function serverTimestampDate() {
  return new Date();
}

function asTrimmedString(value) {
  return (value || "").toString().trim();
}

function ensurePatientUser(profile) {
  if (asTrimmedString(profile?.role) !== "patient") {
    throw new functions.https.HttpsError("permission-denied", "Only patient users can use symptom intake.");
  }
}

function answerFieldMap(session) {
  const out = {};
  for (const answer of Object.values(session?.answers || {})) {
    if (!answer || typeof answer !== "object") continue;
    if (answer.fieldKey) out[answer.fieldKey] = answer;
  }
  return out;
}

function getCurrentQuestion(session) {
  const bank = loadBank(session?.symptomDomain || "general");
  const question = nextQuestion(bank, session?.answers || {});
  return {
    bank,
    question,
    progress: {
      answered: Object.keys(session?.answers || {}).length,
      totalEstimated: bank.questions.length,
    },
  };
}

function isPracticeOpenNow() {
  const now = new Date();
  const day = now.getDay();
  const hour = now.getHours();
  if (day === 0 || day === 6) return false;
  return hour >= 8 && hour < 17;
}

async function createPracticeTask({ session, ruleResult, clinicianSummary }) {
  if (!session.practiceId) return null;
  if (!["urgent_callback", "priority_review"].includes(ruleResult.urgencyTier)) return null;
  const type = ruleResult.urgencyTier === "urgent_callback" ? "triage_callback" : "bring_forward_review";
  const priority = ruleResult.urgencyTier === "urgent_callback" ? "high" : "medium";
  const dueAt =
    typeof ruleResult.callbackTargetMinutes === "number" && ruleResult.callbackTargetMinutes > 0
      ? asFirestoreDate(Date.now() + ruleResult.callbackTargetMinutes * 60 * 1000)
      : null;
  const ref = await admin.firestore().collection("practiceTasks").add({
    practiceId: session.practiceId,
    type,
    priority,
    status: "open",
    triageSessionId: session.id,
    appointmentId: session.appointmentId || null,
    patientId: session.patientId,
    clinicianId: session.clinicianId || null,
    summary: clinicianSummary.llmSummaryText,
    dueAt,
    assignedToUid: null,
    createdAt: serverTimestampDate(),
    updatedAt: serverTimestampDate(),
  });
  return { id: ref.id, dueAt };
}

async function writeAppointmentSnapshot(session, ruleResult, clinicianSummary) {
  if (!session.appointmentId) return;
  await admin.firestore().collection("appointments").doc(session.appointmentId).set(
    {
      triageSessionId: session.id,
      triageStatus: ruleResult.urgencyTier === "emergency_now" ? "escalated" : "completed",
      triageUrgency: ruleResult.urgencyTier,
      triageLastUpdatedAt: serverTimestampDate(),
      triageCallbackBy:
        typeof ruleResult.callbackTargetMinutes === "number" && ruleResult.callbackTargetMinutes > 0
          ? asFirestoreDate(Date.now() + ruleResult.callbackTargetMinutes * 60 * 1000)
          : null,
      triageSnapshot: {
        symptomDomain: session.symptomDomain || "general",
        urgencyTier: ruleResult.urgencyTier,
        summary: clinicianSummary.llmSummaryText,
        redFlagCodes: ruleResult.redFlagCodes,
      },
    },
    { merge: true }
  );
}

async function finalizeSession(sessionRef, session) {
  const ruleResult = computeUrgency({
    domain: session.symptomDomain || "general",
    answers: answerFieldMap(session),
  });
  const clinicianSummary = await buildClinicianSummary(session, ruleResult);
  const patientMessage = renderPatientMessage({
    urgencyTier: ruleResult.urgencyTier,
    callbackTargetMinutes: ruleResult.callbackTargetMinutes,
    practiceOpen: isPracticeOpenNow(),
  });
  const task = await createPracticeTask({ session, ruleResult, clinicianSummary });
  await writeAppointmentSnapshot(session, ruleResult, clinicianSummary);
  await sessionRef.set(
    {
      structuredSummary: clinicianSummary.structuredSummary,
      llmSummaryText: clinicianSummary.llmSummaryText,
      urgencyTier: ruleResult.urgencyTier,
      redFlagCodes: ruleResult.redFlagCodes,
      recommendedAction: ruleResult.recommendedAction,
      callbackTargetMinutes: ruleResult.callbackTargetMinutes,
      callbackBy:
        typeof ruleResult.callbackTargetMinutes === "number" && ruleResult.callbackTargetMinutes > 0
          ? asFirestoreDate(Date.now() + ruleResult.callbackTargetMinutes * 60 * 1000)
          : null,
      patientMessageTemplateId: patientMessage.templateId,
      patientMessageRendered: patientMessage.message,
      status: ruleResult.urgencyTier === "emergency_now" ? "escalated" : "completed",
      completedAt: serverTimestampDate(),
      updatedAt: serverTimestampDate(),
      reviewStatus: "pending",
      modelVersion: clinicianSummary.modelVersion,
    },
    { merge: true }
  );
  return {
    status: ruleResult.urgencyTier === "emergency_now" ? "escalated" : "completed",
    urgencyTier: ruleResult.urgencyTier,
    patientMessage: patientMessage.message,
    callbackBy:
      typeof ruleResult.callbackTargetMinutes === "number" && ruleResult.callbackTargetMinutes > 0
        ? new Date(Date.now() + ruleResult.callbackTargetMinutes * 60 * 1000).toISOString()
        : null,
    createdTaskId: task?.id || null,
    clinicianSnapshot: {
      symptomDomain: session.symptomDomain || "general",
      summary: clinicianSummary.llmSummaryText,
      redFlagCodes: ruleResult.redFlagCodes,
    },
  };
}

async function startSession({ uid, appointmentId, channel, whatsappNumber = "" }) {
  const userProfile = (await admin.firestore().collection("users").doc(uid).get()).data() || {};
  ensurePatientUser(userProfile);
  const patientId = asTrimmedString(userProfile.patientId) || uid;
  const appointmentRef = admin.firestore().collection("appointments").doc(asTrimmedString(appointmentId));
  const appointmentSnap = await appointmentRef.get();
  if (!appointmentSnap.exists) {
    throw new functions.https.HttpsError("not-found", "Appointment not found.");
  }
  const appointment = appointmentSnap.data() || {};
  if (asTrimmedString(appointment.patientUserId) !== uid && asTrimmedString(appointment.patientId) !== patientId) {
    throw new functions.https.HttpsError("permission-denied", "You can only start triage for your own appointment.");
  }

  const existingSnap = await admin
    .firestore()
    .collection("triageSessions")
    .where("appointmentId", "==", asTrimmedString(appointmentId))
    .limit(1)
    .get();
  if (!existingSnap.empty) {
    const row = existingSnap.docs[0];
    const data = row.data() || {};
    if (channel === "whatsapp" && asTrimmedString(whatsappNumber)) {
      await row.ref.set(
        {
          whatsappNumber: asTrimmedString(whatsappNumber),
          updatedAt: serverTimestampDate(),
        },
        { merge: true }
      );
    }
    if (data.status === "completed" || data.status === "escalated") {
      return {
        triageSessionId: row.id,
        status: data.status,
        question: null,
        progress: { answered: Object.keys(data.answers || {}).length, totalEstimated: (data.questionSequence || []).length || 0 },
        outcome: {
          urgencyTier: data.urgencyTier || null,
          patientMessage: data.patientMessageRendered || null,
        },
      };
    }
    const current = getCurrentQuestion(data);
    return {
      triageSessionId: row.id,
      status: "active",
      question: current.question,
      progress: current.progress,
    };
  }

  const bank = loadBank("general");
  const firstQuestion = bank.questions[0] || null;
  const ref = await admin.firestore().collection("triageSessions").add({
    appointmentId: asTrimmedString(appointmentId),
    patientId,
    patientUserId: uid,
    practiceId: asTrimmedString(appointment.practiceId || userProfile.practiceId),
    clinicianId: asTrimmedString(appointment.clinicianId),
    whatsappNumber: channel === "whatsapp" ? asTrimmedString(whatsappNumber) : "",
    channel: channel === "whatsapp" ? "whatsapp" : "portal",
    source: "post_booking",
    status: "active",
    symptomDomain: "general",
    currentQuestionId: firstQuestion?.id || null,
    questionSequence: bank.questions.map((question) => question.id),
    answers: {},
    structuredSummary: null,
    llmSummaryText: null,
    urgencyTier: null,
    redFlagCodes: [],
    recommendedAction: null,
    callbackTargetMinutes: null,
    callbackBy: null,
    patientMessageTemplateId: null,
    patientMessageRendered: null,
    reviewStatus: null,
    reviewedByUid: null,
    reviewNotes: null,
    questionBankVersion: bank.version,
    ruleVersion: "2026-03-09.1",
    modelVersion: null,
    createdAt: serverTimestampDate(),
    updatedAt: serverTimestampDate(),
    completedAt: null,
  });
  await appointmentRef.set(
    {
      triageSessionId: ref.id,
      triageStatus: "active",
      triageUrgency: null,
      triageLastUpdatedAt: serverTimestampDate(),
    },
    { merge: true }
  );
  return {
    triageSessionId: ref.id,
    status: "active",
    question: firstQuestion,
    progress: { answered: 0, totalEstimated: bank.questions.length },
  };
}

async function submitAnswerCore({ sessionRef, session, questionId, value }) {
  if (session.status !== "active") {
    throw new functions.https.HttpsError("failed-precondition", "This triage session is no longer active.");
  }

  const currentBank = loadBank(session.symptomDomain || "general");
  const currentMap = getQuestionMap(currentBank);
  const question = currentMap.get(asTrimmedString(questionId));
  if (!question) {
    throw new functions.https.HttpsError("invalid-argument", "Question not found.");
  }

  const nextAnswers = {
    ...(session.answers || {}),
    [question.id]: {
      questionId: question.id,
      fieldKey: question.fieldKey,
      value,
      answeredAt: serverTimestampDate(),
    },
  };
  let nextDomain = session.symptomDomain || "general";
  if (question.fieldKey === "presentingProblem") {
    nextDomain = detectSymptomDomain(value);
  }
  const nextBank = loadBank(nextDomain);
  const nextQ = nextQuestion(nextBank, nextAnswers);
  await sessionRef.set(
    {
      answers: nextAnswers,
      symptomDomain: nextDomain,
      questionSequence: nextBank.questions.map((item) => item.id),
      questionBankVersion: nextBank.version,
      currentQuestionId: nextQ?.id || null,
      updatedAt: serverTimestampDate(),
    },
    { merge: true }
  );
  if (!nextQ) {
    return {
      status: "completed",
      nextQuestion: null,
      progress: { answered: Object.keys(nextAnswers).length, totalEstimated: nextBank.questions.length },
      urgencyPreview: computeUrgency({ domain: nextDomain, answers: answerFieldMap({ answers: nextAnswers }) }).urgencyTier,
    };
  }
  return {
    status: "active",
    nextQuestion: nextQ,
    progress: { answered: Object.keys(nextAnswers).length, totalEstimated: nextBank.questions.length },
    urgencyPreview: null,
  };
}

async function submitAnswer({ uid, triageSessionId, questionId, value }) {
  const ref = admin.firestore().collection("triageSessions").doc(asTrimmedString(triageSessionId));
  const snap = await ref.get();
  if (!snap.exists) {
    throw new functions.https.HttpsError("not-found", "Triage session not found.");
  }
  const session = { id: snap.id, ...(snap.data() || {}) };
  if (asTrimmedString(session.patientUserId) !== uid) {
    throw new functions.https.HttpsError("permission-denied", "You can only answer your own triage session.");
  }
  return submitAnswerCore({ sessionRef: ref, session, questionId, value });
}

async function reviewSessionDecision({ uid, triageSessionId, urgencyTier, reviewNotes }) {
  const userSnap = await admin.firestore().collection("users").doc(uid).get();
  const userProfile = userSnap.data() || {};
  const role = asTrimmedString(userProfile.role);
  if (role !== "clinician") {
    throw new functions.https.HttpsError("permission-denied", "Only nurses can review triage.");
  }

  const ref = admin.firestore().collection("triageSessions").doc(asTrimmedString(triageSessionId));
  const snap = await ref.get();
  if (!snap.exists) {
    throw new functions.https.HttpsError("not-found", "Triage session not found.");
  }
  const session = { id: snap.id, ...(snap.data() || {}) };
  if (asTrimmedString(session.practiceId) !== asTrimmedString(userProfile.practiceId)) {
    throw new functions.https.HttpsError("permission-denied", "Triage session is outside your practice.");
  }

  const callbackTargetMinutes =
    urgencyTier === "urgent_callback" ? 30 : urgencyTier === "priority_review" ? 120 : null;
  const callbackBy =
    typeof callbackTargetMinutes === "number"
      ? asFirestoreDate(Date.now() + callbackTargetMinutes * 60 * 1000)
      : null;
  const patientMessage = renderPatientMessage({
    urgencyTier,
    callbackTargetMinutes,
    practiceOpen: isPracticeOpenNow(),
  });
  await ref.set(
    {
      urgencyTier,
      callbackTargetMinutes,
      callbackBy,
      patientMessageTemplateId: patientMessage.templateId,
      patientMessageRendered: patientMessage.message,
      reviewStatus: "overridden",
      reviewedByUid: uid,
      reviewNotes: asTrimmedString(reviewNotes) || null,
      updatedAt: serverTimestampDate(),
    },
    { merge: true }
  );
  if (session.appointmentId) {
    await admin.firestore().collection("appointments").doc(session.appointmentId).set(
      {
        triageStatus: urgencyTier === "emergency_now" ? "escalated" : "completed",
        triageUrgency: urgencyTier,
        triageCallbackBy: callbackBy,
        triageLastUpdatedAt: serverTimestampDate(),
        triageSnapshot: {
          symptomDomain: session.symptomDomain || "general",
          urgencyTier,
          summary: asTrimmedString(session.llmSummaryText),
          redFlagCodes: Array.isArray(session.redFlagCodes) ? session.redFlagCodes : [],
        },
      },
      { merge: true }
    );
  }
  const taskSnap = await admin
    .firestore()
    .collection("practiceTasks")
    .where("triageSessionId", "==", session.id)
    .where("status", "==", "open")
    .limit(20)
    .get();
  for (const row of taskSnap.docs) {
    await row.ref.set(
      {
        status: "done",
        assignedToUid: uid,
        updatedAt: serverTimestampDate(),
      },
      { merge: true }
    );
  }
  return {
    success: true,
    triageSessionId: session.id,
    urgencyTier,
    patientMessage: patientMessage.message,
  };
}

module.exports = {
  finalizeSession,
  getCurrentQuestion,
  submitAnswerCore,
  reviewSessionDecision,
  startSession,
  submitAnswer,
};
