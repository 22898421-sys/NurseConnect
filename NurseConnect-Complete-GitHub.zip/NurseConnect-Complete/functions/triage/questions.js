const fs = require("fs");
const path = require("path");

const banksDir = path.join(__dirname, "questionBanks");

function loadBank(domain) {
  const safe = (domain || "general").toString().trim().toLowerCase();
  const candidate = path.join(banksDir, `${safe}.json`);
  const fallback = path.join(banksDir, "general.json");
  const filePath = fs.existsSync(candidate) ? candidate : fallback;
  const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
  const questions = Array.isArray(parsed?.questions) ? parsed.questions : [];
  return {
    domain: parsed?.domain || "general",
    version: parsed?.version || "2026-03-09.1",
    questions,
  };
}

function detectSymptomDomain(text) {
  const input = (text || "").toString().trim().toLowerCase();
  if (!input) return "general";
  if (/(chest pain|chest pressure|chest tightness|pain in chest|tight chest)/.test(input)) return "chest_pain";
  if (/(short of breath|shortness of breath|breathless|difficulty breathing|can't breathe)/.test(input)) return "shortness_of_breath";
  if (/(headache|migraine|weakness|numbness|speech|face droop|dizzy|seizure|fainted)/.test(input)) return "headache_neuro";
  if (/(abdominal pain|stomach pain|belly pain|vomiting|diarrhoea|diarrhea|black stool|blood in stool)/.test(input)) return "abdominal_pain";
  return "general";
}

function getQuestionMap(bank) {
  const out = new Map();
  for (const question of bank.questions || []) {
    out.set(question.id, question);
  }
  return out;
}

function nextQuestion(bank, answers) {
  const answeredIds = new Set(Object.keys(answers || {}));
  for (const question of bank.questions || []) {
    if (!answeredIds.has(question.id)) return question;
  }
  return null;
}

module.exports = {
  detectSymptomDomain,
  getQuestionMap,
  loadBank,
  nextQuestion,
};
