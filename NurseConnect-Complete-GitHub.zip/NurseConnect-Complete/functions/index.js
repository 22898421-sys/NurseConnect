const functions = require("firebase-functions/v1");
const admin = require("firebase-admin");
const Stripe = require("stripe");
const {
  startSession,
  submitAnswer,
  submitAnswerCore,
  finalizeSession,
  reviewSessionDecision,
  getCurrentQuestion,
} = require("./triage/session");

admin.initializeApp();

function asTrimmedString(value) {
  return (value || "").toString().trim();
}

function looksLikeEmail(value) {
  return /\S+@\S+\.\S+/.test(asTrimmedString(value));
}

function titleCaseWords(value) {
  return asTrimmedString(value)
    .split(/\s+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
    .join(" ");
}

function humanizeEmailLocalPart(email) {
  const normalized = asTrimmedString(email);
  if (!looksLikeEmail(normalized)) return "";
  const localPart = normalized.split("@")[0] || "";
  const words = localPart.replace(/[._-]+/g, " ").replace(/\s+/g, " ").trim();
  return words ? titleCaseWords(words) : normalized;
}

function clinicianDisplayLabel(name, email, fallbackId) {
  const trimmedName = asTrimmedString(name);
  if (trimmedName && !looksLikeEmail(trimmedName)) return trimmedName;
  const fromEmail = humanizeEmailLocalPart(email || trimmedName);
  if (fromEmail) return fromEmail;
  return asTrimmedString(email) || asTrimmedString(fallbackId);
}

function sanitizeStringArray(raw, maxItems, maxLength) {
  const items = Array.isArray(raw) ? raw : [];
  return items
    .map((item) => asTrimmedString(item).slice(0, maxLength))
    .filter(Boolean)
    .slice(0, maxItems);
}

function toSlug(value, fallback = "item") {
  const normalized = asTrimmedString(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return normalized || fallback;
}

function serviceRequestManageUrl(data, requestId) {
  const explicit = asTrimmedString(data?.manageUrl);
  if (explicit) return explicit;
  const appBaseUrl = asTrimmedString(process.env.PUBLIC_APP_URL || process.env.APP_BASE_URL);
  return appBaseUrl ? `${appBaseUrl.replace(/\/+$/, "")}/service-requests/manage/${requestId}` : `/service-requests/manage/${requestId}`;
}

function demoBillingEnabled() {
  return asTrimmedString(process.env.ENABLE_DEMO_BILLING).toLowerCase() === "true";
}

const SUBSCRIPTION_TRIAL_DAYS = 7;

function subscriptionBillingOption(value) {
  const normalized = asTrimmedString(value).toLowerCase();
  if (normalized === "half_yearly") return { value: "half_yearly", months: 6, discountPercent: 8 };
  if (normalized === "annually") return { value: "annually", months: 12, discountPercent: 15 };
  if (normalized === "quarterly") return { value: "quarterly", months: 3, discountPercent: 3.5 };
  return { value: "monthly", months: 1, discountPercent: 0 };
}

function clinicianBaseMonthlyFeeCents(nurseType) {
  return asTrimmedString(nurseType).toUpperCase() === "NP" ? 5500 : 5000;
}

function subscriptionPricing(baseMonthlyFeeCents, billingCycle) {
  const option = subscriptionBillingOption(billingCycle);
  const undiscountedCents = baseMonthlyFeeCents * option.months;
  const discountedCents = Math.round(undiscountedCents * (1 - option.discountPercent / 100));
  return {
    ...option,
    undiscountedCents,
    discountedCents,
  };
}

function addDays(date, days) {
  const next = new Date(date.getTime());
  next.setDate(next.getDate() + days);
  return next;
}

let stripeClient = null;

function getStripeClient() {
  const secretKey = asTrimmedString(process.env.STRIPE_SECRET_KEY);
  if (!secretKey) {
    throw new functions.https.HttpsError("failed-precondition", "Stripe secret key is not configured.");
  }
  if (!stripeClient) {
    stripeClient = new Stripe(secretKey);
  }
  return stripeClient;
}

function stripePriceEnvKeyForProfile(nurseType, billingCycle) {
  const normalizedCycle = subscriptionBillingOption(billingCycle).value;
  const cadre = asTrimmedString(nurseType).toUpperCase() === "NP" ? "NP" : "EN_RN";
  if (normalizedCycle === "monthly") return `STRIPE_PRICE_${cadre}_MONTHLY`;
  if (normalizedCycle === "quarterly") return `STRIPE_PRICE_${cadre}_QUARTERLY`;
  if (normalizedCycle === "half_yearly") return `STRIPE_PRICE_${cadre}_HALF_YEARLY`;
  return `STRIPE_PRICE_${cadre}_ANNUAL`;
}

function stripePriceIdForProfile(nurseType, billingCycle) {
  const envKey = stripePriceEnvKeyForProfile(nurseType, billingCycle);
  const priceId = asTrimmedString(process.env[envKey]);
  if (!priceId) {
    throw new functions.https.HttpsError(
      "failed-precondition",
      `Stripe price is not configured for ${envKey}.`
    );
  }
  return priceId;
}

function resolveCheckoutOrigin(rawOrigin) {
  const fallback = asTrimmedString(process.env.PUBLIC_APP_URL || process.env.APP_BASE_URL || "https://www.nurseconnectcare.com.au");
  const candidate = asTrimmedString(rawOrigin || fallback);
  try {
    const url = new URL(candidate);
    const hostname = url.hostname.toLowerCase();
    const isAllowedHost =
      hostname === "www.nurseconnectcare.com.au" ||
      hostname === "nurseconnect-project.web.app" ||
      hostname === "localhost" ||
      hostname === "127.0.0.1";
    if (!isAllowedHost) return fallback;
    return url.origin;
  } catch {
    return fallback;
  }
}

function asDateOrNull(value) {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function fromUnixSecondsOrNull(value) {
  const num = Number(value || 0);
  if (!Number.isFinite(num) || num <= 0) return null;
  return new Date(num * 1000);
}

function normalizeStripeSubscriptionStatus(status) {
  const normalized = asTrimmedString(status).toLowerCase();
  if (normalized === "trialing") return "trial_active";
  if (normalized === "active") return "active";
  if (normalized === "past_due") return "past_due";
  if (normalized === "unpaid") return "unpaid";
  if (normalized === "canceled") return "cancelled";
  if (normalized === "incomplete") return "incomplete";
  if (normalized === "incomplete_expired") return "expired";
  if (normalized === "paused") return "paused";
  return normalized || "pending_payment";
}

function billingCycleFromStripePrice(price) {
  const interval = asTrimmedString(price?.recurring?.interval).toLowerCase();
  const intervalCount = Number(price?.recurring?.interval_count || 0);
  if (interval === "month" && intervalCount === 12) return "annually";
  if (interval === "month" && intervalCount === 6) return "half_yearly";
  if (interval === "month" && intervalCount === 3) return "quarterly";
  return "monthly";
}

async function findUserRefForStripeEvent({ firebaseUid, stripeCustomerId }) {
  const users = admin.firestore().collection("users");
  const explicitUid = asTrimmedString(firebaseUid);
  if (explicitUid) {
    const ref = users.doc(explicitUid);
    const snap = await ref.get();
    if (snap.exists) return { ref, profile: snap.data() || {} };
  }

  const customerId = asTrimmedString(stripeCustomerId);
  if (customerId) {
    const snap = await users.where("stripeCustomerId", "==", customerId).limit(1).get();
    if (!snap.empty) {
      return { ref: snap.docs[0].ref, profile: snap.docs[0].data() || {} };
    }
  }

  return null;
}

async function syncStripeSubscriptionToUser({
  firebaseUid,
  stripeCustomerId,
  stripeSubscription,
  eventId,
  eventType,
}) {
  const userMatch = await findUserRefForStripeEvent({
    firebaseUid,
    stripeCustomerId,
  });
  if (!userMatch) return false;

  const { ref: userRef, profile } = userMatch;
  const primaryItem = stripeSubscription?.items?.data?.[0] || {};
  const price = primaryItem?.price || {};
  const billingCycle = subscriptionBillingOption(
    stripeSubscription?.metadata?.subscriptionBillingCycle ||
      price?.metadata?.billing_cycle ||
      profile.subscriptionBillingCycle ||
      billingCycleFromStripePrice(price)
  ).value;
  const nurseType = asTrimmedString(
    stripeSubscription?.metadata?.nurseType || profile.nurseType || "RN"
  ).toUpperCase();
  const pricing = subscriptionPricing(clinicianBaseMonthlyFeeCents(nurseType), billingCycle);
  const currentPeriodEnd =
    fromUnixSecondsOrNull(stripeSubscription?.current_period_end) ||
    fromUnixSecondsOrNull(stripeSubscription?.trial_end);
  const trialEndsAt = fromUnixSecondsOrNull(stripeSubscription?.trial_end);
  const subscriptionCreatedAt = fromUnixSecondsOrNull(stripeSubscription?.created);

  await userRef.set(
    {
      stripeCustomerId: asTrimmedString(stripeSubscription?.customer || stripeCustomerId) || null,
      stripeSubscriptionId: asTrimmedString(stripeSubscription?.id) || null,
      subscriptionPriceId: asTrimmedString(price?.id) || null,
      subscriptionBillingCycle: billingCycle,
      subscriptionDiscountPercent: pricing.discountPercent,
      subscriptionCurrentPriceCents:
        Number.isFinite(Number(price?.unit_amount)) && Number(price?.unit_amount) > 0
          ? Number(price.unit_amount)
          : pricing.discountedCents,
      subscriptionStatus: normalizeStripeSubscriptionStatus(stripeSubscription?.status),
      subscriptionGateway: "stripe",
      subscriptionGatewayMode: "webhook_synced",
      subscriptionActivatedAt: subscriptionCreatedAt || profile.subscriptionActivatedAt || serverTimestampDate(),
      subscriptionTrialEndsAt: trialEndsAt,
      subscriptionNextBillingAt: currentPeriodEnd,
      subscriptionLastWebhookEventId: eventId,
      subscriptionLastWebhookType: eventType,
      updatedAt: serverTimestampDate(),
    },
    { merge: true }
  );

  return true;
}

async function queueServiceRequestNotification({
  notificationId,
  requestId,
  eventType,
  recipientEmail,
  recipientPhone = null,
  recipientRole,
  subject,
  body,
  metadata = {},
}) {
  if (!requestId || !notificationId || !recipientEmail) return null;
  const notificationRef = admin.firestore().collection("serviceRequestNotifications").doc(notificationId);
  await notificationRef.set(
    {
      requestId,
      eventType,
      recipientRole,
      recipientEmail,
      recipientPhone: recipientPhone || null,
      subject,
      body,
      metadata,
      createdAt: serverTimestampDate(),
      updatedAt: serverTimestampDate(),
    },
    { merge: true }
  );

  const deliveryRef = admin.firestore().collection("serviceRequestNotificationDeliveries").doc(notificationId);
  const resendApiKey = asTrimmedString(process.env.RESEND_API_KEY);
  const fromEmail = asTrimmedString(process.env.NOTIFICATION_FROM_EMAIL || process.env.RESEND_FROM_EMAIL);

  if (!resendApiKey || !fromEmail) {
    await deliveryRef.set(
      {
        requestId,
        notificationId,
        channel: "email",
        recipientEmail,
        status: "stub",
        provider: "resend",
        reason: "missing_email_provider_configuration",
        createdAt: serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      },
      { merge: true }
    );
    return { status: "stub" };
  }

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: fromEmail,
        to: [recipientEmail],
        subject,
        text: body,
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(asTrimmedString(payload?.message) || `Email provider error ${response.status}`);
    }
    await deliveryRef.set(
      {
        requestId,
        notificationId,
        channel: "email",
        recipientEmail,
        status: "sent",
        provider: "resend",
        providerMessageId: asTrimmedString(payload?.id) || null,
        createdAt: serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      },
      { merge: true }
    );
    return { status: "sent", providerMessageId: asTrimmedString(payload?.id) || null };
  } catch (error) {
    await deliveryRef.set(
      {
        requestId,
        notificationId,
        channel: "email",
        recipientEmail,
        status: "failed",
        provider: "resend",
        error: asTrimmedString(error?.message) || "Unknown email delivery error",
        createdAt: serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      },
      { merge: true }
    );
    return { status: "failed" };
  }
}

function buildRequesterSubmissionNotification(requestId, data) {
  const manageUrl = serviceRequestManageUrl(data, requestId);
  const requestType = asTrimmedString(data?.requestType) === "direct_request" ? "direct request" : "open request";
  return {
    subject: `NurseConnectCare request received: ${asTrimmedString(data?.serviceTitle) || "Service request"}`,
    body: [
      `Your ${requestType} has been received by NurseConnectCare.`,
      "",
      `Organisation: ${asTrimmedString(data?.organisationName) || "Not recorded"}`,
      `Service: ${asTrimmedString(data?.serviceTitle) || "Not recorded"}`,
      `Location: ${asTrimmedString(data?.suburb) || "Suburb not recorded"} ${asTrimmedString(data?.postcode)}`.trim(),
      `Required nurse type: ${asTrimmedString(data?.requiredNurseType) || "Not recorded"}`,
      "",
      "Use the management link below to confirm when the request has been filled or withdrawn.",
      manageUrl,
      "",
      "NurseConnectCare relays request activity and responses only. It does not allocate nurses, approve services, process claims, or handle funds.",
    ].join("\n"),
  };
}

function buildDirectRequestNotification(requestId, data, nurseDisplayName) {
  const manageUrl = serviceRequestManageUrl(data, requestId);
  return {
    subject: `Direct service request from ${asTrimmedString(data?.organisationName) || "an organisation"}`,
    body: [
      `A direct service request has been sent to ${nurseDisplayName || "you"} through NurseConnectCare.`,
      "",
      `Service: ${asTrimmedString(data?.serviceTitle) || "Not recorded"}`,
      `Location: ${asTrimmedString(data?.suburb) || "Suburb not recorded"} ${asTrimmedString(data?.postcode)}`.trim(),
      `Timeframe: ${asTrimmedString(data?.timeframe) || "Not recorded"}`,
      `Funding pathway: ${asTrimmedString(data?.fundingPathway) || "Not recorded"}`,
      "",
      `Care context: ${asTrimmedString(data?.carePlanContext) || "Not recorded"}`,
      "",
      "Log in to NurseConnectCare to accept or decline this request.",
      "Requester management reference:",
      manageUrl,
    ].join("\n"),
  };
}

function buildRequesterResponseNotification(data, response) {
  const manageUrl = serviceRequestManageUrl(data, data?.id);
  const responseLabel =
    response?.responseType === "accepted"
      ? "accepted your direct request"
      : response?.responseType === "declined"
        ? "declined your direct request"
        : "expressed interest in your request";
  return {
    subject: `NurseConnectCare update: ${asTrimmedString(response?.nurseDisplayName) || "A nurse"} responded`,
    body: [
      `${asTrimmedString(response?.nurseDisplayName) || "A nurse"} ${responseLabel}.`,
      response?.nurseType ? `Nurse type: ${asTrimmedString(response.nurseType)}` : "",
      response?.note ? `Note: ${asTrimmedString(response.note)}` : "",
      "",
      "Use the management link below to review the request and keep its status current.",
      manageUrl,
    ].filter(Boolean).join("\n"),
  };
}

function buildRequesterStatusNotification(data) {
  const manageUrl = serviceRequestManageUrl(data, data?.id);
  const status = asTrimmedString(data?.status);
  const statusLabel = status === "accepted" ? "accepted" : status === "direct_declined" ? "declined" : status;
  return {
    subject: `NurseConnectCare direct request ${statusLabel}`,
    body: [
      `Your direct request for ${asTrimmedString(data?.serviceTitle) || "a nursing service"} is now marked ${statusLabel}.`,
      "",
      "Use the management link below to confirm whether the request is still open, has been filled, or has been withdrawn.",
      manageUrl,
    ].join("\n"),
  };
}

function buildNurseClosureNotification(data) {
  return {
    subject: `NurseConnectCare request closed: ${asTrimmedString(data?.serviceTitle) || "Service request"}`,
    body: [
      `The requester has marked this service request as ${asTrimmedString(data?.status) === "filled" ? "filled" : "withdrawn"}.`,
      "",
      `Organisation: ${asTrimmedString(data?.organisationName) || "Not recorded"}`,
      `Service: ${asTrimmedString(data?.serviceTitle) || "Not recorded"}`,
      `Location: ${asTrimmedString(data?.suburb) || "Suburb not recorded"} ${asTrimmedString(data?.postcode)}`.trim(),
      "",
      "No further response is needed unless you are already working directly with the requester off-platform.",
    ].join("\n"),
  };
}

function localBootstrapAllowed() {
  const projectId = asTrimmedString(process.env.GCLOUD_PROJECT || process.env.GOOGLE_CLOUD_PROJECT).toLowerCase();
  return process.env.FUNCTIONS_EMULATOR === "true" || projectId.includes("local");
}

async function bootstrapStatusSnapshot() {
  const [systemAdminSnap, anyUserSnap] = await Promise.all([
    admin.firestore().collection("users").where("role", "==", "system_admin").limit(1).get(),
    admin.firestore().collection("users").limit(1).get(),
  ]);
  const hasSystemAdmin = !systemAdminSnap.empty;
  const hasUsers = !anyUserSnap.empty;
  return {
    bootstrapAllowed: localBootstrapAllowed(),
    requiresBootstrap: !hasSystemAdmin,
    hasSystemAdmin,
    hasUsers,
  };
}

function derivePublicNurseProfile(data, uid) {
  if (!data || asTrimmedString(data.role) !== "clinician" || data.active === false || data.publicProfileEnabled !== true) {
    return null;
  }

  const displayName = clinicianDisplayLabel(data.displayName, data.email, uid);
  const designation = asTrimmedString(data.designation);
  const nurseType = asTrimmedString(data.nurseType).toUpperCase();
  const ahpraRegistrationNumber = asTrimmedString(data.ahpraRegistrationNumber).toUpperCase();
  const ahpraVerified = data.ahpraVerified === true;
  const headline = asTrimmedString(data.publicHeadline).slice(0, 160);
  const serviceFocus = asTrimmedString(data.publicServiceFocus).slice(0, 1200);
  const serviceFocusKeywords = sanitizeStringArray(data.publicServiceFocusKeywords, 20, 60);
  const primaryRegion = asTrimmedString(data.publicPrimaryRegion).slice(0, 160);
  const travelRadius = asTrimmedString(data.publicTravelRadius).slice(0, 200);
  const basePostcode = asTrimmedString(data.publicBasePostcode).replace(/[^\d]/g, "").slice(0, 4);
  const baseLatitudeRaw = Number(data.publicBaseLatitude);
  const baseLongitudeRaw = Number(data.publicBaseLongitude);
  const hasBaseCoordinates =
    Number.isFinite(baseLatitudeRaw) &&
    Number.isFinite(baseLongitudeRaw) &&
    baseLatitudeRaw >= -44 &&
    baseLatitudeRaw <= -10 &&
    baseLongitudeRaw >= 112 &&
    baseLongitudeRaw <= 154;
  const servicePostcodes = sanitizeStringArray(data.publicServicePostcodes, 50, 8)
    .map((item) => asTrimmedString(item).replace(/[^\d]/g, "").slice(0, 4))
    .filter((item) => item.length === 4);
  const serviceRadiusKmRaw = Number(data.publicServiceRadiusKm);
  const serviceRadiusKm = Number.isFinite(serviceRadiusKmRaw) && serviceRadiusKmRaw > 0 ? Math.round(serviceRadiusKmRaw) : null;
  const visitTypes = sanitizeStringArray(data.publicVisitTypes, 8, 80);
  const fundingModels = sanitizeStringArray(data.publicFundingModels, 8, 80);
  const responseTime = asTrimmedString(data.publicResponseTime).slice(0, 120);

  if (!displayName || !serviceFocus || !primaryRegion) {
    return null;
  }

  return {
    uid,
    displayName,
    designation: designation || null,
    nurseType: nurseType || null,
    ahpraRegistrationNumber: ahpraRegistrationNumber || null,
    ahpraVerified,
    headline: headline || null,
    serviceFocus,
    serviceFocusKeywords,
    primaryRegion,
    travelRadius: travelRadius || null,
    basePostcode: basePostcode || null,
    baseLatitude: hasBaseCoordinates ? baseLatitudeRaw : null,
    baseLongitude: hasBaseCoordinates ? baseLongitudeRaw : null,
    servicePostcodes,
    serviceRadiusKm,
    visitTypes,
    fundingModels,
    responseTime: responseTime || null,
    updatedAt: serverTimestampDate(),
  };
}

function toPositiveInt(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.floor(n));
}

function dateToDdMmYyyy(date) {
  const dd = `${date.getDate()}`.padStart(2, "0");
  const mm = `${date.getMonth() + 1}`.padStart(2, "0");
  const yyyy = date.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

function dateToHhMm(date) {
  const hh = `${date.getHours()}`.padStart(2, "0");
  const mm = `${date.getMinutes()}`.padStart(2, "0");
  return `${hh}:${mm}`;
}

const WEEKDAY_INDEX = {
  Sun: 0,
  Mon: 1,
  Tue: 2,
  Wed: 3,
  Thu: 4,
  Fri: 5,
  Sat: 6,
};

function minutesFromTimeValue(value) {
  const match = asTrimmedString(value).match(/^([01]\d|2[0-3]):([0-5]\d)$/);
  if (!match) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}

function slotFitsWindow(window, slotStartMinutes, slotEndMinutes) {
  const startMinutes = minutesFromTimeValue(window?.start);
  const endMinutes = minutesFromTimeValue(window?.end);
  if (startMinutes == null || endMinutes == null) return false;

  if (endMinutes > startMinutes) {
    return slotStartMinutes >= startMinutes && slotEndMinutes <= endMinutes;
  }

  const normalizedSlotStart = slotStartMinutes < startMinutes ? slotStartMinutes + 1440 : slotStartMinutes;
  const normalizedSlotEnd = slotEndMinutes <= startMinutes ? slotEndMinutes + 1440 : slotEndMinutes;
  const normalizedWindowEnd = endMinutes + 1440;
  return normalizedSlotStart >= startMinutes && normalizedSlotEnd <= normalizedWindowEnd;
}

function sanitizeWindows(raw) {
  const items = Array.isArray(raw) ? raw : [];
  return items
    .map((item) => ({
      start: asTrimmedString(item?.start),
      end: asTrimmedString(item?.end),
    }))
    .filter((item) => minutesFromTimeValue(item.start) != null && minutesFromTimeValue(item.end) != null && item.start !== item.end);
}

function sanitizeWeekly(raw) {
  const items = Array.isArray(raw) ? raw : [];
  return items
    .map((item) => ({
      dayOfWeek: Number(item?.dayOfWeek),
      enabled: Boolean(item?.enabled),
      windows: sanitizeWindows(item?.windows),
    }))
    .filter((item) => Number.isInteger(item.dayOfWeek) && item.dayOfWeek >= 0 && item.dayOfWeek <= 6);
}

function sanitizeDateBlocks(raw) {
  const items = Array.isArray(raw) ? raw : [];
  return items
    .map((item) => ({
      startDate: asTrimmedString(item?.startDate),
      endDate: asTrimmedString(item?.endDate),
      daysOfWeek: Array.isArray(item?.daysOfWeek)
        ? Array.from(new Set(item.daysOfWeek.map((day) => Number(day)).filter((day) => Number.isInteger(day) && day >= 0 && day <= 6))).sort((a, b) => a - b)
        : [],
      windows: sanitizeWindows(item?.windows),
    }))
    .filter((item) => item.startDate && item.endDate && item.startDate <= item.endDate && item.daysOfWeek.length > 0 && item.windows.length > 0);
}

function zonedDateParts(date, timeZone) {
  const normalizedTimeZone = asTrimmedString(timeZone);
  if (!normalizedTimeZone) {
    return {
      dateInput: `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, "0")}-${`${date.getDate()}`.padStart(2, "0")}`,
      dayOfWeek: date.getDay(),
      startMinutes: date.getHours() * 60 + date.getMinutes(),
    };
  }

  try {
    const formatter = new Intl.DateTimeFormat("en-CA", {
      timeZone: normalizedTimeZone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      weekday: "short",
    });
    const parts = formatter.formatToParts(date);
    const byType = {};
    for (const part of parts) {
      if (part.type !== "literal") byType[part.type] = part.value;
    }
    const year = Number(byType.year);
    const month = Number(byType.month);
    const day = Number(byType.day);
    const hour = Number(byType.hour);
    const minute = Number(byType.minute);
    return {
      dateInput: `${year}-${`${month}`.padStart(2, "0")}-${`${day}`.padStart(2, "0")}`,
      dayOfWeek: WEEKDAY_INDEX[byType.weekday] ?? date.getDay(),
      startMinutes: hour * 60 + minute,
    };
  } catch (error) {
    console.warn("Invalid clinician availability time zone; falling back to server local time.", {
      timeZone: normalizedTimeZone,
      message: error?.message || "Unknown error",
    });
    return {
      dateInput: `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, "0")}-${`${date.getDate()}`.padStart(2, "0")}`,
      dayOfWeek: date.getDay(),
      startMinutes: date.getHours() * 60 + date.getMinutes(),
    };
  }
}

function clinicianAvailabilityAllows(availabilityDoc, at, durationMinutes) {
  if (!availabilityDoc || !at) return false;
  const safeDuration = Math.max(5, toPositiveInt(durationMinutes, 15));
  const zoned = zonedDateParts(at, availabilityDoc.timeZone);
  const slotStartMinutes = zoned.startMinutes;
  const slotEndMinutes = slotStartMinutes + safeDuration;
  const dateInput = zoned.dateInput;
  const dateBlocks = sanitizeDateBlocks(availabilityDoc.dateBlocks);

  if (dateBlocks.length > 0) {
    const applicableBlocks = dateBlocks.filter(
      (block) =>
        dateInput >= block.startDate &&
        dateInput <= block.endDate &&
        block.daysOfWeek.includes(zoned.dayOfWeek)
    );
    return applicableBlocks.some((block) => block.windows.some((window) => slotFitsWindow(window, slotStartMinutes, slotEndMinutes)));
  }

  const weekly = sanitizeWeekly(availabilityDoc.weekly);
  const day = weekly.find((item) => item.dayOfWeek === zoned.dayOfWeek);
  if (!day || !day.enabled || day.windows.length === 0) return false;
  return day.windows.some((window) => slotFitsWindow(window, slotStartMinutes, slotEndMinutes));
}

async function userProfileOrThrow(uid) {
  const snap = await admin.firestore().collection("users").doc(uid).get();
  if (!snap.exists) {
    throw new functions.https.HttpsError("failed-precondition", "User profile not found.");
  }
  return snap.data() || {};
}

async function adminRoleOrThrow(uid) {
  const profile = await userProfileOrThrow(uid);
  const role = asTrimmedString(profile.role);
  if (role !== "system_admin") {
    throw new functions.https.HttpsError("permission-denied", "System admin access is required.");
  }
  return profile;
}

function timestampToDate(value) {
  try {
    if (!value) return null;
    if (typeof value?.toDate === "function") return value.toDate();
    if (typeof value?.seconds === "number") return new Date(value.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

function ageInDays(date) {
  if (!date) return null;
  return Math.floor((Date.now() - date.getTime()) / (24 * 60 * 60 * 1000));
}

async function buildComplianceSnapshot() {
  const db = admin.firestore();
  const configSnap = await db.collection("config").doc("app").get();
  const config = configSnap.exists ? configSnap.data() || {} : {};
  const retentionPolicy = {
    accessAuditDays: toPositiveInt(config?.retentionPolicy?.accessAuditDays, 365) || 365,
    consentEventDays: toPositiveInt(config?.retentionPolicy?.consentEventDays, 2555) || 2555,
    patientSummaryRevisionDays: toPositiveInt(config?.retentionPolicy?.patientSummaryRevisionDays, 365) || 365,
    deidentifiedExportsOnly: config?.retentionPolicy?.deidentifiedExportsOnly !== false,
  };
  const deploymentReadiness = {
    backupsConfigured: config?.deploymentReadiness?.backupsConfigured === true,
    monitoringEnabled: config?.deploymentReadiness?.monitoringEnabled === true,
    restoreRunbookCheckedAt: asTrimmedString(config?.deploymentReadiness?.restoreRunbookCheckedAt),
    incidentContact: asTrimmedString(config?.deploymentReadiness?.incidentContact),
  };

  const [accessSnap, consentSnap] = await Promise.all([
    db.collection("accessAuditLogs").orderBy("occurredAt", "desc").limit(200).get(),
    db.collectionGroup("events").orderBy("occurredAt", "desc").limit(200).get(),
  ]);

  const accessRows = accessSnap.docs.map((doc) => ({ id: doc.id, ...(doc.data() || {}) }));
  const consentRows = consentSnap.docs
    .map((doc) => ({ id: doc.id, ...(doc.data() || {}) }))
    .filter((row) => ["signed", "withdrawn", "updated"].includes(asTrimmedString(row.type)));

  const staleAccessAuditRows = accessRows.filter((row) => {
    const age = ageInDays(timestampToDate(row.occurredAt));
    return age != null && age > retentionPolicy.accessAuditDays;
  }).length;

  const staleConsentEventRows = consentRows.filter((row) => {
    const age = ageInDays(timestampToDate(row.occurredAt));
    return age != null && age > retentionPolicy.consentEventDays;
  }).length;

  const warnings = [];
  if (!deploymentReadiness.backupsConfigured) warnings.push("Backups are not confirmed in config/app.");
  if (!deploymentReadiness.monitoringEnabled) warnings.push("Monitoring is not confirmed in config/app.");
  if (!deploymentReadiness.restoreRunbookCheckedAt) warnings.push("Restore runbook review date is missing.");
  if (!deploymentReadiness.incidentContact) warnings.push("Incident contact is missing.");
  if (staleAccessAuditRows > 0) warnings.push(`Sampled access audit rows older than retention: ${staleAccessAuditRows}.`);
  if (staleConsentEventRows > 0) warnings.push(`Sampled consent events older than retention: ${staleConsentEventRows}.`);

  return {
    generatedAt: admin.firestore.FieldValue.serverTimestamp(),
    retentionPolicy,
    deploymentReadiness,
    findings: {
      staleAccessAuditRows,
      staleConsentEventRows,
      sampledAccessAuditRows: accessRows.length,
      sampledConsentEventRows: consentRows.length,
    },
    warnings,
  };
}

async function buildRetentionDryRunSnapshot() {
  const db = admin.firestore();
  const configSnap = await db.collection("config").doc("app").get();
  const config = configSnap.exists ? configSnap.data() || {} : {};
  const retentionPolicy = {
    accessAuditDays: toPositiveInt(config?.retentionPolicy?.accessAuditDays, 365) || 365,
    consentEventDays: toPositiveInt(config?.retentionPolicy?.consentEventDays, 2555) || 2555,
    patientSummaryRevisionDays: toPositiveInt(config?.retentionPolicy?.patientSummaryRevisionDays, 365) || 365,
  };

  const [accessSnap, consentSnap, summaryRevisionSnap] = await Promise.all([
    db.collection("accessAuditLogs").orderBy("occurredAt", "desc").limit(500).get(),
    db.collectionGroup("events").orderBy("occurredAt", "desc").limit(500).get(),
    db.collectionGroup("revisions").orderBy("editedAt", "desc").limit(500).get(),
  ]);

  const accessCandidates = accessSnap.docs
    .map((doc) => ({ id: doc.id, ...doc.data() }))
    .filter((row) => {
      const age = ageInDays(timestampToDate(row.occurredAt));
      return age != null && age > retentionPolicy.accessAuditDays;
    })
    .slice(0, 50);

  const consentCandidates = consentSnap.docs
    .map((doc) => ({ id: doc.id, path: doc.ref.path, ...doc.data() }))
    .filter((row) => ["signed", "withdrawn", "updated"].includes(asTrimmedString(row.type)))
    .filter((row) => {
      const age = ageInDays(timestampToDate(row.occurredAt));
      return age != null && age > retentionPolicy.consentEventDays;
    })
    .slice(0, 50);

  const patientSummaryRevisionCandidates = summaryRevisionSnap.docs
    .map((doc) => ({ id: doc.id, path: doc.ref.path, ...doc.data() }))
    .filter((row) => asTrimmedString(row.path).startsWith("patientSummaries/"))
    .filter((row) => {
      const age = ageInDays(timestampToDate(row.editedAt));
      return age != null && age > retentionPolicy.patientSummaryRevisionDays;
    })
    .slice(0, 50);

  return {
    generatedAt: admin.firestore.FieldValue.serverTimestamp(),
    retentionPolicy,
    counts: {
      accessAuditLogs: accessCandidates.length,
      consentEvents: consentCandidates.length,
      patientSummaryRevisions: patientSummaryRevisionCandidates.length,
    },
    candidates: {
      accessAuditLogs: accessCandidates,
      consentEvents: consentCandidates,
      patientSummaryRevisions: patientSummaryRevisionCandidates,
    },
  };
}

function normalizeCallableError(error, fallbackMessage) {
  if (error instanceof functions.https.HttpsError) return error;
  const message = asTrimmedString(error?.message || "");
  if (/index/i.test(message) || /failed-precondition/i.test(asTrimmedString(error?.code || ""))) {
    return new functions.https.HttpsError(
      "failed-precondition",
      "Appointment booking requires a Firestore index or supporting live data is incomplete. Deploy functions, firestore rules, and firestore indexes to the live project, then try again."
    );
  }
  if (/time.?zone/i.test(message) || /invalid time zone/i.test(message)) {
    return new functions.https.HttpsError(
      "failed-precondition",
      "The selected clinician has an invalid booking time zone configured. Update the clinician roster time zone and try again."
    );
  }
  if (message) {
    return new functions.https.HttpsError("internal", `${fallbackMessage} ${message}`);
  }
  return new functions.https.HttpsError("internal", fallbackMessage);
}

function normalizePhone(input) {
  const raw = (input || "").toString().trim();
  if (!raw) return "";
  const keepPlus = raw.startsWith("+");
  const digits = raw.replace(/[^\d]/g, "");
  if (!digits) return "";
  return keepPlus ? `+${digits}` : digits;
}

function validateMessageInput(number, message) {
  if (!number || !message) {
    throw new functions.https.HttpsError("invalid-argument", "Both 'number' and 'message' are required.");
  }
  if (message.length > 1000) {
    throw new functions.https.HttpsError("invalid-argument", "Message is too long.");
  }
  const digitCount = number.replace(/[^\d]/g, "").length;
  if (digitCount < 8 || digitCount > 20) {
    throw new functions.https.HttpsError("invalid-argument", "Phone number is invalid.");
  }
}

async function writeWhatsAppStatus(appointmentId, payload) {
  const id = (appointmentId || "").toString().trim();
  if (!id) return;
  const ref = admin.firestore().collection("appointments").doc(id);
  await ref.set(
    {
      whatsapp: {
        ...payload,
        updatedAt: serverTimestampDate(),
      },
    },
    { merge: true }
  );
}

function normalizeWhatsAppFrom(input) {
  return normalizePhone((input || "").toString().replace(/^whatsapp:/i, ""));
}

function asFirestoreDate(value) {
  return value instanceof Date ? value : new Date(value);
}

function serverTimestampDate() {
  return new Date();
}

function sanitizePlainText(value, maxLength) {
  const normalized = asTrimmedString(value).replace(/\s+/g, " ").trim();
  return normalized.slice(0, Math.max(0, maxLength || normalized.length));
}

function readRequestField(req, key) {
  if (req?.body && typeof req.body === "object" && req.body !== null && key in req.body) return req.body[key];
  if (typeof req?.rawBody === "string") {
    const params = new URLSearchParams(req.rawBody);
    return params.get(key);
  }
  return req?.query?.[key] ?? null;
}

function formatQuestionMessage(question, progress) {
  const lines = [];
  lines.push("EIRENIX Care™ symptom intake");
  if (progress) lines.push(`Question ${Math.min(progress.answered + 1, progress.totalEstimated)} of ${progress.totalEstimated}`);
  lines.push(question.text);
  if (question.inputType === "yes_no") {
    lines.push("Reply: YES or NO");
  } else if (Array.isArray(question.options) && question.options.length > 0) {
    lines.push("Reply with one option:");
    question.options.forEach((option, index) => {
      lines.push(`${index + 1}. ${option.label}`);
    });
  } else {
    lines.push("Reply with your answer in your own words.");
  }
  lines.push("Commands: STOP, RESUME, CALL ME");
  return lines.join("\n");
}

exports.submitPublicContactEnquiry = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data) => {
    try {
      const fullName = sanitizePlainText(data?.fullName, 120);
      const email = sanitizePlainText(data?.email, 160).toLowerCase();
      const enquiryType = sanitizePlainText(data?.enquiryType, 80);
      const message = sanitizePlainText(data?.message, 4000);

      if (!fullName) throw new functions.https.HttpsError("invalid-argument", "Please provide your full name.");
      if (!looksLikeEmail(email)) throw new functions.https.HttpsError("invalid-argument", "Please provide a valid email address.");
      if (!["Patient or carer enquiry", "Nurse registration enquiry", "General support"].includes(enquiryType)) {
        throw new functions.https.HttpsError("invalid-argument", "Please select a valid enquiry type.");
      }
      if (message.length < 10) {
        throw new functions.https.HttpsError("invalid-argument", "Please provide a little more detail in your message.");
      }

      const ref = await admin.firestore().collection("publicContactEnquiries").add({
        fullName,
        email,
        enquiryType,
        message,
        status: "new",
        source: "public_contact_form",
        createdAt: serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      });

      return { success: true, enquiryId: ref.id };
    } catch (error) {
      throw normalizeCallableError(error, "Contact enquiry submission failed.");
    }
  });

exports.getBootstrapStatus = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async () => {
    try {
      return await bootstrapStatusSnapshot();
    } catch (error) {
      throw normalizeCallableError(error, "Bootstrap status check failed.");
    }
  });

exports.bootstrapInitialSystemAdmin = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data) => {
    try {
      const status = await bootstrapStatusSnapshot();
      if (!status.bootstrapAllowed) {
        throw new functions.https.HttpsError("permission-denied", "Bootstrap is only available in local emulator environments.");
      }
      if (status.hasSystemAdmin) {
        throw new functions.https.HttpsError("failed-precondition", "A system admin already exists.");
      }

      const email = sanitizePlainText(data?.email, 160).toLowerCase();
      const password = asTrimmedString(data?.password);
      const displayName = sanitizePlainText(data?.displayName, 120) || "System Admin";

      if (!looksLikeEmail(email)) {
        throw new functions.https.HttpsError("invalid-argument", "Please provide a valid email address.");
      }
      if (password.length < 8) {
        throw new functions.https.HttpsError("invalid-argument", "Password must be at least 8 characters long.");
      }

      let userRecord;
      try {
        userRecord = await admin.auth().createUser({
          email,
          password,
          displayName,
        });
      } catch (error) {
        throw normalizeCallableError(error, "Could not create the bootstrap admin account.");
      }

      await admin.firestore().collection("users").doc(userRecord.uid).set({
        uid: userRecord.uid,
        email,
        role: "system_admin",
        active: true,
        displayName,
        createdAt: serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      }, { merge: true });

      return {
        success: true,
        uid: userRecord.uid,
        email,
      };
    } catch (error) {
      throw normalizeCallableError(error, "Bootstrap setup failed.");
    }
  });

exports.submitNurseRegistrationInterest = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data) => {
    try {
      const fullName = sanitizePlainText(data?.fullName, 120);
      const email = sanitizePlainText(data?.email, 160).toLowerCase();
      const primaryRegion = sanitizePlainText(data?.primaryRegion, 160);
      const professionalRole = sanitizePlainText(data?.professionalRole, 80);
      const nurseType = sanitizePlainText(data?.nurseType, 12).toUpperCase();
      const ahpraRegistrationNumber = sanitizePlainText(data?.ahpraRegistrationNumber, 32).toUpperCase();
      const travelRadius = sanitizePlainText(data?.travelRadius, 120);
      const visitTypes = Array.isArray(data?.visitTypes)
        ? data.visitTypes.map((item) => sanitizePlainText(item, 80)).filter(Boolean).slice(0, 6)
        : [];
      const fundingModels = Array.isArray(data?.fundingModels)
        ? data.fundingModels.map((item) => sanitizePlainText(item, 80)).filter(Boolean).slice(0, 6)
        : [];
      const serviceFocus = sanitizePlainText(data?.serviceFocus, 4000);

      if (!fullName) throw new functions.https.HttpsError("invalid-argument", "Please provide your full name.");
      if (!looksLikeEmail(email)) throw new functions.https.HttpsError("invalid-argument", "Please provide a valid email address.");
      if (!primaryRegion) throw new functions.https.HttpsError("invalid-argument", "Please provide your primary service region.");
      if (!["Registered nurse", "Enrolled nurse", "Nurse practitioner"].includes(professionalRole)) {
        throw new functions.https.HttpsError("invalid-argument", "Please select a valid professional role.");
      }
      if (!["RN", "EN", "NP"].includes(nurseType)) {
        throw new functions.https.HttpsError("invalid-argument", "Please select a valid nurse type.");
      }
      if (!ahpraRegistrationNumber || ahpraRegistrationNumber.length < 6) {
        throw new functions.https.HttpsError("invalid-argument", "Please provide your AHPRA registration number.");
      }
      if (!travelRadius) {
        throw new functions.https.HttpsError("invalid-argument", "Please provide your travel radius or service coverage.");
      }
      if (visitTypes.length === 0) {
        throw new functions.https.HttpsError("invalid-argument", "Please select at least one visit type.");
      }
      if (fundingModels.length === 0) {
        throw new functions.https.HttpsError("invalid-argument", "Please select at least one funding pathway.");
      }
      if (serviceFocus.length < 10) {
        throw new functions.https.HttpsError("invalid-argument", "Please provide a short description of your service focus.");
      }

      const ref = await admin.firestore().collection("nurseRegistrationInterests").add({
        fullName,
        email,
        primaryRegion,
        professionalRole,
        nurseType,
        ahpraRegistrationNumber,
        travelRadius,
        visitTypes,
        fundingModels,
        serviceFocus,
        status: "new",
        source: "public_nurse_registration_form",
        createdAt: serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      });

      return { success: true, registrationInterestId: ref.id };
    } catch (error) {
      throw normalizeCallableError(error, "Nurse registration submission failed.");
    }
  });

exports.syncPublicNurseProfile = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .firestore.document("users/{uid}")
  .onWrite(async (change, context) => {
    const uid = context.params.uid;
    const publicRef = admin.firestore().collection("publicNurseProfiles").doc(uid);

    if (!change.after.exists) {
      await publicRef.delete().catch(() => {});
      return null;
    }

    const nextData = change.after.data() || {};
    const publicProfile = derivePublicNurseProfile(nextData, uid);

    if (!publicProfile) {
      await publicRef.delete().catch(() => {});
      return null;
    }

    await publicRef.set(publicProfile, { merge: true });
    return null;
  });

exports.notifyOnServiceRequestWrite = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .firestore.document("serviceRequests/{requestId}")
  .onWrite(async (change, context) => {
    const requestId = context.params.requestId;
    if (!change.after.exists) return null;

    const before = change.before.exists ? { id: requestId, ...(change.before.data() || {}) } : null;
    const after = { id: requestId, ...(change.after.data() || {}) };
    const tasks = [];
    const requesterEmail = asTrimmedString(after.requesterEmail).toLowerCase();

    if (!before) {
      if (looksLikeEmail(requesterEmail)) {
        const notification = buildRequesterSubmissionNotification(requestId, after);
        tasks.push(
          queueServiceRequestNotification({
            notificationId: `${requestId}_requester_created`,
            requestId,
            eventType: "request_created",
            recipientEmail: requesterEmail,
            recipientPhone: normalizePhone(after.requesterPhone),
            recipientRole: "requester",
            subject: notification.subject,
            body: notification.body,
            metadata: { requestType: asTrimmedString(after.requestType), status: asTrimmedString(after.status) },
          })
        );
      }

      if (asTrimmedString(after.requestType) === "direct_request" && asTrimmedString(after.targetNurseUid)) {
        const nurseSnap = await admin.firestore().collection("users").doc(asTrimmedString(after.targetNurseUid)).get();
        const nurse = nurseSnap.exists ? nurseSnap.data() || {} : {};
        const nurseEmail = asTrimmedString(nurse.email).toLowerCase();
        if (looksLikeEmail(nurseEmail)) {
          const notification = buildDirectRequestNotification(requestId, after, clinicianDisplayLabel(nurse.displayName, nurse.email, nurseSnap.id));
          tasks.push(
            queueServiceRequestNotification({
              notificationId: `${requestId}_direct_nurse_created`,
              requestId,
              eventType: "direct_request_created",
              recipientEmail: nurseEmail,
              recipientRole: "nurse",
              subject: notification.subject,
              body: notification.body,
              metadata: { targetNurseUid: nurseSnap.id },
            })
          );
        }
      }
    }

    const beforeResponses = Array.isArray(before?.responses) ? before.responses : [];
    const afterResponses = Array.isArray(after.responses) ? after.responses : [];
    const previousResponseKeys = new Set(
      beforeResponses.map((item) => `${asTrimmedString(item?.nurseUid)}_${asTrimmedString(item?.respondedAt)}`)
    );
    const newResponses = afterResponses.filter(
      (item) => !previousResponseKeys.has(`${asTrimmedString(item?.nurseUid)}_${asTrimmedString(item?.respondedAt)}`)
    );

    if (looksLikeEmail(requesterEmail)) {
      for (const response of newResponses) {
        const notification = buildRequesterResponseNotification(after, response);
        tasks.push(
          queueServiceRequestNotification({
            notificationId: `${requestId}_response_${toSlug(`${response.nurseUid}_${response.respondedAt}`, "response")}`,
            requestId,
            eventType: "nurse_response",
            recipientEmail: requesterEmail,
            recipientPhone: normalizePhone(after.requesterPhone),
            recipientRole: "requester",
            subject: notification.subject,
            body: notification.body,
            metadata: {
              nurseUid: asTrimmedString(response?.nurseUid),
              responseType: asTrimmedString(response?.responseType),
            },
          })
        );
      }
    }

    const beforeStatus = asTrimmedString(before?.status);
    const afterStatus = asTrimmedString(after.status);
    if (looksLikeEmail(requesterEmail) && beforeStatus !== afterStatus && ["accepted", "direct_declined"].includes(afterStatus)) {
      const notification = buildRequesterStatusNotification(after);
      tasks.push(
        queueServiceRequestNotification({
          notificationId: `${requestId}_requester_status_${afterStatus}`,
          requestId,
          eventType: "direct_request_status_changed",
          recipientEmail: requesterEmail,
          recipientPhone: normalizePhone(after.requesterPhone),
          recipientRole: "requester",
          subject: notification.subject,
          body: notification.body,
          metadata: { status: afterStatus },
        })
      );
    }

    if (beforeStatus !== afterStatus && ["filled", "withdrawn"].includes(afterStatus)) {
      const nurseRecipients = new Map();
      if (asTrimmedString(after.targetNurseUid)) {
        const nurseSnap = await admin.firestore().collection("users").doc(asTrimmedString(after.targetNurseUid)).get();
        const nurse = nurseSnap.exists ? nurseSnap.data() || {} : {};
        const nurseEmail = asTrimmedString(nurse.email).toLowerCase();
        if (looksLikeEmail(nurseEmail)) nurseRecipients.set(nurseSnap.id, nurseEmail);
      }
      for (const response of afterResponses) {
        const nurseUid = asTrimmedString(response?.nurseUid);
        const nurseEmail = asTrimmedString(response?.nurseEmail).toLowerCase();
        if (nurseUid && looksLikeEmail(nurseEmail)) {
          nurseRecipients.set(nurseUid, nurseEmail);
        }
      }
      const notification = buildNurseClosureNotification(after);
      for (const [nurseUid, nurseEmail] of nurseRecipients.entries()) {
        tasks.push(
          queueServiceRequestNotification({
            notificationId: `${requestId}_closure_${afterStatus}_${toSlug(nurseUid, "nurse")}`,
            requestId,
            eventType: "request_closed",
            recipientEmail: nurseEmail,
            recipientRole: "nurse",
            subject: notification.subject,
            body: notification.body,
            metadata: { status: afterStatus, nurseUid },
          })
        );
      }
    }

    await Promise.all(tasks);
    return null;
  });

function mapIncomingAnswer(question, rawBody) {
  const body = (rawBody || "").toString().trim();
  const upper = body.toUpperCase();
  if (question.inputType === "yes_no") {
    if (["YES", "Y", "1"].includes(upper)) return "yes";
    if (["NO", "N", "2"].includes(upper)) return "no";
  }
  if (Array.isArray(question.options) && question.options.length > 0) {
    const asNumber = Number(body);
    if (Number.isInteger(asNumber) && asNumber >= 1 && asNumber <= question.options.length) {
      return question.options[asNumber - 1].value;
    }
    const direct = question.options.find((option) => option.value.toLowerCase() === body.toLowerCase() || option.label.toLowerCase() === body.toLowerCase());
    if (direct) return direct.value;
  }
  return body;
}

async function sendWhatsAppMessageInternal({ number, message, appointmentId = "", triggeredBy = null }) {
  validateMessageInput(number, message);
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const fromRaw = process.env.TWILIO_WHATSAPP_FROM || process.env.TWILIO_FROM_NUMBER;
  const from = fromRaw
    ? fromRaw.startsWith("whatsapp:")
      ? fromRaw
      : `whatsapp:${normalizePhone(fromRaw)}`
    : "";
  const to = `whatsapp:${number}`;

  if (!sid || !token || !from) {
    console.log("[sendWhatsApp] Stub mode (missing TWILIO env). Would send:", {
      triggeredBy,
      to,
      from,
      bodyLength: message.length,
    });
    await writeWhatsAppStatus(appointmentId, {
      status: "stub",
      sid: null,
      to,
      from,
      messagePreview: message.slice(0, 140),
      triggeredBy: triggeredBy || null,
    });
    return { success: true, stub: true };
  }

  const twilio = require("twilio");
  const client = twilio(sid, token);
  const res = await client.messages.create({
    body: message,
    to,
    from,
  });
  await writeWhatsAppStatus(appointmentId, {
    status: res.status || "queued",
    sid: res.sid,
    to,
    from,
    messagePreview: message.slice(0, 140),
    triggeredBy: triggeredBy || null,
  });
  return { success: true, sid: res.sid, status: res.status || "queued" };
}

async function resolvePatientWhatsAppNumber(uid, appointmentId) {
  const userProfile = await userProfileOrThrow(uid);
  const patientId = asTrimmedString(userProfile.patientId) || uid;
  const patientSnap = await admin.firestore().collection("patients").doc(patientId).get();
  const patient = patientSnap.exists ? patientSnap.data() || {} : {};
  const appointmentSnap = await admin.firestore().collection("appointments").doc(asTrimmedString(appointmentId)).get();
  const appointment = appointmentSnap.exists ? appointmentSnap.data() || {} : {};
  const number =
    normalizePhone(userProfile.phoneNumber) ||
    normalizePhone(patient.phoneNumber) ||
    normalizePhone(patient.phone) ||
    normalizePhone(appointment.patientPhone);
  if (!number) {
    throw new functions.https.HttpsError("failed-precondition", "No WhatsApp-compatible phone number is available for this patient.");
  }
  return number;
}

async function createManualCallbackTask(session, note) {
  if (!session?.practiceId) return null;
  const ref = await admin.firestore().collection("practiceTasks").add({
    practiceId: session.practiceId,
    type: "triage_callback",
    priority: "high",
    status: "open",
    triageSessionId: session.id,
    appointmentId: session.appointmentId || null,
    patientId: session.patientId,
    clinicianId: session.clinicianId || null,
    summary: note,
    dueAt: asFirestoreDate(Date.now() + 30 * 60 * 1000),
    assignedToUid: null,
    createdAt: serverTimestampDate(),
    updatedAt: serverTimestampDate(),
  });
  return ref.id;
}

/**
 * Local/dev-safe Twilio SMS callable.
 *
 * IMPORTANT:
 * - Do NOT hardcode credentials in source control.
 * - For local emulator usage, set environment variables:
 *     TWILIO_ACCOUNT_SID
 *     TWILIO_AUTH_TOKEN
 *     TWILIO_FROM_NUMBER
 *
 * If not set, this function will behave as a stub and return success without sending.
 */
exports.sendSMS = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
  if (!context?.auth?.uid) {
    throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
  }

  const number = normalizePhone(data?.number);
  const message = (data?.message || "").toString();

  validateMessageInput(number, message);

  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM_NUMBER;

  // Dev/emulator stub mode
  if (!sid || !token || !from) {
    console.log("[sendSMS] Stub mode (missing TWILIO env). Would send:", {
      uid: context.auth.uid,
      to: number,
      from,
      bodyLength: message.length,
    });
    return { success: true, stub: true };
  }

  const twilio = require("twilio");
  const client = twilio(sid, token);

  try {
    const res = await client.messages.create({
      body: message,
      to: number,
      from,
    });
    return { success: true, sid: res.sid };
  } catch (error) {
    console.error("SMS send error:", {
      uid: context.auth.uid,
      message: error?.message || "Unknown error",
      code: error?.code || null,
    });
    throw new functions.https.HttpsError("internal", "SMS failed");
  }
});

exports.sendWhatsApp = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    if (!context?.auth?.uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }

    const number = normalizePhone(data?.number);
    const message = (data?.message || "").toString();
    const appointmentId = (data?.appointmentId || "").toString().trim();
    validateMessageInput(number, message);

    try {
      return await sendWhatsAppMessageInternal({
        number,
        message,
        appointmentId,
        triggeredBy: context.auth.uid,
      });
    } catch (error) {
      console.error("WhatsApp send error:", {
        uid: context.auth.uid,
        message: error?.message || "Unknown error",
        code: error?.code || null,
      });
      await writeWhatsAppStatus(appointmentId, {
        status: "failed",
        sid: null,
        to,
        from,
        error: error?.message || "Unknown error",
        triggeredBy: context.auth.uid,
      });
      throw new functions.https.HttpsError("internal", "WhatsApp send failed");
    }
  });

exports.startWhatsAppTriage = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }
    const appointmentId = asTrimmedString(data?.appointmentId);
    if (!appointmentId) {
      throw new functions.https.HttpsError("invalid-argument", "Appointment ID is required.");
    }
    const number = await resolvePatientWhatsAppNumber(uid, appointmentId);
    const started = await startSession({
      uid,
      appointmentId,
      channel: "whatsapp",
      whatsappNumber: number,
    });
    if (started.question) {
      await sendWhatsAppMessageInternal({
        number,
        message: formatQuestionMessage(started.question, started.progress),
        appointmentId,
        triggeredBy: uid,
      });
    } else if (started.outcome?.patientMessage) {
      await sendWhatsAppMessageInternal({
        number,
        message: started.outcome.patientMessage,
        appointmentId,
        triggeredBy: uid,
      });
    }
    return {
      success: true,
      triageSessionId: started.triageSessionId,
      number,
      status: started.status,
    };
  });

exports.refreshWhatsAppStatus = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    if (!context?.auth?.uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }

    const sidValue = (data?.sid || "").toString().trim();
    const appointmentId = (data?.appointmentId || "").toString().trim();
    if (!sidValue) {
      throw new functions.https.HttpsError("invalid-argument", "'sid' is required.");
    }

    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    if (!sid || !token) {
      throw new functions.https.HttpsError(
        "failed-precondition",
        "Twilio credentials are not configured."
      );
    }

    const twilio = require("twilio");
    const client = twilio(sid, token);

    try {
      const message = await client.messages(sidValue).fetch();
      await writeWhatsAppStatus(appointmentId, {
        status: message.status || "unknown",
        sid: message.sid || sidValue,
        to: message.to || "",
        from: message.from || "",
        error: message.errorMessage || null,
        refreshedBy: context.auth.uid,
      });
      return {
        success: true,
        status: message.status || "unknown",
        sid: message.sid || sidValue,
      };
    } catch (error) {
      console.error("WhatsApp refresh status error:", {
        uid: context.auth.uid,
        sid: sidValue,
        message: error?.message || "Unknown error",
        code: error?.code || null,
      });
      throw new functions.https.HttpsError("internal", "WhatsApp status refresh failed");
    }
  });

exports.requestPatientAppointment = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    try {
      const uid = context?.auth?.uid;
      if (!uid) {
        throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
      }

      const userProfile = await userProfileOrThrow(uid);
      if (asTrimmedString(userProfile.role) !== "patient") {
        throw new functions.https.HttpsError("permission-denied", "Only patient users can book via the patient portal.");
      }

      const patientId = asTrimmedString(userProfile.patientId) || uid;
      const clinicianId = asTrimmedString(data?.clinicianId);
      const mode = asTrimmedString(data?.mode) || "video";
      const reason = asTrimmedString(data?.reason) || null;
      const scheduledAtRaw = data?.scheduledAt;
      const durationMinutes = Math.min(240, Math.max(5, toPositiveInt(data?.durationMinutes, 30)));
      const telehealthGraceMinutesOverride =
        mode === "video" && data?.telehealthGraceMinutesOverride !== undefined && data?.telehealthGraceMinutesOverride !== null
          ? Math.min(240, toPositiveInt(data?.telehealthGraceMinutesOverride, 0))
          : null;

      if (!clinicianId) {
        throw new functions.https.HttpsError("invalid-argument", "A clinician is required.");
      }
      if (!["video", "phone", "in_person"].includes(mode)) {
        throw new functions.https.HttpsError("invalid-argument", "Appointment mode is invalid.");
      }
      if (reason && reason.length > 500) {
        throw new functions.https.HttpsError("invalid-argument", "Reason is too long.");
      }

      const scheduledAtDate = new Date(scheduledAtRaw);
      if (!scheduledAtRaw || Number.isNaN(scheduledAtDate.getTime())) {
        throw new functions.https.HttpsError("invalid-argument", "A valid scheduled date/time is required.");
      }
      if (scheduledAtDate.getTime() < Date.now() - 60 * 1000) {
        throw new functions.https.HttpsError("invalid-argument", "Appointments cannot be booked in the past.");
      }

      const patientSnap = await admin.firestore().collection("patients").doc(patientId).get();
      if (!patientSnap.exists) {
        throw new functions.https.HttpsError("failed-precondition", "Linked patient record not found.");
      }
      const patient = patientSnap.data() || {};

      const availabilitySnap = await admin.firestore().collection("clinicianAvailability").doc(clinicianId).get();
      if (!availabilitySnap.exists) {
        throw new functions.https.HttpsError("failed-precondition", "This clinician is not currently available for portal booking.");
      }
      const availability = availabilitySnap.data() || {};

      if (!clinicianAvailabilityAllows(availability, scheduledAtDate, durationMinutes)) {
        throw new functions.https.HttpsError("failed-precondition", "The selected time is outside this clinician's booking availability.");
      }

      const dayStart = new Date(scheduledAtDate);
      dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(dayStart);
      dayEnd.setDate(dayEnd.getDate() + 1);

      const sameDaySnap = await admin
        .firestore()
        .collection("appointments")
        .where("clinicianId", "==", clinicianId)
        .where("scheduledAt", ">=", asFirestoreDate(dayStart))
        .where("scheduledAt", "<", asFirestoreDate(dayEnd))
        .get();

      const proposedStartMs = scheduledAtDate.getTime();
      const proposedEndMs = proposedStartMs + durationMinutes * 60 * 1000;
      for (const row of sameDaySnap.docs) {
        const existing = row.data() || {};
        if (asTrimmedString(existing.status) === "cancelled") continue;
        const existingDate =
          typeof existing.scheduledAt?.toDate === "function"
            ? existing.scheduledAt.toDate()
            : null;
        if (!existingDate) continue;
        const existingStartMs = existingDate.getTime();
        const existingDuration = Math.min(240, Math.max(5, toPositiveInt(existing.durationMinutes, 15)));
        const existingEndMs = existingStartMs + existingDuration * 60 * 1000;
        if (proposedStartMs < existingEndMs && proposedEndMs > existingStartMs) {
          throw new functions.https.HttpsError("already-exists", "That time is no longer available.");
        }
      }

      const clinicianName = clinicianDisplayLabel(
        availability.clinicianName,
        availability.clinicianEmail,
        clinicianId
      );

      const patientName = asTrimmedString(patient.fullName) || "Patient";
      const patientEmail = asTrimmedString(patient.email) || asTrimmedString(context?.auth?.token?.email) || null;
      const scheduledAt = asFirestoreDate(scheduledAtDate);

      const docRef = await admin.firestore().collection("appointments").add({
        patientId,
        patientUserId: uid,
        patientName,
        patientEmail,
        practiceId: asTrimmedString(availability.practiceId) || asTrimmedString(userProfile.practiceId) || null,
        clinicianId,
        clinicianName,
        scheduledAt,
        durationMinutes,
        telehealthGraceMinutesOverride,
        paymentMethod: null,
        paymentStatus: "unpaid",
        paidAt: null,
        date: dateToDdMmYyyy(scheduledAtDate),
        time: dateToHhMm(scheduledAtDate),
        mode,
        status: "scheduled",
        reason,
        consultationNotes: null,
        createdBy: uid,
        updatedBy: uid,
        source: "patient_portal",
        createdAt: serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      });

      return {
        success: true,
        appointmentId: docRef.id,
      };
    } catch (error) {
      console.error("requestPatientAppointment failed:", {
        uid: context?.auth?.uid || null,
        clinicianId: asTrimmedString(data?.clinicianId),
        mode: asTrimmedString(data?.mode),
        message: error?.message || "Unknown error",
        code: error?.code || null,
        stack: error?.stack || null,
      });
      throw normalizeCallableError(error, "Appointment booking failed.");
    }
  });

exports.startTriageSession = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }
    return startSession({
      uid,
      appointmentId: asTrimmedString(data?.appointmentId),
      channel: asTrimmedString(data?.channel) || "portal",
    });
  });

exports.submitTriageAnswer = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }
    return submitAnswer({
      uid,
      triageSessionId: asTrimmedString(data?.triageSessionId),
      questionId: asTrimmedString(data?.questionId),
      value: data?.value ?? null,
    });
  });

exports.finalizeTriageSession = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }
    const ref = admin.firestore().collection("triageSessions").doc(asTrimmedString(data?.triageSessionId));
    const snap = await ref.get();
    if (!snap.exists) {
      throw new functions.https.HttpsError("not-found", "Triage session not found.");
    }
    const session = { id: snap.id, ...(snap.data() || {}) };
    if (asTrimmedString(session.patientUserId) !== uid) {
      throw new functions.https.HttpsError("permission-denied", "You can only finalize your own triage session.");
    }
    return finalizeSession(ref, session);
  });

exports.reviewTriageDecision = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }
    return reviewSessionDecision({
      uid,
      triageSessionId: asTrimmedString(data?.triageSessionId),
      urgencyTier: asTrimmedString(data?.urgencyTier),
      reviewNotes: asTrimmedString(data?.reviewNotes),
    });
  });

exports.activateDemoSubscription = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }
    if (!demoBillingEnabled()) {
      throw new functions.https.HttpsError(
        "failed-precondition",
        "Demo billing mode is not enabled."
      );
    }

    const userRef = admin.firestore().collection("users").doc(uid);
    const snap = await userRef.get();
    if (!snap.exists) {
      throw new functions.https.HttpsError("not-found", "User profile not found.");
    }
    const profile = snap.data() || {};
    if (asTrimmedString(profile.role) !== "clinician") {
      throw new functions.https.HttpsError("permission-denied", "Only nurse accounts can activate a subscription.");
    }

    const billingCycle = asTrimmedString(data?.subscriptionBillingCycle || profile.subscriptionBillingCycle || "monthly");
    const paymentMethod = asTrimmedString(data?.subscriptionPaymentMethod || profile.subscriptionPaymentMethod || "card");
    const pricing = subscriptionPricing(clinicianBaseMonthlyFeeCents(profile.nurseType), billingCycle);
    const trialEndsAtRaw = profile.subscriptionTrialEndsAt?.toDate?.() || profile.subscriptionTrialEndsAt || null;
    const trialEndsAt = trialEndsAtRaw ? new Date(trialEndsAtRaw) : addDays(new Date(), SUBSCRIPTION_TRIAL_DAYS);
    const now = new Date();
    const trialStillActive = !Number.isNaN(trialEndsAt.getTime()) && trialEndsAt.getTime() > now.getTime();

    await userRef.set(
      {
        subscriptionBillingCycle: billingCycle,
        subscriptionPaymentMethod: paymentMethod,
        subscriptionDiscountPercent: pricing.discountPercent,
        subscriptionCurrentPriceCents: pricing.discountedCents,
        subscriptionStatus: trialStillActive ? "trial_active" : "active",
        subscriptionGateway: "demo",
        subscriptionGatewayMode: "placeholder",
        subscriptionActivatedAt: serverTimestampDate(),
        subscriptionNextBillingAt: trialStillActive ? trialEndsAt : serverTimestampDate(),
        updatedAt: serverTimestampDate(),
      },
      { merge: true }
    );

    return {
      ok: true,
      subscriptionStatus: trialStillActive ? "trial_active" : "active",
      subscriptionGateway: "demo",
      subscriptionGatewayMode: "placeholder",
      discountPercent: pricing.discountPercent,
      currentPriceCents: pricing.discountedCents,
    };
  });

exports.createStripeCheckoutSession = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError("unauthenticated", "Authentication is required.");
    }

    const userRef = admin.firestore().collection("users").doc(uid);
    const snap = await userRef.get();
    if (!snap.exists) {
      throw new functions.https.HttpsError("not-found", "User profile not found.");
    }

    const profile = snap.data() || {};
    if (asTrimmedString(profile.role) !== "clinician") {
      throw new functions.https.HttpsError("permission-denied", "Only nurse accounts can start subscription checkout.");
    }

    const stripe = getStripeClient();
    const billingCycle = subscriptionBillingOption(data?.subscriptionBillingCycle || profile.subscriptionBillingCycle || "monthly").value;
    const paymentMethod = asTrimmedString(data?.subscriptionPaymentMethod || profile.subscriptionPaymentMethod || "card").toLowerCase();
    const appOrigin = resolveCheckoutOrigin(data?.origin);
    const baseMonthlyFeeCents = clinicianBaseMonthlyFeeCents(profile.nurseType);
    const pricing = subscriptionPricing(baseMonthlyFeeCents, billingCycle);
    const priceId = stripePriceIdForProfile(profile.nurseType, billingCycle);

    const trialEndsAtRaw = profile.subscriptionTrialEndsAt?.toDate?.() || profile.subscriptionTrialEndsAt || null;
    const now = new Date();
    const trialEndsAt = trialEndsAtRaw ? new Date(trialEndsAtRaw) : addDays(now, SUBSCRIPTION_TRIAL_DAYS);
    const trialStillActive = !Number.isNaN(trialEndsAt.getTime()) && trialEndsAt.getTime() > now.getTime();
    const trialEndUnix = trialStillActive ? Math.floor(trialEndsAt.getTime() / 1000) : undefined;
    const customerEmail =
      asTrimmedString(profile.email || context?.auth?.token?.email || "") ||
      null;

    let stripeCustomerId = asTrimmedString(profile.stripeCustomerId);
    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({
        email: customerEmail || undefined,
        name: clinicianDisplayLabel(profile.displayName, customerEmail, uid) || undefined,
        metadata: {
          firebaseUid: uid,
          role: "clinician",
          nurseType: asTrimmedString(profile.nurseType || "RN"),
        },
      });
      stripeCustomerId = customer.id;
    }

    const paymentMethodTypes = paymentMethod === "direct_debit" ? ["au_becs_debit"] : ["card"];
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: stripeCustomerId,
      client_reference_id: uid,
      payment_method_types: paymentMethodTypes,
      success_url: `${appOrigin}/nurse-subscription?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${appOrigin}/nurse-subscription?checkout=cancel`,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      metadata: {
        firebaseUid: uid,
        nurseType: asTrimmedString(profile.nurseType || "RN"),
        subscriptionBillingCycle: billingCycle,
        subscriptionPaymentMethod: paymentMethod,
      },
      subscription_data: {
        metadata: {
          firebaseUid: uid,
          nurseType: asTrimmedString(profile.nurseType || "RN"),
          subscriptionBillingCycle: billingCycle,
          subscriptionPaymentMethod: paymentMethod,
        },
        trial_end: trialEndUnix,
      },
    });

    await userRef.set(
      {
        subscriptionBillingCycle: billingCycle,
        subscriptionPaymentMethod: paymentMethod,
        subscriptionDiscountPercent: pricing.discountPercent,
        subscriptionCurrentPriceCents: pricing.discountedCents,
        subscriptionPriceId: priceId,
        subscriptionGateway: "stripe",
        subscriptionGatewayMode: "checkout_session",
        subscriptionCheckoutSessionId: session.id,
        subscriptionCheckoutStatus: "created",
        stripeCustomerId,
        subscriptionTrialStartedAt: profile.subscriptionTrialStartedAt || now,
        subscriptionTrialEndsAt: trialStillActive ? trialEndsAt : profile.subscriptionTrialEndsAt || null,
        subscriptionNextBillingAt: trialStillActive ? trialEndsAt : null,
        updatedAt: serverTimestampDate(),
      },
      { merge: true }
    );

    return {
      ok: true,
      sessionId: session.id,
      url: session.url,
      priceId,
      subscriptionStatus: asTrimmedString(profile.subscriptionStatus || ""),
    };
  });

exports.stripeWebhook = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onRequest(async (req, res) => {
    if (req.method !== "POST") {
      res.status(405).send("Method Not Allowed");
      return;
    }

    const webhookSecret = asTrimmedString(process.env.STRIPE_WEBHOOK_SECRET);
    if (!webhookSecret) {
      res.status(500).send("Stripe webhook secret is not configured.");
      return;
    }

    const signature = req.headers["stripe-signature"];
    if (!signature) {
      res.status(400).send("Missing Stripe signature.");
      return;
    }

    let event;
    try {
      const stripe = getStripeClient();
      event = stripe.webhooks.constructEvent(req.rawBody, signature, webhookSecret);
    } catch (error) {
      res.status(400).send(`Webhook signature verification failed: ${asTrimmedString(error?.message)}`);
      return;
    }

    const eventRef = admin.firestore().collection("stripeWebhookEvents").doc(event.id);
    const existing = await eventRef.get();
    if (existing.exists) {
      res.status(200).json({ received: true, duplicate: true });
      return;
    }

    await eventRef.set({
      eventId: event.id,
      eventType: event.type,
      livemode: Boolean(event.livemode),
      createdAt: serverTimestampDate(),
      processedAt: null,
      status: "received",
    });

    try {
      switch (event.type) {
        case "checkout.session.completed": {
          const session = event.data.object;
          const firebaseUid =
            asTrimmedString(session?.metadata?.firebaseUid) ||
            asTrimmedString(session?.client_reference_id);
          const userMatch = await findUserRefForStripeEvent({
            firebaseUid,
            stripeCustomerId: session?.customer,
          });
          if (userMatch) {
            await userMatch.ref.set(
              {
                stripeCustomerId: asTrimmedString(session?.customer) || null,
                stripeSubscriptionId: asTrimmedString(session?.subscription) || null,
                subscriptionCheckoutSessionId: asTrimmedString(session?.id) || null,
                subscriptionCheckoutStatus: "completed",
                subscriptionGateway: "stripe",
                subscriptionGatewayMode: "checkout_completed",
                subscriptionLastWebhookEventId: event.id,
                subscriptionLastWebhookType: event.type,
                updatedAt: serverTimestampDate(),
              },
              { merge: true }
            );
          }
          break;
        }

        case "customer.subscription.created":
        case "customer.subscription.updated":
        case "customer.subscription.deleted": {
          const subscription = event.data.object;
          await syncStripeSubscriptionToUser({
            firebaseUid: subscription?.metadata?.firebaseUid,
            stripeCustomerId: subscription?.customer,
            stripeSubscription: subscription,
            eventId: event.id,
            eventType: event.type,
          });
          break;
        }

        case "invoice.paid":
        case "invoice.payment_failed": {
          const invoice = event.data.object;
          const userMatch = await findUserRefForStripeEvent({
            firebaseUid: invoice?.parent?.subscription_details?.metadata?.firebaseUid || invoice?.subscription_details?.metadata?.firebaseUid,
            stripeCustomerId: invoice?.customer,
          });
          if (userMatch) {
            await userMatch.ref.set(
              {
                stripeCustomerId: asTrimmedString(invoice?.customer) || null,
                stripeSubscriptionId: asTrimmedString(invoice?.subscription) || null,
                subscriptionLastInvoiceId: asTrimmedString(invoice?.id) || null,
                subscriptionLastInvoiceStatus: asTrimmedString(invoice?.status) || null,
                subscriptionLastInvoiceUrl: asTrimmedString(invoice?.hosted_invoice_url) || null,
                subscriptionLastPaymentAt: event.type === "invoice.paid" ? serverTimestampDate() : userMatch.profile?.subscriptionLastPaymentAt || null,
                subscriptionStatus:
                  event.type === "invoice.payment_failed"
                    ? "past_due"
                    : userMatch.profile?.subscriptionStatus || "active",
                subscriptionGateway: "stripe",
                subscriptionGatewayMode: "webhook_synced",
                subscriptionLastWebhookEventId: event.id,
                subscriptionLastWebhookType: event.type,
                updatedAt: serverTimestampDate(),
              },
              { merge: true }
            );
          }
          break;
        }

        default:
          break;
      }

      await eventRef.set(
        {
          processedAt: serverTimestampDate(),
          status: "processed",
        },
        { merge: true }
      );
      res.status(200).json({ received: true });
    } catch (error) {
      await eventRef.set(
        {
          processedAt: serverTimestampDate(),
          status: "failed",
          error: asTrimmedString(error?.message) || "Unknown Stripe webhook processing error",
        },
        { merge: true }
      );
      res.status(500).send(asTrimmedString(error?.message) || "Stripe webhook processing failed.");
    }
  });

exports.handleWhatsAppTriageReply = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 30, memory: "256MB" })
  .https.onRequest(async (req, res) => {
    try {
      const from = normalizeWhatsAppFrom(readRequestField(req, "From"));
      const body = asTrimmedString(readRequestField(req, "Body"));
      if (!from || !body) {
        res.status(200).type("text/xml").send("<Response></Response>");
        return;
      }

      const snap = await admin
        .firestore()
        .collection("triageSessions")
        .where("channel", "==", "whatsapp")
        .where("whatsappNumber", "==", from)
        .orderBy("updatedAt", "desc")
        .limit(1)
        .get();

      if (snap.empty) {
        await sendWhatsAppMessageInternal({
          number: from,
          message: "No active WhatsApp symptom intake was found for this number. Start from the patient portal, or reply START after your practice sends a triage invitation.",
          appointmentId: "",
          triggeredBy: "whatsapp_webhook",
        });
        res.status(200).type("text/xml").send("<Response></Response>");
        return;
      }

      const sessionRef = snap.docs[0].ref;
      let session = { id: snap.docs[0].id, ...(snap.docs[0].data() || {}) };
      const upper = body.toUpperCase();

      if (upper === "STOP" || upper === "PAUSE") {
        await sessionRef.set(
          {
            status: "abandoned",
            updatedAt: serverTimestampDate(),
          },
          { merge: true }
        );
        await sendWhatsAppMessageInternal({
          number: from,
          message: "Your symptom intake has been paused. Reply RESUME to continue later, or CALL ME if you want the practice to contact you.",
          appointmentId: session.appointmentId || "",
          triggeredBy: "whatsapp_webhook",
        });
        res.status(200).type("text/xml").send("<Response></Response>");
        return;
      }

      if (upper === "CALL ME") {
        const taskId = await createManualCallbackTask(
          session,
          "Patient requested a callback from WhatsApp symptom intake."
        );
        await sessionRef.set(
          {
            status: "active",
            reviewStatus: "pending",
            recommendedAction: "patient_requested_callback",
            callbackTargetMinutes: 30,
            callbackBy: asFirestoreDate(Date.now() + 30 * 60 * 1000),
            updatedAt: serverTimestampDate(),
          },
          { merge: true }
        );
        await sendWhatsAppMessageInternal({
          number: from,
          message: "Your request has been sent to the practice. A member of the team will contact you as soon as possible.",
          appointmentId: session.appointmentId || "",
          triggeredBy: "whatsapp_webhook",
        });
        if (taskId && session.appointmentId) {
          await admin.firestore().collection("appointments").doc(session.appointmentId).set(
            {
              triageStatus: "active",
              triageUrgency: "urgent_callback",
              triageLastUpdatedAt: serverTimestampDate(),
            },
            { merge: true }
          );
        }
        res.status(200).type("text/xml").send("<Response></Response>");
        return;
      }

      if (upper === "RESUME" || upper === "START") {
        if (session.status === "abandoned") {
          await sessionRef.set(
            {
              status: "active",
              updatedAt: serverTimestampDate(),
            },
            { merge: true }
          );
          session = { ...session, status: "active" };
        }
        const current = getCurrentQuestion(session);
        const message = current.question
          ? formatQuestionMessage(current.question, current.progress)
          : session.patientMessageRendered || "Your symptom intake has already been completed.";
        await sendWhatsAppMessageInternal({
          number: from,
          message,
          appointmentId: session.appointmentId || "",
          triggeredBy: "whatsapp_webhook",
        });
        res.status(200).type("text/xml").send("<Response></Response>");
        return;
      }

      if (session.status === "abandoned") {
        await sendWhatsAppMessageInternal({
          number: from,
          message: "Your symptom intake is currently paused. Reply RESUME to continue or CALL ME if you want the practice to contact you.",
          appointmentId: session.appointmentId || "",
          triggeredBy: "whatsapp_webhook",
        });
        res.status(200).type("text/xml").send("<Response></Response>");
        return;
      }

      const current = getCurrentQuestion(session);
      if (!current.question) {
        await sendWhatsAppMessageInternal({
          number: from,
          message: session.patientMessageRendered || "Your symptom intake has already been completed.",
          appointmentId: session.appointmentId || "",
          triggeredBy: "whatsapp_webhook",
        });
        res.status(200).type("text/xml").send("<Response></Response>");
        return;
      }

      const mappedValue = mapIncomingAnswer(current.question, body);
      const answerResult = await submitAnswerCore({
        sessionRef,
        session,
        questionId: current.question.id,
        value: mappedValue,
      });

      const refreshed = await sessionRef.get();
      session = { id: refreshed.id, ...(refreshed.data() || {}) };

      if (answerResult.status === "active" && answerResult.nextQuestion) {
        await sendWhatsAppMessageInternal({
          number: from,
          message: formatQuestionMessage(answerResult.nextQuestion, answerResult.progress),
          appointmentId: session.appointmentId || "",
          triggeredBy: "whatsapp_webhook",
        });
      } else {
        const finalResult = await finalizeSession(sessionRef, session);
        await sendWhatsAppMessageInternal({
          number: from,
          message: finalResult.patientMessage,
          appointmentId: session.appointmentId || "",
          triggeredBy: "whatsapp_webhook",
        });
      }

      res.status(200).type("text/xml").send("<Response></Response>");
    } catch (error) {
      console.error("WhatsApp triage webhook error:", error?.message || error);
      res.status(200).type("text/xml").send("<Response></Response>");
    }
  });

exports.generateComplianceSnapshot = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 60, memory: "256MB" })
  .https.onCall(async (_data, context) => {
    if (!context.auth?.uid) {
      throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
    }
    await adminRoleOrThrow(context.auth.uid);
    try {
      const snapshot = await buildComplianceSnapshot();
      const ref = await admin.firestore().collection("complianceReports").add({
        ...snapshot,
        generatedByUid: context.auth.uid,
        trigger: "manual",
      });
      return { id: ref.id, warningCount: snapshot.warnings.length };
    } catch (error) {
      console.error("generateComplianceSnapshot failed", error);
      throw new functions.https.HttpsError("internal", error?.message || "Compliance snapshot generation failed.");
    }
  });

exports.retentionComplianceSweep = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 120, memory: "256MB" })
  .pubsub.schedule("every 24 hours")
  .timeZone("Australia/Melbourne")
  .onRun(async () => {
    try {
      const snapshot = await buildComplianceSnapshot();
      await admin.firestore().collection("complianceReports").add({
        ...snapshot,
        trigger: "scheduled",
      });
      return null;
    } catch (error) {
      console.error("retentionComplianceSweep failed", error);
      throw error;
    }
  });

exports.generateRetentionDryRun = functions
  .region("australia-southeast1")
  .runWith({ timeoutSeconds: 60, memory: "256MB" })
  .https.onCall(async (_data, context) => {
    if (!context.auth?.uid) {
      throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
    }
    await adminRoleOrThrow(context.auth.uid);
    try {
      const snapshot = await buildRetentionDryRunSnapshot();
      const ref = await admin.firestore().collection("retentionRuns").add({
        ...snapshot,
        generatedByUid: context.auth.uid,
        trigger: "manual",
        mode: "dry_run",
      });
      return { id: ref.id, counts: snapshot.counts };
    } catch (error) {
      console.error("generateRetentionDryRun failed", error);
      throw new functions.https.HttpsError("internal", error?.message || "Retention dry-run generation failed.");
    }
  });
