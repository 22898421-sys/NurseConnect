# EIRENIX Care™ Build Documentation

This repository is the NurseConnectCare-aligned EIRENIX Care™ build.

## Product scope

- Australia-only configuration
- nurse-only clinician model
- self-sign-up for patients/carers and nurses
- restricted `system_admin` support and compliance administration
- public NurseConnectCare connector website for care discovery, client/carer demand capture, provider-aware service requests, nurse registration, and access flows
- EIRENIX Care™ restricted workspace for telehealth, charting, billing facilitation, home-care assessments, Support at Home-aligned service evidence, compliance records, and audited support access

NurseConnectCare is positioned as connector and workflow infrastructure. It does not employ nurses, provide nursing care, process claims, approve Support at Home eligibility, or hold patient/client funds.

## Active roles

- `patient`
- `clinician`
- `system_admin`

`clinician` is the nurse workspace role. Nurse-specific capability such as prescribing is further gated by nurse type, for example `NP`.

`system_admin` is for platform support, public enquiry review, compliance administration, and audited troubleshooting workflows. System admins must not browse client records by default.

## Main runtime areas

- public website and access flows: `src/components/NurseConnectCareLandingPage.tsx`
- public care discovery and request routing: `src/components/PatientBookingPage.tsx`
- organisation/provider-aware service request form: `src/components/ServiceRequestPage.tsx`
- nurse workspace: `src/components/ClinicianPortal.tsx`
- patient portal: `src/components/PatientPortal.tsx`
- patient chart and encounters: `src/components/PatientChartPage.tsx`, `src/components/EncounterDetailPage.tsx`
- home-care assessments: `src/lib/homeCareAssessments.ts`
- service requests: `src/lib/serviceRequests.ts`
- billing facilitation: `src/lib/billingFacilitation.ts`
- nurse practitioner prescribing: `src/components/NursePrescribingTab.tsx`, `src/lib/prescribing.ts`
- compliance console: `src/components/ComplianceConsolePage.tsx`, `src/lib/compliance.ts`
- audited support access: `src/components/SupportAccessPage.tsx`, `src/lib/supportAccess.ts`
- access audit logging: `src/lib/accessAudit.ts`

## Restricted administration

The restricted admin surface currently includes:

- `/system-admin` - system support console and nurse AHPRA verification queue
- `/public-enquiries` - public contact, nurse registration interest, and service request review
- `/compliance` - provider onboarding, credential expiry tracking, associated-provider records, incident/complaint records, and audit readiness dashboard
- `/support-access` - provider/clinician-requested, time-limited admin troubleshooting access to specific client records

## Support access and privacy posture

Admins are restricted from ordinary client-record browsing. A clinician/provider user must create a support access request for a specific client record and reason. A system admin can then approve a time-limited grant for that admin and client record.

Before the support admin preview loads the client record, the app writes an `accessAuditLogs` entry using action `support_patient_record_access`.

Relevant collections:

- `supportAccessRequests`
- `supportAccessGrants`
- `accessAuditLogs`

Relevant Firestore rules are in `firestore.rules`.

## Compliance data collections

The compliance console uses:

- `complianceProviders`
- `complianceCredentials`
- `associatedProviders`
- `incidentComplaints`

These collections are restricted to `system_admin` users by Firestore rules. Deletes are blocked.

## Service request model

Service requests now capture provider and Support at Home context, including:

- requester role
- registered provider name/reference
- Support at Home category
- funding pathway
- care-plan context
- open or direct nurse request type

## Local development

Use:

```bash
npm run emulators
npm run start:local
```

Current local emulator ports are defined in `firebase.json`. This instance is isolated for NurseConnectCare local use.

## Build and deployment

Production build:

```bash
npm run build
```

Deploy live hosting:

```bash
firebase deploy --only hosting
```

Deploy Firestore rules and hosting when rules change:

```bash
firebase deploy --only firestore:rules,hosting
```

Deploy the active preview channel used for testing:

```bash
firebase hosting:channel:deploy website-fixes-20260524
```

Current Firebase default project is defined in `.firebaserc` as `nurseconnect-project`.

Live URL:

```text
https://nurseconnect-project.web.app
```

Preview URL:

```text
https://nurseconnect-project--website-fixes-20260524-0r5q4yed.web.app
```

## Production readiness

See `PRODUCTION_READINESS_PIPELINE.md` for the 6-week production readiness pipeline, including security testing, legal/privacy review, operational SOPs, controlled pilot, and production cutover criteria.

## Notes

- Seeded Botswana demo data is intentionally removed from this build.
- Nurse practitioner prescribing should always be checked against current PBS nurse practitioner listings and applicable scope rules.
- A local NP prescribing cache can be built from an official PBS export with `npm run pbs:import:np -- <file>`.
- NurseConnectCare and EIRENIX Care™ do not process claims or patient funds.
- Terms of Use and Privacy Policy are still expected to receive formal legal review before public production use.
- The current deployment is appropriate for controlled testing/pilot use, not unsupervised public production.
