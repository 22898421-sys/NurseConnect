# NurseConnectCare Production Readiness Pipeline

## Objective

Prepare NurseConnectCare and the restricted EIRENIX Care environment for a controlled production launch within a realistic 6-week timeframe.

This plan assumes the current deployment is suitable for private testing and controlled pilot activity, but not yet full public production use.

## Launch Recommendation

- **4 weeks:** realistic for a private beta or tightly controlled pilot.
- **6 weeks:** realistic for a cautious production launch, assuming legal/privacy review happens in parallel.

## Production Decision Rule

Do not proceed to public production until all of the following are true:

- Role-based access tests pass for client, clinician, and system admin users.
- Admin access to client records is request-based, time-limited, and audited.
- Terms of Use and Privacy Policy have been legally reviewed.
- Incident and complaint workflows are documented and tested.
- Credential and provider verification workflows are documented.
- A controlled pilot workflow has been completed successfully.
- No critical or high-severity privacy, security, or clinical-governance issues remain open.

---

## Week 1: Product Freeze And Risk Baseline

### Goal

Stop scope drift and define exactly what production means for the first release.

### Deliverables

- Launch scope statement.
- Role and permission map.
- Data inventory for personal, health, billing, provider, and compliance records.
- Production readiness checklist.
- Risk register.

### Engineering Tasks

- Confirm live and preview Firebase environments.
- Review all public routes.
- Review all restricted routes.
- Confirm user roles:
  - client/carer
  - clinician/nurse
  - system admin
- Identify all Firestore collections containing sensitive information.
- Document current admin access boundaries.

### Exit Criteria

- Launch scope is written and agreed.
- No ambiguity remains about who can access what.
- Launch-blocking risks are listed and prioritised.

---

## Week 2: Security Rules And Access Testing

### Goal

Prove access controls work before real client/provider use.

### Deliverables

- Automated Firestore rules test suite.
- Manual role-based access test report.
- Support access audit test report.

### Required Test Cases

- Client can access only their own records.
- Clinician can access only appropriate practice/client records.
- System admin cannot browse client records by default.
- System admin can access a client record only after a provider/clinician support access request is approved.
- Support access creates an audit log entry.
- Expired or revoked support grants deny access.
- Public users cannot access restricted collections.
- Compliance records are restricted to system admins.

### Exit Criteria

- Firestore rules tests pass.
- No broad admin access to client records remains.
- Audited support access can be demonstrated end to end.

---

## Week 3: Legal, Privacy And Governance Pack

### Goal

Make the operating model defensible under Australian privacy, health-data, and Support at Home expectations.

### Deliverables

- Final Terms of Use.
- Final Privacy Policy.
- Nurse/provider participation terms.
- Support access SOP.
- Incident and complaint SOP.
- Data retention policy.
- Breach response procedure.
- Provider/subcontractor responsibility statement.

### External Review

- Australian privacy lawyer.
- Aged care / Support at Home regulatory advisor if available.

### Exit Criteria

- Placeholder legal/privacy copy is replaced.
- Support/admin access procedure is documented.
- Incident and complaint workflow has named owners and response targets.

---

## Week 4: Operational Readiness

### Goal

Make the platform usable by real operators without developer intervention.

### Deliverables

- Admin runbook.
- Nurse onboarding checklist.
- Provider onboarding checklist.
- Credential verification checklist.
- Associated-provider checklist.
- Incident/complaint triage matrix.
- Support escalation contacts.
- Known-issues register.

### Engineering Tasks

- Confirm provider onboarding records work.
- Confirm credential expiry tracking works.
- Confirm associated-provider records work.
- Confirm incident/complaint workflow works.
- Confirm evidence pack flow works.
- Confirm contact/support inbox works.
- Confirm audited support access flow works.

### Exit Criteria

- A new nurse can be onboarded using a written checklist.
- A provider request can be processed end to end.
- Support/admin users know what to do when something goes wrong.

---

## Week 5: Controlled Pilot

### Goal

Test real workflows under limited operational risk.

### Suggested Pilot Scope

- 1-2 trusted nurses.
- 1-2 provider or care-manager contacts.
- 3-5 client/test scenarios.
- Manual oversight for all high-risk clinical or privacy events.

### Pilot Scenarios

- Client/carer enquiry.
- Provider service request.
- Nurse profile and service response.
- Booking or request workflow.
- Clinical record workflow.
- Billing/evidence pack workflow.
- Provider compliance record.
- Credential expiry record.
- Associated-provider record.
- Mock incident/complaint event.
- Admin troubleshooting access request.

### Exit Criteria

- All pilot issues are logged.
- Critical and high-severity issues are fixed.
- No unresolved privacy/security concern remains.
- Manual support process works without developer intervention.

---

## Week 6: Production Cutover

### Goal

Launch cautiously with monitoring and support processes in place.

### Deliverables

- Production launch checklist.
- Release decision note.
- Monitoring and alerting checklist.
- Backup/export approach.
- Final deployment record.

### Launch Tasks

- Deploy final hosting.
- Deploy final Firestore rules.
- Deploy final functions if changed.
- Smoke test public routes.
- Smoke test restricted routes.
- Test login for all roles.
- Test support access workflow.
- Confirm audit logs write correctly.
- Confirm contact forms and service requests work.
- Confirm compliance console is restricted to system admins.

### Exit Criteria

- No critical or high defects open.
- Legal/privacy sign-off completed.
- Admin/support SOPs ready.
- Pilot users can operate without developer intervention.
- Production release decision is recorded.

---

## Critical Path

The most likely blockers are:

1. Legal/privacy review.
2. Firestore rules test coverage.
3. Admin/support SOPs.
4. Credential and provider verification process.
5. Pilot validation with real workflows.

## Workstream Summary

| Workstream | Primary Goal | Target Window | Launch Critical |
| --- | --- | --- | --- |
| Product scope | Lock launch model and roles | Week 1 | Yes |
| Security rules | Prove least-privilege access | Week 2 | Yes |
| Legal/privacy | Finalise public and operational policies | Weeks 2-4 | Yes |
| Compliance operations | Provider, credential, incident, complaint workflows | Weeks 3-4 | Yes |
| Pilot | Validate real workflows | Week 5 | Yes |
| Production cutover | Deploy and smoke test final release | Week 6 | Yes |

## Current Platform Status

Already implemented:

- Public Support at Home-aligned positioning.
- Provider-aware service request fields.
- Restricted compliance console.
- Audited support access workflow.
- System-admin-only compliance collections.
- Firebase live and preview deployment flow.
- GitHub main branch deployment workflow.

Still required:

- Automated Firestore rules tests.
- Legal/privacy review.
- Operational SOPs.
- Credential verification evidence process.
- Controlled pilot.
- Production launch checklist sign-off.
