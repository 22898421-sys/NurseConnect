# Compliance Workflow Validation Evidence

Date: 2026-06-18

This evidence covers the current EIRENIX Care restricted compliance console workflows for Support at Home-aligned operations.

## Result

Passed.

The compliance workspace has executable Firestore rules validation and UI/data-model evidence for:

- `T050` - Confirm provider onboarding records work
- `T051` - Confirm credential expiry tracking works
- `T052` - Confirm associated-provider records work
- `T053` - Confirm incident/complaint workflow works

## Evidence Command

With the local Firestore emulator already running on `127.0.0.1:8380`:

```bash
npm run test:compliance:local
```

This test is also included in the consolidated rules suite:

```bash
npm run test:rules:local
```

Expected terminal evidence:

```text
Compliance workspace rules validation passed.
```

## Validated Workflows

### Provider onboarding records

Validated collection: `complianceProviders`

Evidence:

- system-admin users can create provider onboarding records
- system-admin users can list and read provider records
- system-admin users can update provider status to a valid state
- invalid provider status values are denied
- clinician, patient, and unauthenticated users cannot read provider records
- deletes are denied

UI/data evidence:

- `src/components/ComplianceConsolePage.tsx` includes provider onboarding form, provider list, status controls, and audit-readiness dashboard metrics
- `src/lib/compliance.ts` writes provider records with normalized text, service categories, status, and timestamps

### Credential expiry tracking

Validated collection: `complianceCredentials`

Evidence:

- system-admin users can create credential records
- system-admin users can list and read credential records
- system-admin users can update credential status to a valid state
- invalid subject/status structures are denied
- clinician, patient, and unauthenticated users cannot read credential records
- deletes are denied

UI/data evidence:

- `src/components/ComplianceConsolePage.tsx` includes credential form, expiry date, evidence reference, status controls, and risk dashboard
- `src/lib/compliance.ts` includes `credentialComputedStatus()` and `daysUntil()` for expired/expiring credential tracking

### Associated-provider records

Validated collection: `associatedProviders`

Evidence:

- system-admin users can create associated-provider records
- system-admin users can list and read associated-provider records
- system-admin users can update agreement status to a valid state
- invalid agreement status values are denied
- clinician, patient, and unauthenticated users cannot read associated-provider records
- deletes are denied

UI/data evidence:

- `src/components/ComplianceConsolePage.tsx` includes associated-provider form, agreement status, insurance expiry, screening status, and list/status controls
- `src/lib/compliance.ts` writes associated-provider records with normalized provider context, agreement status, insurance expiry, and screening status

### Incident/complaint workflow

Validated collection: `incidentComplaints`

Evidence:

- system-admin users can create incident and complaint records
- system-admin users can list and read incident/complaint records
- system-admin users can update incident/complaint status to a valid state
- invalid type/severity/status values are denied
- clinician, patient, and unauthenticated users cannot read incident/complaint records
- deletes are denied

UI/data evidence:

- `src/components/ComplianceConsolePage.tsx` includes incident/complaint form, type, provider context, participant reference, severity, status, owner, due date, and summary
- `src/lib/compliance.ts` writes incident/complaint records with normalized fields and timestamps

## Files

- `scripts/testComplianceWorkspaceRules.mjs`
- `src/components/ComplianceConsolePage.tsx`
- `src/lib/compliance.ts`
- `firestore.rules`
- `package.json`
- `BUILD_DOCUMENTATION.md`
- `PRODUCT_SCOPE_EVIDENCE_PACK.md`

## Residual Scope

This evidence validates that the restricted compliance workflows and Firestore access controls work for the current build. It does not sign off:

- final admin runbook
- nurse onboarding checklist
- provider onboarding checklist
- credential verification checklist
- associated-provider operating checklist
- incident/complaint SOP or triage matrix
- live pilot execution
- legal/privacy sign-off
- final production cutover

