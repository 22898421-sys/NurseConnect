# Video Call Cost Estimate

Date: 09-03-2026

## Current Build Wiring

The current EIRENIX build is wired to Jitsi by default.

Relevant implementation:

- `src/components/VideoCallPage.tsx`
  - `VIDEO_PROVIDER` defaults to `jitsi`
  - active calls load `https://meet.jit.si/{roomName}` in an iframe

Twilio is present in the repo for messaging-related functions and as a future video placeholder, but the current live video-call path is Jitsi.

## Cost Interpretation

Because the current build uses public Jitsi Meet embedding:

- Direct per-call video platform cost to the practice from EIRENIX: `P0`
- Practice-side network cost on office fibre / Wi-Fi: usually treated as part of the existing internet subscription rather than a meaningful per-call marginal charge

This means the main variable cost is the patient's mobile data usage when the patient joins over a Botswana mobile network.

## Botswana Mobile Data Rates Used

Input reference:

- Orange Botswana: `P0.014 - P0.017` per MB
- Mascom Wireless: `P0.016 - P0.018` per MB
- BTC Mobile: `P0.015 - P0.018` per MB

Blended practical range used for estimation:

- `P0.014 - P0.018` per MB

## Assumed Data Usage for a 30-Minute 1:1 Video Call

Estimated Jitsi data consumption:

- Low / constrained call: `150 MB`
- Typical SD call: `300 MB`
- Higher quality call: `450 MB`

These are planning estimates, not guaranteed billing values. Real usage varies with:

- video quality
- network conditions
- whether camera is on continuously
- screen size / browser behaviour
- audio-only fallback periods

## Estimated Patient Cost for a 30-Minute Call

If the patient joins on Botswana mobile data:

- `150 MB` x `P0.014 - P0.018` = `P2.10 - P2.70`
- `300 MB` x `P0.014 - P0.018` = `P4.20 - P5.40`
- `450 MB` x `P0.014 - P0.018` = `P6.30 - P8.10`

Working estimate for patient communication:

- Typical 30-minute mobile-data call: about `P4 - P5`

## Estimated Practice Cost for a 30-Minute Call

If the clinician joins from office fibre / office Wi-Fi / intranet:

- Direct Jitsi platform cost: `P0`
- Practical marginal network cost per call: effectively `P0`

Working estimate for practice communication:

- Typical 30-minute call from office network: effectively `P0` marginal cost

## Summary

- Patient cost:
  - typical: about `P4 - P5`
  - plausible range: about `P2 - P8`

- Practice cost:
  - office fibre / Wi-Fi setup: effectively `P0` marginal per call

## FOR sms 
local SMS Gateway costs approx. P0.20 (USD0.015) which is a cost to the clinic