#!/usr/bin/env node
const { spawnSync } = require("child_process");

const steps = [
  {
    label: "Readiness check",
    command: "node",
    args: ["scripts/deploymentReadinessCheck.js"],
  },
  {
    label: "Production build",
    command: "npm",
    args: ["run", "build"],
  },
];

console.log("EIRENIX deployment gate");
console.log("");

for (const step of steps) {
  console.log(`Running: ${step.label}`);
  const result = spawnSync(step.command, step.args, {
    stdio: "inherit",
    shell: process.platform === "win32",
  });
  if (result.status !== 0) {
    console.error("");
    console.error(`Gate failed at: ${step.label}`);
    process.exit(result.status || 1);
  }
  console.log("");
}

console.log("Deployment gate passed.");
