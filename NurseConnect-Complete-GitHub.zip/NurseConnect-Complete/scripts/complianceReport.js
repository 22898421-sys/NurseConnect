#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = process.cwd();
const projectId = process.env.GCLOUD_PROJECT || process.env.GOOGLE_CLOUD_PROJECT || "eirenix-project";
const emulatorHost = process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8280";

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function readJson(relPath) {
  return JSON.parse(fs.readFileSync(path.join(root, relPath), "utf8"));
}

function timestampToDate(value) {
  if (!value) return null;
  if (typeof value.toDate === "function") return value.toDate();
  if (typeof value.seconds === "number") return new Date(value.seconds * 1000);
  return null;
}

function daysBetween(now, past) {
  return Math.floor((now - past) / (24 * 60 * 60 * 1000));
}

function preferLocalEmulatorIfNeeded() {
  const hasExplicitCredentials =
    Boolean(process.env.GOOGLE_APPLICATION_CREDENTIALS) ||
    Boolean(process.env.FIRESTORE_EMULATOR_HOST) ||
    Boolean(process.env.FIREBASE_CONFIG);

  if (!hasExplicitCredentials) {
    process.env.FIRESTORE_EMULATOR_HOST = emulatorHost;
    process.env.GCLOUD_PROJECT = projectId;
    process.env.GOOGLE_CLOUD_PROJECT = projectId;
  }
}

async function tryLoadFirestoreData() {
  try {
    preferLocalEmulatorIfNeeded();
    const admin = require(path.join(root, "functions", "node_modules", "firebase-admin"));
    if (!admin.apps.length) {
      admin.initializeApp({ projectId });
    }
    const db = admin.firestore();
    const configSnap = await db.collection("config").doc("app").get();
    const config = configSnap.exists ? configSnap.data() || {} : {};

    const [accessSnap, consentSnap] = await Promise.all([
      db.collection("accessAuditLogs").orderBy("occurredAt", "desc").limit(200).get(),
      db.collectionGroup("events").orderBy("occurredAt", "desc").limit(200).get(),
    ]);

    return {
      ok: true,
      config,
      accessAuditRows: accessSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() })),
      consentEventRows: consentSnap.docs
        .map((doc) => ({ id: doc.id, ...doc.data() }))
        .filter((row) => row.type === "signed" || row.type === "withdrawn" || row.type === "updated"),
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : String(error),
      config: {},
      accessAuditRows: [],
      consentEventRows: [],
    };
  }
}

async function main() {
  const packageJson = readJson("package.json");
  const now = new Date();
  const firestore = await tryLoadFirestoreData();

  const retentionPolicy = {
    accessAuditDays: Number(firestore.config?.retentionPolicy?.accessAuditDays) || 365,
    consentEventDays: Number(firestore.config?.retentionPolicy?.consentEventDays) || 2555,
    patientSummaryRevisionDays: Number(firestore.config?.retentionPolicy?.patientSummaryRevisionDays) || 365,
    deidentifiedExportsOnly: firestore.config?.retentionPolicy?.deidentifiedExportsOnly !== false,
  };

  const deploymentReadiness = {
    backupsConfigured: firestore.config?.deploymentReadiness?.backupsConfigured === true,
    monitoringEnabled: firestore.config?.deploymentReadiness?.monitoringEnabled === true,
    restoreRunbookCheckedAt: String(firestore.config?.deploymentReadiness?.restoreRunbookCheckedAt || ""),
    incidentContact: String(firestore.config?.deploymentReadiness?.incidentContact || ""),
  };

  const staleAccessAudit = firestore.accessAuditRows.filter((row) => {
    const dt = timestampToDate(row.occurredAt);
    return dt ? daysBetween(now, dt) > retentionPolicy.accessAuditDays : false;
  });
  const staleConsentEvents = firestore.consentEventRows.filter((row) => {
    const dt = timestampToDate(row.occurredAt);
    return dt ? daysBetween(now, dt) > retentionPolicy.consentEventDays : false;
  });

  const warnings = [];
  if (!deploymentReadiness.backupsConfigured) warnings.push("Backups are not confirmed in config/app.");
  if (!deploymentReadiness.monitoringEnabled) warnings.push("Monitoring is not confirmed in config/app.");
  if (!deploymentReadiness.restoreRunbookCheckedAt) warnings.push("Restore runbook review date is missing.");
  if (!deploymentReadiness.incidentContact) warnings.push("Incident contact is missing.");
  if (!packageJson.scripts?.["deployment:gate"]) warnings.push("deployment:gate script is missing.");
  if (!packageJson.scripts?.["deployment:check"]) warnings.push("deployment:check script is missing.");
  if (staleAccessAudit.length > 0) warnings.push(`Sampled access audit rows older than retention: ${staleAccessAudit.length}.`);
  if (staleConsentEvents.length > 0) warnings.push(`Sampled consent events older than retention: ${staleConsentEvents.length}.`);
  if (!firestore.ok) warnings.push(`Firestore sampling unavailable: ${firestore.error}`);

  const report = {
    generatedAt: now.toISOString(),
    projectId,
    firestoreSampling: {
      ok: firestore.ok,
      error: firestore.ok ? null : firestore.error,
      accessAuditSampleSize: firestore.accessAuditRows.length,
      consentEventSampleSize: firestore.consentEventRows.length,
    },
    retentionPolicy,
    deploymentReadiness,
    findings: {
      staleAccessAuditRows: staleAccessAudit.length,
      staleConsentEventRows: staleConsentEvents.length,
    },
    warnings,
  };

  const outputDir = path.join(root, "local-artifacts");
  ensureDir(outputDir);
  const outputPath = path.join(outputDir, "compliance-report.json");
  fs.writeFileSync(outputPath, JSON.stringify(report, null, 2));

  console.log("EIRENIX compliance report");
  console.log("");
  console.log(`Generated: ${report.generatedAt}`);
  console.log(`Output: ${outputPath}`);
  console.log(`Firestore sampling: ${report.firestoreSampling.ok ? "available" : "unavailable"}`);
  console.log(`Firestore target: ${process.env.FIRESTORE_EMULATOR_HOST ? `emulator ${process.env.FIRESTORE_EMULATOR_HOST}` : "application default credentials"}`);
  console.log(`Access audit sample: ${report.firestoreSampling.accessAuditSampleSize}`);
  console.log(`Consent event sample: ${report.firestoreSampling.consentEventSampleSize}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) {
    console.log(`- ${warning}`);
  }

  process.exit(warnings.length > 0 ? 1 : 0);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
