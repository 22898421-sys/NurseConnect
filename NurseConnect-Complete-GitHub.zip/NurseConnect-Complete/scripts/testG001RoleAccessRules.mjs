import fs from "node:fs";
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
} from "@firebase/rules-unit-testing";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  query,
  setDoc,
  updateDoc,
  where,
} from "firebase/firestore";

const projectId = "nurseconnectcare-g001";
const practiceA = "practice-g001-a";
const practiceB = "practice-g001-b";
const clinicianAUid = "clinician-g001-a";
const clinicianBUid = "clinician-g001-b";
const patientAUid = "patient-user-g001-a";
const patientBUid = "patient-user-g001-b";
const adminUid = "system-admin-g001";
const patientAId = "patient-g001-a";
const patientBId = "patient-g001-b";

const now = new Date();

const testEnv = await initializeTestEnvironment({
  projectId,
  firestore: {
    rules: fs.readFileSync("firestore.rules", "utf8"),
    host: "127.0.0.1",
    port: 8380,
  },
});

async function seedBaseData() {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();

    await setDoc(doc(db, "users", clinicianAUid), {
      role: "clinician",
      displayName: "G001 Clinician A",
      practiceId: practiceA,
    });
    await setDoc(doc(db, "users", clinicianBUid), {
      role: "clinician",
      displayName: "G001 Clinician B",
      practiceId: practiceB,
    });
    await setDoc(doc(db, "users", patientAUid), { role: "patient", patientId: patientAId });
    await setDoc(doc(db, "users", patientBUid), { role: "patient", patientId: patientBId });
    await setDoc(doc(db, "users", adminUid), { role: "system_admin", displayName: "G001 System Admin" });

    await setDoc(doc(db, "patients", patientAId), {
      userId: patientAUid,
      fullName: "G001 Client A",
      practiceId: practiceA,
      updatedAt: now,
    });
    await setDoc(doc(db, "patients", patientBId), {
      userId: patientBUid,
      fullName: "G001 Client B",
      practiceId: practiceB,
      updatedAt: now,
    });

    await setDoc(doc(db, "patientClinicalRecords", patientAId), {
      patientId: patientAId,
      practiceId: practiceA,
      chartData: { allergies: [] },
      updatedAt: now,
    });
    await setDoc(doc(db, "patientClinicalRecords", patientBId), {
      patientId: patientBId,
      practiceId: practiceB,
      chartData: { allergies: [] },
      updatedAt: now,
    });

    await setDoc(doc(db, "patientSummaries", patientAId), {
      patientId: patientAId,
      practiceId: practiceA,
      summary: "Plain-language summary A",
      updatedAt: now,
    });
    await setDoc(doc(db, "patientSummaries", patientBId), {
      patientId: patientBId,
      practiceId: practiceB,
      summary: "Plain-language summary B",
      updatedAt: now,
    });

    await setDoc(doc(db, "patients", patientAId, "portalDocuments", "doc-a"), {
      patientId: patientAId,
      title: "Visible document A",
      kind: "summary",
      patientVisible: true,
      printPath: "/print/a",
    });
    await setDoc(doc(db, "patients", patientBId, "portalDocuments", "doc-b"), {
      patientId: patientBId,
      title: "Visible document B",
      kind: "summary",
      patientVisible: true,
      printPath: "/print/b",
    });

    await setDoc(doc(db, "encounters", "encounter-a"), {
      patientId: patientAId,
      practitionerId: clinicianAUid,
      practiceId: practiceA,
      status: "completed",
      createdAt: now,
    });
    await setDoc(doc(db, "encounters", "encounter-b"), {
      patientId: patientBId,
      practitionerId: clinicianBUid,
      practiceId: practiceB,
      status: "completed",
      createdAt: now,
    });

    await setDoc(doc(db, "complianceProviders", "provider-a"), {
      name: "G001 Compliance Provider",
      status: "active",
      updatedAt: now,
    });
  });
}

function clinicianA() {
  return testEnv.authenticatedContext(clinicianAUid).firestore();
}

function patientA() {
  return testEnv.authenticatedContext(patientAUid).firestore();
}

function admin() {
  return testEnv.authenticatedContext(adminUid).firestore();
}

function publicDb() {
  return testEnv.unauthenticatedContext().firestore();
}

async function main() {
  await testEnv.clearFirestore();
  await seedBaseData();

  const clinicianDb = clinicianA();
  const patientDb = patientA();
  const adminDb = admin();
  const anonDb = publicDb();

  // Public boundary: unauthenticated users cannot read restricted collections.
  await assertFails(getDoc(doc(anonDb, "patients", patientAId)));
  await assertFails(getDoc(doc(anonDb, "patientClinicalRecords", patientAId)));
  await assertFails(getDoc(doc(anonDb, "patientSummaries", patientAId)));
  await assertFails(getDoc(doc(anonDb, "encounters", "encounter-a")));
  await assertFails(getDoc(doc(anonDb, "complianceProviders", "provider-a")));

  // Client/carer boundary: own records only, no clinical chart internals.
  await assertSucceeds(getDoc(doc(patientDb, "patients", patientAId)));
  await assertFails(getDoc(doc(patientDb, "patients", patientBId)));
  await assertSucceeds(getDoc(doc(patientDb, "patientSummaries", patientAId)));
  await assertFails(getDoc(doc(patientDb, "patientSummaries", patientBId)));
  await assertSucceeds(getDoc(doc(patientDb, "patients", patientAId, "portalDocuments", "doc-a")));
  await assertFails(getDoc(doc(patientDb, "patients", patientBId, "portalDocuments", "doc-b")));
  await assertFails(getDoc(doc(patientDb, "patientClinicalRecords", patientAId)));
  await assertFails(getDoc(doc(patientDb, "encounters", "encounter-a")));

  // Clinician/nurse boundary: own practice/client records only.
  await assertSucceeds(getDoc(doc(clinicianDb, "patients", patientAId)));
  await assertFails(getDoc(doc(clinicianDb, "patients", patientBId)));
  await assertSucceeds(
    getDocs(query(collection(clinicianDb, "patients"), where("practiceId", "==", practiceA), limit(20)))
  );
  await assertFails(getDocs(query(collection(clinicianDb, "patients"), limit(20))));
  await assertSucceeds(getDoc(doc(clinicianDb, "patientClinicalRecords", patientAId)));
  await assertFails(getDoc(doc(clinicianDb, "patientClinicalRecords", patientBId)));
  await assertSucceeds(getDoc(doc(clinicianDb, "patientSummaries", patientAId)));
  await assertFails(getDoc(doc(clinicianDb, "patientSummaries", patientBId)));
  await assertSucceeds(getDoc(doc(clinicianDb, "patients", patientAId, "portalDocuments", "doc-a")));
  await assertFails(getDoc(doc(clinicianDb, "patients", patientBId, "portalDocuments", "doc-b")));
  await assertSucceeds(getDoc(doc(clinicianDb, "encounters", "encounter-a")));
  await assertFails(getDoc(doc(clinicianDb, "encounters", "encounter-b")));
  await assertSucceeds(
    updateDoc(doc(clinicianDb, "patients", patientAId), {
      fullName: "G001 Client A Updated",
      practiceId: practiceA,
      updatedAt: now,
    })
  );
  await assertFails(
    updateDoc(doc(clinicianDb, "patients", patientBId), {
      fullName: "G001 Client B Wrong Practice Update",
      practiceId: practiceB,
      updatedAt: now,
    })
  );

  // System admin boundary: no default client-record browsing, but admin governance collections remain available.
  await assertFails(getDoc(doc(adminDb, "patients", patientAId)));
  await assertFails(getDoc(doc(adminDb, "patientClinicalRecords", patientAId)));
  await assertFails(getDoc(doc(adminDb, "patientSummaries", patientAId)));
  await assertFails(getDoc(doc(adminDb, "encounters", "encounter-a")));
  await assertSucceeds(getDoc(doc(adminDb, "complianceProviders", "provider-a")));
  await assertFails(getDoc(doc(clinicianDb, "complianceProviders", "provider-a")));

  console.log("G001 role-based access rules validation passed.");
}

try {
  await main();
} finally {
  await testEnv.cleanup();
}
