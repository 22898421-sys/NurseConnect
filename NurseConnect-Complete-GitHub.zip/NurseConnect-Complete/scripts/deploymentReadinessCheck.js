#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = process.cwd();

function exists(relPath) {
  return fs.existsSync(path.join(root, relPath));
}

function readJson(relPath) {
  return JSON.parse(fs.readFileSync(path.join(root, relPath), "utf8"));
}

const packageJson = readJson("package.json");

const checks = [
  {
    label: "Firestore rules present",
    ok: exists("firestore.rules"),
    detail: "Required for access control and audit enforcement.",
  },
  {
    label: "Firebase config present",
    ok: exists("firebase.json"),
    detail: "Required for deployment target and emulator/runtime config.",
  },
  {
    label: "Functions source present",
    ok: exists("functions/index.js"),
    detail: "Required for callable workflows and production backend hooks.",
  },
  {
    label: "Build script configured",
    ok: Boolean(packageJson.scripts && packageJson.scripts.build),
    detail: "Required for production build verification.",
  },
  {
    label: "Local emulator workflow configured",
    ok: Boolean(packageJson.scripts && packageJson.scripts.emulators),
    detail: "Useful for release validation before deploy.",
  },
  {
    label: "Deployment script configured",
    ok:
      Boolean(packageJson.scripts && Object.keys(packageJson.scripts).find((key) => key.includes("deploy"))) ||
      exists(".firebaserc"),
    detail: "A deploy path or Firebase project mapping should be present.",
  },
  {
    label: "Access audit helper present",
    ok: exists("src/lib/accessAudit.ts"),
    detail: "Supports traceable sensitive-read and review activity.",
  },
  {
    label: "FHIR-lite export helper present",
    ok: exists("src/lib/fhirExport.ts"),
    detail: "Supports portability and integration demos.",
  },
];

const failures = checks.filter((check) => !check.ok);

console.log("EIRENIX deployment readiness check");
console.log("");
for (const check of checks) {
  console.log(`${check.ok ? "PASS" : "WARN"}  ${check.label}`);
  console.log(`      ${check.detail}`);
}

console.log("");
if (failures.length === 0) {
  console.log("Result: baseline repo readiness checks passed.");
  process.exit(0);
}

console.log(`Result: ${failures.length} readiness item(s) still need attention.`);
process.exit(1);
