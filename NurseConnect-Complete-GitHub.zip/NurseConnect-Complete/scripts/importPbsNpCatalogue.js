const fs = require("fs");
const path = require("path");

function usage() {
  console.error("Usage: node scripts/importPbsNpCatalogue.js <pbs-export.json|pbs-export.csv>");
}

function slugify(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 120);
}

function splitCsvLine(line) {
  const out = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === "\"") {
      if (inQuotes && line[i + 1] === "\"") {
        current += "\"";
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      out.push(current);
      current = "";
    } else {
      current += char;
    }
  }
  out.push(current);
  return out;
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = splitCsvLine(lines[0]).map((item) => item.trim());
  return lines.slice(1).map((line) => {
    const values = splitCsvLine(line);
    const row = {};
    headers.forEach((header, index) => {
      row[header] = values[index] || "";
    });
    return row;
  });
}

function firstValue(row, keys) {
  for (const key of keys) {
    if (row[key] !== undefined && String(row[key]).trim()) return String(row[key]).trim();
  }
  return "";
}

function isNpEligible(row) {
  const joined = Object.values(row)
    .map((value) => String(value || "").toUpperCase())
    .join(" ");
  return joined.includes(" NP ") || joined.includes("(NP)") || joined.includes("NURSE PRACTITIONER");
}

function normalizeRow(row) {
  const medicationName = firstValue(row, [
    "drug_name",
    "item_name",
    "mp_name",
    "prescriber_form_strength",
    "listed_drug",
    "drug",
  ]);
  if (!medicationName) return null;

  const form = firstValue(row, ["form", "form_strength", "dose_form", "mpp_form"]);
  const strength = firstValue(row, ["strength", "prescribing_text", "prescriber_form_strength", "item_form_strength"]);
  const route = firstValue(row, ["manner_of_administration", "route"]);
  const notes = firstValue(row, ["restriction", "restriction_text", "prescribing_note", "note"]);
  const idBase = firstValue(row, ["pbs_code", "item_code", "code", "schedule_code"]) || `${medicationName}-${strength}-${form}`;

  return {
    id: slugify(idBase),
    medicationName,
    form: form || undefined,
    strength: strength || undefined,
    route: route || undefined,
    defaultFrequency: undefined,
    notes: notes || undefined,
  };
}

function dedupe(items) {
  const seen = new Map();
  for (const item of items) {
    if (!item) continue;
    const key = item.id || slugify(`${item.medicationName}-${item.strength || ""}-${item.form || ""}`);
    if (!seen.has(key)) seen.set(key, { ...item, id: key });
  }
  return Array.from(seen.values()).sort((a, b) => a.medicationName.localeCompare(b.medicationName));
}

function main() {
  const inputPath = process.argv[2];
  if (!inputPath) {
    usage();
    process.exit(1);
  }

  const resolved = path.resolve(process.cwd(), inputPath);
  if (!fs.existsSync(resolved)) {
    console.error(`File not found: ${resolved}`);
    process.exit(1);
  }

  const raw = fs.readFileSync(resolved, "utf8");
  let rows;
  if (resolved.toLowerCase().endsWith(".json")) {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) rows = parsed;
    else if (Array.isArray(parsed.items)) rows = parsed.items;
    else if (Array.isArray(parsed.data)) rows = parsed.data;
    else throw new Error("Unsupported JSON shape. Expected an array or an object with items/data array.");
  } else if (resolved.toLowerCase().endsWith(".csv")) {
    rows = parseCsv(raw);
  } else {
    throw new Error("Unsupported file type. Use a JSON or CSV export.");
  }

  const items = dedupe(rows.filter((row) => row && typeof row === "object" && isNpEligible(row)).map(normalizeRow));

  const output = {
    source: {
      label: "PBS nurse practitioner listings",
      organisation: "Pharmaceutical Benefits Scheme (Australian Government)",
      browseUrl: "https://www.pbs.gov.au/browse/nurse",
      dataUrl: "https://www.pbs.gov.au/info/downloads/data",
      apiInfoUrl: "https://data.pbs.gov.au/document/91327.html",
      disclaimer:
        "Use the PBS nurse practitioner listings and current state, territory, and scope-of-practice rules to verify prescribing eligibility before issuing a prescription.",
    },
    generatedAt: new Date().toISOString(),
    itemCount: items.length,
    items,
  };

  const outPath = path.resolve(process.cwd(), "src/data/npMedicationCatalogue.json");
  fs.writeFileSync(outPath, `${JSON.stringify(output, null, 2)}\n`);
  console.log(`Wrote ${items.length} NP catalogue items to ${outPath}`);
}

main();
