#!/usr/bin/env node

/*
 * Backfill patient-facing summaries from the latest encounter SOAP Assessment + Plan.
 *
 * Usage:
 *   node scripts/backfillPatientSummariesFromEncounters.js [--dry-run] [--force] [--limit=100]
 *
 * Notes:
 * - Uses firebase-admin via functions/node_modules.
 * - Honors FIRESTORE_EMULATOR_HOST if set.
 */

const path = require("path");
const admin = require(path.join(__dirname, "..", "functions", "node_modules", "firebase-admin"));

const projectId =
  process.env.REACT_APP_FIREBASE_PROJECT_ID ||
  process.env.GCLOUD_PROJECT ||
  process.env.GOOGLE_CLOUD_PROJECT ||
  "eirenix-project";

const args = process.argv.slice(2);
const dryRun = args.includes("--dry-run");
const force = args.includes("--force");
const limitArg = args.find((a) => a.startsWith("--limit="));
const limit = limitArg ? Number(limitArg.split("=")[1]) : null;

if (!admin.apps.length) {
  admin.initializeApp({ projectId });
}

const db = admin.firestore();

function buildSummaryFromSoap(soap) {
  const assessment = String(soap?.assessment || "").trim();
  const plan = String(soap?.plan || "").trim();
  if (!assessment && !plan) return "";
  if (assessment && plan) return `Assessment:\n${assessment}\n\nPlan:\n${plan}`;
  if (assessment) return `Assessment:\n${assessment}`;
  return `Plan:\n${plan}`;
}

async function run() {
  const processedPatients = new Set();
  let scanned = 0;
  let updated = 0;
  let skippedExisting = 0;
  let skippedNoSoap = 0;
  let skippedNoPractice = 0;

  const baseQuery = db.collection("encounters").orderBy("createdAt", "desc").limit(500);
  let lastDoc = null;

  while (true) {
    const snap = lastDoc ? await baseQuery.startAfter(lastDoc).get() : await baseQuery.get();
    if (snap.empty) break;

    for (const docSnap of snap.docs) {
      scanned += 1;
      const data = docSnap.data() || {};
      const patientId = data.patientId;
      if (!patientId || processedPatients.has(patientId)) continue;

      const practiceId = String(data.practiceId || "").trim();
      if (!practiceId) {
        skippedNoPractice += 1;
        continue;
      }

      const summary = buildSummaryFromSoap(data.soap || {});
      if (!summary) {
        skippedNoSoap += 1;
        continue;
      }

      const summaryRef = db.collection("patientSummaries").doc(patientId);
      if (!force) {
        const existing = await summaryRef.get();
        if (existing.exists) {
          const existingSummary = String(existing.data()?.summary || "").trim();
          if (existingSummary) {
            skippedExisting += 1;
            processedPatients.add(patientId);
            continue;
          }
        }
      }

      if (!dryRun) {
        await summaryRef.set(
          {
            patientId,
            practiceId,
            summary,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            updatedByUid: "backfill_script",
            sourceEncounterId: docSnap.id,
          },
          { merge: true }
        );
      }

      updated += 1;
      processedPatients.add(patientId);

      if (limit && updated >= limit) {
        console.log(`Reached limit: ${limit}`);
        console.log(`Scanned: ${scanned}, Updated: ${updated}`);
        return;
      }
    }

    lastDoc = snap.docs[snap.docs.length - 1];
  }

  console.log("Backfill complete.");
  console.log(`Scanned: ${scanned}`);
  console.log(`Updated: ${updated}${dryRun ? " (dry-run)" : ""}`);
  console.log(`Skipped (existing summary): ${skippedExisting}`);
  console.log(`Skipped (no SOAP A/P): ${skippedNoSoap}`);
  console.log(`Skipped (no practiceId): ${skippedNoPractice}`);
}

run().catch((err) => {
  console.error("Backfill failed:", err);
  process.exit(1);
});
