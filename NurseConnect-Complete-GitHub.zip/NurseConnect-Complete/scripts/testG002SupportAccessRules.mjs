import fs from "node:fs";
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
} from "@firebase/rules-unit-testing";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  setDoc,
} from "firebase/firestore";

const projectId = "nurseconnectcare-g002";
const adminUid = "system-admin-g002";
const otherAdminUid = "other-system-admin-g002";
const clinicianUid = "clinician-g002";
const patientUid = "patient-user-g002";
const patientId = "patient-g002";
const requestId = "support-request-g002";
const encounterId = "encounter-g002";
const grantId = `${patientId}_${adminUid}`;

const now = new Date();
const future = new Date(Date.now() + 4 * 60 * 60 * 1000);
const past = new Date(Date.now() - 60 * 1000);

const testEnv = await initializeTestEnvironment({
  projectId,
  firestore: {
    rules: fs.readFileSync("firestore.rules", "utf8"),
    host: "127.0.0.1",
    port: 8380,
  },
});

async function seedBaseData() {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await setDoc(doc(db, "users", adminUid), { role: "system_admin", displayName: "G002 Admin" });
    await setDoc(doc(db, "users", otherAdminUid), { role: "system_admin", displayName: "Other Admin" });
    await setDoc(doc(db, "users", clinicianUid), {
      role: "clinician",
      displayName: "Provider Requester",
      practiceId: "practice-g002",
      practiceName: "G002 Practice",
    });
    await setDoc(doc(db, "users", patientUid), { role: "patient", patientId });
    await setDoc(doc(db, "patients", patientId), {
      userId: patientUid,
      displayName: "G002 Client",
      practiceId: "practice-g002",
    });
    await setDoc(doc(db, "encounters", encounterId), {
      patientId,
      practitionerId: clinicianUid,
      practiceId: "practice-g002",
      status: "completed",
      summary: "Restricted G002 encounter",
    });
  });
}

function adminDb() {
  return testEnv.authenticatedContext(adminUid).firestore();
}

function clinicianDb() {
  return testEnv.authenticatedContext(clinicianUid).firestore();
}

function otherAdminDb() {
  return testEnv.authenticatedContext(otherAdminUid).firestore();
}

async function main() {
  await testEnv.clearFirestore();
  await seedBaseData();

  const clinician = clinicianDb();
  const admin = adminDb();
  const otherAdmin = otherAdminDb();

  await assertFails(getDoc(doc(admin, "patients", patientId)));
  await assertFails(getDoc(doc(admin, "encounters", encounterId)));

  await assertSucceeds(
    setDoc(doc(clinician, "supportAccessRequests", requestId), {
      patientId,
      patientLabel: "G002 Client",
      practiceId: "practice-g002",
      practiceName: "G002 Practice",
      requesterUid: clinicianUid,
      requesterName: "Provider Requester",
      reason: "Troubleshooting client record issue for G002 validation",
      scope: "technical_troubleshooting",
      urgency: "routine",
      status: "requested",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    setDoc(doc(otherAdmin, "supportAccessGrants", `${patientId}_${adminUid}`), {
      requestId,
      patientId,
      adminUid,
      status: "active",
      reason: "Wrong admin cannot grant access for another admin",
      expiresAt: future,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    setDoc(doc(admin, "supportAccessGrants", grantId), {
      requestId,
      patientId,
      adminUid,
      status: "active",
      reason: "Approved for G002 troubleshooting validation",
      expiresAt: future,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(getDoc(doc(admin, "patients", patientId)));
  await assertSucceeds(getDoc(doc(admin, "encounters", encounterId)));

  await assertSucceeds(
    addDoc(collection(admin, "accessAuditLogs"), {
      actorUid: adminUid,
      role: "system_admin",
      action: "support_patient_record_access",
      resourceType: "patient",
      resourceId: patientId,
      patientId,
      supportAccessRequestId: requestId,
      reason: "Troubleshooting client record issue for G002 validation",
      occurredAt: now,
    })
  );

  await testEnv.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "supportAccessGrants", grantId), {
      requestId,
      patientId,
      adminUid,
      status: "active",
      reason: "Expired grant should deny access",
      expiresAt: past,
      createdAt: now,
      updatedAt: now,
    });
  });
  await assertFails(getDoc(doc(admin, "patients", patientId)));

  await testEnv.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), "supportAccessGrants", grantId), {
      requestId,
      patientId,
      adminUid,
      status: "revoked",
      reason: "Revoked grant should deny access",
      expiresAt: future,
      createdAt: now,
      updatedAt: now,
    });
  });
  await assertFails(getDoc(doc(admin, "patients", patientId)));

  console.log("G002 support-access rules validation passed.");
}

try {
  await main();
} finally {
  await testEnv.cleanup();
}
