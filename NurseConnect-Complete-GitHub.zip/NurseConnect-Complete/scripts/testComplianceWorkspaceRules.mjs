import fs from "node:fs";
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
} from "@firebase/rules-unit-testing";
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  query,
  setDoc,
  updateDoc,
} from "firebase/firestore";

const projectId = "nurseconnectcare-compliance";
const adminUid = "system-admin-compliance";
const clinicianUid = "clinician-compliance";
const patientUid = "patient-compliance";
const now = new Date();

const testEnv = await initializeTestEnvironment({
  projectId,
  firestore: {
    rules: fs.readFileSync("firestore.rules", "utf8"),
    host: "127.0.0.1",
    port: 8380,
  },
});

async function seedUsers() {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await setDoc(doc(db, "users", adminUid), { role: "system_admin", displayName: "Compliance Admin" });
    await setDoc(doc(db, "users", clinicianUid), { role: "clinician", displayName: "Compliance Clinician", practiceId: "practice-compliance" });
    await setDoc(doc(db, "users", patientUid), { role: "patient", patientId: "patient-compliance" });
  });
}

function adminDb() {
  return testEnv.authenticatedContext(adminUid).firestore();
}

function clinicianDb() {
  return testEnv.authenticatedContext(clinicianUid).firestore();
}

function patientDb() {
  return testEnv.authenticatedContext(patientUid).firestore();
}

function publicDb() {
  return testEnv.unauthenticatedContext().firestore();
}

async function main() {
  await testEnv.clearFirestore();
  await seedUsers();

  const admin = adminDb();
  const clinician = clinicianDb();
  const patient = patientDb();
  const anon = publicDb();

  const providerRef = doc(admin, "complianceProviders", "provider-compliance");
  const credentialRef = doc(admin, "complianceCredentials", "credential-compliance");
  const associatedRef = doc(admin, "associatedProviders", "associated-compliance");
  const incidentRef = doc(admin, "incidentComplaints", "incident-compliance");

  // Provider onboarding records: system-admin only, valid statuses only, no deletes.
  await assertSucceeds(setDoc(providerRef, {
    name: "Compliance Test Provider",
    registrationId: "REG-001",
    contactEmail: "provider@example.test",
    serviceCategories: ["Clinical supports"],
    status: "onboarding",
    createdAt: now,
    updatedAt: now,
  }));
  await assertSucceeds(getDoc(providerRef));
  await assertSucceeds(getDocs(query(collection(admin, "complianceProviders"), limit(20))));
  await assertSucceeds(updateDoc(providerRef, { status: "active", updatedAt: now }));
  await assertFails(setDoc(doc(admin, "complianceProviders", "bad-provider"), {
    name: "Bad Provider",
    status: "unreviewed",
    createdAt: now,
    updatedAt: now,
  }));
  await assertFails(getDoc(doc(clinician, "complianceProviders", "provider-compliance")));
  await assertFails(getDoc(doc(patient, "complianceProviders", "provider-compliance")));
  await assertFails(getDoc(doc(anon, "complianceProviders", "provider-compliance")));
  await assertFails(deleteDoc(providerRef));

  // Credential expiry tracking: system-admin only, valid subject/status fields only, no deletes.
  await assertSucceeds(setDoc(credentialRef, {
    subjectName: "Compliance Nurse",
    subjectType: "nurse",
    credentialType: "AHPRA registration",
    providerName: "Compliance Test Provider",
    expiryDate: "2026-12-31",
    status: "pending",
    evidenceReference: "AHPRA-CHECK-001",
    createdAt: now,
    updatedAt: now,
  }));
  await assertSucceeds(getDoc(credentialRef));
  await assertSucceeds(getDocs(query(collection(admin, "complianceCredentials"), limit(20))));
  await assertSucceeds(updateDoc(credentialRef, { status: "verified", updatedAt: now }));
  await assertFails(setDoc(doc(admin, "complianceCredentials", "bad-credential"), {
    subjectName: "Bad Credential",
    subjectType: "person",
    credentialType: "Unknown",
    status: "pending",
    createdAt: now,
    updatedAt: now,
  }));
  await assertFails(getDoc(doc(clinician, "complianceCredentials", "credential-compliance")));
  await assertFails(getDoc(doc(patient, "complianceCredentials", "credential-compliance")));
  await assertFails(getDoc(doc(anon, "complianceCredentials", "credential-compliance")));
  await assertFails(deleteDoc(credentialRef));

  // Associated-provider records: system-admin only, valid agreement statuses only, no deletes.
  await assertSucceeds(setDoc(associatedRef, {
    organisationName: "Compliance Associated Provider",
    providerName: "Compliance Test Provider",
    contactEmail: "associated@example.test",
    serviceCategory: "Clinical supports",
    agreementStatus: "pending",
    insuranceExpiry: "2026-12-31",
    screeningStatus: "Pending",
    createdAt: now,
    updatedAt: now,
  }));
  await assertSucceeds(getDoc(associatedRef));
  await assertSucceeds(getDocs(query(collection(admin, "associatedProviders"), limit(20))));
  await assertSucceeds(updateDoc(associatedRef, { agreementStatus: "approved", updatedAt: now }));
  await assertFails(setDoc(doc(admin, "associatedProviders", "bad-associated"), {
    organisationName: "Bad Associated Provider",
    agreementStatus: "unknown",
    createdAt: now,
    updatedAt: now,
  }));
  await assertFails(getDoc(doc(clinician, "associatedProviders", "associated-compliance")));
  await assertFails(getDoc(doc(patient, "associatedProviders", "associated-compliance")));
  await assertFails(getDoc(doc(anon, "associatedProviders", "associated-compliance")));
  await assertFails(deleteDoc(associatedRef));

  // Incident/complaint workflow: system-admin only, valid type/severity/status fields only, no deletes.
  await assertSucceeds(setDoc(incidentRef, {
    type: "complaint",
    title: "Compliance Test Complaint",
    providerName: "Compliance Test Provider",
    participantReference: "Participant-001",
    severity: "medium",
    status: "open",
    owner: "Compliance Admin",
    dueDate: "2026-07-01",
    summary: "Test complaint record",
    createdAt: now,
    updatedAt: now,
  }));
  await assertSucceeds(getDoc(incidentRef));
  await assertSucceeds(getDocs(query(collection(admin, "incidentComplaints"), limit(20))));
  await assertSucceeds(updateDoc(incidentRef, { status: "in_review", updatedAt: now }));
  await assertFails(setDoc(doc(admin, "incidentComplaints", "bad-incident"), {
    type: "event",
    title: "Bad Incident",
    severity: "medium",
    status: "open",
    createdAt: now,
    updatedAt: now,
  }));
  await assertFails(getDoc(doc(clinician, "incidentComplaints", "incident-compliance")));
  await assertFails(getDoc(doc(patient, "incidentComplaints", "incident-compliance")));
  await assertFails(getDoc(doc(anon, "incidentComplaints", "incident-compliance")));
  await assertFails(deleteDoc(incidentRef));

  console.log("Compliance workspace rules validation passed.");
}

try {
  await main();
} finally {
  await testEnv.cleanup();
}
