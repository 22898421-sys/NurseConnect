import fs from "fs/promises";
import path from "path";

const root = path.resolve(".");
const buildDir = path.join(root, "build");
const assetsDir = path.join(buildDir, "onboarding-assets");
const htmlPath = path.join(buildDir, "TRIAL_ONBOARDING_GUIDE.html");

const logoPath = path.join(buildDir, "eirenix-logo.png");

function rel(file) {
  return path.relative(buildDir, file).split(path.sep).join("/");
}

function sectionImage(file, alt) {
  return `
    <div class="image-block">
      <img src="${rel(path.join(assetsDir, file))}" alt="${alt}" />
      <div class="caption">${alt}</div>
    </div>
  `;
}

const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>EIRENIX Trial Onboarding Guide</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      color: #1d2733;
      margin: 36px;
      line-height: 1.45;
    }
    h1, h2, h3 {
      color: #12374a;
      margin-bottom: 10px;
    }
    h1 {
      font-size: 24pt;
      margin-top: 0;
    }
    h2 {
      font-size: 16pt;
      border-bottom: 1px solid #d6e2e8;
      padding-bottom: 6px;
      margin-top: 28px;
    }
    h3 {
      font-size: 12pt;
      margin-top: 18px;
    }
    p, li {
      font-size: 10.5pt;
    }
    ul, ol {
      margin-top: 6px;
      margin-bottom: 10px;
    }
    .cover {
      text-align: center;
      margin-bottom: 28px;
    }
    .cover img {
      max-width: 260px;
      height: auto;
      margin-bottom: 14px;
    }
    .note {
      background: #eef7f7;
      border: 1px solid #c8e4e2;
      padding: 10px 12px;
      border-radius: 8px;
      margin: 12px 0;
    }
    .image-block {
      margin: 16px 0 22px;
      page-break-inside: avoid;
    }
    .image-block img {
      width: 100%;
      max-width: 720px;
      border: 1px solid #d6e2e8;
      border-radius: 8px;
    }
    .caption {
      font-size: 9pt;
      color: #567;
      margin-top: 6px;
    }
    .small {
      font-size: 9pt;
      color: #567;
    }
  </style>
</head>
<body>
  <div class="cover">
    <img src="${rel(logoPath)}" alt="EIRENIX logo" />
    <h1>EIRENIX Trial Onboarding Guide</h1>
    <p>Practice Admin, Clinician, and Patient trial onboarding</p>
    <p class="small">Prepared on 09-03-2026</p>
  </div>

  <h2>1. Purpose</h2>
  <p>This guide helps trial users enter EIRENIX and test the main workflows for their role. It is written for short-term evaluation use.</p>

  <h2>2. Sign-In</h2>
  <p>Users can either log in with an existing email and password or accept an invite. For this trial, seeded test accounts already exist for each role.</p>
  ${sectionImage("login-page.png", "EIRENIX login page")}

  <h2>3. Practice Admin</h2>
  <p>The Practice Admin is responsible for practice details, invites, operational setup, appointments, rosters, and billing oversight.</p>
  <h3>First steps</h3>
  <ol>
    <li>Log in with your practice admin account.</li>
    <li>Review and confirm practice details.</li>
    <li>Create clinician and patient invites if needed.</li>
    <li>Review appointments, rosters, and billing pages.</li>
  </ol>
  ${sectionImage("practice-admin-dashboard.png", "Practice Admin dashboard")}
  <div class="note">
    <strong>What to test:</strong>
    <ul>
      <li>Practice details save correctly.</li>
      <li>Invites are created successfully.</li>
      <li>Appointments and rosters are visible.</li>
      <li>Users appear linked to the correct practice.</li>
    </ul>
  </div>

  <h2>4. Clinician</h2>
  <p>The Clinician uses EIRENIX for schedule review, patient chart access, SOAP documentation, telehealth, and structured clinical actions.</p>
  <h3>First steps</h3>
  <ol>
    <li>Log in with your clinician account.</li>
    <li>Review upcoming tasks and appointments.</li>
    <li>Open a patient chart and create or review an encounter.</li>
    <li>Enter SOAP notes and create structured clinical actions.</li>
  </ol>
  ${sectionImage("clinician-schedule.png", "Clinician schedule and tasks page")}
  <div class="note">
    <strong>What to test:</strong>
    <ul>
      <li>SOAP notes save and remain visible.</li>
      <li>Lab, imaging, referral, prescription, and medical certificate actions work.</li>
      <li>Print documents show the clinician and practice clearly.</li>
      <li>Telehealth loads if part of the trial.</li>
    </ul>
  </div>

  <h2>5. Patient</h2>
  <p>The Patient uses EIRENIX for portal access, appointments, clinical documents, billing visibility, and self-booking where enabled.</p>
  <h3>First steps</h3>
  <ol>
    <li>Log in with your patient account.</li>
    <li>Review the patient portal sections.</li>
    <li>Check appointments and documents.</li>
    <li>Try self-booking if available in the trial environment.</li>
  </ol>
  ${sectionImage("patient-portal.png", "Patient portal")}
  <div class="note">
    <strong>What to test:</strong>
    <ul>
      <li>Patient portal loads without errors.</li>
      <li>Clinician names display properly when booking.</li>
      <li>Patient-facing documents are readable and simplified.</li>
      <li>Billing and consent sections load where records exist.</li>
    </ul>
  </div>

  <h2>6. Reporting Issues</h2>
  <p>When raising a problem, please include the role, page, action attempted, exact error message, and whether anything appeared to save anyway. Screenshots are helpful.</p>

  <h2>7. Trial Accounts Used For Screenshots</h2>
  <ul>
    <li>Practice Admin: Kefilwe Sechele</li>
    <li>Clinician: Dr Thato Mooketsi</li>
    <li>Patient: Boitumelo Moalosi</li>
  </ul>
</body>
</html>`;

await fs.writeFile(htmlPath, html, "utf8");
console.log(`Wrote ${htmlPath}`);
