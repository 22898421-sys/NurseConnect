#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = process.cwd();
const projectId = process.env.GCLOUD_PROJECT || process.env.GOOGLE_CLOUD_PROJECT || "eirenix-project";
const emulatorHost = process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8280";

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function toDate(value) {
  if (!value) return null;
  if (typeof value.toDate === "function") return value.toDate();
  if (typeof value.seconds === "number") return new Date(value.seconds * 1000);
  return null;
}

function ageInDays(value) {
  const date = toDate(value);
  if (!date) return null;
  return Math.floor((Date.now() - date.getTime()) / (24 * 60 * 60 * 1000));
}

function preferLocalEmulatorIfNeeded() {
  const hasExplicitCredentials =
    Boolean(process.env.GOOGLE_APPLICATION_CREDENTIALS) ||
    Boolean(process.env.FIRESTORE_EMULATOR_HOST) ||
    Boolean(process.env.FIREBASE_CONFIG);

  if (!hasExplicitCredentials) {
    process.env.FIRESTORE_EMULATOR_HOST = emulatorHost;
    process.env.GCLOUD_PROJECT = projectId;
    process.env.GOOGLE_CLOUD_PROJECT = projectId;
  }
}

async function main() {
  preferLocalEmulatorIfNeeded();
  const admin = require(path.join(root, "functions", "node_modules", "firebase-admin"));
  if (!admin.apps.length) {
    admin.initializeApp({ projectId });
  }
  const db = admin.firestore();

  const configSnap = await db.collection("config").doc("app").get();
  const config = configSnap.exists ? configSnap.data() || {} : {};
  const retentionPolicy = {
    accessAuditDays: Number(config?.retentionPolicy?.accessAuditDays) || 365,
    consentEventDays: Number(config?.retentionPolicy?.consentEventDays) || 2555,
    patientSummaryRevisionDays: Number(config?.retentionPolicy?.patientSummaryRevisionDays) || 365,
  };

  const [accessSnap, consentSnap, summaryRevisionSnap] = await Promise.all([
    db.collection("accessAuditLogs").orderBy("occurredAt", "desc").limit(500).get(),
    db.collectionGroup("events").orderBy("occurredAt", "desc").limit(500).get(),
    db.collectionGroup("revisions").orderBy("editedAt", "desc").limit(500).get(),
  ]);

  const accessCandidates = accessSnap.docs
    .map((doc) => ({ id: doc.id, ...doc.data() }))
    .filter((row) => {
      const age = ageInDays(row.occurredAt);
      return age != null && age > retentionPolicy.accessAuditDays;
    })
    .slice(0, 50);

  const consentCandidates = consentSnap.docs
    .map((doc) => ({ id: doc.id, ...doc.data() }))
    .filter((row) => ["signed", "withdrawn", "updated"].includes(String(row.type || "")))
    .filter((row) => {
      const age = ageInDays(row.occurredAt);
      return age != null && age > retentionPolicy.consentEventDays;
    })
    .slice(0, 50);

  const summaryRevisionCandidates = summaryRevisionSnap.docs
    .map((doc) => ({ id: doc.id, path: doc.ref.path, ...doc.data() }))
    .filter((row) => row.path.startsWith("patientSummaries/"))
    .filter((row) => {
      const age = ageInDays(row.editedAt);
      return age != null && age > retentionPolicy.patientSummaryRevisionDays;
    })
    .slice(0, 50);

  const report = {
    generatedAt: new Date().toISOString(),
    projectId,
    retentionPolicy,
    candidates: {
      accessAuditLogs: accessCandidates,
      consentEvents: consentCandidates,
      patientSummaryRevisions: summaryRevisionCandidates,
    },
    counts: {
      accessAuditLogs: accessCandidates.length,
      consentEvents: consentCandidates.length,
      patientSummaryRevisions: summaryRevisionCandidates.length,
    },
  };

  const outputDir = path.join(root, "local-artifacts");
  ensureDir(outputDir);
  const outputPath = path.join(outputDir, "retention-dry-run.json");
  fs.writeFileSync(outputPath, JSON.stringify(report, null, 2));

  console.log("EIRENIX retention dry-run");
  console.log("");
  console.log(`Generated: ${report.generatedAt}`);
  console.log(`Output: ${outputPath}`);
  console.log(`Firestore target: ${process.env.FIRESTORE_EMULATOR_HOST ? `emulator ${process.env.FIRESTORE_EMULATOR_HOST}` : "application default credentials"}`);
  console.log(`Access audit candidates: ${report.counts.accessAuditLogs}`);
  console.log(`Consent event candidates: ${report.counts.consentEvents}`);
  console.log(`Patient summary revision candidates: ${report.counts.patientSummaryRevisions}`);
}

main().catch((error) => {
  console.error(error?.message || error);
  process.exit(1);
});
