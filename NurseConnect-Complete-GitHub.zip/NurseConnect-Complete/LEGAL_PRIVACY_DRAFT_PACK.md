# Legal and Privacy Draft Pack

Date: 2026-06-18

This pack prepares review-ready draft operating content for NurseConnectCare. It is not legal advice and must be reviewed by an Australian privacy/legal advisor before public production launch.

NurseConnectCare is positioned as connector and workflow infrastructure for independent nurses, clients/carers, care managers, and registered provider workflows. NurseConnectCare does not employ nurses, act as the care provider, approve Support at Home eligibility, submit claims, process payments, or hold client funds.

## Covered Tracker Items

This pack supports draft progress on:

- `T029` - Prepare Final Terms of Use
- `T030` - Prepare Final Privacy Policy
- `T031` - Prepare Nurse/provider participation terms
- `T032` - Prepare Support access SOP
- `T033` - Prepare Incident and complaint SOP
- `T034` - Prepare Data retention policy
- `T035` - Prepare Breach response procedure
- `T036` - Prepare Provider/subcontractor responsibility statement
- `T040` - Document support/admin access procedure
- `T041` - Assign incident and complaint owners and targets

Do not mark the final/legal sign-off tasks complete until external review is recorded.

## Draft Terms of Use Outline

Final Terms of Use should cover:

1. Platform role and infrastructure-only positioning.
2. Independent nurse/provider responsibilities.
3. Client/carer, provider, care-manager, and funder request pathways.
4. No employment, agency, clinical supervision, claim submission, payment handling, or eligibility approval by NurseConnectCare.
5. Account access, role-based access, and acceptable use.
6. Service requests, bookings, evidence packs, and communication boundaries.
7. Nurse-owned billing/evidence records and relay-only support.
8. Provider and care-manager responsibilities for care-plan/funding decisions.
9. User obligations for accurate information, privacy, and lawful use.
10. Incident, complaint, support, and troubleshooting procedures.
11. Intellectual property and platform content.
12. Limitations, disclaimers, suspension/termination, governing law, and contact details.

Current implementation note:

- `src/components/TermsPage.tsx` is still marked as placeholder and must be replaced after review.

## Draft Privacy Policy Outline

Final Privacy Policy should cover:

1. Information collected:
   - contact and enquiry information
   - nurse registration interest details
   - account and role information
   - provider/service request details
   - client/carer records where account workflows are used
   - clinical, billing, evidence, support, audit, compliance, incident, and complaint records where applicable
2. Why information is collected and used:
   - operating the platform
   - routing care/service requests
   - supporting accounts and subscriptions
   - enabling nurse documentation and evidence packs
   - managing compliance and support workflows
   - maintaining audit/security logs
3. Health information and sensitive information handling.
4. Australian Privacy Principles and health-record privacy considerations for Australian users.
5. Disclosure boundaries:
   - independent nurses
   - clients/carers
   - providers/care managers/funders
   - support/admin users under restricted circumstances
   - legal/regulatory or safety requirements
6. Admin access restrictions and support-access audit controls.
7. Data retention, correction, access requests, and complaints.
8. Overseas disclosure/cloud service considerations.
9. Security controls and limitations.
10. Contact and privacy complaint pathway.

Current implementation note:

- `src/components/PrivacyPolicyPage.tsx` is still marked as placeholder and must be replaced after review.

## Draft Nurse/Provider Participation Terms

Nurse/provider participation terms should state that:

- nurses operate independently and are responsible for their own professional registration, scope, insurance, clinical judgement, documentation, service pricing, service acceptance, and care delivery
- NurseConnectCare provides workflow infrastructure, not employment, supervision, or clinical direction
- nurses must keep registration, credentials, service profile, billing profile, and contact details accurate
- nurses must comply with applicable professional, privacy, health-record, incident, complaint, and care documentation obligations
- providers/care managers/funders remain responsible for care-plan, funding, authorisation, and Support at Home decisions where applicable
- users must not upload unnecessary sensitive information into public forms
- evidence packs are prepared for relay on the nurse's instruction and do not represent claim approval
- support access to client records must be requested, scoped, time-limited, and audited
- breaches, incidents, complaints, or access concerns must be escalated through the published support pathway

## Support Access SOP

Support/admin users must not browse client records by default.

Approved support access procedure:

1. Clinician/provider user identifies a specific support need.
2. Clinician/provider submits support access request with:
   - client record ID
   - client label
   - reason
   - scope
   - urgency
3. System admin reviews the request from `/support-access`.
4. System admin approves only where the request is specific, necessary, and proportionate.
5. Approval creates a time-limited support grant assigned to the acting admin.
6. Before loading the client record, the admin writes an access audit log.
7. Admin performs only the troubleshooting activity described in the request.
8. Admin revokes or closes the grant when no longer needed.
9. Any concern is recorded as an incident/complaint or known issue.

Existing evidence:

- `G002_SUPPORT_ACCESS_SIGNOFF.md`
- `SECURITY_RULES_TEST_SUITE.md`
- `ONBOARDING_AND_SUPPORT_REHEARSAL_PACK.md`

## Incident and Complaint SOP

Incident/complaint handling procedure:

1. Create an `incidentComplaints` record in `/compliance`.
2. Record:
   - type: incident or complaint
   - title
   - provider context
   - participant/client reference where appropriate
   - severity
   - status
   - owner
   - due date
   - summary
3. Triage severity:
   - Critical: same day
   - High: 1 business day
   - Medium: 3 business days
   - Low: 5 business days
4. Escalate privacy, client safety, unauthorised access, or regulatory-risk matters to the founder plus legal/privacy or clinical governance advisor.
5. Record decisions, remediation, communications, and closure notes.
6. Keep systemic issues in the known-issues register.

Existing evidence:

- `COMPLIANCE_OPERATIONS_RUNBOOK.md`
- `COMPLIANCE_WORKFLOW_VALIDATION.md`

## Data Retention Policy Draft

Draft retention principles:

- retain records only for a lawful and operationally necessary purpose
- avoid collecting sensitive details in public forms where not required
- preserve audit logs for support access, clinical record activity, and compliance actions
- block routine deletion of compliance, support access, and audit records
- use controlled exports or retention reviews before deletion or archival
- review retention obligations for health information, billing/evidence records, incident/complaint records, and business/account records before production

Record categories requiring final retention rules:

| Category | Examples | Draft posture |
|---|---|---|
| Account/role records | `users`, `practices` | retain while account active plus legal/business retention period |
| Client/clinical records | `patients`, `patientClinicalRecords`, `encounters`, `patientSummaries` | retain according to health-record obligations after legal review |
| Billing/evidence records | `serviceInvoices`, `invoices`, evidence packs | retain for tax/business/provider evidence obligations |
| Compliance records | providers, credentials, associated providers, incidents/complaints | retain for governance/audit period |
| Support access records | requests, grants, access audit logs | retain for audit, privacy, and security review |
| Public enquiries | contact and nurse-registration interests | retain only as long as operationally needed unless converted into account/business records |

Existing technical support:

- `scripts/retentionDryRun.js`
- `scripts/complianceReport.js`

## Breach Response Procedure Draft

Potential breach or unauthorised access procedure:

1. Identify and contain:
   - suspend access if needed
   - revoke support grants if relevant
   - preserve logs and affected record IDs
2. Assess:
   - what information was involved
   - whether health/sensitive information was involved
   - who was affected
   - likelihood of serious harm
   - whether the incident is notifiable
3. Escalate:
   - Founder
   - Support/Admin Lead
   - Legal/Privacy Advisor
   - Clinical Governance Lead where client safety or clinical records are involved
4. Remediate:
   - fix access/configuration issue
   - update rules/workflows where needed
   - document corrective action
5. Notify:
   - affected people, providers, or authorities if required after legal/privacy advice
6. Record:
   - incident/complaint record
   - known issue if systemic
   - closure note and prevention action

## Provider/Subcontractor Responsibility Statement Draft

Responsibility boundaries:

- registered providers/care managers/funders retain responsibility for care-plan, funding, authorisation, and Support at Home decisions where applicable
- independent nurses retain responsibility for care delivery, clinical scope, professional judgement, documentation, billing decisions, and insurance
- associated providers/suppliers retain responsibility for their own credentials, insurance, screening, services, and legal obligations
- NurseConnectCare provides routing, records, workflow, evidence, and support infrastructure
- NurseConnectCare does not become the employer, clinical supervisor, registered provider, claim approver, or funds handler by providing the platform

## Owners and Response Targets

Owner placeholders are prepared but must be replaced with named people before production launch.

| Area | Draft owner role | Target |
|---|---|---|
| Privacy/legal concern | Legal/Privacy Advisor plus Founder | same day for critical/high |
| Clinical governance concern | Clinical Governance Lead plus Founder | same day for critical/high |
| Support/admin workflow issue | Support/Admin Lead | 1 business day for high |
| Provider/credential issue | Operations Lead | 1 business day for high |
| Technical access/rules issue | Engineering plus Founder | same day for critical |
| Public enquiry issue | Support/Admin Lead | 3 business days unless urgent |

## External Review Gates

Still required:

- Australian privacy/legal review
- aged care / Support at Home regulatory review if available
- final wording updates to public Terms and Privacy pages
- named owner confirmation
- production release decision

