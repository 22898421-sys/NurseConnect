module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          900: "#112F2D",
          700: "#1F746B",
          500: "#2F8C80",
          200: "#A8D9CE",
          50: "#DFF1EC",
        },
        ink: {
          900: "#173B39",
          700: "#254D49",
          500: "#627874",
          200: "#D7E5E1",
        },
        sand: {
          100: "#FBFAF6",
          200: "#F2F8F6",
        },
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui"],
        serif: ["Inter", "ui-sans-serif", "system-ui"],
      },
      boxShadow: {
        soft: "0 12px 34px -18px rgba(20,70,64,0.28)",
        lift: "0 24px 70px -28px rgba(20,70,64,0.38)",
      },
      borderRadius: {
        xl: "18px",
      },
    },
  },
  plugins: [],
}
