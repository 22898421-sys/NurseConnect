# Telehealth Deployment Checklist

This checklist is for deployment testing of the current Jitsi-based telehealth flow in `EIRENIX Care™`.

## Current implementation

- Video calls currently use Jitsi in an iframe.
- Default domain: `meet.jit.si`
- Room naming is appointment-based.
- Provider selection is controlled by:

```bash
REACT_APP_VIDEO_PROVIDER=jitsi
REACT_APP_JITSI_DOMAIN=meet.jit.si
REACT_APP_JITSI_ROOM_PREFIX=healthful
```

Relevant code:

- [src/components/VideoCallPage.tsx](src/components/VideoCallPage.tsx)
- [src/components/JitsiVideoRoom.tsx](src/components/JitsiVideoRoom.tsx)
- [src/lib/video.ts](src/lib/video.ts)

## Must-have deployment conditions

1. Deploy over `https`
- Browser camera/microphone access is not reliable for production-like testing without HTTPS.

2. Do not block Jitsi in headers or CSP
- If you later add a Content Security Policy, allow:
  - `frame-src https://meet.jit.si`
  - `connect-src https://meet.jit.si wss://meet.jit.si`
  - `script-src` and `img-src` allowances if you later move beyond the plain iframe model

3. Confirm route access works live
- Nurse: `/call/:appointmentId`
- Patient: `/call/:appointmentId`
- Both sides must land in the same appointment-linked room

4. Confirm browser permissions
- Chrome desktop
- Safari desktop
- iPhone Safari
- Android Chrome

## Deployment test flow

1. Create a real video appointment in the deployed environment.
2. Log in as the nurse in one browser.
3. Log in as the patient in another browser or device.
4. Open the same appointment join route on both sides.
5. Confirm:
- camera permission prompt appears
- microphone permission prompt appears
- both participants join the same room
- two-way audio works
- two-way video works
- nurse can still save notes during the call
- ending the consultation still works

## Recommended checks during testing

- Test on separate networks if possible
- Test with one device on mobile data
- Test join-link sending by SMS/email from the nurse workflow
- Test what happens if one party joins early
- Test what happens if browser permission is denied first and then re-enabled

## Current limitations

- No custom Jitsi branding
- No JWT-secured rooms
- No host/moderator enforcement
- No waiting-room flow
- No Jitsi webhook/event audit integration
- No recording controls

## Recommended next step after basic deployment testing

If deployment testing succeeds, decide whether to:

1. Keep `meet.jit.si` temporarily for pilot use, or
2. Move to a managed/private Jitsi deployment with stronger control over:
- branding
- room access
- moderation
- auditability
- operational reliability
