import imagingPlaybookCatalog from "./imagingPlaybookCatalog.json";

type ImagingPlaybookRow = {
  longName: string;
  shortName: string;
  modality: string;
  bodyRegion: string;
  bodyRegion2: string;
  anatomicFocus: string;
  laterality: string;
  technique: string;
  pharmaceutical: string;
};

export const IMAGING_PLAYBOOK_STUDIES = imagingPlaybookCatalog as ImagingPlaybookRow[];

export const COMMON_IMAGING_STUDIES = [
  "CT Head wo IV Contrast",
  "CT Chest w IV Contrast",
  "CT Abdomen/Pelvis w IV Contrast",
  "US Abdomen",
  "US Pelvis",
  "XR Chest 2 Views",
  "XR Knee 3 Views",
  "MR Lumbar Spine wo IV Contrast",
  "CT Abdomen wo  IV Contrast",
  "XR Shoulder 2+ Views",
] as const;

function normalizeImagingText(value: string) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

export const ALL_IMAGING_STUDY_NAMES = IMAGING_PLAYBOOK_STUDIES.map((item) => item.longName);

export const IMAGING_STUDY_BY_SEARCH_KEY = Object.fromEntries(
  IMAGING_PLAYBOOK_STUDIES.flatMap((item) => {
    const pairs: Array<readonly [string, ImagingPlaybookRow]> = [[normalizeImagingText(item.longName), item]];
    if (item.shortName) pairs.push([normalizeImagingText(item.shortName), item]);
    return pairs;
  })
) as Record<string, ImagingPlaybookRow>;

export function resolveImagingStudy(input: string) {
  return IMAGING_STUDY_BY_SEARCH_KEY[normalizeImagingText(input)] || null;
}
