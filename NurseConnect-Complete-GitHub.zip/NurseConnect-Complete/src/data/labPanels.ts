// Source: build/RCPA-Top-50-Priority-Tests-for-SPIA-adoption-v1-1.xlsx
// Column used: "RCPA SPIA Preferred term"

export const RCPA_SPIA_LAB_PANELS = [
  { term: "ACTH", specimen: "Serum", synonyms: [] },
  { term: "Albumin:creatinine ratio", specimen: "Urine", synonyms: ["Urine ACR", "ACR"] },
  { term: "Antinuclear Ab", specimen: "Serum", synonyms: ["ANA", "Antinuclear antibody"] },
  { term: "Beta HCG quantitation", specimen: "Serum;Plasma", synonyms: ["Beta HCG", "Quantitative beta HCG"] },
  { term: "Blood culture", specimen: "Whole blood", synonyms: ["Blood cultures"] },
  { term: "Blood gas arterial", specimen: "Arterial Blood", synonyms: ["ABG", "Arterial blood gas"] },
  { term: "Blood group and antibody screen", specimen: "Whole blood", synonyms: ["Group and screen"] },
  { term: "Calcium ionised", specimen: "Serum", synonyms: ["Ionised calcium"] },
  { term: "Calcium Magnesium Phosphate", specimen: "Serum", synonyms: ["CMP", "Calcium magnesium phosphate"] },
  { term: "Cervical Co-test", specimen: "Cervix swab", synonyms: ["Cervical cotest", "Pap and HPV"] },
  { term: "Coagulation profile", specimen: "Plasma", synonyms: ["Coags", "Clotting profile"] },
  { term: "Cortisol", specimen: "Serum", synonyms: [] },
  { term: "C-reactive protein", specimen: "Serum", synonyms: ["CRP"] },
  { term: "Creatine kinase", specimen: "Serum", synonyms: ["CK"] },
  { term: "D-dimer", specimen: "Platelet poor plasma", synonyms: ["D dimer"] },
  { term: "Digoxin level", specimen: "Serum", synonyms: ["Digoxin"] },
  { term: "Electrolytes Urea Creatinine", specimen: "Serum", synonyms: ["U&E", "Urea and electrolytes", "U&E / Creatinine", "UEC"] },
  { term: "Erythrocyte sedimentation rate", specimen: "Whole blood", synonyms: ["ESR"] },
  { term: "Follicle stimulating hormone", specimen: "Serum", synonyms: ["FSH"] },
  { term: "Free T4", specimen: "Serum", synonyms: ["FT4"] },
  { term: "Full blood count", specimen: "Whole blood", synonyms: ["FBC", "CBC", "Complete blood count"] },
  { term: "Glucose fasting", specimen: "Serum;Plasma", synonyms: ["Fasting glucose", "Fasting blood glucose"] },
  { term: "Glucose random", specimen: "Serum;Plasma", synonyms: ["Random glucose", "Random blood glucose"] },
  { term: "HbA1c", specimen: "Whole blood", synonyms: ["A1c", "Glycated haemoglobin"] },
  { term: "Hepatitis B surface Ab", specimen: "Serum", synonyms: ["HBsAb", "Hep B surface antibody"] },
  { term: "Histology", specimen: "Tissue", synonyms: [] },
  { term: "HIV serology", specimen: "Serum", synonyms: ["HIV test"] },
  { term: "INR", specimen: "Plasma", synonyms: ["International normalized ratio"] },
  { term: "Iron studies", specimen: "Serum", synonyms: [] },
  { term: "Lipase", specimen: "Serum", synonyms: [] },
  { term: "Lipids fasting", specimen: "Serum", synonyms: ["Fasting lipids", "Fasting lipid profile", "Lipid profile"] },
  { term: "Lipids random", specimen: "Serum", synonyms: ["Random lipids", "Random lipid profile"] },
  { term: "Liver function tests", specimen: "Serum", synonyms: ["LFT", "LFTs"] },
  { term: "Luteinising hormone", specimen: "Serum", synonyms: ["LH"] },
  { term: "MCS genital", specimen: "Genital swab;Vaginal swab", synonyms: ["Genital MCS"] },
  { term: "MCS urine", specimen: "Urine", synonyms: ["Urine MCS", "MCS"] },
  { term: "Neisseria gonorrhoea nucleic acid", specimen: "Any", synonyms: ["Gonorrhoea NAAT", "Gonorrhea NAAT"] },
  { term: "Paracetamol level", specimen: "Serum", synonyms: ["Paracetamol"] },
  { term: "Parathyroid hormone", specimen: "Serum", synonyms: ["PTH"] },
  { term: "Prostate specific antigen", specimen: "Serum;Plasma", synonyms: ["PSA"] },
  { term: "Prothrombin time", specimen: "Plasma", synonyms: ["PT"] },
  { term: "Rheumatoid factor", specimen: "Serum", synonyms: ["RF"] },
  { term: "SARS-CoV-2 nucleic acid", specimen: "Any", synonyms: ["COVID PCR", "SARS-CoV-2 PCR"] },
  { term: "SARS-CoV-2 serology", specimen: "Any", synonyms: ["COVID serology"] },
  { term: "Testosterone", specimen: "Serum", synonyms: [] },
  { term: "Thyroid function tests", specimen: "Serum", synonyms: ["TFT", "TFTs"] },
  { term: "Thyroid stimulating hormone", specimen: "Serum", synonyms: ["TSH"] },
  { term: "Urate", specimen: "Serum", synonyms: ["Uric acid"] },
  { term: "Vitamin B12", specimen: "Serum", synonyms: ["B12"] },
  { term: "Vitamin D", specimen: "Serum", synonyms: [] },
] as const;

const COMMON_PRIMARY_CARE_LAB_PANELS = [
  "Full blood count",
  "Electrolytes Urea Creatinine",
  "Liver function tests",
  "HbA1c",
  "Lipids fasting",
  "Thyroid function tests",
  "Albumin:creatinine ratio",
  "MCS urine",
  "C-reactive protein",
  "Coagulation profile",
] as const;

export const COMMON_LAB_PANELS = [...COMMON_PRIMARY_CARE_LAB_PANELS];

export const ALL_LAB_PANELS = RCPA_SPIA_LAB_PANELS.map((item) => item.term);

export const LAB_PANEL_SPECIMEN_BY_TERM = Object.fromEntries(
  RCPA_SPIA_LAB_PANELS.map((item) => [item.term, item.specimen])
) as Record<string, string>;

function normalizeLabText(value: string) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

export const LAB_PANEL_BY_SEARCH_KEY = Object.fromEntries(
  RCPA_SPIA_LAB_PANELS.flatMap((item) => [
    [normalizeLabText(item.term), item.term],
    ...item.synonyms.map((synonym) => [normalizeLabText(synonym), item.term] as const),
  ])
) as Record<string, string>;

export function resolvePreferredLabPanelTerm(input: string) {
  return LAB_PANEL_BY_SEARCH_KEY[normalizeLabText(input)] || "";
}
