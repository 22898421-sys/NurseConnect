export const NURSE_TYPE_OPTIONS = [
  {
    value: "EN",
    label: "Enrolled Nurse (EN)",
    professionalRole: "Enrolled nurse",
    monthlyFeeCents: 5000,
    requiresAhpra: true,
  },
  {
    value: "RN",
    label: "Registered Nurse (RN)",
    professionalRole: "Registered nurse",
    monthlyFeeCents: 5000,
    requiresAhpra: true,
  },
  {
    value: "NP",
    label: "Nurse Practitioner (NP)",
    professionalRole: "Nurse practitioner",
    monthlyFeeCents: 5500,
    requiresAhpra: true,
  },
] as const;

export type NurseType = (typeof NURSE_TYPE_OPTIONS)[number]["value"];

function safeStr(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

export function normalizeNurseType(value: unknown): NurseType | "" {
  const normalized = safeStr(value).toUpperCase();
  return NURSE_TYPE_OPTIONS.some((option) => option.value === normalized) ? (normalized as NurseType) : "";
}

export function nurseTypeLabel(value: unknown): string {
  const normalized = normalizeNurseType(value);
  return normalized || "";
}

export function getNurseTypeOption(value: unknown) {
  const normalized = normalizeNurseType(value);
  return NURSE_TYPE_OPTIONS.find((option) => option.value === normalized) || null;
}

export function nurseTypeMonthlyFeeCents(value: unknown): number | null {
  return getNurseTypeOption(value)?.monthlyFeeCents ?? null;
}

export function nurseTypeRequiresAhpra(value: unknown): boolean {
  return getNurseTypeOption(value)?.requiresAhpra ?? true;
}

export function formatNurseProfileLabel(input: {
  displayName?: unknown;
  designation?: unknown;
  nurseType?: unknown;
  email?: unknown;
  fallback?: unknown;
}) {
  const displayName = safeStr(input.displayName);
  const designation = safeStr(input.designation);
  const nurseType = nurseTypeLabel(input.nurseType);
  const email = safeStr(input.email);
  const fallback = safeStr(input.fallback);
  const base = displayName || email || fallback || "—";
  const suffix = designation || nurseType;
  return suffix ? `${base} (${suffix})` : base;
}
