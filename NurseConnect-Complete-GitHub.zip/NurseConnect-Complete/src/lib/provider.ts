// src/lib/provider.ts
import { doc, getDoc, setDoc } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { db } from "../firebaseConfig";
import { NurseType, nurseTypeLabel } from "./nurses";

export type ProviderIdentity = {
  uid: string;
  displayName: string;
  email?: string | null;
  role?: string | null;

  // Optional (future-proofing): whichever you standardise later will be used as the suffix
  designation?: string | null; // e.g. "RN"
  nurseType?: NurseType | null;
  discipline?: string | null;  // e.g. "Community Nursing"
  specialty?: string | null;   // e.g. "Aged Care"

  // Canonical, formatted label for UI/print/export
  label: string;
};

// In-memory cache for the current session.
// - Intentionally no TTL: a hard reload will reflect profile changes.
// - Reduces repeated reads when rendering encounters/audit trails/print views.
const cache = new Map<string, ProviderIdentity>();

function safeStr(v: any): string {
  return typeof v === "string" ? v.trim() : "";
}

function shortUid(uid: string): string {
  const s = safeStr(uid);
  if (!s) return "—";
  if (s.length <= 10) return s;
  return `${s.slice(0, 6)}…${s.slice(-4)}`;
}

function roleLabel(role?: string | null): string {
  const r = safeStr(role).toLowerCase();
  if (!r) return "";
  if (r === "system_admin") return "System Admin";
  if (r === "clinician") return "Nurse";
  if (r === "patient") return "Patient";
  return r.replace(/_/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
}

function preferredDesignation(identity: Partial<ProviderIdentity>): string {
  // Preference order: designation -> specialty -> discipline
  const d = safeStr(identity.designation);
  if (d) return d;
  const nurseType = nurseTypeLabel(identity.nurseType);
  if (nurseType) return nurseType;
  const s = safeStr(identity.specialty);
  if (s) return s;
  const dis = safeStr(identity.discipline);
  if (dis) return dis;
  return "";
}

// Creates a consistent, human-readable label for UI and print output.
// Examples:
// - "Jane Doe (RN)" if designation exists
// - "Jane Doe (Nurse)" otherwise
export function formatProviderLabel(identity: ProviderIdentity, opts?: { includeRole?: boolean }): string {
  const name = safeStr(identity.displayName) || shortUid(identity.uid);

  // By default, include a suffix (designation OR role)
  const includeRole = opts?.includeRole !== false;

  if (!includeRole) return name;

  const designation = preferredDesignation(identity);
  if (designation) return `${name} (${designation})`;

  const role = roleLabel(identity.role);
  return role ? `${name} (${role})` : name;
}

async function maybeBackfillCurrentUserDisplayName(targetUid: string, rawUserDoc: any): Promise<void> {
  // Firebase client SDK cannot read other users' Auth profiles.
  // But we *can* backfill the *current* user's /users/{uid} doc from auth.currentUser
  // so that future lookups (including by admins) show names instead of emails.
  try {
    const auth = getAuth();
    const cu = auth.currentUser;
    if (!cu) return;
    if (cu.uid !== targetUid) return;

    const authDisplayName = safeStr(cu.displayName);
    const authEmail = safeStr(cu.email);

    // Only write if the Firestore user profile is missing a meaningful displayName.
    const existingDisplayName =
      safeStr(rawUserDoc?.displayName) || safeStr(rawUserDoc?.fullName) || safeStr(rawUserDoc?.name);
    if (existingDisplayName) return;
    if (!authDisplayName) return;

    await setDoc(
      doc(db, "users", cu.uid),
      {
        displayName: authDisplayName,
        ...(authEmail ? { email: authEmail } : {}),
        updatedAt: new Date(),
      },
      { merge: true }
    );

    // Clear cache so the next resolve reflects the new displayName.
    cache.delete(cu.uid);
  } catch {
    // Non-fatal
  }
}

function buildIdentity(uid: string, raw?: any): ProviderIdentity {
  const id = safeStr(uid);
  const displayName =
    safeStr(raw?.displayName) ||
    safeStr(raw?.fullName) ||
    safeStr(raw?.name) ||
    safeStr(raw?.email) ||
    shortUid(id);

  const ident: ProviderIdentity = {
    uid: id,
    displayName,
    email: raw?.email ?? null,
    role: raw?.role ?? null,

    designation: raw?.designation ?? null,
    nurseType: raw?.nurseType ?? null,
    discipline: raw?.discipline ?? null,
    specialty: raw?.specialty ?? null,

    label: "—",
  };

  ident.label = formatProviderLabel(ident, { includeRole: true });
  return ident;
}

// Resolves a provider identity from /users/{uid} with basic fallbacks.
export async function resolveProvider(uid: string): Promise<ProviderIdentity> {
  const id = safeStr(uid);
  if (!id) return { uid: "", displayName: "—", email: null, role: null, designation: null, discipline: null, specialty: null, label: "—" };

  const cached = cache.get(id);
  if (cached) return cached;

  try {
    const snap = await getDoc(doc(db, "users", id));
    if (!snap.exists()) {
      const fallback = buildIdentity(id, null);
      cache.set(id, fallback);
      return fallback;
    }

    const raw = snap.data() as any;

    // Opportunistic backfill for current user's displayName (if missing in Firestore).
    await maybeBackfillCurrentUserDisplayName(id, raw);

    const resolved = buildIdentity(id, raw);
    cache.set(id, resolved);
    return resolved;
  } catch {
    const fallback = buildIdentity(id, null);
    cache.set(id, fallback);
    return fallback;
  }
}

// Convenience helper to resolve and format in one call.
export async function resolveProviderLabel(uid: string, opts?: { includeRole?: boolean }): Promise<string> {
  const ident = await resolveProvider(uid);
  // If caller opts out of suffix, respect that; otherwise return the canonical label.
  if (opts?.includeRole === false) {
    return formatProviderLabel(ident, { includeRole: false });
  }
  return ident.label || formatProviderLabel(ident, { includeRole: true });
}

export function clearProviderCache() {
  cache.clear();
}
