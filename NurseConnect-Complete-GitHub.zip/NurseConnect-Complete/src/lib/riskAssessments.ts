import { collection, doc, runTransaction, serverTimestamp } from "firebase/firestore";
import { db } from "../firebaseConfig";

export type HomeCareConcernLevel = "low" | "moderate" | "high" | "urgent";

export type HomeCareAssessmentDomain = {
  key:
    | "fallsMobility"
    | "skinIntegrity"
    | "medicationSupport"
    | "cognitionCapacity"
    | "continence"
    | "homeEnvironment"
    | "carerSupport"
    | "escalationNeed";
  title: string;
  concernLevel: HomeCareConcernLevel;
  summary: string;
};

export type HomeCareAssessmentSummary = {
  overallConcernLevel?: HomeCareConcernLevel | null;
  reviewTimeframe?: string | null;
  carePrioritySummary?: string | null;
  escalationAction?: string | null;
};

export type RiskAssessmentDoc = {
  tool: "nurse_home_care_assessment";
  status: "completed";
  integrationMode: "nurse_workflow";
  patientId: string;
  practiceId: string;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  launchedByUid: string;
  launchedByDisplayName?: string | null;
  launchedAt?: unknown;
  completedAt?: unknown;
  updatedAt?: unknown;
  questionnairePayload: {
    visitContext?: string | null;
    domains: HomeCareAssessmentDomain[];
  };
  scorePayload: {
    domainCount: number;
    highConcernCount: number;
    urgentConcernCount: number;
  };
  resultSummary: HomeCareAssessmentSummary;
  printableSummary: string;
  reportStatus: "pending_pdf_generation";
  reportStoragePath?: string | null;
  reportFileName?: string | null;
};

type CreateManualRiskAssessmentInput = {
  patientId: string;
  practiceId: string;
  clinicianUid: string;
  clinicianDisplayName?: string | null;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  questionnairePayload: {
    visitContext?: string | null;
    domains: HomeCareAssessmentDomain[];
  };
  scorePayload: {
    domainCount: number;
    highConcernCount: number;
    urgentConcernCount: number;
  };
  resultSummary: HomeCareAssessmentSummary;
  printableSummary: string;
};

type ClinicalDocumentEntry = {
  id: string;
  date: string;
  title: string;
  status: string;
  notes: string;
  attachments: Array<unknown>;
  meta: Record<string, unknown>;
};

function makeId(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function todayDateInput() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

export function formatConcernLevel(level?: HomeCareConcernLevel | null) {
  if (!level) return "Not recorded";
  return level.charAt(0).toUpperCase() + level.slice(1);
}

export function buildRiskAssessmentPlanLine(summary: HomeCareAssessmentSummary): string {
  const parts: string[] = [];
  if (summary.overallConcernLevel) parts.push(`overall concern ${formatConcernLevel(summary.overallConcernLevel).toLowerCase()}`);
  if (summary.reviewTimeframe) parts.push(`review ${summary.reviewTimeframe}`);
  if (summary.carePrioritySummary) parts.push(summary.carePrioritySummary);
  if (summary.escalationAction) parts.push(`escalation: ${summary.escalationAction}`);
  const line = parts.length ? `Home-care assessment: ${parts.join("; ")}.` : "Home-care assessment completed.";
  return line;
}

function buildRiskAssessmentDocumentTitle(summary: HomeCareAssessmentSummary) {
  const level = formatConcernLevel(summary.overallConcernLevel);
  return `Home-care assessment summary (${level})`;
}

function buildDomainNotes(domains: HomeCareAssessmentDomain[]) {
  return domains.map((domain) => `${domain.title}: ${formatConcernLevel(domain.concernLevel)}. ${domain.summary}`).join("\n");
}

function buildRiskAssessmentDocumentEntry(assessmentId: string, input: CreateManualRiskAssessmentInput): ClinicalDocumentEntry {
  return {
    id: makeId("entry"),
    date: todayDateInput(),
    title: buildRiskAssessmentDocumentTitle(input.resultSummary),
    status: "completed",
    notes: [
      "Home-care assessment summary",
      input.resultSummary.overallConcernLevel ? `Overall concern: ${formatConcernLevel(input.resultSummary.overallConcernLevel)}` : "",
      input.resultSummary.reviewTimeframe ? `Review timeframe: ${input.resultSummary.reviewTimeframe}` : "",
      input.resultSummary.carePrioritySummary ? `Priority summary: ${input.resultSummary.carePrioritySummary}` : "",
      input.resultSummary.escalationAction ? `Escalation action: ${input.resultSummary.escalationAction}` : "",
      input.questionnairePayload.visitContext ? `Visit context: ${input.questionnairePayload.visitContext}` : "",
      "",
      buildDomainNotes(input.questionnairePayload.domains),
      "",
      String(input.printableSummary || "").trim(),
      "",
      "PDF generation pending future report generation workflow.",
    ]
      .filter(Boolean)
      .join("\n"),
    attachments: [],
    meta: {
      kind: "home_care_assessment_summary",
      tool: "nurse_home_care_assessment",
      linkedAssessmentId: assessmentId,
      sourceEncounterId: input.sourceEncounterId || "",
      sourceAppointmentId: input.sourceAppointmentId || "",
      reportStatus: "pending_pdf_generation",
    },
  };
}

function appendDocumentEntryToChartData(chartData: any, entry: ClinicalDocumentEntry) {
  const safeChartData = chartData && typeof chartData === "object" ? chartData : {};
  const documents = safeChartData.documents && typeof safeChartData.documents === "object" ? safeChartData.documents : {};
  const items = Array.isArray(documents.items) ? [...documents.items] : [];
  return {
    ...safeChartData,
    documents: {
      ...documents,
      items: [entry, ...items],
    },
  };
}

export async function createManualRiskAssessment(input: CreateManualRiskAssessmentInput) {
  const assessmentRef = doc(collection(db, "riskAssessments"));
  const clinicalRef = doc(db, "patientClinicalRecords", input.patientId);
  const documentEntry = buildRiskAssessmentDocumentEntry(assessmentRef.id, input);
  const planLine = buildRiskAssessmentPlanLine(input.resultSummary);

  await runTransaction(db, async (tx) => {
    const clinicalSnap = await tx.get(clinicalRef);
    const previousChartData = clinicalSnap.exists() ? (clinicalSnap.data() as any)?.chartData ?? null : null;
    const nextChartData = appendDocumentEntryToChartData(previousChartData, documentEntry);

    const assessmentDoc: RiskAssessmentDoc = {
      tool: "nurse_home_care_assessment",
      status: "completed",
      integrationMode: "nurse_workflow",
      patientId: input.patientId,
      practiceId: input.practiceId,
      sourceEncounterId: input.sourceEncounterId || null,
      sourceAppointmentId: input.sourceAppointmentId || null,
      launchedByUid: input.clinicianUid,
      launchedByDisplayName: input.clinicianDisplayName || null,
      launchedAt: serverTimestamp(),
      completedAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      questionnairePayload: input.questionnairePayload,
      scorePayload: input.scorePayload,
      resultSummary: input.resultSummary,
      printableSummary: input.printableSummary,
      reportStatus: "pending_pdf_generation",
      reportStoragePath: null,
      reportFileName: null,
    };

    tx.set(assessmentRef, assessmentDoc);
    tx.set(
      clinicalRef,
      {
        patientId: input.patientId,
        practiceId: input.practiceId,
        chartData: nextChartData,
        updatedAt: serverTimestamp(),
        updatedByUid: input.clinicianUid,
      },
      { merge: true }
    );

    const auditRef = doc(collection(db, "patientClinicalRecords", input.patientId, "revisions"));
    tx.set(auditRef, {
      patientId: input.patientId,
      practiceId: input.practiceId,
      editorId: input.clinicianUid,
      editedAt: serverTimestamp(),
      previousChartData,
      nextChartData,
      reason: "home_care_assessment_summary_added",
      linkedAssessmentId: assessmentRef.id,
    });
  });

  return {
    assessmentId: assessmentRef.id,
    planLine,
    documentEntryTitle: documentEntry.title,
  };
}
