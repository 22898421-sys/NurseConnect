import { collection, getDocs, limit, orderBy, query } from "firebase/firestore";
import { db } from "../firebaseConfig";

export type PracticeRecord = {
  id: string;
  name: string;
  address?: string | null;
  phoneNumber?: string | null;
  fax?: string | null;
  email?: string | null;
  city?: string | null;
  country?: string | null;
  active?: boolean | null;
};

function safeStr(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

export function practiceOptionLabel(practice: PracticeRecord) {
  const name = safeStr(practice.name) || practice.id;
  const city = safeStr(practice.city);
  return city ? `${name} (${city})` : name;
}

export async function listPractices() {
  const snap = await getDocs(query(collection(db, "practices"), orderBy("name", "asc"), limit(200)));
  return snap.docs.map((item) => {
    const raw = item.data() as any;
    return {
      id: item.id,
      name: safeStr(raw?.name),
      address: safeStr(raw?.address) || null,
      phoneNumber: safeStr(raw?.phoneNumber) || null,
      fax: safeStr(raw?.fax) || null,
      email: safeStr(raw?.email) || null,
      city: safeStr(raw?.city) || null,
      country: safeStr(raw?.country) || null,
      active: raw?.active ?? true,
    } as PracticeRecord;
  });
}
