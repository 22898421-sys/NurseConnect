export type GeoPointLike = {
  lat: number;
  lng: number;
};

export type PostcodeCentroid = GeoPointLike & {
  postcode: string;
  label: string;
};

// Lightweight centroids for common Australian metro and regional postcodes.
// This keeps public search useful without introducing a paid geocoding dependency.
const POSTCODE_CENTROIDS: Record<string, PostcodeCentroid> = {
  "2000": { postcode: "2000", label: "Sydney NSW", lat: -33.8698, lng: 151.2083 },
  "2010": { postcode: "2010", label: "Surry Hills NSW", lat: -33.8846, lng: 151.2131 },
  "2026": { postcode: "2026", label: "Bondi NSW", lat: -33.8915, lng: 151.2767 },
  "2060": { postcode: "2060", label: "North Sydney NSW", lat: -33.839, lng: 151.207 },
  "2150": { postcode: "2150", label: "Parramatta NSW", lat: -33.8148, lng: 151.0017 },
  "2250": { postcode: "2250", label: "Gosford NSW", lat: -33.425, lng: 151.341 },
  "2300": { postcode: "2300", label: "Newcastle NSW", lat: -32.9283, lng: 151.7817 },
  "2500": { postcode: "2500", label: "Wollongong NSW", lat: -34.4278, lng: 150.8931 },
  "2600": { postcode: "2600", label: "Canberra ACT", lat: -35.3075, lng: 149.1244 },
  "3000": { postcode: "3000", label: "Melbourne VIC", lat: -37.8136, lng: 144.9631 },
  "3002": { postcode: "3002", label: "East Melbourne VIC", lat: -37.8161, lng: 144.9879 },
  "3004": { postcode: "3004", label: "Melbourne/St Kilda Road VIC", lat: -37.841, lng: 144.976 },
  "3053": { postcode: "3053", label: "Carlton VIC", lat: -37.8004, lng: 144.9685 },
  "3065": { postcode: "3065", label: "Fitzroy VIC", lat: -37.7984, lng: 144.9786 },
  "3121": { postcode: "3121", label: "Richmond VIC", lat: -37.819, lng: 145.0019 },
  "3141": { postcode: "3141", label: "South Yarra VIC", lat: -37.8382, lng: 144.9923 },
  "3161": { postcode: "3161", label: "Caulfield VIC", lat: -37.8822, lng: 145.0224 },
  "3205": { postcode: "3205", label: "South Melbourne VIC", lat: -37.8335, lng: 144.9575 },
  "3220": { postcode: "3220", label: "Geelong VIC", lat: -38.1499, lng: 144.3617 },
  "3350": { postcode: "3350", label: "Ballarat VIC", lat: -37.5622, lng: 143.8503 },
  "3550": { postcode: "3550", label: "Bendigo VIC", lat: -36.757, lng: 144.2794 },
  "4000": { postcode: "4000", label: "Brisbane QLD", lat: -27.4698, lng: 153.0251 },
  "4217": { postcode: "4217", label: "Surfers Paradise QLD", lat: -28.0027, lng: 153.4297 },
  "4305": { postcode: "4305", label: "Ipswich QLD", lat: -27.6167, lng: 152.7667 },
  "4350": { postcode: "4350", label: "Toowoomba QLD", lat: -27.561, lng: 151.9539 },
  "4551": { postcode: "4551", label: "Caloundra QLD", lat: -26.8044, lng: 153.1244 },
  "4810": { postcode: "4810", label: "Townsville QLD", lat: -19.2589, lng: 146.8169 },
  "4870": { postcode: "4870", label: "Cairns QLD", lat: -16.9186, lng: 145.7781 },
  "5000": { postcode: "5000", label: "Adelaide SA", lat: -34.9285, lng: 138.6007 },
  "5045": { postcode: "5045", label: "Glenelg SA", lat: -34.9805, lng: 138.512 },
  "5251": { postcode: "5251", label: "Mount Barker SA", lat: -35.0667, lng: 138.8667 },
  "6000": { postcode: "6000", label: "Perth WA", lat: -31.9523, lng: 115.8613 },
  "6160": { postcode: "6160", label: "Fremantle WA", lat: -32.0569, lng: 115.7439 },
  "6230": { postcode: "6230", label: "Bunbury WA", lat: -33.3271, lng: 115.6414 },
  "7000": { postcode: "7000", label: "Hobart TAS", lat: -42.8821, lng: 147.3272 },
  "7250": { postcode: "7250", label: "Launceston TAS", lat: -41.4332, lng: 147.1441 },
  "0800": { postcode: "0800", label: "Darwin NT", lat: -12.4634, lng: 130.8456 },
};

const POSTCODE_PREFIX_CENTROIDS: Array<{ pattern: RegExp; centroid: PostcodeCentroid }> = [
  { pattern: /^3\d{3}$/, centroid: POSTCODE_CENTROIDS["3000"] },
  { pattern: /^2\d{3}$/, centroid: POSTCODE_CENTROIDS["2000"] },
  { pattern: /^4\d{3}$/, centroid: POSTCODE_CENTROIDS["4000"] },
  { pattern: /^5\d{3}$/, centroid: POSTCODE_CENTROIDS["5000"] },
  { pattern: /^6\d{3}$/, centroid: POSTCODE_CENTROIDS["6000"] },
  { pattern: /^7\d{3}$/, centroid: POSTCODE_CENTROIDS["7000"] },
  { pattern: /^0\d{3}$/, centroid: POSTCODE_CENTROIDS["0800"] },
];

export function normalizePostcode(value: unknown) {
  return String(value || "").replace(/[^\d]/g, "").slice(0, 4);
}

export function isFiniteCoordinate(value: unknown) {
  return typeof value === "number" && Number.isFinite(value);
}

export function parseCoordinate(value: unknown) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

export function hasUsableCoordinates(point: Partial<GeoPointLike> | null | undefined): point is GeoPointLike {
  const lat = point?.lat;
  const lng = point?.lng;
  return Boolean(
    typeof lat === "number" &&
      Number.isFinite(lat) &&
      typeof lng === "number" &&
      Number.isFinite(lng) &&
      lat >= -44 &&
      lat <= -10 &&
      lng >= 112 &&
      lng <= 154
  );
}

export function resolvePostcodeCentroid(postcode: unknown): PostcodeCentroid | null {
  const normalized = normalizePostcode(postcode);
  if (!normalized || normalized.length !== 4) return null;
  if (POSTCODE_CENTROIDS[normalized]) return POSTCODE_CENTROIDS[normalized];
  const prefixMatch = POSTCODE_PREFIX_CENTROIDS.find((item) => item.pattern.test(normalized));
  if (!prefixMatch) return null;
  return {
    ...prefixMatch.centroid,
    postcode: normalized,
    label: `${normalized} approximate region`,
  };
}

export function distanceKm(a: GeoPointLike, b: GeoPointLike) {
  const earthRadiusKm = 6371;
  const dLat = toRadians(b.lat - a.lat);
  const dLng = toRadians(b.lng - a.lng);
  const lat1 = toRadians(a.lat);
  const lat2 = toRadians(b.lat);
  const h =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return earthRadiusKm * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function toRadians(value: number) {
  return (value * Math.PI) / 180;
}
