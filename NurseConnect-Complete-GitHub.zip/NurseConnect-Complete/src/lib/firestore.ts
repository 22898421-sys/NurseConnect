// src/lib/firestore.ts
import { db } from "../firebaseConfig";
import {
  doc,
  setDoc,
  getDocs,
  getDoc,
  collection,
  addDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp,
  updateDoc,
} from "firebase/firestore";

/**
 * USER TYPES & HELPERS
 * --------------------
 */

export interface AppUser {
  id: string;
  email: string;
  role: string;
  active?: boolean;
  createdAt?: any;
}

/**
 * Save basic user data to Firestore with UID as the document ID.
 * New users default to active: true.
 */
export const saveUserData = async (userData: {
  uid: string;
  email: string;
  role: string;
}) => {
  try {
    await setDoc(doc(db, "users", userData.uid), {
      email: userData.email,
      role: userData.role,
      active: true,
      createdAt: serverTimestamp(),
    });
    console.log("✅ User saved to Firestore with UID:", userData.uid);
  } catch (error) {
    console.error("❌ Error writing user data:", error);
  }
};

/**
 * Retrieve all users (for AdminPanel or debugging).
 */
export const getAllUsers = async (): Promise<AppUser[]> => {
  const querySnapshot = await getDocs(collection(db, "users"));
  return querySnapshot.docs.map((docSnap) => ({
    id: docSnap.id,
    ...(docSnap.data() as Omit<AppUser, "id">),
  }));
};

/**
 * Update a user's role.
 */
export const updateUserRole = async (uid: string, role: string) => {
  await setDoc(
    doc(db, "users", uid),
    {
      role,
    },
    { merge: true }
  );
};

/**
 * Update a user's active status.
 */
export const updateUserActiveStatus = async (uid: string, active: boolean) => {
  await setDoc(
    doc(db, "users", uid),
    {
      active,
    },
    { merge: true }
  );
};

/**
 * APPOINTMENT TYPES & HELPERS
 * ---------------------------
 *
 * Canonical field for ordering/filtering is:
 *  - scheduledAt: Timestamp
 *
 * Compatibility fields:
 *  - date: "DD-MM-YYYY"  (as requested)
 *  - time: "HH:MM"
 */

export type AppointmentStatus =
  | "scheduled"
  | "in_progress"
  | "completed"
  | "cancelled";

export type AppointmentMode = "video" | "phone" | "in_person";

export interface Appointment {
  id: string;

  patientId: string;
  clinicianId: string;

  patientName?: string | null;
  patientEmail?: string | null;
  clinicianName?: string | null;

  // Canonical scheduling
  scheduledAt: Timestamp;
  durationMinutes?: number | null;

  // Compatibility display fields
  date: string; // "DD-MM-YYYY"
  time: string; // "HH:MM"

  mode: AppointmentMode;
  status: AppointmentStatus;

  reason?: string | null;
  consultationNotes?: string | null;

  createdAt?: any;
  updatedAt?: any;
  createdBy?: string | null;
  updatedBy?: string | null;
}

export type AppointmentInput = Omit<
  Appointment,
  "id" | "createdAt" | "updatedAt"
>;

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

/**
 * Convert a JS Date to "DD-MM-YYYY" (local time).
 */
export function formatDDMMYYYY(d: Date): string {
  return `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()}`;
}

/**
 * Convert a JS Date to "HH:MM" (local time).
 */
export function formatHHMM(d: Date): string {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

/**
 * Create a new appointment.
 * Writes both scheduledAt (Timestamp) and date/time strings (DD-MM-YYYY / HH:MM).
 */
export const createAppointment = async (input: Omit<AppointmentInput, "date" | "time"> & { scheduledAt: Timestamp }) => {
  const dt = input.scheduledAt.toDate();
  const date = formatDDMMYYYY(dt);
  const time = formatHHMM(dt);

  const docRef = await addDoc(collection(db, "appointments"), {
    ...input,
    date,
    time,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  console.log("✅ Appointment created with id:", docRef.id);
  return docRef.id;
};

/**
 * Update an appointment by ID (merge-like update).
 * If scheduledAt is updated, date/time are updated to match (DD-MM-YYYY, HH:MM).
 */
export const updateAppointment = async (
  id: string,
  patch: Partial<Omit<Appointment, "id">>
) => {
  const ref = doc(db, "appointments", id);

  const payload: any = {
    ...patch,
    updatedAt: serverTimestamp(),
  };

  if (patch.scheduledAt instanceof Timestamp) {
    const dt = patch.scheduledAt.toDate();
    payload.date = formatDDMMYYYY(dt);
    payload.time = formatHHMM(dt);
  }

  await updateDoc(ref, payload);
};

/**
 * Cancel appointment (soft cancel).
 */
export const cancelAppointment = async (id: string) => {
  await updateAppointment(id, { status: "cancelled" });
};

/**
 * Get all appointments (ordered by scheduledAt ASC).
 */
export const getAllAppointments = async (): Promise<Appointment[]> => {
  const q = query(collection(db, "appointments"), orderBy("scheduledAt", "asc"));
  const snapshot = await getDocs(q);

  return snapshot.docs.map((docSnap) => {
    const raw = docSnap.data() as any;

    // Backfill date/time if older docs lack them
    const scheduledAt: Timestamp =
      raw?.scheduledAt instanceof Timestamp
        ? raw.scheduledAt
        : Timestamp.fromDate(new Date());

    const dt = scheduledAt.toDate();
    const date = String(raw?.date || formatDDMMYYYY(dt));
    const time = String(raw?.time || formatHHMM(dt));

    return {
      id: docSnap.id,
      ...raw,
      scheduledAt,
      date,
      time,
    } as Appointment;
  });
};

/**
 * Get a single appointment by ID.
 */
export const getAppointmentById = async (
  id: string
): Promise<Appointment | null> => {
  const docRef = doc(db, "appointments", id);
  const snap = await getDoc(docRef);
  if (!snap.exists()) return null;

  const raw = snap.data() as any;
  const scheduledAt: Timestamp =
    raw?.scheduledAt instanceof Timestamp
      ? raw.scheduledAt
      : Timestamp.fromDate(new Date());

  const dt = scheduledAt.toDate();
  const date = String(raw?.date || formatDDMMYYYY(dt));
  const time = String(raw?.time || formatHHMM(dt));

  return {
    id: snap.id,
    ...raw,
    scheduledAt,
    date,
    time,
  } as Appointment;
};

/**
 * Get appointments for a specific clinician (ordered by scheduledAt ASC).
 */
export const getAppointmentsForClinician = async (
  clinicianId: string
): Promise<Appointment[]> => {
  const q = query(
    collection(db, "appointments"),
    where("clinicianId", "==", clinicianId),
    orderBy("scheduledAt", "asc")
  );

  const snapshot = await getDocs(q);
  return snapshot.docs.map((docSnap) => {
    const raw = docSnap.data() as any;
    const scheduledAt: Timestamp =
      raw?.scheduledAt instanceof Timestamp
        ? raw.scheduledAt
        : Timestamp.fromDate(new Date());
    const dt = scheduledAt.toDate();

    return {
      id: docSnap.id,
      ...raw,
      scheduledAt,
      date: String(raw?.date || formatDDMMYYYY(dt)),
      time: String(raw?.time || formatHHMM(dt)),
    } as Appointment;
  });
};

/**
 * Get appointments for a specific patient (ordered by scheduledAt ASC).
 */
export const getAppointmentsForPatient = async (
  patientId: string
): Promise<Appointment[]> => {
  const q = query(
    collection(db, "appointments"),
    where("patientId", "==", patientId),
    orderBy("scheduledAt", "asc")
  );

  const snapshot = await getDocs(q);
  return snapshot.docs.map((docSnap) => {
    const raw = docSnap.data() as any;
    const scheduledAt: Timestamp =
      raw?.scheduledAt instanceof Timestamp
        ? raw.scheduledAt
        : Timestamp.fromDate(new Date());
    const dt = scheduledAt.toDate();

    return {
      id: docSnap.id,
      ...raw,
      scheduledAt,
      date: String(raw?.date || formatDDMMYYYY(dt)),
      time: String(raw?.time || formatHHMM(dt)),
    } as Appointment;
  });
};
