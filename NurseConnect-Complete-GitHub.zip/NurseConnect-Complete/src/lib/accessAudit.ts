import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "../firebaseConfig";

export type AccessAuditAction =
  | "read_patient_chart"
  | "read_encounter"
  | "break_glass_enable"
  | "review_clinical_document"
  | "export_patient_chart"
  | "support_patient_record_access";

type LogSensitiveAccessParams = {
  actorUid: string;
  role?: string | null;
  action: AccessAuditAction;
  resourceType: string;
  resourceId: string;
  patientId?: string | null;
  practiceId?: string | null;
  encounterId?: string | null;
};

function cleanString(value: string | null | undefined): string | null {
  const next = String(value || "").trim();
  return next ? next : null;
}

export async function logSensitiveAccess(params: LogSensitiveAccessParams) {
  const actorUid = cleanString(params.actorUid);
  const resourceType = cleanString(params.resourceType);
  const resourceId = cleanString(params.resourceId);
  if (!actorUid || !resourceType || !resourceId) return;

  try {
    await addDoc(collection(db, "accessAuditLogs"), {
      actorUid,
      role: cleanString(params.role) || "",
      action: params.action,
      resourceType,
      resourceId,
      patientId: cleanString(params.patientId),
      practiceId: cleanString(params.practiceId),
      encounterId: cleanString(params.encounterId),
      occurredAt: serverTimestamp(),
    });
  } catch (error) {
    console.error("Failed to write access audit log:", error);
  }
}
