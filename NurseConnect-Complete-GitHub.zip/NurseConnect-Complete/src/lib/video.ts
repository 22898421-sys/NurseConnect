export const VIDEO_PROVIDER = (process.env.REACT_APP_VIDEO_PROVIDER || "jitsi").toLowerCase();
export const JITSI_DOMAIN = (process.env.REACT_APP_JITSI_DOMAIN || "meet.jit.si").trim();
export const JITSI_ROOM_PREFIX = (process.env.REACT_APP_JITSI_ROOM_PREFIX || "healthful").trim();

export function buildJitsiRoomName(appointmentId: string) {
  const safePrefix = JITSI_ROOM_PREFIX || "healthful";
  return `${safePrefix}-${appointmentId || "unknown"}`;
}

export function buildJitsiUrl(roomName: string) {
  const domain = JITSI_DOMAIN || "meet.jit.si";
  return `https://${domain}/${encodeURIComponent(roomName)}#config.prejoinPageEnabled=false`;
}
