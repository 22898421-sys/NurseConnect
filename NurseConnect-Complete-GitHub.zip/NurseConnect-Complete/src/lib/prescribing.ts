import { collection, doc, runTransaction, serverTimestamp } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { PrescriptionRecord } from "./prescriptions";

export type PrescriptionDraft = {
  patientId: string;
  practiceId: string;
  prescriberUid: string;
  prescriberLabel: string;
  medication: string;
  strength: string;
  dose: string;
  route: string;
  frequency: string;
  duration: string;
  quantity: string;
  repeats: string;
  indication: string;
  notes: string;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
};

function safe(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function asNonNegativeInteger(value: string): number {
  const parsed = Number(String(value || "").trim());
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : 0;
}

function todayDateInput() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

function makeId(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export function prescriptionPrintPath(patientId: string, prescriptionId: string) {
  return `/patients/${patientId}/documents/${prescriptionId}/print`;
}

export function buildPrescriptionRecordFromDraft(prescriptionId: string, draft: PrescriptionDraft): PrescriptionRecord {
  const originalRepeats = asNonNegativeInteger(draft.repeats);
  return {
    prescriptionId,
    chartEntryId: prescriptionId,
    patientId: draft.patientId,
    practiceId: draft.practiceId,
    medication: safe(draft.medication),
    strength: safe(draft.strength),
    dose: safe(draft.dose),
    route: safe(draft.route),
    frequency: safe(draft.frequency),
    duration: safe(draft.duration),
    quantity: safe(draft.quantity),
    indication: safe(draft.indication),
    notes: safe(draft.notes),
    originalRepeats,
    remainingRepeatsReported: originalRepeats,
    totalDispenseNotifications: 0,
    initialDispenseRecorded: false,
    status: "active",
    issuedByUid: draft.prescriberUid,
    issuedAt: new Date().toISOString(),
    lastDispensedAt: null,
    lastDispensedByPharmacy: null,
    lastVerificationMethod: null,
    sourceAppointmentId: draft.sourceAppointmentId || null,
    sourceEncounterId: draft.sourceEncounterId || null,
    trackingMode: "clinic_reported",
  };
}

export function buildPrescriptionPortalDocument(record: PrescriptionRecord, prescriberLabel: string) {
  return {
    kind: "prescription",
    patientId: record.patientId,
    practiceId: record.practiceId,
    patientVisible: true,
    title: record.medication || "Medication",
    status: record.status,
    createdByUid: record.issuedByUid,
    chartEntryId: record.chartEntryId,
    sourceAppointmentId: record.sourceAppointmentId || null,
    sourceEncounterId: record.sourceEncounterId || null,
    printPath: prescriptionPrintPath(record.patientId, record.prescriptionId),
    printablePayload: {
      kind: "prescription",
      title: record.medication,
      date: todayDateInput(),
      dateLabel: todayDateInput().split("-").reverse().join("-"),
      strength: record.strength,
      dose: record.dose,
      route: record.route,
      frequency: record.frequency,
      duration: record.duration,
      quantity: record.quantity,
      repeats: String(record.originalRepeats),
      clinicalQuestion: record.indication,
      notes: record.notes,
      orderedByUid: record.issuedByUid,
      orderedAt: record.issuedAt,
      issuingClinicianLabel: prescriberLabel,
      prescriptionId: record.prescriptionId,
      originalRepeats: String(record.originalRepeats),
      remainingRepeatsReported: String(record.remainingRepeatsReported),
      totalDispenseNotifications: String(record.totalDispenseNotifications),
      clinicTrackingStatus: record.status,
      clinicTrackingStatusLabel: "Active",
      clinicTrackingMode: record.trackingMode,
      clinicTrackingDisclaimer:
        "Remaining repeats shown here reflect dispense notifications reported back to this clinic only. This is not a national live eScript register.",
      initialDispenseRecorded: "no",
      lastDispensedAt: "",
      lastDispensedByPharmacy: "",
      lastVerificationMethod: "",
    },
  };
}

export async function createPrescriptionFromDraft(draft: PrescriptionDraft) {
  const prescriptionId = makeId("rx");
  const record = buildPrescriptionRecordFromDraft(prescriptionId, draft);
  const prescriptionRef = doc(db, "prescriptions", prescriptionId);
  const portalRef = doc(db, "patients", draft.patientId, "portalDocuments", prescriptionId);
  const patientSummaryRevisionRef = doc(collection(db, "patients", draft.patientId, "prescriptionAudit"));
  const portalDoc = buildPrescriptionPortalDocument(record, draft.prescriberLabel);

  await runTransaction(db, async (tx) => {
    tx.set(
      prescriptionRef,
      {
        ...record,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    tx.set(
      portalRef,
      {
        ...portalDoc,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    tx.set(patientSummaryRevisionRef, {
      prescriptionId,
      patientId: draft.patientId,
      practiceId: draft.practiceId,
      action: "created",
      createdByUid: draft.prescriberUid,
      createdAt: serverTimestamp(),
      medication: record.medication,
      sourceEncounterId: draft.sourceEncounterId || null,
      sourceAppointmentId: draft.sourceAppointmentId || null,
    });
  });

  return { prescriptionId, record };
}
