import { httpsCallable } from "firebase/functions";
import { functions } from "../firebaseConfig";

export async function submitPublicContactEnquiry(input: {
  fullName: string;
  email: string;
  enquiryType: string;
  message: string;
}) {
  const callable = httpsCallable<
    { fullName: string; email: string; enquiryType: string; message: string },
    { success: boolean; enquiryId: string }
  >(functions, "submitPublicContactEnquiry");
  const result = await callable(input);
  return result.data;
}

export async function submitNurseRegistrationInterest(input: {
  fullName: string;
  email: string;
  primaryRegion: string;
  professionalRole: string;
  nurseType: string;
  ahpraRegistrationNumber: string;
  travelRadius: string;
  visitTypes: string[];
  fundingModels: string[];
  serviceFocus: string;
}) {
  const callable = httpsCallable<
    {
      fullName: string;
      email: string;
      primaryRegion: string;
      professionalRole: string;
      nurseType: string;
      ahpraRegistrationNumber: string;
      travelRadius: string;
      visitTypes: string[];
      fundingModels: string[];
      serviceFocus: string;
    },
    { success: boolean; registrationInterestId: string }
  >(functions, "submitNurseRegistrationInterest");
  const result = await callable(input);
  return result.data;
}
