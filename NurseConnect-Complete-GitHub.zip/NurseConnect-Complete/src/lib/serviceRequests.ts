export type ServiceRequestType = "open_request" | "direct_request";
export type ServiceRequestStatus =
  | "open"
  | "interest_received"
  | "direct_pending"
  | "accepted"
  | "direct_declined"
  | "filled"
  | "withdrawn";

export type ServiceRequestFundingPathway = "support_at_home" | "private_pay" | "mixed" | "to_be_confirmed";
export type ServiceRequestDeliveryMode = "in_person" | "telehealth" | "hybrid";
export type ServiceRequestOrganisationRole =
  | "registered_provider"
  | "care_manager_or_funder"
  | "independent_nurse_provider"
  | "participant_or_carer"
  | "other";
export type SupportAtHomeServiceCategory =
  | "clinical_supports"
  | "independence_services"
  | "everyday_living_services"
  | "not_sure"
  | "not_applicable";

export type ServiceRequestResponse = {
  nurseUid: string;
  nurseDisplayName: string;
  nurseEmail?: string | null;
  nurseType?: string | null;
  responseType: "interest" | "accepted" | "declined";
  note?: string | null;
  respondedAt: string;
};

export type ServiceRequestDoc = {
  id: string;
  manageToken: string;
  requestType: ServiceRequestType;
  status: ServiceRequestStatus;
  manageUrl?: string | null;
  organisationName: string;
  requesterName: string;
  requesterEmail: string;
  requesterPhone?: string | null;
  organisationRole?: ServiceRequestOrganisationRole | null;
  registeredProviderName?: string | null;
  registeredProviderId?: string | null;
  supportAtHomeCategory?: SupportAtHomeServiceCategory | null;
  clientReference?: string | null;
  suburb: string;
  postcode: string;
  state: string;
  requiredNurseType: string;
  serviceTitle: string;
  serviceKeywords?: string[];
  deliveryModePreference: ServiceRequestDeliveryMode;
  requestedVisits?: number | null;
  timeframe: string;
  carePlanContext: string;
  fundingPathway: ServiceRequestFundingPathway;
  targetNurseUid?: string | null;
  targetNurseName?: string | null;
  targetNurseType?: string | null;
  responses?: ServiceRequestResponse[];
  responseCount?: number;
  acceptedByNurseUid?: string | null;
  acceptedAt?: string | null;
  filledConfirmedAt?: string | null;
  filledConfirmedBy?: string | null;
  updatedByUid?: string | null;
  createdAt?: unknown;
  updatedAt?: unknown;
};

export const AU_STATES = [
  "Australian Capital Territory",
  "New South Wales",
  "Northern Territory",
  "Queensland",
  "South Australia",
  "Tasmania",
  "Victoria",
  "Western Australia",
] as const;

export function formatServiceRequestStatus(status: ServiceRequestStatus) {
  switch (status) {
    case "interest_received":
      return "Interest received";
    case "direct_pending":
      return "Direct request pending";
    case "direct_declined":
      return "Direct request declined";
    case "accepted":
      return "Accepted";
    case "filled":
      return "Filled";
    case "withdrawn":
      return "Withdrawn";
    default:
      return "Open";
  }
}

export function formatOrganisationRole(value: ServiceRequestOrganisationRole | null | undefined) {
  switch (value) {
    case "registered_provider":
      return "Registered Support at Home provider";
    case "care_manager_or_funder":
      return "Care manager or funder";
    case "independent_nurse_provider":
      return "Independent nurse provider";
    case "participant_or_carer":
      return "Participant or carer";
    case "other":
      return "Other organisation";
    default:
      return "Not recorded";
  }
}

export function formatSupportAtHomeCategory(value: SupportAtHomeServiceCategory | null | undefined) {
  switch (value) {
    case "clinical_supports":
      return "Clinical supports";
    case "independence_services":
      return "Independence services";
    case "everyday_living_services":
      return "Everyday living services";
    case "not_sure":
      return "Not sure";
    case "not_applicable":
      return "Not applicable";
    default:
      return "Not recorded";
  }
}

export function formatDeliveryModePreference(value: ServiceRequestDeliveryMode) {
  switch (value) {
    case "telehealth":
      return "Telehealth";
    case "hybrid":
      return "Hybrid";
    default:
      return "In person";
  }
}

export function formatFundingPathway(pathway: ServiceRequestFundingPathway) {
  switch (pathway) {
    case "support_at_home":
      return "Support at Home";
    case "private_pay":
      return "Private pay";
    case "mixed":
      return "Mixed funding";
    default:
      return "To be confirmed";
  }
}
