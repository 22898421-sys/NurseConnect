import { collection, doc, runTransaction, serverTimestamp } from "firebase/firestore";
import { db } from "../firebaseConfig";

export type CarePlanTemplateKey =
  | "comprehensive_home_care"
  | "post_hospital_recovery"
  | "wound_management"
  | "chronic_disease_support"
  | "palliative_support";

export type CarePlanStatus = "active" | "review_due" | "completed" | "superseded";

export type CarePlanPayload = {
  visitContext?: string | null;
  personalPreferences?: string | null;
  clinicalAssessmentSummary: string;
  clinicalNeeds: string;
  personalCareNeeds: string;
  shortTermGoals: string;
  longTermGoals: string;
  identifiedRisks: string;
  nursingInterventions: string;
  personalCareInterventions: string;
  equipmentRequirements: string;
  delegationPlan: string;
  visitSchedule: string;
  monitoringParameters: string;
  referralsAndTeam: string;
  escalationTriggers: string;
  transitionConsiderations: string;
};

export type CarePlanResultSummary = {
  templateKey: CarePlanTemplateKey;
  status: CarePlanStatus;
  goalSummary: string;
  outcomeTargets?: string | null;
  reviewTimeframe: string;
  agreedServiceDays?: string | null;
  evaluationPlan?: string | null;
  agreedWithPatientOrRepresentative: boolean;
  agreementName?: string | null;
};

export type CarePlanDoc = {
  tool: "nurse_comprehensive_care_plan";
  status: CarePlanStatus;
  integrationMode: "nurse_workflow";
  templateKey: CarePlanTemplateKey;
  patientId: string;
  practiceId: string;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  authoredByUid: string;
  authoredByDisplayName?: string | null;
  authoredAt?: unknown;
  completedAt?: unknown;
  updatedAt?: unknown;
  planPayload: CarePlanPayload;
  resultSummary: CarePlanResultSummary;
  printableSummary: string;
  reportStatus: "pending_pdf_generation";
  reportStoragePath?: string | null;
  reportFileName?: string | null;
};

type CreateCarePlanInput = {
  templateKey: CarePlanTemplateKey;
  patientId: string;
  practiceId: string;
  clinicianUid: string;
  clinicianDisplayName?: string | null;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  planPayload: CarePlanPayload;
  resultSummary: CarePlanResultSummary;
  printableSummary: string;
};

type ClinicalDocumentEntry = {
  id: string;
  date: string;
  title: string;
  status: string;
  notes: string;
  attachments: Array<unknown>;
  meta: Record<string, unknown>;
};

export type CarePlanTemplate = {
  key: CarePlanTemplateKey;
  label: string;
  description: string;
  suggestedVisitContext: string;
  defaultReviewTimeframe: string;
  suggestedGoalSummary: string;
};

function makeId(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function todayDateInput() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

function cleanText(value: unknown) {
  return String(value || "").trim();
}

export const CARE_PLAN_TEMPLATES: CarePlanTemplate[] = [
  {
    key: "comprehensive_home_care",
    label: "Comprehensive home-care plan",
    description:
      "Broad person-centred nursing care plan covering assessment findings, goals, risks, interventions, delegation, review, and home-care delivery arrangements.",
    suggestedVisitContext: "Comprehensive home nursing care planning",
    defaultReviewTimeframe: "Review within 7 days, then as clinical needs change",
    suggestedGoalSummary: "Stabilise current needs, support safe care at home, and track agreed outcomes across the episode of care.",
  },
  {
    key: "post_hospital_recovery",
    label: "Post-hospital recovery plan",
    description:
      "Focused plan for discharge transition, wound or medication follow-up, mobility support, escalation monitoring, and coordination back to community providers.",
    suggestedVisitContext: "Post-discharge recovery nursing plan",
    defaultReviewTimeframe: "Review within 72 hours of commencement",
    suggestedGoalSummary: "Support safe recovery at home, reduce avoidable deterioration, and coordinate the transition after discharge.",
  },
  {
    key: "wound_management",
    label: "Wound management plan",
    description:
      "Structured plan for wound assessment, dressing schedule, infection monitoring, pain control, education, and timely escalation if healing stalls.",
    suggestedVisitContext: "Wound management care planning",
    defaultReviewTimeframe: "Review at next dressing cycle or within 48 hours if high risk",
    suggestedGoalSummary: "Promote wound healing, prevent infection, and maintain comfort and skin integrity.",
  },
  {
    key: "chronic_disease_support",
    label: "Chronic disease support plan",
    description:
      "Ongoing plan for monitoring chronic conditions, medicines, self-management support, symptom surveillance, and liaison with the broader care team.",
    suggestedVisitContext: "Chronic disease nursing support plan",
    defaultReviewTimeframe: "Review every 28 days or sooner if condition changes",
    suggestedGoalSummary: "Support symptom stability, adherence, and self-management while reducing escalation risk.",
  },
  {
    key: "palliative_support",
    label: "Palliative support plan",
    description:
      "Comfort-focused plan for symptom support, family communication, home setup, escalation preferences, and end-of-life aligned care delivery.",
    suggestedVisitContext: "Palliative support care planning",
    defaultReviewTimeframe: "Review within 24 hours and after any significant change",
    suggestedGoalSummary: "Maintain comfort, dignity, communication clarity, and timely response to changing needs.",
  },
];

export function getCarePlanTemplate(key?: CarePlanTemplateKey | null): CarePlanTemplate {
  return CARE_PLAN_TEMPLATES.find((item) => item.key === key) || CARE_PLAN_TEMPLATES[0];
}

export function formatCarePlanStatus(status?: CarePlanStatus | null) {
  if (!status) return "Not recorded";
  return status
    .split("_")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

export function buildCarePlanPlanLine(summary: CarePlanResultSummary): string {
  const template = getCarePlanTemplate(summary.templateKey);
  const parts = [
    template.label,
    cleanText(summary.goalSummary),
    cleanText(summary.reviewTimeframe) ? `review ${cleanText(summary.reviewTimeframe)}` : "",
    cleanText(summary.outcomeTargets),
  ].filter(Boolean);
  return parts.length ? `Care plan updated: ${parts.join("; ")}.` : "Care plan updated.";
}

function buildCarePlanDocumentTitle(summary: CarePlanResultSummary) {
  return `${getCarePlanTemplate(summary.templateKey).label} (${formatCarePlanStatus(summary.status)})`;
}

function sectionLine(label: string, value: unknown) {
  const clean = cleanText(value);
  return clean ? `${label}: ${clean}` : "";
}

function buildCarePlanDocumentEntry(carePlanId: string, input: CreateCarePlanInput): ClinicalDocumentEntry {
  const p = input.planPayload;
  const s = input.resultSummary;

  return {
    id: makeId("entry"),
    date: todayDateInput(),
    title: buildCarePlanDocumentTitle(s),
    status: s.status,
    notes: [
      "Structured care plan summary",
      sectionLine("Template", getCarePlanTemplate(input.templateKey).label),
      sectionLine("Status", formatCarePlanStatus(s.status)),
      sectionLine("Goal summary", s.goalSummary),
      sectionLine("Outcome targets", s.outcomeTargets),
      sectionLine("Review timeframe", s.reviewTimeframe),
      sectionLine("Agreed service days", s.agreedServiceDays),
      sectionLine("Evaluation plan", s.evaluationPlan),
      sectionLine(
        "Agreement",
        s.agreedWithPatientOrRepresentative
          ? `Agreed with patient/representative${cleanText(s.agreementName) ? ` (${cleanText(s.agreementName)})` : ""}`
          : "Clinician draft pending patient/representative agreement"
      ),
      "",
      sectionLine("Visit context", p.visitContext),
      sectionLine("Personal preferences and communication needs", p.personalPreferences),
      sectionLine("Clinical assessment summary", p.clinicalAssessmentSummary),
      sectionLine("Clinical and personal care needs", [cleanText(p.clinicalNeeds), cleanText(p.personalCareNeeds)].filter(Boolean).join("\n")),
      sectionLine("Short-term goals", p.shortTermGoals),
      sectionLine("Long-term goals", p.longTermGoals),
      sectionLine("Identified risks and mitigation priorities", p.identifiedRisks),
      sectionLine("Nursing interventions", p.nursingInterventions),
      sectionLine("Personal care interventions", p.personalCareInterventions),
      sectionLine("Equipment and resources", p.equipmentRequirements),
      sectionLine("Delegation and personnel level", p.delegationPlan),
      sectionLine("Visit schedule and timeframes", p.visitSchedule),
      sectionLine("Monitoring and review parameters", p.monitoringParameters),
      sectionLine("People involved and referrals", p.referralsAndTeam),
      sectionLine("Escalation triggers and actions", p.escalationTriggers),
      sectionLine("Transition or discharge considerations", p.transitionConsiderations),
      "",
      cleanText(input.printableSummary),
      "",
      "PDF generation pending future report generation workflow.",
    ]
      .filter(Boolean)
      .join("\n"),
    attachments: [],
    meta: {
      kind: "care_plan_summary",
      tool: "nurse_comprehensive_care_plan",
      linkedCarePlanId: carePlanId,
      sourceEncounterId: input.sourceEncounterId || "",
      sourceAppointmentId: input.sourceAppointmentId || "",
      reportStatus: "pending_pdf_generation",
      templateKey: input.templateKey,
      carePlanStatus: s.status,
    },
  };
}

function appendDocumentEntryToChartData(chartData: any, entry: ClinicalDocumentEntry) {
  const safeChartData = chartData && typeof chartData === "object" ? chartData : {};
  const documents = safeChartData.documents && typeof safeChartData.documents === "object" ? safeChartData.documents : {};
  const items = Array.isArray(documents.items) ? [...documents.items] : [];
  return {
    ...safeChartData,
    documents: {
      ...documents,
      items: [entry, ...items],
    },
  };
}

export async function createManualCarePlan(input: CreateCarePlanInput) {
  const carePlanRef = doc(collection(db, "carePlans"));
  const clinicalRef = doc(db, "patientClinicalRecords", input.patientId);
  const documentEntry = buildCarePlanDocumentEntry(carePlanRef.id, input);
  const planLine = buildCarePlanPlanLine(input.resultSummary);

  await runTransaction(db, async (tx) => {
    const clinicalSnap = await tx.get(clinicalRef);
    const previousChartData = clinicalSnap.exists() ? (clinicalSnap.data() as any)?.chartData ?? null : null;
    const nextChartData = appendDocumentEntryToChartData(previousChartData, documentEntry);

    const carePlanDoc: CarePlanDoc = {
      tool: "nurse_comprehensive_care_plan",
      status: input.resultSummary.status,
      integrationMode: "nurse_workflow",
      templateKey: input.templateKey,
      patientId: input.patientId,
      practiceId: input.practiceId,
      sourceEncounterId: input.sourceEncounterId || null,
      sourceAppointmentId: input.sourceAppointmentId || null,
      authoredByUid: input.clinicianUid,
      authoredByDisplayName: input.clinicianDisplayName || null,
      authoredAt: serverTimestamp(),
      completedAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      planPayload: input.planPayload,
      resultSummary: input.resultSummary,
      printableSummary: input.printableSummary,
      reportStatus: "pending_pdf_generation",
      reportStoragePath: null,
      reportFileName: null,
    };

    tx.set(carePlanRef, carePlanDoc);
    tx.set(
      clinicalRef,
      {
        patientId: input.patientId,
        practiceId: input.practiceId,
        chartData: nextChartData,
        updatedAt: serverTimestamp(),
        updatedByUid: input.clinicianUid,
      },
      { merge: true }
    );

    const auditRef = doc(collection(db, "patientClinicalRecords", input.patientId, "revisions"));
    tx.set(auditRef, {
      patientId: input.patientId,
      practiceId: input.practiceId,
      editorId: input.clinicianUid,
      editedAt: serverTimestamp(),
      previousChartData,
      nextChartData,
      reason: "care_plan_summary_added",
      linkedCarePlanId: carePlanRef.id,
    });
  });

  return {
    carePlanId: carePlanRef.id,
    planLine,
    documentEntryTitle: documentEntry.title,
  };
}
