export type SubscriptionBillingCycle = "monthly" | "quarterly" | "half_yearly" | "annually";

export const SUBSCRIPTION_TRIAL_DAYS = 7;

export const SUBSCRIPTION_BILLING_OPTIONS: Array<{
  value: SubscriptionBillingCycle;
  label: string;
  months: number;
  discountPercent: number;
}> = [
  { value: "monthly", label: "Monthly", months: 1, discountPercent: 0 },
  { value: "quarterly", label: "Quarterly", months: 3, discountPercent: 3.5 },
  { value: "half_yearly", label: "Half-yearly", months: 6, discountPercent: 8 },
  { value: "annually", label: "Annually", months: 12, discountPercent: 15 },
];

export function getSubscriptionBillingOption(value: unknown) {
  const normalized = String(value || "").trim().toLowerCase() as SubscriptionBillingCycle;
  return SUBSCRIPTION_BILLING_OPTIONS.find((option) => option.value === normalized) || SUBSCRIPTION_BILLING_OPTIONS[0];
}

export function computeSubscriptionChargeCents(baseMonthlyFeeCents: number, cycle: unknown) {
  const option = getSubscriptionBillingOption(cycle);
  const undiscountedCents = baseMonthlyFeeCents * option.months;
  const discountedCents = Math.round(undiscountedCents * (1 - option.discountPercent / 100));
  return {
    ...option,
    undiscountedCents,
    discountedCents,
    savingsCents: undiscountedCents - discountedCents,
  };
}

export function addDays(date: Date, days: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export function formatCurrencyAUD(cents: number) {
  return new Intl.NumberFormat("en-AU", {
    style: "currency",
    currency: "AUD",
    minimumFractionDigits: 2,
  }).format(cents / 100);
}

export function formatLongDate(value: Date | string | null | undefined) {
  if (!value) return "—";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-AU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}
