// src/lib/dates.ts
export function formatToDDMMYYYY(input?: string | null): string {
  const raw = String(input || "").trim();
  if (!raw) return "";

  const m1 = raw.match(/^(\d{4})-([0-1]?\d)-([0-3]?\d)$/);
  if (m1) {
    const yyyy = m1[1];
    const mm = m1[2].padStart(2, "0");
    const dd = m1[3].padStart(2, "0");
    return `${dd}-${mm}-${yyyy}`;
  }

  const m2 = raw.match(/^([0-3]?\d)-([0-1]?\d)-(\d{4})$/);
  if (m2) {
    const dd = m2[1].padStart(2, "0");
    const mm = m2[2].padStart(2, "0");
    const yyyy = m2[3];
    return `${dd}-${mm}-${yyyy}`;
  }

  return raw;
}
