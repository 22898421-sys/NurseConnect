export type AvailabilityWindow = {
  start: string;
  end: string;
};

export type AvailabilityDay = {
  dayOfWeek: number;
  enabled: boolean;
  windows: AvailabilityWindow[];
};

export type AvailabilityDateBlock = {
  id: string;
  startDate: string;
  endDate: string;
  daysOfWeek: number[];
  windows: AvailabilityWindow[];
};

export type ClinicianAvailabilityDoc = {
  clinicianId: string;
  practiceId: string;
  clinicianEmail?: string | null;
  clinicianName?: string | null;
  nurseType?: string | null;
  designation?: string | null;
  timeZone?: string | null;
  weekly: AvailabilityDay[];
  dateBlocks?: AvailabilityDateBlock[];
  createdAt?: unknown;
  updatedAt?: unknown;
  updatedByUid?: string | null;
};

export type AvailabilityStatus =
  | "available"
  | "busy"
  | "outside_roster"
  | "no_roster";

export const WEEKDAY_OPTIONS = [
  { dayOfWeek: 1, label: "Monday", shortLabel: "Mon" },
  { dayOfWeek: 2, label: "Tuesday", shortLabel: "Tue" },
  { dayOfWeek: 3, label: "Wednesday", shortLabel: "Wed" },
  { dayOfWeek: 4, label: "Thursday", shortLabel: "Thu" },
  { dayOfWeek: 5, label: "Friday", shortLabel: "Fri" },
  { dayOfWeek: 6, label: "Saturday", shortLabel: "Sat" },
  { dayOfWeek: 0, label: "Sunday", shortLabel: "Sun" },
];

const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const WEEKDAY_INDEX: Record<string, number> = {
  Sun: 0,
  Mon: 1,
  Tue: 2,
  Wed: 3,
  Thu: 4,
  Fri: 5,
  Sat: 6,
};

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function todayDateInput() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function addDays(dateInput: string, days: number): string {
  const d = new Date(`${dateInput}T00:00:00`);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function formatDateLong(dateInput: string): string {
  if (!DATE_RE.test(dateInput)) return dateInput || "Invalid date";
  const d = new Date(`${dateInput}T00:00:00`);
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export function isValidTimeValue(value: string): boolean {
  return TIME_RE.test(String(value || "").trim());
}

function timeToMinutes(value: string): number | null {
  const match = String(value || "").trim().match(TIME_RE);
  if (!match) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}

function normalizeWindow(input: Partial<AvailabilityWindow>): AvailabilityWindow | null {
  const start = String(input.start || "").trim();
  const end = String(input.end || "").trim();
  if (!isValidTimeValue(start) || !isValidTimeValue(end)) return null;
  if (start === end) return null;
  return { start, end };
}

export function createDefaultWeeklyAvailability(): AvailabilityDay[] {
  return WEEKDAY_OPTIONS.map(({ dayOfWeek }) => ({
    dayOfWeek,
    enabled: dayOfWeek >= 1 && dayOfWeek <= 5,
    windows: dayOfWeek >= 1 && dayOfWeek <= 5 ? [{ start: "08:00", end: "17:00" }] : [],
  }));
}

export function createAvailabilityDateBlock(): AvailabilityDateBlock {
  const startDate = todayDateInput();
  return {
    id: `block_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    startDate,
    endDate: addDays(startDate, 27),
    daysOfWeek: [1, 2, 3, 4, 5],
    windows: [{ start: "08:00", end: "17:00" }],
  };
}

export function sanitizeDateBlocks(raw: unknown): AvailabilityDateBlock[] {
  const items = Array.isArray(raw) ? raw : [];
  return items
    .map((item) => {
      const startDate = String((item as any)?.startDate || "").trim();
      const endDate = String((item as any)?.endDate || "").trim();
      if (!DATE_RE.test(startDate) || !DATE_RE.test(endDate) || startDate > endDate) return null;
      const daysOfWeek = Array.isArray((item as any)?.daysOfWeek)
        ? (Array.from(
            new Set<number>(
              (item as any).daysOfWeek
                .map((day: unknown) => Number(day))
                .filter((day: number) => Number.isInteger(day) && day >= 0 && day <= 6)
            )
          ) as number[]).sort((a, b) => a - b)
        : [];
      const windows = Array.isArray((item as any)?.windows)
        ? ((item as any).windows as unknown[])
            .map((window) => normalizeWindow((window as any) || {}))
            .filter((window): window is AvailabilityWindow => Boolean(window))
        : [];
      if (daysOfWeek.length === 0 || windows.length === 0) return null;
      windows.sort((a, b) => (timeToMinutes(a.start) ?? 0) - (timeToMinutes(b.start) ?? 0));
      return {
        id: String((item as any)?.id || `block_${startDate}_${endDate}`),
        startDate,
        endDate,
        daysOfWeek,
        windows,
      };
    })
    .filter((item): item is AvailabilityDateBlock => Boolean(item))
    .sort((a, b) => {
      if (a.startDate !== b.startDate) return a.startDate.localeCompare(b.startDate);
      return a.endDate.localeCompare(b.endDate);
    });
}

export function sanitizeWeeklyAvailability(raw: unknown): AvailabilityDay[] {
  const byDay = new Map<number, AvailabilityDay>();
  const items = Array.isArray(raw) ? raw : [];

  for (const day of items) {
    const dayOfWeek = Number((day as any)?.dayOfWeek);
    if (!Number.isInteger(dayOfWeek) || dayOfWeek < 0 || dayOfWeek > 6) continue;
    const windows = Array.isArray((day as any)?.windows)
      ? ((day as any).windows as unknown[])
          .map((window) => normalizeWindow((window as any) || {}))
          .filter((window): window is AvailabilityWindow => Boolean(window))
      : [];

    windows.sort((a, b) => {
      const aMinutes = timeToMinutes(a.start) ?? 0;
      const bMinutes = timeToMinutes(b.start) ?? 0;
      return aMinutes - bMinutes;
    });

    byDay.set(dayOfWeek, {
      dayOfWeek,
      enabled: Boolean((day as any)?.enabled) && windows.length > 0,
      windows,
    });
  }

  return WEEKDAY_OPTIONS.map(({ dayOfWeek }) => {
    const existing = byDay.get(dayOfWeek);
    if (existing) return existing;
    return { dayOfWeek, enabled: false, windows: [] };
  });
}

function dateInputFromDate(date: Date): string {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function zonedDateParts(date: Date, timeZone?: string | null) {
  if (!timeZone) {
    return {
      dateInput: dateInputFromDate(date),
      dayOfWeek: date.getDay(),
      startMinutes: date.getHours() * 60 + date.getMinutes(),
    };
  }

  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    weekday: "short",
  });
  const parts = formatter.formatToParts(date);
  const byType: Record<string, string> = {};
  for (const part of parts) {
    if (part.type !== "literal") byType[part.type] = part.value;
  }
  const year = Number(byType.year);
  const month = Number(byType.month);
  const day = Number(byType.day);
  const hour = Number(byType.hour);
  const minute = Number(byType.minute);
  const weekday = WEEKDAY_INDEX[byType.weekday] ?? date.getDay();
  return {
    dateInput: `${year}-${pad2(month)}-${pad2(day)}`,
    dayOfWeek: weekday,
    startMinutes: hour * 60 + minute,
  };
}

export function getAvailabilityForDay(
  weekly: AvailabilityDay[] | null | undefined,
  dayOfWeek: number
): AvailabilityDay {
  const safeWeekly = sanitizeWeeklyAvailability(weekly);
  return (
    safeWeekly.find((entry) => entry.dayOfWeek === dayOfWeek) || {
      dayOfWeek,
      enabled: false,
      windows: [],
    }
  );
}

function windowCoversSlot(window: AvailabilityWindow, slotStartMinutes: number, slotEndMinutes: number): boolean {
  const startMinutes = timeToMinutes(window.start);
  const endMinutes = timeToMinutes(window.end);
  if (startMinutes == null || endMinutes == null) return false;

  if (endMinutes > startMinutes) {
    return slotStartMinutes >= startMinutes && slotEndMinutes <= endMinutes;
  }

  const normalizedSlotStart = slotStartMinutes < startMinutes ? slotStartMinutes + 1440 : slotStartMinutes;
  const normalizedSlotEnd = slotEndMinutes <= startMinutes ? slotEndMinutes + 1440 : slotEndMinutes;
  const normalizedWindowEnd = endMinutes + 1440;
  return normalizedSlotStart >= startMinutes && normalizedSlotEnd <= normalizedWindowEnd;
}

export function isClinicianAvailableAt(
  doc: ClinicianAvailabilityDoc | null | undefined,
  at: Date | null,
  durationMinutes: number
): boolean {
  if (!doc || !at) return false;
  const zoned = zonedDateParts(at, doc.timeZone);
  const startMinutes = zoned.startMinutes;
  const slotEnd = startMinutes + Math.max(0, Number(durationMinutes || 0));
  const dateInput = zoned.dateInput;
  const dateBlocks = sanitizeDateBlocks(doc.dateBlocks);
  if (dateBlocks.length > 0) {
    const applicableBlocks = dateBlocks.filter(
      (block) =>
        dateInput >= block.startDate &&
        dateInput <= block.endDate &&
        block.daysOfWeek.includes(zoned.dayOfWeek)
    );
    return applicableBlocks.some((block) =>
      block.windows.some((window) => windowCoversSlot(window, startMinutes, slotEnd))
    );
  }

  const day = getAvailabilityForDay(doc.weekly, zoned.dayOfWeek);
  if (!day.enabled || day.windows.length === 0) return false;
  return day.windows.some((window) => windowCoversSlot(window, startMinutes, slotEnd));
}

export function formatDayAvailability(day: AvailabilityDay | null | undefined): string {
  if (!day || !day.enabled || day.windows.length === 0) return "Unavailable";
  return day.windows.map((window) => `${window.start}-${window.end}`).join(", ");
}

export function formatDateBlockSummary(block: AvailabilityDateBlock): string {
  const weekdaySummary = block.daysOfWeek
    .map((day) => WEEKDAY_OPTIONS.find((option) => option.dayOfWeek === day)?.shortLabel || String(day))
    .join(", ");
  const windowSummary = block.windows.map((window) => `${window.start}-${window.end}`).join(", ");
  return `${formatDateLong(block.startDate)} to ${formatDateLong(block.endDate)} · ${weekdaySummary} · ${windowSummary}`;
}

export function formatAvailabilityForDate(
  doc: ClinicianAvailabilityDoc | null | undefined,
  at: Date | null
): string {
  if (!doc || !at) return "No roster configured";
  const zoned = zonedDateParts(at, doc.timeZone);
  const dateInput = zoned.dateInput;
  const dateBlocks = sanitizeDateBlocks(doc.dateBlocks);
  if (dateBlocks.length > 0) {
    const applicableBlocks = dateBlocks.filter(
      (block) =>
        dateInput >= block.startDate &&
        dateInput <= block.endDate &&
        block.daysOfWeek.includes(zoned.dayOfWeek)
    );
    if (applicableBlocks.length === 0) return "No roster block covers that date";
    return applicableBlocks.map(formatDateBlockSummary).join(" | ");
  }
  return formatDayAvailability(getAvailabilityForDay(doc.weekly, zoned.dayOfWeek));
}

export function availabilityStatusLabel(status: AvailabilityStatus): string {
  if (status === "available") return "Available";
  if (status === "busy") return "Busy";
  if (status === "outside_roster") return "Outside roster";
  return "No roster";
}
