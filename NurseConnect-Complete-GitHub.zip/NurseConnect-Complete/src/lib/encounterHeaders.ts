export type EncounterHeaderLike = {
  patientId: string;
  practitionerId: string;
  practiceId?: string | null;
  practitionerDisplayName?: string | null;
  practitionerLabel?: string | null;
  encounterDate: string;
  encounterDateISO?: string | null;
  type?: string | null;
  reason?: string | null;
  status?: "draft" | "completed" | null;
  breakGlass?: {
    enabled?: boolean;
    enabledBy?: string;
    enabledAt?: unknown;
    reason?: string;
    resolvedBy?: string;
    resolvedAt?: unknown;
    correctionReason?: string;
  } | null;
  createdAt?: unknown;
  updatedAt?: unknown;
  updatedBy?: string | null;
};

export function buildEncounterHeader(data: EncounterHeaderLike) {
  return {
    patientId: data.patientId,
    practitionerId: data.practitionerId,
    practiceId: data.practiceId ?? null,
    practitionerDisplayName: data.practitionerDisplayName ?? null,
    practitionerLabel: data.practitionerLabel ?? null,
    encounterDate: data.encounterDate,
    encounterDateISO: data.encounterDateISO ?? null,
    type: data.type ?? "consultation",
    reason: null,
    status: data.status ?? "draft",
    breakGlass: data.breakGlass ?? { enabled: false },
    createdAt: data.createdAt ?? null,
    updatedAt: data.updatedAt ?? null,
    updatedBy: data.updatedBy ?? null,
  };
}
