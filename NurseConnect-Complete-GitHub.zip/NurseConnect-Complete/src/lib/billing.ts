export const SUPPORTED_CURRENCIES = ["AUD", "USD", "EUR", "GBP", "NZD"] as const;
export type SupportedCurrency = (typeof SUPPORTED_CURRENCIES)[number];
export const AUSTRALIAN_PRIVATE_FUNDS = [
  "Bupa",
  "Medibank",
  "HCF",
  "nib",
  "ahm",
  "Australian Unity",
] as const;
export const INSURER_OTHER = "__OTHER__";

const DEFAULT_CURRENCY_FALLBACK: SupportedCurrency = "AUD";
const DEFAULT_CURRENCY_KEY = "eirenix_default_currency";

export function normalizeCurrency(input?: string | null): SupportedCurrency {
  const code = String(input || "").trim().toUpperCase();
  if ((SUPPORTED_CURRENCIES as readonly string[]).includes(code)) {
    return code as SupportedCurrency;
  }
  return DEFAULT_CURRENCY_FALLBACK;
}

export function getDefaultCurrency(): SupportedCurrency {
  if (typeof window !== "undefined") {
    try {
      const stored = window.localStorage.getItem(DEFAULT_CURRENCY_KEY);
      if (stored) return normalizeCurrency(stored);
    } catch {
      // ignore storage access failures
    }
  }
  const envCode =
    (typeof process !== "undefined" && process.env && (process.env.REACT_APP_DEFAULT_CURRENCY as string)) || "";
  return normalizeCurrency(envCode || DEFAULT_CURRENCY_FALLBACK);
}

export function setDefaultCurrency(currency: string): SupportedCurrency {
  const normalized = normalizeCurrency(currency);
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(DEFAULT_CURRENCY_KEY, normalized);
    } catch {
      // ignore storage access failures
    }
  }
  return normalized;
}

export function formatMoney(cents: number, currency?: string): string {
  const safeCurrency = normalizeCurrency(currency || getDefaultCurrency());
  return new Intl.NumberFormat("en-AU", {
    style: "currency",
    currency: safeCurrency,
    minimumFractionDigits: 2,
  }).format((Number(cents || 0) || 0) / 100);
}
