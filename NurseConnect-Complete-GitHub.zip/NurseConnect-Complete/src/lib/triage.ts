import { httpsCallable } from "firebase/functions";
import { functions } from "../firebaseConfig";
import { TriageAnswerResult, TriageChannel, TriageOutcome, TriageSessionStartResult } from "../models/triage";

export async function startTriageSession(appointmentId: string, channel: TriageChannel = "portal") {
  const call = httpsCallable(functions, "startTriageSession");
  const res = await call({ appointmentId, channel });
  return res.data as TriageSessionStartResult;
}

export async function submitTriageAnswer(triageSessionId: string, questionId: string, value: string) {
  const call = httpsCallable(functions, "submitTriageAnswer");
  const res = await call({ triageSessionId, questionId, value });
  return res.data as TriageAnswerResult;
}

export async function finalizeTriageSession(triageSessionId: string) {
  const call = httpsCallable(functions, "finalizeTriageSession");
  const res = await call({ triageSessionId });
  return res.data as TriageOutcome;
}
