import {
  collection,
  doc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  where
} from "firebase/firestore";
import { db } from "../firebaseConfig";

export type PrescriptionTrackingStatus =
  | "active"
  | "initial_dispensed"
  | "partially_dispensed"
  | "fully_dispensed"
  | "cancelled"
  | "superseded";

export type PrescriptionRecord = {
  prescriptionId: string;
  chartEntryId: string;
  patientId: string;
  practiceId: string;
  medication: string;
  strength: string;
  dose: string;
  route: string;
  frequency: string;
  duration: string;
  quantity: string;
  indication: string;
  notes: string;
  originalRepeats: number;
  remainingRepeatsReported: number;
  totalDispenseNotifications: number;
  initialDispenseRecorded: boolean;
  status: PrescriptionTrackingStatus;
  issuedByUid: string;
  issuedAt?: string;
  lastDispensedAt?: string | null;
  lastDispensedByPharmacy?: string | null;
  lastVerificationMethod?: string | null;
  sourceAppointmentId?: string | null;
  sourceEncounterId?: string | null;
  trackingMode: "clinic_reported";
  createdAt?: unknown;
  updatedAt?: unknown;
};

export type DispenseNotificationInput = {
  prescriptionId: string;
  patientId: string;
  clinicianUid: string;
  pharmacyName: string;
  pharmacistName: string;
  dispenseDate: string;
  quantityDispensed: string;
  dispenseKind: "initial" | "repeat";
  verificationMethod: "phone_verified" | "manual_exception";
  notes: string;
};

export type PrescriptionDispenseNotification = {
  id: string;
  prescriptionId: string;
  patientId: string;
  practiceId: string;
  pharmacyName: string;
  pharmacistName: string;
  dispenseDate: string;
  quantityDispensed: string;
  dispenseKind: "initial" | "repeat";
  verificationMethod: "phone_verified" | "manual_exception";
  verifiedByPrescriberUid: string;
  notes: string;
  createdAt?: unknown;
};

export function prescriptionTrackingStatusLabel(status: string) {
  if (status === "fully_dispensed") return "Fully dispensed";
  if (status === "partially_dispensed") return "Repeat(s) partly used";
  if (status === "initial_dispensed") return "Initial dispense recorded";
  if (status === "cancelled") return "Cancelled";
  if (status === "superseded") return "Superseded";
  return "Active";
}

function buildPrescriptionStatus(record: {
  initialDispenseRecorded: boolean;
  remainingRepeatsReported: number;
  totalDispenseNotifications: number;
}): PrescriptionTrackingStatus {
  if (!record.initialDispenseRecorded) return "active";
  if (record.remainingRepeatsReported <= 0) return "fully_dispensed";
  if (record.totalDispenseNotifications <= 1) return "initial_dispensed";
  return "partially_dispensed";
}

export function prescriptionPortalPayload(record: PrescriptionRecord, basePayload?: Record<string, unknown>) {
  return {
    ...(basePayload || {}),
    prescriptionId: record.prescriptionId,
    originalRepeats: String(record.originalRepeats),
    remainingRepeatsReported: String(record.remainingRepeatsReported),
    totalDispenseNotifications: String(record.totalDispenseNotifications),
    clinicTrackingStatus: record.status,
    clinicTrackingStatusLabel: prescriptionTrackingStatusLabel(record.status),
    clinicTrackingMode: record.trackingMode,
    clinicTrackingDisclaimer:
      "Remaining repeats shown here reflect dispense notifications reported back to this clinic only. This is not a national live eScript register.",
    initialDispenseRecorded: record.initialDispenseRecorded ? "yes" : "no",
    lastDispensedAt: record.lastDispensedAt || "",
    lastDispensedByPharmacy: record.lastDispensedByPharmacy || "",
    lastVerificationMethod: record.lastVerificationMethod || "",
  };
}

export async function listPatientPrescriptions(patientId: string) {
  const snap = await getDocs(
    query(collection(db, "prescriptions"), where("patientId", "==", patientId), orderBy("updatedAt", "desc"), limit(200))
  );
  return snap.docs.map((item) => ({ id: item.id, ...(item.data() as any) })) as Array<PrescriptionRecord & { id: string }>;
}

export async function recordDispenseNotification(input: DispenseNotificationInput) {
  const prescriptionRef = doc(db, "prescriptions", input.prescriptionId);
  const uploadRef = doc(db, "patients", input.patientId, "portalDocuments", input.prescriptionId);
  const dispenseRef = doc(collection(db, "prescriptions", input.prescriptionId, "dispenses"));

  await runTransaction(db, async (tx) => {
    const [prescriptionSnap, uploadSnap] = await Promise.all([tx.get(prescriptionRef), tx.get(uploadRef)]);
    if (!prescriptionSnap.exists()) {
      throw new Error("Prescription tracking record not found.");
    }
    const current = prescriptionSnap.data() as PrescriptionRecord;
    if (current.status === "cancelled" || current.status === "superseded" || current.status === "fully_dispensed") {
      throw new Error("This prescription is not available for another dispense notification.");
    }
    if (input.dispenseKind === "initial" && current.initialDispenseRecorded) {
      throw new Error("The initial dispense has already been recorded for this prescription.");
    }
    if (input.dispenseKind === "repeat" && current.remainingRepeatsReported < 1) {
      throw new Error("No remaining repeats are available to record.");
    }

    const nextRemainingRepeats =
      input.dispenseKind === "repeat" ? Math.max(0, current.remainingRepeatsReported - 1) : current.remainingRepeatsReported;
    const nextTotalNotifications = (current.totalDispenseNotifications || 0) + 1;
    const nextInitialDispenseRecorded = current.initialDispenseRecorded || input.dispenseKind === "initial";
    const nextStatus = buildPrescriptionStatus({
      initialDispenseRecorded: nextInitialDispenseRecorded,
      remainingRepeatsReported: nextRemainingRepeats,
      totalDispenseNotifications: nextTotalNotifications,
    });

    const nextRecord: PrescriptionRecord = {
      ...current,
      remainingRepeatsReported: nextRemainingRepeats,
      totalDispenseNotifications: nextTotalNotifications,
      initialDispenseRecorded: nextInitialDispenseRecorded,
      status: nextStatus,
      lastDispensedAt: input.dispenseDate,
      lastDispensedByPharmacy: input.pharmacyName,
      lastVerificationMethod: input.verificationMethod,
    };

    const basePayload =
      uploadSnap.exists() && typeof uploadSnap.data()?.printablePayload === "object"
        ? (uploadSnap.data()?.printablePayload as Record<string, unknown>)
        : {};

    tx.set(
      prescriptionRef,
      {
        remainingRepeatsReported: nextRemainingRepeats,
        totalDispenseNotifications: nextTotalNotifications,
        initialDispenseRecorded: nextInitialDispenseRecorded,
        status: nextStatus,
        lastDispensedAt: input.dispenseDate,
        lastDispensedByPharmacy: input.pharmacyName,
        lastVerificationMethod: input.verificationMethod,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    tx.set(dispenseRef, {
      prescriptionId: input.prescriptionId,
      patientId: input.patientId,
      practiceId: current.practiceId,
      pharmacyName: input.pharmacyName.trim(),
      pharmacistName: input.pharmacistName.trim(),
      dispenseDate: input.dispenseDate,
      quantityDispensed: input.quantityDispensed.trim(),
      dispenseKind: input.dispenseKind,
      verificationMethod: input.verificationMethod,
      verifiedByPrescriberUid: input.clinicianUid,
      notes: input.notes.trim(),
      createdAt: serverTimestamp(),
    } satisfies Omit<PrescriptionDispenseNotification, "id">);

    tx.set(
      uploadRef,
      {
        printablePayload: prescriptionPortalPayload(nextRecord, basePayload),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  });
}
