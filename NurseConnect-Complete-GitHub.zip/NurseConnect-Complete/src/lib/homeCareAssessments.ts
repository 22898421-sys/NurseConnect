import { collection, doc, runTransaction, serverTimestamp } from "firebase/firestore";
import { db } from "../firebaseConfig";

export type HomeCareConcernLevel = "low" | "moderate" | "high" | "urgent";
export type HomeCareAssessmentTemplateKey = "initial_home_visit" | "falls_review" | "wound_review" | "palliative_support_review";

export type HomeCareAssessmentDomain = {
  key:
    | "fallsMobility"
    | "skinIntegrity"
    | "medicationSupport"
    | "cognitionCapacity"
    | "continence"
    | "homeEnvironment"
    | "carerSupport"
    | "escalationNeed";
  title: string;
  concernLevel: HomeCareConcernLevel;
  summary: string;
};

export type HomeCareAssessmentSummary = {
  templateKey?: HomeCareAssessmentTemplateKey | null;
  overallConcernLevel?: HomeCareConcernLevel | null;
  reviewTimeframe?: string | null;
  carePrioritySummary?: string | null;
  escalationAction?: string | null;
};

export type RiskAssessmentDoc = {
  tool: "nurse_home_care_assessment";
  status: "completed";
  integrationMode: "nurse_workflow";
  templateKey: HomeCareAssessmentTemplateKey;
  patientId: string;
  practiceId: string;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  launchedByUid: string;
  launchedByDisplayName?: string | null;
  launchedAt?: unknown;
  completedAt?: unknown;
  updatedAt?: unknown;
  questionnairePayload: {
    visitContext?: string | null;
    domains: HomeCareAssessmentDomain[];
  };
  scorePayload: {
    domainCount: number;
    highConcernCount: number;
    urgentConcernCount: number;
  };
  resultSummary: HomeCareAssessmentSummary;
  printableSummary: string;
  reportStatus: "pending_pdf_generation";
  reportStoragePath?: string | null;
  reportFileName?: string | null;
};

type CreateManualRiskAssessmentInput = {
  templateKey: HomeCareAssessmentTemplateKey;
  patientId: string;
  practiceId: string;
  clinicianUid: string;
  clinicianDisplayName?: string | null;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  questionnairePayload: {
    visitContext?: string | null;
    domains: HomeCareAssessmentDomain[];
  };
  scorePayload: {
    domainCount: number;
    highConcernCount: number;
    urgentConcernCount: number;
  };
  resultSummary: HomeCareAssessmentSummary;
  printableSummary: string;
};

export type HomeCareAssessmentTemplate = {
  key: HomeCareAssessmentTemplateKey;
  label: string;
  description: string;
  suggestedVisitContext: string;
  defaultReviewTimeframe: string;
  domainKeys: HomeCareAssessmentDomain["key"][];
};

type ClinicalDocumentEntry = {
  id: string;
  date: string;
  title: string;
  status: string;
  notes: string;
  attachments: Array<unknown>;
  meta: Record<string, unknown>;
};

function makeId(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function todayDateInput() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

const DOMAIN_LABELS: Record<HomeCareAssessmentDomain["key"], string> = {
  fallsMobility: "Falls and mobility",
  skinIntegrity: "Skin integrity and wounds",
  medicationSupport: "Medication support and adherence",
  cognitionCapacity: "Cognition, communication, and capacity",
  continence: "Continence, catheter, or stoma care",
  homeEnvironment: "Home environment and safety",
  carerSupport: "Carer capability and support",
  escalationNeed: "Escalation and follow-up need",
};

export const HOME_CARE_ASSESSMENT_TEMPLATES: HomeCareAssessmentTemplate[] = [
  {
    key: "initial_home_visit",
    label: "Initial home visit",
    description: "Broad first-visit assessment covering safety, support needs, medication, environment, and escalation planning.",
    suggestedVisitContext: "Initial home nursing assessment",
    defaultReviewTimeframe: "Within 7 days",
    domainKeys: ["fallsMobility", "skinIntegrity", "medicationSupport", "cognitionCapacity", "continence", "homeEnvironment", "carerSupport", "escalationNeed"],
  },
  {
    key: "falls_review",
    label: "Falls review",
    description: "Focused review of falls risk, mobility supports, home hazards, cognition, and follow-up escalation.",
    suggestedVisitContext: "Falls and mobility review",
    defaultReviewTimeframe: "Within 48 hours",
    domainKeys: ["fallsMobility", "cognitionCapacity", "homeEnvironment", "carerSupport", "escalationNeed"],
  },
  {
    key: "wound_review",
    label: "Wound review",
    description: "Focused review for wound status, skin integrity, medication support, environmental risks, and follow-up needs.",
    suggestedVisitContext: "Wound review visit",
    defaultReviewTimeframe: "At next scheduled dressing review",
    domainKeys: ["skinIntegrity", "medicationSupport", "homeEnvironment", "escalationNeed"],
  },
  {
    key: "palliative_support_review",
    label: "Palliative support review",
    description: "Supportive review of symptom management, continence needs, home setup, family support, and escalation planning.",
    suggestedVisitContext: "Palliative support review",
    defaultReviewTimeframe: "Within 24 hours",
    domainKeys: ["medicationSupport", "cognitionCapacity", "continence", "homeEnvironment", "carerSupport", "escalationNeed"],
  },
];

export function getHomeCareAssessmentTemplate(key?: HomeCareAssessmentTemplateKey | null): HomeCareAssessmentTemplate {
  return HOME_CARE_ASSESSMENT_TEMPLATES.find((item) => item.key === key) || HOME_CARE_ASSESSMENT_TEMPLATES[0];
}

export function buildTemplateDomains(key?: HomeCareAssessmentTemplateKey | null): HomeCareAssessmentDomain[] {
  const template = getHomeCareAssessmentTemplate(key);
  return template.domainKeys.map((domainKey) => ({
    key: domainKey,
    title: DOMAIN_LABELS[domainKey],
    concernLevel: "low",
    summary: "",
  }));
}

export function formatConcernLevel(level?: HomeCareConcernLevel | null) {
  if (!level) return "Not recorded";
  return level.charAt(0).toUpperCase() + level.slice(1);
}

export function buildRiskAssessmentPlanLine(summary: HomeCareAssessmentSummary): string {
  const parts: string[] = [];
  if (summary.templateKey) parts.push(getHomeCareAssessmentTemplate(summary.templateKey).label.toLowerCase());
  if (summary.overallConcernLevel) parts.push(`overall concern ${formatConcernLevel(summary.overallConcernLevel).toLowerCase()}`);
  if (summary.reviewTimeframe) parts.push(`review ${summary.reviewTimeframe}`);
  if (summary.carePrioritySummary) parts.push(summary.carePrioritySummary);
  if (summary.escalationAction) parts.push(`escalation: ${summary.escalationAction}`);
  const line = parts.length ? `Home-care assessment: ${parts.join("; ")}.` : "Home-care assessment completed.";
  return line;
}

function buildRiskAssessmentDocumentTitle(summary: HomeCareAssessmentSummary) {
  const level = formatConcernLevel(summary.overallConcernLevel);
  const templateLabel = summary.templateKey ? getHomeCareAssessmentTemplate(summary.templateKey).label : "Home-care assessment";
  return `${templateLabel} summary (${level})`;
}

function buildDomainNotes(domains: HomeCareAssessmentDomain[]) {
  return domains.map((domain) => `${domain.title}: ${formatConcernLevel(domain.concernLevel)}. ${domain.summary}`).join("\n");
}

function buildRiskAssessmentDocumentEntry(assessmentId: string, input: CreateManualRiskAssessmentInput): ClinicalDocumentEntry {
  return {
    id: makeId("entry"),
    date: todayDateInput(),
    title: buildRiskAssessmentDocumentTitle(input.resultSummary),
    status: "completed",
    notes: [
      "Home-care assessment summary",
      input.resultSummary.templateKey ? `Template: ${getHomeCareAssessmentTemplate(input.resultSummary.templateKey).label}` : "",
      input.resultSummary.overallConcernLevel ? `Overall concern: ${formatConcernLevel(input.resultSummary.overallConcernLevel)}` : "",
      input.resultSummary.reviewTimeframe ? `Review timeframe: ${input.resultSummary.reviewTimeframe}` : "",
      input.resultSummary.carePrioritySummary ? `Priority summary: ${input.resultSummary.carePrioritySummary}` : "",
      input.resultSummary.escalationAction ? `Escalation action: ${input.resultSummary.escalationAction}` : "",
      input.questionnairePayload.visitContext ? `Visit context: ${input.questionnairePayload.visitContext}` : "",
      "",
      buildDomainNotes(input.questionnairePayload.domains),
      "",
      String(input.printableSummary || "").trim(),
      "",
      "PDF generation pending future report generation workflow.",
    ]
      .filter(Boolean)
      .join("\n"),
    attachments: [],
    meta: {
      kind: "home_care_assessment_summary",
      tool: "nurse_home_care_assessment",
      linkedAssessmentId: assessmentId,
      sourceEncounterId: input.sourceEncounterId || "",
      sourceAppointmentId: input.sourceAppointmentId || "",
      reportStatus: "pending_pdf_generation",
    },
  };
}

function appendDocumentEntryToChartData(chartData: any, entry: ClinicalDocumentEntry) {
  const safeChartData = chartData && typeof chartData === "object" ? chartData : {};
  const documents = safeChartData.documents && typeof safeChartData.documents === "object" ? safeChartData.documents : {};
  const items = Array.isArray(documents.items) ? [...documents.items] : [];
  return {
    ...safeChartData,
    documents: {
      ...documents,
      items: [entry, ...items],
    },
  };
}

export async function createManualRiskAssessment(input: CreateManualRiskAssessmentInput) {
  const assessmentRef = doc(collection(db, "riskAssessments"));
  const clinicalRef = doc(db, "patientClinicalRecords", input.patientId);
  const documentEntry = buildRiskAssessmentDocumentEntry(assessmentRef.id, input);
  const planLine = buildRiskAssessmentPlanLine(input.resultSummary);

  await runTransaction(db, async (tx) => {
    const clinicalSnap = await tx.get(clinicalRef);
    const previousChartData = clinicalSnap.exists() ? (clinicalSnap.data() as any)?.chartData ?? null : null;
    const nextChartData = appendDocumentEntryToChartData(previousChartData, documentEntry);

    const assessmentDoc: RiskAssessmentDoc = {
      tool: "nurse_home_care_assessment",
      status: "completed",
      integrationMode: "nurse_workflow",
      templateKey: input.templateKey,
      patientId: input.patientId,
      practiceId: input.practiceId,
      sourceEncounterId: input.sourceEncounterId || null,
      sourceAppointmentId: input.sourceAppointmentId || null,
      launchedByUid: input.clinicianUid,
      launchedByDisplayName: input.clinicianDisplayName || null,
      launchedAt: serverTimestamp(),
      completedAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      questionnairePayload: input.questionnairePayload,
      scorePayload: input.scorePayload,
      resultSummary: input.resultSummary,
      printableSummary: input.printableSummary,
      reportStatus: "pending_pdf_generation",
      reportStoragePath: null,
      reportFileName: null,
    };

    tx.set(assessmentRef, assessmentDoc);
    tx.set(
      clinicalRef,
      {
        patientId: input.patientId,
        practiceId: input.practiceId,
        chartData: nextChartData,
        updatedAt: serverTimestamp(),
        updatedByUid: input.clinicianUid,
      },
      { merge: true }
    );

    const auditRef = doc(collection(db, "patientClinicalRecords", input.patientId, "revisions"));
    tx.set(auditRef, {
      patientId: input.patientId,
      practiceId: input.practiceId,
      editorId: input.clinicianUid,
      editedAt: serverTimestamp(),
      previousChartData,
      nextChartData,
      reason: "home_care_assessment_summary_added",
      linkedAssessmentId: assessmentRef.id,
    });
  });

  return {
    assessmentId: assessmentRef.id,
    planLine,
    documentEntryTitle: documentEntry.title,
  };
}
