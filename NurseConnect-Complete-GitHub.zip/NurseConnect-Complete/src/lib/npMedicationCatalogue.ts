import cache from "../data/npMedicationCatalogue.json";

export type NPMedicationCatalogueItem = {
  id: string;
  medicationName: string;
  form?: string;
  strength?: string;
  route?: string;
  defaultFrequency?: string;
  notes?: string;
};

type CatalogueCache = {
  source: {
    label: string;
    organisation: string;
    browseUrl: string;
    dataUrl: string;
    apiInfoUrl: string;
    disclaimer: string;
  };
  generatedAt: string | null;
  itemCount: number;
  items: NPMedicationCatalogueItem[];
};

const typedCache = cache as CatalogueCache;

export const NP_MEDICATION_CATALOGUE_SOURCE = typedCache.source;
export const NP_MEDICATION_CATALOGUE_GENERATED_AT = typedCache.generatedAt;
export const NP_MEDICATION_CATALOGUE_COUNT = typedCache.itemCount;
export const NP_MEDICATION_CATALOGUE: NPMedicationCatalogueItem[] = Array.isArray(typedCache.items) ? typedCache.items : [];

export const NP_PBS_BROWSE_INITIALS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").map((initial) => ({
  initial,
  url: `https://www.pbs.gov.au/browse/nurse?initial=${initial.toLowerCase()}`,
}));
