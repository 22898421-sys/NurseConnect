export type FundingPathway = "support_at_home" | "private_pay";
export type EvidenceRelayChannel = "email";
export type RecipientType = "care_manager" | "provider_finance" | "xero" | "client" | "other";
export type InvoiceStatus = "draft" | "ready_to_issue" | "issued" | "relayed" | "paid" | "cancelled";
export type TaxTreatment = "gst_free" | "gst_included" | "tax_to_be_confirmed";

export type SupportAtHomeServiceItem = {
  id: string;
  code: string;
  title: string;
  category: string;
  groupCode: string;
  groupTitle: string;
  unitLabel: string;
  defaultDurationMinutes: number;
  nurseSummaryHint: string;
  invoiceDescriptionGuidance: string;
  eligibleNurseTypes: string[];
  deliveryModes: string[];
  fundingGuidance: string;
};

export const SUPPORT_AT_HOME_SERVICE_CATALOGUE: SupportAtHomeServiceItem[] = [
  {
    id: "a1-clinical-assessment-monitoring",
    code: "A1",
    title: "Clinical assessment and monitoring",
    category: "Clinical supports -> Nursing care",
    groupCode: "A",
    groupTitle: "Assessment & Monitoring",
    unitLabel: "visit",
    defaultDurationMinutes: 60,
    nurseSummaryHint: "Assessment findings, risks identified, and agreed next steps.",
    invoiceDescriptionGuidance:
      "Community-based nursing care provided to assess and monitor clinical conditions, in line with the participant's care plan.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person", "Telehealth"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "a2-post-hospital-nursing-review",
    code: "A2",
    title: "Post-hospital nursing review",
    category: "Support at Home aligned clinical care",
    groupCode: "A",
    groupTitle: "Assessment & Monitoring",
    unitLabel: "visit",
    defaultDurationMinutes: 60,
    nurseSummaryHint: "Recovery status, clinical review findings, and discharge-related follow-up.",
    invoiceDescriptionGuidance:
      "Post-hospital community nursing review to monitor recovery and manage clinical care needs following discharge.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "a3-chronic-condition-monitoring",
    code: "A3",
    title: "Chronic condition monitoring",
    category: "Support at Home aligned clinical care",
    groupCode: "A",
    groupTitle: "Assessment & Monitoring",
    unitLabel: "visit",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Clinical monitoring completed, education provided, and changes requiring follow-up.",
    invoiceDescriptionGuidance:
      "Ongoing nursing monitoring and support for chronic health conditions, including clinical observation and education.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person", "Telehealth"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "b1-medication-administration",
    code: "B1",
    title: "Medication administration",
    category: "Support at Home aligned clinical care",
    groupCode: "B",
    groupTitle: "Medication Support",
    unitLabel: "visit",
    defaultDurationMinutes: 30,
    nurseSummaryHint: "Medication administration completed, observations recorded, and escalation needs noted.",
    invoiceDescriptionGuidance:
      "Nursing care provided for safe administration of prescribed medications, including injections, as clinically indicated.",
    eligibleNurseTypes: ["RN", "EN (within scope/endorsement)"],
    deliveryModes: ["In person"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "b2-medication-adherence-support-education",
    code: "B2",
    title: "Medication adherence support and education",
    category: "Support at Home aligned clinical care",
    groupCode: "B",
    groupTitle: "Medication Support",
    unitLabel: "visit",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Medication adherence support provided, education delivered, and monitoring actions recorded.",
    invoiceDescriptionGuidance:
      "Nursing support to promote medication adherence, including monitoring and education.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person", "Telehealth"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "c1-wound-assessment-management",
    code: "C1",
    title: "Wound assessment and management",
    category: "Support at Home aligned clinical care",
    groupCode: "C",
    groupTitle: "Wound & Skin Care",
    unitLabel: "visit",
    defaultDurationMinutes: 60,
    nurseSummaryHint: "Wound assessment, treatment provided, dressing or product use, and review plan.",
    invoiceDescriptionGuidance:
      "Community-based nursing care to assess, treat and monitor wounds and skin integrity in accordance with clinical care needs.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "c2-pressure-injury-prevention-management",
    code: "C2",
    title: "Pressure injury prevention and management",
    category: "Support at Home aligned clinical care",
    groupCode: "C",
    groupTitle: "Wound & Skin Care",
    unitLabel: "visit",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Skin integrity support delivered, risks addressed, and management plan documented.",
    invoiceDescriptionGuidance:
      "Nursing care focused on skin integrity and pressure injury prevention and management.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "d1-clinical-continence-assessment",
    code: "D1",
    title: "Clinical continence assessment",
    category: "Support at Home aligned clinical care",
    groupCode: "D",
    groupTitle: "Continence & Elimination (Clinical)",
    unitLabel: "visit",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Continence needs assessed, education delivered, and monitoring or management plan documented.",
    invoiceDescriptionGuidance:
      "Clinical nursing assessment and management of continence needs, including education and monitoring.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "d2-catheter-care-management",
    code: "D2",
    title: "Catheter care and management",
    category: "Support at Home aligned clinical care",
    groupCode: "D",
    groupTitle: "Continence & Elimination (Clinical)",
    unitLabel: "visit",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Catheter care completed, observations recorded, and follow-up needs noted.",
    invoiceDescriptionGuidance:
      "Nursing care provided for catheter management and monitoring as required to meet clinical care needs.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "d3-stoma-care",
    code: "D3",
    title: "Stoma care",
    category: "Support at Home aligned clinical care",
    groupCode: "D",
    groupTitle: "Continence & Elimination (Clinical)",
    unitLabel: "visit",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Stoma care provided, observations recorded, and related education or monitoring needs documented.",
    invoiceDescriptionGuidance:
      "Specialised nursing care provided to support stoma management and related clinical monitoring.",
    eligibleNurseTypes: ["RN", "EN where appropriately trained"],
    deliveryModes: ["In person"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "e1-short-term-recovery-nursing",
    code: "E1",
    title: "Short-term recovery nursing",
    category: "Support at Home aligned clinical care",
    groupCode: "E",
    groupTitle: "Post-Acute & Restorative Nursing",
    unitLabel: "visit",
    defaultDurationMinutes: 60,
    nurseSummaryHint: "Recovery nursing support delivered, current status documented, and next recovery actions agreed.",
    invoiceDescriptionGuidance:
      "Short-term community nursing support to assist recovery following illness or surgery.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person", "Telehealth follow-up"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "e2-reablement-restorative-nursing-support",
    code: "E2",
    title: "Reablement and restorative nursing support",
    category: "Support at Home aligned restorative support",
    groupCode: "E",
    groupTitle: "Post-Acute & Restorative Nursing",
    unitLabel: "visit",
    defaultDurationMinutes: 60,
    nurseSummaryHint: "Restorative support delivered, function or independence goals reviewed, and progress noted.",
    invoiceDescriptionGuidance:
      "Time-limited nursing support aimed at restoring function and promoting independence.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person"],
    fundingGuidance: "May require confirmation",
  },
  {
    id: "f1-palliative-nursing-care",
    code: "F1",
    title: "Palliative nursing care",
    category: "Support at Home aligned clinical care",
    groupCode: "F",
    groupTitle: "Palliative & End-of-Life Nursing",
    unitLabel: "visit",
    defaultDurationMinutes: 60,
    nurseSummaryHint: "Symptom management, comfort measures, and family or care-team communication documented.",
    invoiceDescriptionGuidance:
      "Community-based nursing care focused on symptom management and comfort for individuals receiving palliative support.",
    eligibleNurseTypes: ["RN", "EN where appropriate"],
    deliveryModes: ["In person"],
    fundingGuidance: "May require confirmation",
  },
  {
    id: "f2-family-carer-support-palliative",
    code: "F2",
    title: "Family and carer support (palliative)",
    category: "Support at Home aligned clinical care",
    groupCode: "F",
    groupTitle: "Palliative & End-of-Life Nursing",
    unitLabel: "session",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Education and support provided to family or carers, with advice and care needs documented.",
    invoiceDescriptionGuidance:
      "Nursing support provided to educate and support family members and carers in managing care needs.",
    eligibleNurseTypes: ["RN"],
    deliveryModes: ["In person", "Telehealth"],
    fundingGuidance: "May require confirmation",
  },
  {
    id: "g1-health-education-self-management-support",
    code: "G1",
    title: "Health education and self-management support",
    category: "Support at Home aligned clinical care",
    groupCode: "G",
    groupTitle: "Education & Care Coordination",
    unitLabel: "session",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Health education delivered, self-management supports reviewed, and agreed actions documented.",
    invoiceDescriptionGuidance:
      "Nursing education provided to support safe self-management of health conditions and care needs.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["In person", "Telehealth"],
    fundingGuidance: "Commonly funded",
  },
  {
    id: "g2-nursing-liaison-care-coordination",
    code: "G2",
    title: "Nursing liaison and care coordination",
    category: "Support at Home aligned coordination support",
    groupCode: "G",
    groupTitle: "Education & Care Coordination",
    unitLabel: "session",
    defaultDurationMinutes: 45,
    nurseSummaryHint: "Coordination completed, liaison with health professionals documented, and next actions recorded.",
    invoiceDescriptionGuidance:
      "Nursing coordination and liaison with health professionals to support integrated care delivery.",
    eligibleNurseTypes: ["RN"],
    deliveryModes: ["In person", "Telehealth"],
    fundingGuidance: "May require confirmation",
  },
  {
    id: "h1-telehealth-nursing-consultation",
    code: "H1",
    title: "Telehealth nursing consultation",
    category: "Support at Home aligned clinical care",
    groupCode: "H",
    groupTitle: "Telehealth & Follow-up Nursing",
    unitLabel: "session",
    defaultDurationMinutes: 30,
    nurseSummaryHint: "Virtual consultation completed, clinical issues addressed, and follow-up plan documented.",
    invoiceDescriptionGuidance:
      "Virtual nursing consultation provided to support ongoing clinical monitoring and follow-up care.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["Telehealth"],
    fundingGuidance: "May require confirmation",
  },
  {
    id: "h2-medication-prompts-remote-monitoring",
    code: "H2",
    title: "Medication prompts and remote monitoring",
    category: "Support at Home aligned clinical care",
    groupCode: "H",
    groupTitle: "Telehealth & Follow-up Nursing",
    unitLabel: "session",
    defaultDurationMinutes: 20,
    nurseSummaryHint: "Remote monitoring or prompts completed, issues addressed, and escalation needs documented.",
    invoiceDescriptionGuidance:
      "Remote nursing support including clinical check-ins and medication prompts, where appropriate.",
    eligibleNurseTypes: ["RN", "EN"],
    deliveryModes: ["Telehealth"],
    fundingGuidance: "May require confirmation",
  },
];

export type ServiceInvoiceRecord = {
  id: string;
  invoiceNumber: string;
  nurseUid: string;
  practiceId?: string | null;
  patientId: string;
  patientName: string;
  appointmentId?: string | null;
  status: InvoiceStatus;
  fundingPathway: FundingPathway;
  currency: string;
  invoiceDate: string;
  dueDate?: string | null;
  taxTreatment: TaxTreatment;
  serviceItemId: string;
  serviceCode: string;
  serviceTitle: string;
  serviceCategory: string;
  serviceDate: string;
  serviceStartTime?: string | null;
  durationMinutes: number;
  quantity: number;
  unitLabel: string;
  unitPriceCents: number;
  totalCents: number;
  invoiceDescription: string;
  clinicalServiceNotes?: string | null;
  serviceSummary: string;
  visitConfirmation: {
    confirmed: true;
    confirmationMethod: string;
    confirmedAt: string;
  };
  nurseSnapshot: {
    displayName: string;
    designation?: string | null;
    nurseType?: string | null;
    ahpraRegistrationNumber?: string | null;
    businessName?: string | null;
    abn?: string | null;
    billingEmail?: string | null;
    billingPhone?: string | null;
    billingAddress?: string | null;
  };
  clientFundingSnapshot: {
    billingType?: string | null;
    pathwayLabel: string;
    nominatedPayerName?: string | null;
    nominatedPayerEmail?: string | null;
    recipientType?: RecipientType | null;
  };
  evidencePack: {
    bookingRecordSummary: string;
    credentialsSummary: string;
    visitConfirmationSummary: string;
    serviceSummary: string;
    documentationNoteSummary?: string | null;
    declarationSummary: string;
  };
  declarations: {
    billingAccuracyConfirmed: true;
    scopeAlignmentConfirmed: true;
    boundaryAcknowledged: true;
    declaredAt: string;
  };
  relay?: {
    recipientName?: string | null;
    recipientEmail?: string | null;
    recipientType?: RecipientType | null;
    channel?: EvidenceRelayChannel | null;
    lastRelayedAt?: string | null;
    relayCount?: number | null;
  } | null;
  auditTrail?: Array<{
    type: "created" | "status_changed" | "relayed";
    at: string;
    actorUid: string;
    note: string;
  }> | null;
  createdAt?: unknown;
  updatedAt?: unknown;
};

export function formatFundingPathwayLabel(pathway: FundingPathway) {
  return pathway === "support_at_home" ? "Support at Home" : "Private pay";
}

export function getServiceItemById(serviceItemId: string) {
  return SUPPORT_AT_HOME_SERVICE_CATALOGUE.find((item) => item.id === serviceItemId) || null;
}

export function formatInvoiceStatusLabel(status: InvoiceStatus) {
  switch (status) {
    case "ready_to_issue":
      return "Ready to issue";
    case "issued":
      return "Issued";
    case "relayed":
      return "Relayed";
    case "paid":
      return "Paid";
    case "cancelled":
      return "Cancelled";
    default:
      return "Draft";
  }
}

export function formatTaxTreatmentLabel(taxTreatment: TaxTreatment) {
  switch (taxTreatment) {
    case "gst_free":
      return "GST-free healthcare service";
    case "gst_included":
      return "GST included";
    default:
      return "Tax treatment to be confirmed by issuing nurse";
  }
}

export function isValidAbn(input: string) {
  const digits = String(input || "").replace(/[^\d]/g, "");
  if (digits.length !== 11) return false;
  const values = digits.split("").map((d) => Number(d));
  values[0] -= 1;
  const weights = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19];
  const total = values.reduce((sum, value, index) => sum + value * weights[index], 0);
  return total % 89 === 0;
}

export function buildServiceInvoiceNumber() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `NCC-${yyyy}${mm}${dd}-${suffix}`;
}

export function invoicePrintPath(invoiceId: string) {
  return `/billing/service-invoices/${invoiceId}/print`;
}

export function evidencePackPrintPath(invoiceId: string) {
  return `/billing/service-invoices/${invoiceId}/evidence`;
}
