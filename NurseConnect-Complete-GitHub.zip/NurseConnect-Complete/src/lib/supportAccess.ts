import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "../firebaseConfig";

export type SupportAccessStatus = "requested" | "approved" | "declined" | "closed";
export type SupportAccessUrgency = "routine" | "urgent";
export type SupportAccessScope = "patient_profile" | "technical_troubleshooting" | "billing_or_booking_support";
export type SupportGrantStatus = "active" | "revoked" | "expired";

export type SupportAccessRequest = {
  id: string;
  patientId: string;
  patientLabel?: string | null;
  practiceId?: string | null;
  practiceName?: string | null;
  requesterUid: string;
  requesterName?: string | null;
  reason: string;
  scope: SupportAccessScope;
  urgency: SupportAccessUrgency;
  status: SupportAccessStatus;
  assignedAdminUid?: string | null;
  decisionNote?: string | null;
  createdAt?: unknown;
  updatedAt?: unknown;
  approvedAt?: unknown;
  closedAt?: unknown;
};

export type SupportAccessGrant = {
  id: string;
  requestId: string;
  patientId: string;
  adminUid: string;
  status: SupportGrantStatus;
  reason: string;
  expiresAt: unknown;
  createdAt?: unknown;
  updatedAt?: unknown;
};

function cleanText(value: unknown) {
  return String(value || "").trim();
}

export function supportGrantId(patientId: string, adminUid: string) {
  return `${cleanText(patientId)}_${cleanText(adminUid)}`;
}

export function toAccessDateLabel(value: unknown) {
  const date = value instanceof Date ? value : typeof (value as any)?.toDate === "function" ? (value as any).toDate() : null;
  return date ? date.toLocaleString() : "Not recorded";
}

export async function createSupportAccessRequest(input: {
  patientId: string;
  patientLabel?: string;
  practiceId?: string | null;
  practiceName?: string | null;
  requesterUid: string;
  requesterName?: string | null;
  reason: string;
  scope: SupportAccessScope;
  urgency: SupportAccessUrgency;
}) {
  return addDoc(collection(db, "supportAccessRequests"), {
    patientId: cleanText(input.patientId),
    patientLabel: cleanText(input.patientLabel) || null,
    practiceId: cleanText(input.practiceId) || null,
    practiceName: cleanText(input.practiceName) || null,
    requesterUid: cleanText(input.requesterUid),
    requesterName: cleanText(input.requesterName) || null,
    reason: cleanText(input.reason),
    scope: input.scope,
    urgency: input.urgency,
    status: "requested",
    assignedAdminUid: null,
    decisionNote: null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

export async function listMySupportAccessRequests(uid: string) {
  const q = query(
    collection(db, "supportAccessRequests"),
    where("requesterUid", "==", uid),
    orderBy("updatedAt", "desc"),
    limit(100)
  );
  const snap = await getDocs(q);
  return snap.docs.map((row) => ({ id: row.id, ...(row.data() as any) })) as SupportAccessRequest[];
}

export async function listAllSupportAccessRequests() {
  const q = query(collection(db, "supportAccessRequests"), orderBy("updatedAt", "desc"), limit(200));
  const snap = await getDocs(q);
  return snap.docs.map((row) => ({ id: row.id, ...(row.data() as any) })) as SupportAccessRequest[];
}

export async function approveSupportAccessRequest(input: {
  request: SupportAccessRequest;
  adminUid: string;
  note?: string;
  hours?: number;
}) {
  const hours = Math.max(1, Math.min(Number(input.hours || 4), 24));
  const expiresAt = new Date(Date.now() + hours * 60 * 60 * 1000);
  const grantId = supportGrantId(input.request.patientId, input.adminUid);
  await setDoc(doc(db, "supportAccessGrants", grantId), {
    requestId: input.request.id,
    patientId: input.request.patientId,
    adminUid: input.adminUid,
    status: "active",
    reason: cleanText(input.request.reason),
    expiresAt,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  await updateDoc(doc(db, "supportAccessRequests", input.request.id), {
    status: "approved",
    assignedAdminUid: input.adminUid,
    decisionNote: cleanText(input.note) || null,
    approvedAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

export async function declineSupportAccessRequest(requestId: string, note: string) {
  return updateDoc(doc(db, "supportAccessRequests", requestId), {
    status: "declined",
    decisionNote: cleanText(note) || null,
    updatedAt: serverTimestamp(),
  });
}

export async function closeSupportAccessRequest(requestId: string, note: string) {
  return updateDoc(doc(db, "supportAccessRequests", requestId), {
    status: "closed",
    decisionNote: cleanText(note) || null,
    closedAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

export async function revokeSupportGrant(patientId: string, adminUid: string) {
  return updateDoc(doc(db, "supportAccessGrants", supportGrantId(patientId, adminUid)), {
    status: "revoked",
    updatedAt: serverTimestamp(),
  });
}

export async function getSupportGrant(patientId: string, adminUid: string) {
  const snap = await getDoc(doc(db, "supportAccessGrants", supportGrantId(patientId, adminUid)));
  return snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as SupportAccessGrant) : null;
}

export async function logSupportPatientRead(input: {
  actorUid: string;
  patientId: string;
  requestId: string;
  reason: string;
}) {
  return addDoc(collection(db, "accessAuditLogs"), {
    actorUid: input.actorUid,
    role: "system_admin",
    action: "support_patient_record_access",
    resourceType: "patient",
    resourceId: input.patientId,
    patientId: input.patientId,
    supportAccessRequestId: input.requestId,
    reason: cleanText(input.reason),
    occurredAt: serverTimestamp(),
  });
}

export async function readPatientForSupport(patientId: string) {
  const snap = await getDoc(doc(db, "patients", patientId));
  return snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as Record<string, any>) : null;
}
