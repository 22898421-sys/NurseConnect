import { NurseType, normalizeNurseType } from "./nurses";

export function getNurseType(value: unknown): NurseType | "" {
  return normalizeNurseType(value);
}

export function canNursePrescribe(value: unknown): boolean {
  return getNurseType(value) === "NP";
}

export function nursePrescribingLabel(value: unknown): string {
  return canNursePrescribe(value) ? "Nurse practitioner prescribing enabled" : "Prescribing unavailable for this nurse type";
}
