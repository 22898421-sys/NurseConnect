import { Patient } from "../models/emr";

type ClinicalEntry = {
  id: string;
  date: string;
  title: string;
  status: string;
  notes: string;
};

type ChartData = {
  overview: {
    summary: string;
    problems: string;
    pastMedicalHistory: string;
    familyHistory: string;
    socialHistory: string;
    carePlan: string;
  };
  allergiesAlerts: {
    allergies: ClinicalEntry[];
    alerts: ClinicalEntry[];
  };
  documents: { items: ClinicalEntry[] };
  history: { items: ClinicalEntry[] };
};

type InvoiceRow = {
  id: string;
  description: string;
  totalCents: number;
  currency: string;
  status: string;
  issuedDate: string;
  dueDate: string;
};

function clean(value: unknown) {
  return String(value || "").trim();
}

function entryDateTime(dateValue: string) {
  const value = clean(dateValue);
  if (!value) return new Date().toISOString();
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return `${value}T00:00:00Z`;
  return value;
}

function bundleEntry(resource: Record<string, unknown>) {
  return {
    fullUrl: `urn:uuid:${resource.id || Math.random().toString(36).slice(2)}`,
    resource,
  };
}

function noteList(text: string) {
  const value = clean(text);
  if (!value) return [];
  return [{ text: value }];
}

function clinicalEntriesToResources(
  patientId: string,
  entries: ClinicalEntry[],
  resourceType: "ServiceRequest" | "MedicationRequest" | "DocumentReference" | "AllergyIntolerance" | "Flag",
  category: string
) {
  return entries.map((entry) => {
    const status = clean(entry.status) || "active";
    if (resourceType === "MedicationRequest") {
      return bundleEntry({
        resourceType,
        id: entry.id,
        status,
        intent: "order",
        subject: { reference: `Patient/${patientId}` },
        authoredOn: entryDateTime(entry.date),
        medicationCodeableConcept: {
          text: clean(entry.title) || "Medication",
        },
        note: noteList(entry.notes),
      });
    }
    if (resourceType === "DocumentReference") {
      return bundleEntry({
        resourceType,
        id: entry.id,
        status: "current",
        type: {
          text: category,
        },
        subject: { reference: `Patient/${patientId}` },
        date: entryDateTime(entry.date),
        description: clean(entry.title) || category,
      });
    }
    if (resourceType === "AllergyIntolerance") {
      return bundleEntry({
        resourceType,
        id: entry.id,
        clinicalStatus: {
          text: status,
        },
        patient: { reference: `Patient/${patientId}` },
        code: {
          text: clean(entry.title) || "Allergy",
        },
        note: noteList(entry.notes),
      });
    }
    if (resourceType === "Flag") {
      return bundleEntry({
        resourceType,
        id: entry.id,
        status: "active",
        category: [{ text: category }],
        subject: { reference: `Patient/${patientId}` },
        code: {
          text: clean(entry.title) || "Clinical alert",
        },
        period: {
          start: entryDateTime(entry.date),
        },
      });
    }
    return bundleEntry({
      resourceType,
      id: entry.id,
      status,
      intent: "order",
      category: [{ text: category }],
      subject: { reference: `Patient/${patientId}` },
      authoredOn: entryDateTime(entry.date),
      code: {
        text: clean(entry.title) || category,
      },
      note: noteList(entry.notes),
    });
  });
}

export function buildPatientChartExportBundle(params: {
  patient: Patient;
  chartData: ChartData;
  patientSummary?: string | null;
  invoices?: InvoiceRow[];
}) {
  const { patient, chartData, patientSummary, invoices = [] } = params;
  const patientId = clean(patient.id) || "unknown-patient";
  const entries: Array<{ fullUrl: string; resource: Record<string, unknown> }> = [];

  entries.push(
    bundleEntry({
      resourceType: "Patient",
      id: patientId,
      identifier: [
        clean(patient.urNumber)
          ? {
              system: "urn:eirenix:patient:ur-number",
              value: clean(patient.urNumber),
            }
          : null,
      ].filter(Boolean),
      name: [
        {
          text: clean(patient.fullName) || "Unnamed",
        },
      ],
      telecom: [
        clean(patient.phone)
          ? {
              system: "phone",
              value: clean(patient.phone),
            }
          : null,
        clean(patient.email)
          ? {
              system: "email",
              value: clean(patient.email),
            }
          : null,
      ].filter(Boolean),
      gender: clean(patient.sex) || "unknown",
      birthDate: clean(patient.dateOfBirth) || undefined,
      address: clean(patient.address)
        ? [
            {
              text: clean(patient.address),
            },
          ]
        : undefined,
    })
  );

  if (clean(patientSummary)) {
    entries.push(
      bundleEntry({
        resourceType: "DocumentReference",
        id: `${patientId}-patient-summary`,
        status: "current",
        type: {
          text: "Patient-facing summary",
        },
        subject: { reference: `Patient/${patientId}` },
        description: clean(patientSummary),
      })
    );
  }

  if (clean(chartData.overview.problems)) {
    entries.push(
      bundleEntry({
        resourceType: "Condition",
        id: `${patientId}-problem-list`,
        clinicalStatus: {
          text: "active",
        },
        subject: { reference: `Patient/${patientId}` },
        code: {
          text: "Problem list",
        },
        note: noteList(chartData.overview.problems),
      })
    );
  }

  if (clean(chartData.overview.carePlan)) {
    entries.push(
      bundleEntry({
        resourceType: "CarePlan",
        id: `${patientId}-care-plan`,
        status: "active",
        intent: "plan",
        subject: { reference: `Patient/${patientId}` },
        description: clean(chartData.overview.carePlan),
      })
    );
  }

  entries.push(
    ...clinicalEntriesToResources(patientId, chartData.allergiesAlerts.allergies, "AllergyIntolerance", "Allergy"),
    ...clinicalEntriesToResources(patientId, chartData.allergiesAlerts.alerts, "Flag", "Alert"),
    ...clinicalEntriesToResources(patientId, chartData.documents.items, "DocumentReference", "Clinical document")
  );

  for (const invoice of invoices) {
    entries.push(
      bundleEntry({
        resourceType: "Basic",
        id: invoice.id,
        code: {
          text: "Billing invoice",
        },
        subject: { reference: `Patient/${patientId}` },
        extension: [
          { url: "urn:eirenix:invoice:description", valueString: clean(invoice.description) },
          { url: "urn:eirenix:invoice:status", valueString: clean(invoice.status) },
          { url: "urn:eirenix:invoice:issuedDate", valueString: clean(invoice.issuedDate) },
          { url: "urn:eirenix:invoice:dueDate", valueString: clean(invoice.dueDate) },
          { url: "urn:eirenix:invoice:currency", valueString: clean(invoice.currency) },
          { url: "urn:eirenix:invoice:totalCents", valueInteger: Number(invoice.totalCents || 0) },
        ],
      })
    );
  }

  return {
    resourceType: "Bundle",
    type: "collection",
    timestamp: new Date().toISOString(),
    identifier: {
      system: "urn:eirenix:exports:patient-chart",
      value: patientId,
    },
    meta: {
      tag: [
        {
          system: "urn:eirenix:export",
          code: "standards-shaped-fhir-lite",
          display: "EIRENIX Care™ standards-shaped export",
        },
      ],
    },
    entry: entries,
  };
}

function deepClone(value: any) {
  return JSON.parse(JSON.stringify(value));
}

function maskDate(value: string) {
  const v = clean(value);
  if (!v) return "";
  const match = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return "";
  return `${match[1]}-01-01`;
}

export function buildDeidentifiedPatientChartExportBundle(params: {
  patient: Patient;
  chartData: ChartData;
  patientSummary?: string | null;
  invoices?: InvoiceRow[];
}) {
  const clonedPatient: Patient = {
    ...params.patient,
    fullName: `Patient ${clean(params.patient.id) || "redacted"}`,
    email: null,
    phone: null,
    phoneNumber: null,
    address: null,
    urNumber: null,
    omang: null,
    idNumber: null,
    nextOfKinName: null,
    nextOfKinPhone: null,
    emergencyContactName: null,
    emergencyContactPhone: null,
    powerOfAttorneyName: null,
    powerOfAttorneyPhone: null,
    powerOfAttorneyEmail: null,
    dateOfBirth: maskDate(params.patient.dateOfBirth || ""),
  };

  const bundle = deepClone(
    buildPatientChartExportBundle({
      patient: clonedPatient,
      chartData: params.chartData,
      patientSummary: params.patientSummary,
      invoices: params.invoices,
    })
  );

  bundle.identifier = {
    system: "urn:eirenix:exports:patient-chart:deidentified",
    value: `deid-${clean(params.patient.id) || "patient"}`,
  };
  bundle.meta = bundle.meta || {};
  bundle.meta.tag = [
    ...(Array.isArray(bundle.meta.tag) ? bundle.meta.tag : []),
    {
      system: "urn:eirenix:export",
      code: "deidentified",
      display: "De-identified export",
    },
  ];

  if (Array.isArray(bundle.entry)) {
    bundle.entry = bundle.entry.map((entry: any) => {
      const resource = entry?.resource || {};
      if (resource.resourceType === "Patient") {
        resource.identifier = [];
        resource.telecom = [];
        resource.address = [];
        resource.name = [{ text: "De-identified patient" }];
        if (resource.birthDate) resource.birthDate = maskDate(resource.birthDate);
      }
      if (resource.subject?.reference) {
        resource.subject.reference = "Patient/deidentified";
      }
      if (resource.patient?.reference) {
        resource.patient.reference = "Patient/deidentified";
      }
      if (resource.note) {
        resource.note = [{ text: "Redacted in de-identified export." }];
      }
      if (resource.description && resource.resourceType === "DocumentReference" && resource.id === `${clean(params.patient.id)}-patient-summary`) {
        resource.description = "Redacted patient summary in de-identified export.";
      }
      return {
        ...entry,
        resource,
      };
    });
  }

  return bundle;
}
