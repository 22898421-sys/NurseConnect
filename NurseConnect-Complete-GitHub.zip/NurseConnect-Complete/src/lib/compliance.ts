import {
  addDoc,
  collection,
  doc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";
import { db } from "../firebaseConfig";

export type ComplianceProviderStatus = "onboarding" | "active" | "paused" | "closed";
export type CredentialStatus = "pending" | "verified" | "expiring" | "expired" | "rejected";
export type AssociatedProviderStatus = "pending" | "approved" | "suspended" | "ended";
export type IncidentComplaintType = "incident" | "complaint";
export type IncidentComplaintSeverity = "low" | "medium" | "high" | "critical";
export type IncidentComplaintStatus = "open" | "in_review" | "escalated" | "closed";

export type ComplianceProvider = {
  id: string;
  name: string;
  registrationId?: string | null;
  contactName?: string | null;
  contactEmail?: string | null;
  serviceCategories?: string[];
  status: ComplianceProviderStatus;
  notes?: string | null;
  createdAt?: unknown;
  updatedAt?: unknown;
};

export type ComplianceCredential = {
  id: string;
  subjectName: string;
  subjectType: "nurse" | "associated_provider" | "supplier";
  credentialType: string;
  providerName?: string | null;
  expiryDate?: string | null;
  status: CredentialStatus;
  evidenceReference?: string | null;
  notes?: string | null;
  createdAt?: unknown;
  updatedAt?: unknown;
};

export type AssociatedProviderRecord = {
  id: string;
  organisationName: string;
  providerName?: string | null;
  contactEmail?: string | null;
  serviceCategory?: string | null;
  agreementStatus: AssociatedProviderStatus;
  insuranceExpiry?: string | null;
  screeningStatus?: string | null;
  notes?: string | null;
  createdAt?: unknown;
  updatedAt?: unknown;
};

export type IncidentComplaintRecord = {
  id: string;
  type: IncidentComplaintType;
  title: string;
  providerName?: string | null;
  participantReference?: string | null;
  severity: IncidentComplaintSeverity;
  status: IncidentComplaintStatus;
  owner?: string | null;
  dueDate?: string | null;
  summary?: string | null;
  createdAt?: unknown;
  updatedAt?: unknown;
};

export function toDateLabel(value: unknown) {
  if (!value) return "Not recorded";
  if (typeof value === "string") return value;
  const date = value instanceof Date ? value : typeof (value as any)?.toDate === "function" ? (value as any).toDate() : null;
  return date ? date.toLocaleDateString() : "Not recorded";
}

export function daysUntil(dateText: string | null | undefined) {
  if (!dateText) return null;
  const date = new Date(`${dateText}T00:00:00`);
  if (Number.isNaN(date.getTime())) return null;
  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  return Math.ceil((date.getTime() - todayStart.getTime()) / 86400000);
}

export function credentialComputedStatus(row: ComplianceCredential): CredentialStatus {
  if (row.status === "rejected" || row.status === "pending") return row.status;
  const remaining = daysUntil(row.expiryDate);
  if (remaining == null) return row.status;
  if (remaining < 0) return "expired";
  if (remaining <= 30) return "expiring";
  return row.status === "expired" || row.status === "expiring" ? "verified" : row.status;
}

function cleanText(value: unknown) {
  return String(value || "").trim();
}

function cleanArray(values: string[]) {
  return values.map((item) => cleanText(item)).filter(Boolean).slice(0, 12);
}

export async function listComplianceProviders() {
  const snap = await getDocs(query(collection(db, "complianceProviders"), orderBy("updatedAt", "desc"), limit(200)));
  return snap.docs.map((row) => ({ id: row.id, ...(row.data() as any) })) as ComplianceProvider[];
}

export async function saveComplianceProvider(input: Omit<ComplianceProvider, "id" | "createdAt" | "updatedAt">) {
  const payload = {
    name: cleanText(input.name),
    registrationId: cleanText(input.registrationId) || null,
    contactName: cleanText(input.contactName) || null,
    contactEmail: cleanText(input.contactEmail).toLowerCase() || null,
    serviceCategories: cleanArray(input.serviceCategories || []),
    status: input.status,
    notes: cleanText(input.notes) || null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  return addDoc(collection(db, "complianceProviders"), payload);
}

export async function updateComplianceProviderStatus(id: string, status: ComplianceProviderStatus) {
  return updateDoc(doc(db, "complianceProviders", id), { status, updatedAt: serverTimestamp() });
}

export async function listComplianceCredentials() {
  const snap = await getDocs(query(collection(db, "complianceCredentials"), orderBy("updatedAt", "desc"), limit(200)));
  return snap.docs.map((row) => ({ id: row.id, ...(row.data() as any) })) as ComplianceCredential[];
}

export async function saveComplianceCredential(input: Omit<ComplianceCredential, "id" | "createdAt" | "updatedAt">) {
  const payload = {
    subjectName: cleanText(input.subjectName),
    subjectType: input.subjectType,
    credentialType: cleanText(input.credentialType),
    providerName: cleanText(input.providerName) || null,
    expiryDate: cleanText(input.expiryDate) || null,
    status: input.status,
    evidenceReference: cleanText(input.evidenceReference) || null,
    notes: cleanText(input.notes) || null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  return addDoc(collection(db, "complianceCredentials"), payload);
}

export async function updateCredentialStatus(id: string, status: CredentialStatus) {
  return updateDoc(doc(db, "complianceCredentials", id), { status, updatedAt: serverTimestamp() });
}

export async function listAssociatedProviders() {
  const snap = await getDocs(query(collection(db, "associatedProviders"), orderBy("updatedAt", "desc"), limit(200)));
  return snap.docs.map((row) => ({ id: row.id, ...(row.data() as any) })) as AssociatedProviderRecord[];
}

export async function saveAssociatedProvider(input: Omit<AssociatedProviderRecord, "id" | "createdAt" | "updatedAt">) {
  const payload = {
    organisationName: cleanText(input.organisationName),
    providerName: cleanText(input.providerName) || null,
    contactEmail: cleanText(input.contactEmail).toLowerCase() || null,
    serviceCategory: cleanText(input.serviceCategory) || null,
    agreementStatus: input.agreementStatus,
    insuranceExpiry: cleanText(input.insuranceExpiry) || null,
    screeningStatus: cleanText(input.screeningStatus) || null,
    notes: cleanText(input.notes) || null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  return addDoc(collection(db, "associatedProviders"), payload);
}

export async function updateAssociatedProviderStatus(id: string, agreementStatus: AssociatedProviderStatus) {
  return updateDoc(doc(db, "associatedProviders", id), { agreementStatus, updatedAt: serverTimestamp() });
}

export async function listIncidentComplaints() {
  const snap = await getDocs(query(collection(db, "incidentComplaints"), orderBy("updatedAt", "desc"), limit(200)));
  return snap.docs.map((row) => ({ id: row.id, ...(row.data() as any) })) as IncidentComplaintRecord[];
}

export async function saveIncidentComplaint(input: Omit<IncidentComplaintRecord, "id" | "createdAt" | "updatedAt">) {
  const payload = {
    type: input.type,
    title: cleanText(input.title),
    providerName: cleanText(input.providerName) || null,
    participantReference: cleanText(input.participantReference) || null,
    severity: input.severity,
    status: input.status,
    owner: cleanText(input.owner) || null,
    dueDate: cleanText(input.dueDate) || null,
    summary: cleanText(input.summary) || null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  return addDoc(collection(db, "incidentComplaints"), payload);
}

export async function updateIncidentComplaintStatus(id: string, status: IncidentComplaintStatus) {
  return updateDoc(doc(db, "incidentComplaints", id), { status, updatedAt: serverTimestamp() });
}
