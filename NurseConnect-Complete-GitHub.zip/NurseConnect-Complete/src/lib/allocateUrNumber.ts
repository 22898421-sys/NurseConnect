// src/lib/allocateUrNumber.ts
import { collection, getDocs, limit, query, where } from "firebase/firestore";
import { db } from "../firebaseConfig";

function generateUrCandidate(): string {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  const n = arr[0] % 1_000_000_0000;
  return String(n).padStart(10, "0");
}

/**
 * Allocates a 10-digit, zero-padded UR number.
 * Currently unique across all patients.
 * Later: scope query by practiceId.
 */
export async function allocateUrNumber(): Promise<string> {
  for (let attempt = 0; attempt < 20; attempt++) {
    const candidate = generateUrCandidate();
    const q = query(
      collection(db, "patients"),
      where("urNumber", "==", candidate),
      limit(1)
    );
    const snap = await getDocs(q);
    if (snap.empty) return candidate;
  }
  throw new Error("Unable to allocate unique UR number");
}
