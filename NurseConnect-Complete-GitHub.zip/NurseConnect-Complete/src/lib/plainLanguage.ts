function cleanMessage(raw: string): string {
  return raw
    .replace(/^functions\/[a-z-]+:\s*/i, "")
    .replace(/^firebase:\s*error\s*\(([^)]+)\)\.?/i, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

export function toPlainLanguageOutcomeMessage(input: any, fallback: string): string {
  const details =
    typeof input?.details === "string"
      ? input.details.trim()
      : typeof input?.customData?.details === "string"
        ? input.customData.details.trim()
        : "";

  const message =
    typeof input === "string"
      ? input
      : typeof input?.message === "string"
        ? input.message
        : "";

  const code =
    typeof input?.code === "string"
      ? input.code.replace(/^functions\//, "").trim().toLowerCase()
      : "";

  const raw = cleanMessage(details || message);
  const normalized = raw.toLowerCase();

  if (!raw && code === "already-exists") return "That option is no longer available. Please choose another one.";
  if (!raw && code === "failed-precondition") return fallback;
  if (!raw && code === "invalid-argument") return fallback;
  if (!raw && code === "permission-denied") return "You do not have access to complete that action.";
  if (!raw && code === "unauthenticated") return "Please sign in again and try once more.";

  if (!raw || normalized === "error" || normalized === "internal") return fallback;

  if (normalized === "auth/invalid-credential" || normalized.includes("invalid-credential")) {
    return "Those sign-in details were not accepted. Check the email and password and try again.";
  }
  if (normalized.includes("not currently available")) {
    return "This option is not available right now.";
  }
  if (normalized.includes("outside this clinician's booking availability")) {
    return "That time falls outside the nurse's available booking hours.";
  }
  if (normalized.includes("no longer available")) {
    return "That option is no longer available. Please choose another one.";
  }
  if (normalized.includes("not found")) {
    return raw;
  }
  if (normalized.includes("must be valid json")) {
    return "Please check the assessment details. The questionnaire and score fields need valid JSON.";
  }
  if (normalized.includes("false") || normalized.includes("negative result")) {
    return "The evaluation result was negative. No further action is needed unless the clinical picture changes.";
  }
  if (normalized.includes("not eligible")) {
    return "This result did not meet the required criteria.";
  }
  if (normalized.includes("does not meet") || normalized.includes("did not meet")) {
    return "This result did not meet the required criteria.";
  }
  if (normalized.includes("no whatsapp-compatible phone number")) {
    return "No valid mobile phone number is recorded for this patient.";
  }
  if (normalized.includes("failed-precondition")) {
    return fallback;
  }

  return raw;
}
