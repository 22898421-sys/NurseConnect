import { httpsCallable } from "firebase/functions";
import { functions } from "../firebaseConfig";

export type BootstrapStatus = {
  bootstrapAllowed: boolean;
  requiresBootstrap: boolean;
  hasSystemAdmin: boolean;
  hasUsers: boolean;
};

export async function getBootstrapStatus() {
  const callable = httpsCallable<undefined, BootstrapStatus>(functions, "getBootstrapStatus");
  const result = await callable();
  return result.data;
}

export async function bootstrapInitialSystemAdmin(input: {
  email: string;
  password: string;
  displayName: string;
}) {
  const callable = httpsCallable<
    { email: string; password: string; displayName: string },
    { success: boolean; uid: string; email: string }
  >(functions, "bootstrapInitialSystemAdmin");
  const result = await callable(input);
  return result.data;
}
