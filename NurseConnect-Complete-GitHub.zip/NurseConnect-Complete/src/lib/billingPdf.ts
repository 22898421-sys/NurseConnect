import { formatMoney } from "./billing";
import { formatInvoiceStatusLabel, formatTaxTreatmentLabel, ServiceInvoiceRecord } from "./billingFacilitation";
import { downloadTextPdf } from "./simplePdf";

function blank() {
  return " ";
}

export function downloadInvoicePdf(record: ServiceInvoiceRecord) {
  const lines = [
    "NurseConnectCare Invoice",
    `Invoice number: ${record.invoiceNumber}`,
    `Status: ${formatInvoiceStatusLabel(record.status)}`,
    `Invoice date: ${record.invoiceDate || "Not recorded"}`,
    `Due date: ${record.dueDate || "Not recorded"}`,
    blank(),
    `Issuing nurse: ${record.nurseSnapshot.businessName || record.nurseSnapshot.displayName}`,
    `ABN: ${record.nurseSnapshot.abn || "Not recorded"}`,
    `AHPRA: ${record.nurseSnapshot.ahpraRegistrationNumber || "Not recorded"}`,
    `Billing email: ${record.nurseSnapshot.billingEmail || "Not recorded"}`,
    `Billing phone: ${record.nurseSnapshot.billingPhone || "Not recorded"}`,
    `Billing address: ${record.nurseSnapshot.billingAddress || "Not recorded"}`,
    blank(),
    `Client: ${record.patientName}`,
    `Funding pathway: ${record.clientFundingSnapshot.pathwayLabel}`,
    `Bill to: ${record.clientFundingSnapshot.nominatedPayerName || record.patientName}`,
    `Recipient email: ${record.clientFundingSnapshot.nominatedPayerEmail || "Not recorded"}`,
    blank(),
    `Service: ${record.serviceCode} ${record.serviceTitle}`,
    `Category: ${record.serviceCategory}`,
    `Service date: ${record.serviceDate}`,
    `Start time: ${record.serviceStartTime || "Not recorded"}`,
    `Duration: ${record.durationMinutes} minutes`,
    `Quantity: ${record.quantity} ${record.unitLabel}`,
    `Unit fee: ${formatMoney(record.unitPriceCents, record.currency)}`,
    `Total: ${formatMoney(record.totalCents, record.currency)}`,
    `Tax treatment: ${formatTaxTreatmentLabel(record.taxTreatment)}`,
    blank(),
    "Invoice description",
    record.invoiceDescription || record.serviceSummary,
    blank(),
    "Declaration",
    record.evidencePack.declarationSummary,
    blank(),
    "Boundary notice",
    "NurseConnectCare only prepares and relays billing documents on the nurse's instruction. It does not process payments, approve claims, determine eligibility, or hold funds.",
  ];
  downloadTextPdf(`${record.invoiceNumber}.pdf`, lines);
}

export function downloadEvidencePackPdf(record: ServiceInvoiceRecord) {
  const lines = [
    "NurseConnectCare Evidence Pack",
    `Invoice number: ${record.invoiceNumber}`,
    `Invoice date: ${record.invoiceDate || "Not recorded"}`,
    `Due date: ${record.dueDate || "Not recorded"}`,
    blank(),
    "1. Booking record",
    record.evidencePack.bookingRecordSummary,
    blank(),
    "2. Nurse credentials snapshot",
    record.evidencePack.credentialsSummary,
    blank(),
    "3. Visit confirmation",
    record.evidencePack.visitConfirmationSummary,
    blank(),
    "4. Service summary",
    record.evidencePack.serviceSummary,
    blank(),
    "5. Nurse documentation note",
    record.evidencePack.documentationNoteSummary || "Not recorded",
    blank(),
    "6. Nurse declaration",
    record.evidencePack.declarationSummary,
    blank(),
    "7. Relay and audit history",
    ...((record.auditTrail || []).length
      ? (record.auditTrail || []).map((entry) => `${new Date(entry.at).toLocaleString()} - ${entry.note}`)
      : ["No relay or audit entries recorded."]),
    blank(),
    "Boundary notice",
    "NurseConnectCare only prepares and relays this evidence pack as a delivery conduit. It does not assess funding eligibility, submit a claim, approve reimbursement, or receive payment on behalf of the nurse.",
  ];
  downloadTextPdf(`${record.invoiceNumber}-evidence-pack.pdf`, lines);
}
