// src/contexts/AuthContext.tsx
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  createUserWithEmailAndPassword,
  updateProfile,
} from "firebase/auth";
import { doc, onSnapshot, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, db } from "../firebaseConfig";
import { NurseType } from "../lib/nurses";
import { SUBSCRIPTION_TRIAL_DAYS, addDays, computeSubscriptionChargeCents } from "../lib/subscriptions";

export type NormalizedRole = "patient" | "clinician" | "system_admin" | "";

type Role = NormalizedRole;

type UserProfile = {
  uid: string;
  email: string;
  role: Role;
  active: boolean;
  displayName?: string;
  designation?: string | null;
  nurseType?: NurseType | null;
  ahpraRegistrationNumber?: string | null;
  ahpraVerified?: boolean | null;
  ahpraVerifiedAt?: any;
  ahpraVerifiedByUid?: string | null;
  ahpraVerificationNotes?: string | null;
  timeZone?: string | null;
  practiceTimeZone?: string | null;
  phoneNumber?: string | null;
  patientId?: string | null;
  practiceId?: string | null;
  practiceName?: string | null;
  publicProfileEnabled?: boolean | null;
  publicHeadline?: string | null;
  publicServiceFocus?: string | null;
  publicServiceFocusKeywords?: string[] | null;
  publicPrimaryRegion?: string | null;
  publicTravelRadius?: string | null;
  publicBasePostcode?: string | null;
  publicServicePostcodes?: string[] | null;
  publicServiceRadiusKm?: number | null;
  publicVisitTypes?: string[] | null;
  publicFundingModels?: string[] | null;
  publicResponseTime?: string | null;
  billingBusinessName?: string | null;
  billingAbn?: string | null;
  billingEmail?: string | null;
  billingPhone?: string | null;
  billingAddress?: string | null;
  billingFavouriteServiceItemIds?: string[] | null;
  billingRecipientPresets?: Array<{
    id: string;
    label: string;
    recipientName: string;
    recipientEmail: string;
    recipientType: string;
  }> | null;
  subscriptionPlan?: string | null;
  subscriptionBillingCycle?: string | null;
  subscriptionPaymentMethod?: string | null;
  subscriptionStatus?: string | null;
  subscriptionGateway?: string | null;
  subscriptionGatewayMode?: string | null;
  subscriptionActivatedAt?: any;
  subscriptionDiscountPercent?: number | null;
  subscriptionCurrentPriceCents?: number | null;
  subscriptionTrialStartedAt?: any;
  subscriptionTrialEndsAt?: any;
  subscriptionNextBillingAt?: any;
  signupSource?: string | null;
  createdAt?: any;
  updatedAt?: any;
};

type SelfRegisterPatientInput = {
  displayName: string;
  email: string;
  password: string;
  phoneNumber?: string;
};

type SelfRegisterNurseInput = {
  displayName: string;
  email: string;
  password: string;
  nurseType: NurseType;
  ahpraRegistrationNumber: string;
  subscriptionBillingCycle: string;
};

type AuthContextValue = {
  user: User | null;
  currentUserData: UserProfile | null;
  normalizedRole: NormalizedRole;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  forceLogout: (reason: string) => Promise<void>;
  beginProvisioning: () => void;
  endProvisioning: () => void;
  registerPatient: (input: SelfRegisterPatientInput) => Promise<void>;
  registerNurse: (input: SelfRegisterNurseInput) => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const LOGOUT_REASON_KEY = "eirenix_logout_reason";

function normalizeEmail(email: string) {
  return (email || "").trim().toLowerCase();
}
function normalizePhone(phone: string) {
  const raw = (phone || "").toString().trim();
  if (!raw) return "";
  const keepPlus = raw.startsWith("+");
  const digits = raw.replace(/[^\d]/g, "");
  if (!digits) return "";
  return keepPlus ? `+${digits}` : digits;
}

function normalizeRole(role: Role | undefined | null): NormalizedRole {
  if (!role) return "";
  if (role === "patient" || role === "clinician" || role === "system_admin") {
    return role;
  }
  return "";
}

function safeSetLogoutReason(reason: string) {
  try {
    if (typeof window === "undefined") return;
    window.sessionStorage.setItem(LOGOUT_REASON_KEY, reason || "");
  } catch {
    // ignore
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [currentUserData, setCurrentUserData] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const profileUnsubRef = useRef<null | (() => void)>(null);
  const provisioningRef = useRef(false);
  const forceLogoutInFlightRef = useRef(false);

  const forceLogout = useCallback(async (reason: string) => {
    if (forceLogoutInFlightRef.current) return;
    forceLogoutInFlightRef.current = true;
    try {
      safeSetLogoutReason(reason);
      await signOut(auth);
    } finally {
      forceLogoutInFlightRef.current = false;
    }
  }, []);

  // Auth + real-time profile enforcement (lint-clean deps)
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);

      if (profileUnsubRef.current) {
        try {
          profileUnsubRef.current();
        } catch {
          // ignore
        }
        profileUnsubRef.current = null;
      }

      if (!u) {
        setCurrentUserData(null);
        setLoading(false);
        return;
      }

      setLoading(true);

      const userRef = doc(db, "users", u.uid);

      profileUnsubRef.current = onSnapshot(
        userRef,
        async (snap) => {
          if (!snap.exists()) {
            if (provisioningRef.current) {
              setCurrentUserData(null);
              setLoading(true);
              return;
            }
            setCurrentUserData(null);
            setLoading(false);
            await forceLogout("unprovisioned");
            return;
          }

          const data = snap.data() as any;

          const profile: UserProfile = {
            uid: u.uid,
            email: data?.email ?? normalizeEmail(u.email || ""),
            role: data?.role ?? "",
            active: data?.active ?? true,
            displayName: data?.displayName ?? "",
            designation: data?.designation ?? null,
            nurseType: data?.nurseType ?? null,
            ahpraRegistrationNumber: data?.ahpraRegistrationNumber ?? null,
            ahpraVerified: data?.ahpraVerified ?? null,
            ahpraVerifiedAt: data?.ahpraVerifiedAt ?? null,
            ahpraVerifiedByUid: data?.ahpraVerifiedByUid ?? null,
            ahpraVerificationNotes: data?.ahpraVerificationNotes ?? null,
            timeZone: data?.timeZone ?? null,
            practiceTimeZone: data?.practiceTimeZone ?? null,
            phoneNumber: data?.phoneNumber ?? null,
            patientId: data?.patientId ?? null,
            practiceId: data?.practiceId ?? null,
            practiceName: data?.practiceName ?? null,
            publicProfileEnabled: data?.publicProfileEnabled ?? null,
            publicHeadline: data?.publicHeadline ?? null,
            publicServiceFocus: data?.publicServiceFocus ?? null,
            publicServiceFocusKeywords: Array.isArray(data?.publicServiceFocusKeywords) ? data.publicServiceFocusKeywords : null,
            publicPrimaryRegion: data?.publicPrimaryRegion ?? null,
            publicTravelRadius: data?.publicTravelRadius ?? null,
            publicBasePostcode: data?.publicBasePostcode ?? null,
            publicServicePostcodes: Array.isArray(data?.publicServicePostcodes) ? data.publicServicePostcodes : null,
            publicServiceRadiusKm: typeof data?.publicServiceRadiusKm === "number" ? data.publicServiceRadiusKm : null,
            publicVisitTypes: Array.isArray(data?.publicVisitTypes) ? data.publicVisitTypes : null,
            publicFundingModels: Array.isArray(data?.publicFundingModels) ? data.publicFundingModels : null,
            publicResponseTime: data?.publicResponseTime ?? null,
            billingBusinessName: data?.billingBusinessName ?? null,
            billingAbn: data?.billingAbn ?? null,
            billingEmail: data?.billingEmail ?? null,
            billingPhone: data?.billingPhone ?? null,
            billingAddress: data?.billingAddress ?? null,
            billingFavouriteServiceItemIds: Array.isArray(data?.billingFavouriteServiceItemIds) ? data.billingFavouriteServiceItemIds : [],
            billingRecipientPresets: Array.isArray(data?.billingRecipientPresets) ? data.billingRecipientPresets : [],
            subscriptionPlan: data?.subscriptionPlan ?? null,
            subscriptionBillingCycle: data?.subscriptionBillingCycle ?? null,
            subscriptionPaymentMethod: data?.subscriptionPaymentMethod ?? null,
            subscriptionStatus: data?.subscriptionStatus ?? null,
            subscriptionGateway: data?.subscriptionGateway ?? null,
            subscriptionGatewayMode: data?.subscriptionGatewayMode ?? null,
            subscriptionActivatedAt: data?.subscriptionActivatedAt ?? null,
            subscriptionDiscountPercent: data?.subscriptionDiscountPercent ?? null,
            subscriptionCurrentPriceCents: data?.subscriptionCurrentPriceCents ?? null,
            subscriptionTrialStartedAt: data?.subscriptionTrialStartedAt ?? null,
            subscriptionTrialEndsAt: data?.subscriptionTrialEndsAt ?? null,
            subscriptionNextBillingAt: data?.subscriptionNextBillingAt ?? null,
            signupSource: data?.signupSource ?? null,
            createdAt: data?.createdAt,
            updatedAt: data?.updatedAt,
          };

          const nr = normalizeRole(profile.role);
          if (!nr) {
            setCurrentUserData(profile);
            setLoading(false);
            await forceLogout("unprovisioned");
            return;
          }

          if (profile.active === false) {
            setCurrentUserData(profile);
            setLoading(false);
            await forceLogout("inactive");
            return;
          }

          setCurrentUserData(profile);
          setLoading(false);
        },
        async (err) => {
          console.error("User profile listener error:", err);
          setCurrentUserData(null);
          setLoading(false);
          await forceLogout("profile_error");
        }
      );
    });

    return () => {
      try {
        unsubAuth();
      } catch {
        // ignore
      }
      if (profileUnsubRef.current) {
        try {
          profileUnsubRef.current();
        } catch {
          // ignore
        }
        profileUnsubRef.current = null;
      }
    };
  }, [forceLogout]);

  const normalizedRole = useMemo<NormalizedRole>(() => {
    return normalizeRole(currentUserData?.role);
  }, [currentUserData?.role]);

  const login = useCallback(async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, normalizeEmail(email), password);
  }, []);

  const logout = useCallback(async () => {
    await signOut(auth);
  }, []);

  const beginProvisioning = useCallback(() => {
    provisioningRef.current = true;
  }, []);
  const endProvisioning = useCallback(() => {
    provisioningRef.current = false;
  }, []);

  const registerPatient = useCallback(async ({ displayName, email, password, phoneNumber }: SelfRegisterPatientInput) => {
    const emailNorm = normalizeEmail(email);
    const phoneNorm = normalizePhone(phoneNumber || "");
    const safeDisplayName = (displayName || "").trim() || "Patient";

    provisioningRef.current = true;
    try {
      const cred = await createUserWithEmailAndPassword(auth, emailNorm, password);
      const uid = cred.user.uid;

      try {
        await updateProfile(cred.user, { displayName: safeDisplayName });
      } catch {
        // ignore
      }

      await setDoc(
        doc(db, "users", uid),
        {
          uid,
          email: emailNorm,
          role: "patient",
          active: true,
          displayName: safeDisplayName,
          phoneNumber: phoneNorm || null,
          patientId: uid,
          signupSource: "self_service",
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      await setDoc(
        doc(db, "patients", uid),
        {
          fullName: safeDisplayName,
          email: emailNorm,
          phone: phoneNorm || null,
          userId: uid,
          billingType: "medicare",
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      try {
        await cred.user.getIdToken(true);
      } catch {
        // ignore
      }
    } finally {
      provisioningRef.current = false;
    }
  }, []);

  const registerNurse = useCallback(async ({ displayName, email, password, nurseType, ahpraRegistrationNumber, subscriptionBillingCycle }: SelfRegisterNurseInput) => {
    const emailNorm = normalizeEmail(email);
    const safeDisplayName = (displayName || "").trim() || emailNorm;
    const safeAhpra = (ahpraRegistrationNumber || "").trim().toUpperCase();
    const trialStartedAt = new Date();
    const trialEndsAt = addDays(trialStartedAt, SUBSCRIPTION_TRIAL_DAYS);
    const pricing = computeSubscriptionChargeCents(nurseType === "NP" ? 5500 : 5000, subscriptionBillingCycle);

    provisioningRef.current = true;
    try {
      const cred = await createUserWithEmailAndPassword(auth, emailNorm, password);
      const uid = cred.user.uid;

      try {
        await updateProfile(cred.user, { displayName: safeDisplayName });
      } catch {
        // ignore
      }

      await setDoc(
        doc(db, "users", uid),
        {
          uid,
          email: emailNorm,
          role: "clinician",
          active: true,
          displayName: safeDisplayName,
          designation: nurseType,
          nurseType,
          ahpraRegistrationNumber: safeAhpra,
          publicProfileEnabled: false,
          subscriptionPlan: "independent_nurse",
          subscriptionBillingCycle,
          subscriptionStatus: "trial_active",
          subscriptionDiscountPercent: pricing.discountPercent,
          subscriptionCurrentPriceCents: pricing.discountedCents,
          subscriptionTrialStartedAt: trialStartedAt,
          subscriptionTrialEndsAt: trialEndsAt,
          subscriptionNextBillingAt: trialEndsAt,
          signupSource: "self_service",
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      try {
        await cred.user.getIdToken(true);
      } catch {
        // ignore
      }
    } finally {
      provisioningRef.current = false;
    }
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      currentUserData,
      normalizedRole,
      loading,
      login,
      logout,
      forceLogout,
      beginProvisioning,
      endProvisioning,
      registerPatient,
      registerNurse,
    }),
    [user, currentUserData, normalizedRole, loading, login, logout, forceLogout, beginProvisioning, endProvisioning, registerPatient, registerNurse]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
