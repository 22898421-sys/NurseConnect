import React, { useCallback, useEffect, useState } from "react";
import MainLayout from "./MainLayout";
import { useAuth } from "../contexts/AuthContext";
import {
  SupportAccessRequest,
  SupportAccessScope,
  SupportAccessUrgency,
  approveSupportAccessRequest,
  closeSupportAccessRequest,
  createSupportAccessRequest,
  declineSupportAccessRequest,
  getSupportGrant,
  listAllSupportAccessRequests,
  listMySupportAccessRequests,
  logSupportPatientRead,
  readPatientForSupport,
  revokeSupportGrant,
  toAccessDateLabel,
} from "../lib/supportAccess";
import { FiAlertCircle, FiCheckCircle, FiClipboard, FiShield } from "./PublicIcons";

function titleCase(value: string) {
  return value
    .split("_")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function statusClass(status: string) {
  if (status === "approved" || status === "closed") return "bg-emerald-50 text-emerald-800 border-emerald-200";
  if (status === "declined") return "bg-rose-50 text-rose-800 border-rose-200";
  if (status === "urgent" || status === "requested") return "bg-amber-50 text-amber-800 border-amber-200";
  return "bg-ink-50 text-ink-700 border-ink-200";
}

function Pill({ value }: { value: string }) {
  return <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${statusClass(value)}`}>{titleCase(value)}</span>;
}

function safe(value: unknown) {
  return String(value || "").trim();
}

function patientDisplay(patient: Record<string, any> | null) {
  if (!patient) return "No client record loaded";
  return safe(patient.fullName) || safe(patient.displayName) || safe(patient.name) || patient.id || "Client";
}

export default function SupportAccessPage() {
  const { user, currentUserData, normalizedRole } = useAuth() as any;
  const isAdmin = normalizedRole === "system_admin";
  const isClinician = normalizedRole === "clinician";
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [requests, setRequests] = useState<SupportAccessRequest[]>([]);
  const [decisionNotes, setDecisionNotes] = useState<Record<string, string>>({});
  const [loadedPatients, setLoadedPatients] = useState<Record<string, Record<string, any> | null>>({});

  const [form, setForm] = useState({
    patientId: "",
    patientLabel: "",
    reason: "",
    scope: "technical_troubleshooting" as SupportAccessScope,
    urgency: "routine" as SupportAccessUrgency,
  });

  const refresh = useCallback(async () => {
    if (!user?.uid) return;
    setLoading(true);
    setError("");
    try {
      const rows = isAdmin ? await listAllSupportAccessRequests() : await listMySupportAccessRequests(user.uid);
      setRequests(rows);
    } catch (err: any) {
      console.error("Failed to load support access requests", err);
      setError(err?.message || "Could not load support access requests.");
    } finally {
      setLoading(false);
    }
  }, [isAdmin, user?.uid]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  if (!isAdmin && !isClinician) {
    return (
      <MainLayout>
        <div className="text-sm text-rose-600">Access denied.</div>
      </MainLayout>
    );
  }

  async function runAction(action: () => Promise<unknown>, success: string) {
    setSaving(true);
    setMessage("");
    setError("");
    try {
      await action();
      setMessage(success);
      await refresh();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Support access action failed.");
    } finally {
      setSaving(false);
    }
  }

  async function submitRequest(event: React.FormEvent) {
    event.preventDefault();
    if (!user?.uid) return;
    if (!form.patientId.trim() || !form.reason.trim()) {
      setError("Client record ID and reason are required.");
      return;
    }
    await runAction(
      () =>
        createSupportAccessRequest({
          patientId: form.patientId,
          patientLabel: form.patientLabel,
          practiceId: currentUserData?.practiceId || null,
          practiceName: currentUserData?.practiceName || null,
          requesterUid: user.uid,
          requesterName: currentUserData?.displayName || currentUserData?.email || user.email || null,
          reason: form.reason,
          scope: form.scope,
          urgency: form.urgency,
        }),
      "Support access request submitted."
    );
    setForm({ patientId: "", patientLabel: "", reason: "", scope: "technical_troubleshooting", urgency: "routine" });
  }

  async function approve(request: SupportAccessRequest) {
    if (!user?.uid) return;
    await runAction(
      () =>
        approveSupportAccessRequest({
          request,
          adminUid: user.uid,
          note: decisionNotes[request.id] || "Approved for troubleshooting.",
          hours: 4,
        }),
      "Time-limited support grant created."
    );
  }

  async function readPatient(request: SupportAccessRequest) {
    if (!user?.uid) return;
    await runAction(async () => {
      const grant = await getSupportGrant(request.patientId, user.uid);
      if (!grant || grant.status !== "active") {
        throw new Error("No active support access grant exists for this admin and client record.");
      }
      await logSupportPatientRead({
        actorUid: user.uid,
        patientId: request.patientId,
        requestId: request.id,
        reason: request.reason,
      });
      const patient = await readPatientForSupport(request.patientId);
      setLoadedPatients((current) => ({ ...current, [request.id]: patient }));
    }, "Client record read logged in the audit trail.");
  }

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="card p-6">
          <div className="flex items-start gap-3">
            <FiShield className="mt-1 h-6 w-6 text-brand-700" />
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Privacy controlled support</p>
              <h1 className="section-title mt-2">Client record support access</h1>
              <p className="section-subtitle mt-2 max-w-4xl">
                Support admins cannot browse client records by default. A clinician or registered-provider user must
                request access for a specific client record and reason. Admin reads are time-limited and written to the
                access audit log before the record is loaded.
              </p>
            </div>
          </div>
        </div>

        {message ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{message}</div> : null}
        {error ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

        {isClinician ? (
          <form className="card p-5 space-y-4" onSubmit={submitRequest}>
            <div className="flex items-center gap-3">
              <FiClipboard className="h-5 w-5 text-brand-700" />
              <h2 className="text-xl font-semibold text-ink-900">Request admin troubleshooting access</h2>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <label className="label">Client record ID</label>
                <input className="input" value={form.patientId} onChange={(e) => setForm((v) => ({ ...v, patientId: e.target.value }))} placeholder="patients/{id}" />
              </div>
              <div>
                <label className="label">Client label</label>
                <input className="input" value={form.patientLabel} onChange={(e) => setForm((v) => ({ ...v, patientLabel: e.target.value }))} placeholder="Name, initials or internal reference" />
              </div>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <label className="label">Scope</label>
                <select className="select" value={form.scope} onChange={(e) => setForm((v) => ({ ...v, scope: e.target.value as SupportAccessScope }))}>
                  <option value="technical_troubleshooting">Technical troubleshooting</option>
                  <option value="billing_or_booking_support">Billing or booking support</option>
                  <option value="patient_profile">Patient profile only</option>
                </select>
              </div>
              <div>
                <label className="label">Urgency</label>
                <select className="select" value={form.urgency} onChange={(e) => setForm((v) => ({ ...v, urgency: e.target.value as SupportAccessUrgency }))}>
                  <option value="routine">Routine</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
            </div>
            <div>
              <label className="label">Reason access is required</label>
              <textarea className="input min-h-[110px]" value={form.reason} onChange={(e) => setForm((v) => ({ ...v, reason: e.target.value }))} placeholder="Describe the provider request and the troubleshooting task. Do not include more clinical detail than needed." />
            </div>
            <button className="btn-primary" type="submit" disabled={saving}>{saving ? "Submitting..." : "Submit support access request"}</button>
          </form>
        ) : null}

        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <FiAlertCircle className="h-5 w-5 text-brand-700" />
            <h2 className="text-xl font-semibold text-ink-900">{isAdmin ? "Provider-requested access queue" : "My support access requests"}</h2>
          </div>
          {loading ? <div className="card p-5 text-sm text-ink-600">Loading support access requests...</div> : null}
          {!loading && requests.length === 0 ? <div className="card p-5 text-sm text-ink-600">No support access requests found.</div> : null}
          {!loading ? requests.map((request) => (
            <div key={request.id} className="card p-5 space-y-4">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-ink-900">{request.patientLabel || request.patientId}</h3>
                  <p className="mt-1 text-sm text-ink-600">Client ID: {request.patientId}</p>
                  <p className="mt-1 text-sm text-ink-600">
                    Requested by {request.requesterName || request.requesterUid} · {request.practiceName || request.practiceId || "No provider context"}
                  </p>
                  <p className="mt-2 text-sm text-ink-700">{request.reason}</p>
                  <p className="mt-2 text-xs text-ink-500">Created: {toAccessDateLabel(request.createdAt)} · Updated: {toAccessDateLabel(request.updatedAt)}</p>
                </div>
                <div className="flex flex-wrap gap-2 lg:justify-end">
                  <Pill value={request.status} />
                  <Pill value={request.urgency} />
                  <Pill value={request.scope} />
                </div>
              </div>

              {isAdmin ? (
                <div className="rounded-2xl border border-ink-200 bg-sand-100/70 p-4">
                  <label className="label">Decision note</label>
                  <textarea
                    className="input min-h-[80px]"
                    value={decisionNotes[request.id] || ""}
                    onChange={(e) => setDecisionNotes((current) => ({ ...current, [request.id]: e.target.value }))}
                    placeholder="Why access was approved, declined or closed."
                  />
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button className="btn-primary" type="button" disabled={saving || request.status === "approved"} onClick={() => void approve(request)}>
                      Approve 4-hour grant to me
                    </button>
                    <button className="btn-secondary" type="button" disabled={saving} onClick={() => void readPatient(request)}>
                      Log and load client record
                    </button>
                    <button className="btn-secondary" type="button" disabled={saving} onClick={() => void runAction(() => revokeSupportGrant(request.patientId, user.uid), "Support grant revoked.")}>
                      Revoke my grant
                    </button>
                    <button className="btn-secondary" type="button" disabled={saving || request.status === "declined"} onClick={() => void runAction(() => declineSupportAccessRequest(request.id, decisionNotes[request.id] || "Declined."), "Support access request declined.")}>
                      Decline
                    </button>
                    <button className="btn-secondary" type="button" disabled={saving || request.status === "closed"} onClick={() => void runAction(() => closeSupportAccessRequest(request.id, decisionNotes[request.id] || "Closed."), "Support access request closed.")}>
                      Close
                    </button>
                  </div>
                </div>
              ) : null}

              {loadedPatients[request.id] !== undefined ? (
                <div className="rounded-2xl border border-brand-200 bg-brand-50 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-ink-900">
                    <FiCheckCircle className="h-4 w-4 text-brand-700" />
                    Audited client record preview
                  </div>
                  <div className="mt-3 grid gap-2 text-sm text-ink-700 md:grid-cols-2">
                    <div>Name: {patientDisplay(loadedPatients[request.id])}</div>
                    <div>Email: {safe(loadedPatients[request.id]?.email) || "Not recorded"}</div>
                    <div>Phone: {safe(loadedPatients[request.id]?.phoneNumber || loadedPatients[request.id]?.phone) || "Not recorded"}</div>
                    <div>Practice ID: {safe(loadedPatients[request.id]?.practiceId) || "Not recorded"}</div>
                  </div>
                </div>
              ) : null}
            </div>
          )) : null}
        </div>
      </div>
    </MainLayout>
  );
}
