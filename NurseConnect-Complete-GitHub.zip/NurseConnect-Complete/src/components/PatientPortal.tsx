// src/components/PatientPortal.tsx
import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { doc, getDoc, collection, getDocs, limit, orderBy, query, where, serverTimestamp, writeBatch } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { db, functions } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { Appointment, Patient } from "../models/emr";
import { MainLayout } from "./MainLayout";
import { formatDateTimeInZone, getClinicTimeZone, getLocalTimeZone } from "../lib/time";
import { formatMoney, getDefaultCurrency } from "../lib/billing";
import { formatToDDMMYYYY } from "../lib/dates";
import { toPlainLanguageOutcomeMessage } from "../lib/plainLanguage";
import {
  ClinicianAvailabilityDoc,
  formatAvailabilityForDate,
  isClinicianAvailableAt,
  sanitizeDateBlocks,
  sanitizeWeeklyAvailability,
} from "../lib/clinicianAvailability";
import TriageIntakeCard from "./triage/TriageIntakeCard";
import { formatNurseProfileLabel, nurseTypeLabel } from "../lib/nurses";

function normalizeEmail(email: string) {
  return (email || "").trim().toLowerCase();
}

function looksLikeEmail(value: string | null | undefined) {
  return /\S+@\S+\.\S+/.test(String(value || "").trim());
}

function titleCaseWords(value: string) {
  return value
    .split(/\s+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
    .join(" ");
}

function humanizeClinicianEmail(email: string | null | undefined) {
  const normalized = String(email || "").trim();
  if (!looksLikeEmail(normalized)) return "";
  const localPart = normalized.split("@")[0] || "";
  const words = localPart
    .replace(/[._-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return words ? titleCaseWords(words) : normalized;
}

function clinicianDisplayLabel(name: string | null | undefined, email: string | null | undefined, fallbackId: string) {
  const trimmedName = String(name || "").trim();
  if (trimmedName && !looksLikeEmail(trimmedName)) return trimmedName;
  const fromEmail = humanizeClinicianEmail(email || trimmedName);
  if (fromEmail) return `Nurse ${fromEmail}`;
  return String(email || "").trim() || fallbackId;
}

function toDateMaybe(t: any): Date | null {
  try {
    if (!t) return null;
    if (typeof t?.toDate === "function") return t.toDate();
    if (typeof t?.seconds === "number") return new Date(t.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

function formatWhen(a: any, clinicTz: string | null, localTz: string) {
  const d = toDateMaybe(a?.scheduledAt);
  if (!d) return null;
  const effectiveClinicTz = clinicTz || localTz;
  return {
    local: formatDateTimeInZone(d, localTz),
    clinic: formatDateTimeInZone(d, effectiveClinicTz),
    clinicTz: effectiveClinicTz,
  };
}

function statusChip(status?: string) {
  if (status === "completed") return "chip chip-success";
  if (status === "in_progress") return "chip chip-info";
  if (status === "cancelled") return "chip chip-danger";
  return "chip chip-warning";
}

function formatDateTimeInputInZone(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const byType: Record<string, string> = {};
  for (const part of parts) {
    if (part.type !== "literal") byType[part.type] = part.value;
  }
  return `${byType.year}-${byType.month}-${byType.day}T${byType.hour}:${byType.minute}`;
}

function timeZoneOffsetMs(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const byType: Record<string, string> = {};
  for (const part of parts) {
    if (part.type !== "literal") byType[part.type] = part.value;
  }
  const utcMs = Date.UTC(
    Number(byType.year),
    Number(byType.month) - 1,
    Number(byType.day),
    Number(byType.hour),
    Number(byType.minute),
    Number(byType.second)
  );
  return utcMs - date.getTime();
}

function defaultBookingDateTime(timeZone: string) {
  const next = new Date();
  next.setMinutes(0, 0, 0);
  next.setHours(next.getHours() + 1);
  return formatDateTimeInputInZone(next, timeZone);
}

function parseDateTimeInZone(value: string, timeZone: string): Date | null {
  const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const hour = Number(match[4]);
  const minute = Number(match[5]);
  const utcGuess = Date.UTC(year, month - 1, day, hour, minute, 0);
  let result = new Date(utcGuess - timeZoneOffsetMs(new Date(utcGuess), timeZone));
  const corrected = new Date(utcGuess - timeZoneOffsetMs(result, timeZone));
  if (!Number.isNaN(corrected.getTime())) result = corrected;
  return Number.isNaN(result.getTime()) ? null : result;
}

function getCallableErrorMessage(error: any, fallback: string) {
  return toPlainLanguageOutcomeMessage(error, fallback);
}

const CONSENT_FORMS = [
  { id: "telehealth", title: "Telehealth Consent", version: "1.0" },
  { id: "privacy", title: "Privacy Notice Acknowledgement", version: "1.0" },
  { id: "treatment", title: "Treatment Consent", version: "1.0" },
];

type InvoiceRow = {
  id: string;
  patientId: string;
  description?: string | null;
  status?: string | null;
  totalCents?: number | null;
  currency?: string | null;
  issuedDate?: string | null;
  dueDate?: string | null;
};

type PatientUploadRow = {
  id: string;
  patientId?: string | null;
  title?: string | null;
  status?: string | null;
  kind?: string | null;
  printPath?: string | null;
  createdAt?: Date | null;
  statusLabel?: string | null;
};

type BookableClinician = ClinicianAvailabilityDoc & {
  id: string;
  label: string;
};

type ConsentRow = {
  consentId: string;
  patientId?: string;
  practiceId?: string | null;
  title?: string;
  version: string;
  status?: "signed" | "withdrawn";
  signedAt?: any;
  signedByUid?: string;
  withdrawnAt?: any;
  withdrawnByUid?: string;
  updatedAt?: any;
  updatedByUid?: string;
};

function fallbackDocumentStatusLabel(item: PatientUploadRow) {
  const kind = String(item.kind || "").trim();
  const status = String(item.status || "").trim();
  if (kind === "prescription") {
    if (status === "fully_dispensed") return "Fully dispensed";
    if (status === "partially_dispensed") return "Repeat(s) partly used";
    if (status === "initial_dispensed") return "Initial dispense recorded";
    if (status === "cancelled") return "Cancelled";
    if (status === "superseded") return "Superseded";
    if (status === "active") return "Active";
  }
  if (status === "requested") return "Requested";
  if (status === "pending") return "Pending";
  if (status === "completed") return "Completed";
  if (status === "issued") return "Issued";
  if (status === "active") return "Active";
  if (status === "filed") return "Filed";
  return status ? status.replace(/_/g, " ") : "Available";
}

function documentStatusChipClass(item: PatientUploadRow) {
  const label = (item.statusLabel || fallbackDocumentStatusLabel(item)).toLowerCase();
  if (label.includes("fully dispensed") || label.includes("completed") || label.includes("filed")) return "chip chip-success";
  if (label.includes("active") || label.includes("initial dispense")) return "chip chip-info";
  if (label.includes("partly used") || label.includes("pending") || label.includes("requested")) return "chip chip-warning";
  return "chip chip-info";
}

function journeyCardTone(kind: "ready" | "action" | "info") {
  if (kind === "ready") return "border-emerald-200 bg-emerald-50";
  if (kind === "action") return "border-amber-200 bg-amber-50";
  return "border-sky-200 bg-sky-50";
}

function nextAppointmentActionLabel(appointment: Appointment | null, nowMs: number, graceMinutes: number) {
  if (!appointment) return "No visit booked";
  const when = toDateMaybe((appointment as any)?.scheduledAt);
  if (!when) return "Visit scheduled";
  const startMs = when.getTime();
  const graceMs = Math.max(0, graceMinutes) * 60 * 1000;
  if (appointment.status === "completed") return "Visit completed";
  if (appointment.status === "cancelled") return "Visit cancelled";
  if (appointment.mode === "video" && nowMs >= startMs - 10 * 60 * 1000 && nowMs <= startMs + graceMs) {
    return "Ready to join";
  }
  if (nowMs < startMs) return "Upcoming visit";
  return "Follow-up needed";
}

export const PatientPortal: React.FC = () => {
  const { user, currentUserData, normalizedRole, loading: authLoading } = useAuth() as any;
  const canUse = normalizedRole === "patient";

  const [patient, setPatient] = useState<Patient | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [invoices, setInvoices] = useState<InvoiceRow[]>([]);
  const [patientSummary, setPatientSummary] = useState("");
  const [patientSummaryUpdatedAt, setPatientSummaryUpdatedAt] = useState<Date | null>(null);
  const [documents, setDocuments] = useState<PatientUploadRow[]>([]);
  const [telehealthGraceMinutes, setTelehealthGraceMinutes] = useState<number>(30);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [consents, setConsents] = useState<Record<string, ConsentRow>>({});
  const [showConsents, setShowConsents] = useState(false);
  const [showBilling, setShowBilling] = useState(false);
  const [bookableClinicians, setBookableClinicians] = useState<BookableClinician[]>([]);
  const [bookingClinicianId, setBookingClinicianId] = useState("");
  const [bookingDateTime, setBookingDateTime] = useState("");
  const [bookingDurationMinutes, setBookingDurationMinutes] = useState(30);
  const [bookingMode, setBookingMode] = useState<"video" | "phone" | "in_person">("video");
  const [bookingReason, setBookingReason] = useState("");
  const [bookingBusy, setBookingBusy] = useState(false);
  const [bookingMsg, setBookingMsg] = useState<string | null>(null);
  const [bookingErr, setBookingErr] = useState<string | null>(null);

  const patientIdFromProfile = useMemo(() => currentUserData?.patientId || null, [currentUserData]);
  const localTz = useMemo(() => getLocalTimeZone(), []);
  const clinicTz = useMemo(
    () =>
      getClinicTimeZone(
        currentUserData?.practiceTimeZone,
        currentUserData?.timeZone
      ),
    [currentUserData]
  );
  const nextVideoAppt = useMemo(() => {
    const now = Date.now();
    const defaultGraceMs = Math.max(0, telehealthGraceMinutes) * 60 * 1000;
    const upcoming = appointments
      .map((a) => {
        const d = toDateMaybe(a?.scheduledAt);
        const override = Number(a?.telehealthGraceMinutesOverride);
        const graceMs = Number.isFinite(override) && override >= 0 ? override * 60 * 1000 : defaultGraceMs;
        return { a, d, graceMs };
      })
      .filter((row) => row.a?.mode === "video" && row.d && row.d.getTime() + row.graceMs > now)
      .sort((x, y) => x.d!.getTime() - y.d!.getTime());
    return upcoming.length > 0 ? upcoming[0].a : null;
  }, [appointments, telehealthGraceMinutes]);
  const nowMs = Date.now();
  const upcomingAppointments = useMemo(() => {
    return appointments
      .map((appointment) => ({
        appointment,
        when: toDateMaybe((appointment as any)?.scheduledAt),
      }))
      .filter((row) => row.when && row.appointment.status !== "cancelled")
      .sort((a, b) => a.when!.getTime() - b.when!.getTime());
  }, [appointments]);
  const nextAppointment = useMemo(
    () => upcomingAppointments.find((row) => row.when && row.when.getTime() + telehealthGraceMinutes * 60 * 1000 > nowMs)?.appointment || null,
    [nowMs, telehealthGraceMinutes, upcomingAppointments]
  );
  const unsignedConsentCount = useMemo(
    () => CONSENT_FORMS.filter((item) => consents[item.id]?.status !== "signed").length,
    [consents]
  );
  const unpaidInvoiceCount = useMemo(
    () => invoices.filter((invoice) => String(invoice.status || "unpaid").toLowerCase() !== "paid").length,
    [invoices]
  );
  const recentDocuments = useMemo(
    () =>
      documents
        .filter((item) => item.createdAt && nowMs - item.createdAt.getTime() <= 14 * 24 * 60 * 60 * 1000)
        .slice(0, 3),
    [documents, nowMs]
  );
  const nextAppointmentWhen = nextAppointment ? formatWhen(nextAppointment as any, clinicTz, localTz) : null;
  const triageNeeded = Boolean(nextAppointment && nextAppointment.status !== "cancelled" && (nextAppointment as any).triageStatus !== "completed");
  const journeyChecklist = useMemo(() => {
    const items: Array<{ id: string; title: string; detail: string; tone: "ready" | "action" | "info"; href?: string | null }> = [];
    if (nextAppointment) {
      items.push({
        id: "appointment",
        title: nextAppointmentActionLabel(nextAppointment, nowMs, telehealthGraceMinutes),
        detail: nextAppointmentWhen
          ? `${nextAppointment.mode === "video" ? "Telehealth" : "Visit"} with ${clinicianDisplayLabel(
              nextAppointment.clinicianName,
              (nextAppointment as any)?.clinicianEmail,
              nextAppointment.clinicianId
            )} at ${nextAppointmentWhen.local}.`
          : "Your next appointment is scheduled and visible in the appointments section.",
        tone:
          nextAppointment.mode === "video" && nextAppointmentWhen && nextAppointmentActionLabel(nextAppointment, nowMs, telehealthGraceMinutes) === "Ready to join"
            ? "ready"
            : "info",
        href: nextAppointment.mode === "video" ? `/call/${nextAppointment.id}` : "#appointments",
      });
    }
    if (triageNeeded) {
      items.push({
        id: "triage",
        title: "Complete symptom questions",
        detail: "Finish the intake questions for your next visit so your nurse sees your current concerns before the consult starts.",
        tone: "action",
        href: "#appointments",
      });
    }
    if (unsignedConsentCount > 0) {
      items.push({
        id: "consents",
        title: `${unsignedConsentCount} consent item${unsignedConsentCount === 1 ? "" : "s"} still open`,
        detail: "Sign outstanding consent and privacy acknowledgements before your next visit to reduce check-in delays.",
        tone: "action",
        href: "#consents",
      });
    }
    if (unpaidInvoiceCount > 0) {
      items.push({
        id: "billing",
        title: `${unpaidInvoiceCount} billing item${unpaidInvoiceCount === 1 ? "" : "s"} to review`,
        detail: "Check billing before your next visit so there are no avoidable delays with scheduling or document release.",
        tone: "action",
        href: "#billing",
      });
    }
    if (recentDocuments.length > 0) {
      items.push({
        id: "documents",
        title: `${recentDocuments.length} recent document${recentDocuments.length === 1 ? "" : "s"} available`,
        detail: "Your latest care documents and visit records are ready in the documents area.",
        tone: "info",
        href: "#documents",
      });
    }
    if (items.length === 0) {
      items.push({
        id: "empty",
        title: "Portal is up to date",
        detail: "You do not have any immediate next-step items. You can still book a visit, view documents, or check billing below.",
        tone: "ready",
        href: null,
      });
    }
    return items;
  }, [nextAppointment, nowMs, telehealthGraceMinutes, nextAppointmentWhen, triageNeeded, unsignedConsentCount, unpaidInvoiceCount, recentDocuments]);

  const filteredDocuments = documents;
  const selectedBookingClinician = useMemo(
    () => bookableClinicians.find((item) => item.id === bookingClinicianId) || null,
    [bookableClinicians, bookingClinicianId]
  );
  const bookingTimeZone = useMemo(
    () => selectedBookingClinician?.timeZone || clinicTz || localTz,
    [selectedBookingClinician?.timeZone, clinicTz, localTz]
  );
  const bookingDate = useMemo(
    () => parseDateTimeInZone(bookingDateTime, bookingTimeZone),
    [bookingDateTime, bookingTimeZone]
  );
  const bookingAvailabilitySummary = useMemo(() => {
    if (!selectedBookingClinician || !bookingDate) return null;
    return {
      available: isClinicianAvailableAt(selectedBookingClinician, bookingDate, bookingDurationMinutes),
      summary: formatAvailabilityForDate(selectedBookingClinician, bookingDate),
    };
  }, [selectedBookingClinician, bookingDate, bookingDurationMinutes]);

  const load = async () => {
    setErr(null);

    if (authLoading) return;
    if (!canUse) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      const email = normalizeEmail(user?.email || "");
      const patientId = patientIdFromProfile || user?.uid;

      if (!patientId) {
        setLoading(false);
        setErr("No linked patient record found. Set users/{uid}.patientId (recommended).");
        return;
      }

      // Patient record (direct get; avoids list permission)
      const patSnap = await getDoc(doc(db, "patients", patientId));
      if (patSnap.exists()) {
        setPatient({ id: patSnap.id, ...(patSnap.data() as any) });
      } else {
        // Fallback: shell portal even if patient doc isn't present yet
        setPatient({ id: patientId, fullName: "Patient", email } as any);
      }

      // Patient-facing summary
      try {
        const summarySnap = await getDoc(doc(db, "patientSummaries", patientId));
        if (summarySnap.exists()) {
          const data = summarySnap.data() as any;
          setPatientSummary(String(data?.summary || ""));
          setPatientSummaryUpdatedAt(toDateMaybe(data?.updatedAt));
        } else {
          setPatientSummary("");
          setPatientSummaryUpdatedAt(null);
        }
      } catch (e) {
        console.error("Failed to load patient summary:", e);
      }

      // System-wide config
      try {
        const cfgSnap = await getDoc(doc(db, "config", "app"));
        if (cfgSnap.exists()) {
          const raw = cfgSnap.data() as any;
          const minutes = Number(raw?.telehealthGraceMinutes);
          if (Number.isFinite(minutes) && minutes >= 0 && minutes <= 240) {
            setTelehealthGraceMinutes(minutes);
          }
        }
      } catch (e) {
        console.error("Failed to load app config:", e);
      }

      // Appointments (bounded query REQUIRED by rules)
      const aSnap = await getDocs(
        query(
          collection(db, "appointments"),
          where("patientId", "==", patientId),
          orderBy("scheduledAt", "asc"),
          limit(200)
        )
      );

      const rows: Appointment[] = aSnap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      setAppointments(rows);

      const patientPracticeId = String(currentUserData?.practiceId || "").trim();
      const availabilitySnap = patientPracticeId
        ? await getDocs(
            query(
              collection(db, "clinicianAvailability"),
              where("practiceId", "==", patientPracticeId),
              limit(200)
            )
          )
        : { docs: [] as any[] };
      const clinicianRows: BookableClinician[] = [];
      for (const d of availabilitySnap.docs) {
        const raw = d.data() as any;
        const id = String(raw?.clinicianId || d.id || "");
        if (!id) continue;
        const clinicianName = String(raw?.clinicianName || "").trim();
        const clinicianEmail = String(raw?.clinicianEmail || "").trim();
        clinicianRows.push({
          id,
          clinicianId: id,
          practiceId: String(raw?.practiceId || ""),
          clinicianName: clinicianName || null,
          clinicianEmail: clinicianEmail || null,
          nurseType: nurseTypeLabel(raw?.nurseType) || null,
          timeZone: raw?.timeZone ?? null,
          weekly: sanitizeWeeklyAvailability(raw?.weekly),
          dateBlocks: sanitizeDateBlocks(raw?.dateBlocks),
          createdAt: raw?.createdAt,
          updatedAt: raw?.updatedAt,
          updatedByUid: raw?.updatedByUid ?? null,
          label: formatNurseProfileLabel({
            displayName: clinicianName || null,
            nurseType: raw?.nurseType || null,
            email: clinicianEmail || null,
            fallback: id,
          }),
        });
      }
      clinicianRows.sort((a, b) => a.label.localeCompare(b.label));
      setBookableClinicians(clinicianRows);

      // Invoices
      const invSnap = await getDocs(
        query(collection(db, "invoices"), where("patientId", "==", patientId), orderBy("createdAt", "desc"), limit(50))
      );
      const invRows: InvoiceRow[] = invSnap.docs.map((d) => {
        const raw = d.data() as any;
        return {
          id: d.id,
          patientId: String(raw?.patientId || ""),
          description: raw?.description ?? null,
          status: raw?.status ?? null,
          totalCents: typeof raw?.totalCents === "number" ? raw.totalCents : null,
          currency: raw?.currency ?? null,
          issuedDate: raw?.issuedDate ?? null,
          dueDate: raw?.dueDate ?? null,
        };
      });
      setInvoices(invRows);

      const docsSnap = await getDocs(
        query(collection(db, "patients", patientId, "portalDocuments"), limit(100))
      );
      setDocuments(
        docsSnap.docs.map((d) => {
          const raw = d.data() as any;
          return {
            id: d.id,
            title: raw?.title ?? null,
            status: raw?.status ?? null,
            kind: raw?.kind ?? null,
            printPath: raw?.printPath ?? null,
            createdAt: toDateMaybe(raw?.createdAt),
            statusLabel: raw?.printablePayload?.clinicTrackingStatusLabel ?? null,
          };
        }).sort((a, b) => {
          const at = a.createdAt ? a.createdAt.getTime() : 0;
          const bt = b.createdAt ? b.createdAt.getTime() : 0;
          return bt - at;
        })
      );

      // Consents
      const consentsSnap = await getDocs(
        query(collection(db, "patients", patientId, "consents"), limit(200))
      );
      const consentMap: Record<string, ConsentRow> = {};
      consentsSnap.docs.forEach((d) => {
        consentMap[d.id] = { ...(d.data() as ConsentRow), consentId: d.id };
      });
      setConsents(consentMap);
    } catch (e: any) {
      console.error(e);
      setErr(e?.message ?? "Failed to load patient portal.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (canUse) void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canUse, user?.uid, authLoading, patientIdFromProfile]);

  useEffect(() => {
    if (!bookingClinicianId && bookableClinicians.length > 0) {
      setBookingClinicianId(bookableClinicians[0].id);
    }
  }, [bookingClinicianId, bookableClinicians]);

  useEffect(() => {
    setBookingDateTime((current) => (current ? current : defaultBookingDateTime(bookingTimeZone)));
  }, [bookingTimeZone]);

  if (!canUse) {
    return (
      <MainLayout>
        <div className="text-sm text-red-600">Access denied.</div>
      </MainLayout>
    );
  }

  const p: any = patient || {};

  const signConsent = async (consentId: string, version: string) => {
    if (!p?.id) return;
    try {
      const consentTitle = CONSENT_FORMS.find((item) => item.id === consentId)?.title || consentId;
      const batch = writeBatch(db);
      const consentRef = doc(db, "patients", p.id, "consents", consentId);
      const eventRef = doc(collection(db, "patients", p.id, "consents", consentId, "events"));
      const now = serverTimestamp();

      batch.set(consentRef, {
        consentId,
        patientId: p.id,
        practiceId: currentUserData?.practiceId || null,
        title: consentTitle,
        version,
        status: "signed",
        signedAt: now,
        signedByUid: user?.uid || "",
      });
      batch.set(eventRef, {
        patientId: p.id,
        consentId,
        type: "signed",
        title: consentTitle,
        version,
        actorUid: user?.uid || "",
        occurredAt: now,
      });
      await batch.commit();
      await load();
    } catch (e: any) {
      setErr(toPlainLanguageOutcomeMessage(e, "We could not record that consent just now."));
    }
  };

  const withdrawConsent = async (consentId: string) => {
    if (!p?.id) return;
    const current = consents?.[consentId];
    if (!current || current.status === "withdrawn") return;
    try {
      const batch = writeBatch(db);
      const consentRef = doc(db, "patients", p.id, "consents", consentId);
      const eventRef = doc(collection(db, "patients", p.id, "consents", consentId, "events"));
      const now = serverTimestamp();

      batch.set(
        consentRef,
        {
          status: "withdrawn",
          withdrawnAt: now,
          withdrawnByUid: user?.uid || "",
          updatedAt: now,
          updatedByUid: user?.uid || "",
        },
        { merge: true }
      );
      batch.set(eventRef, {
        patientId: p.id,
        consentId,
        type: "withdrawn",
        title: current.title || consentId,
        version: current.version,
        actorUid: user?.uid || "",
        occurredAt: now,
      });
      await batch.commit();
      await load();
    } catch (e: any) {
      setErr(toPlainLanguageOutcomeMessage(e, "We could not update that consent just now."));
    }
  };

  const submitBooking = async () => {
    if (!p?.id) {
      setBookingErr("Linked patient record not found.");
      return;
    }

    if (!bookingClinicianId) {
      setBookingErr("Select a nurse.");
      return;
    }

    const scheduledAt = parseDateTimeInZone(bookingDateTime, bookingTimeZone);
    if (!scheduledAt) {
      setBookingErr("Enter a valid date and time.");
      return;
    }

    setBookingBusy(true);
    setBookingErr(null);
    setBookingMsg(null);
    try {
      const call = httpsCallable(functions, "requestPatientAppointment");
      await call({
        clinicianId: bookingClinicianId,
        scheduledAt: scheduledAt.toISOString(),
        durationMinutes: Math.max(5, Number(bookingDurationMinutes || 30)),
        mode: bookingMode,
        reason: bookingReason.trim() || null,
      });
      setBookingMsg("Appointment booked. You can now optionally complete symptom questions for your nurse.");
      setBookingReason("");
      setBookingDurationMinutes(30);
      setBookingMode("video");
      setBookingDateTime(defaultBookingDateTime(bookingTimeZone));
      await load();
    } catch (e: any) {
      console.error(e);
      setBookingErr(getCallableErrorMessage(e, "Failed to book appointment."));
    } finally {
      setBookingBusy(false);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4 patient-portal pb-32 md:pb-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Patient Portal</h1>
            <p className="section-subtitle">Your appointments and telehealth access.</p>
          </div>
        </div>

        {err && <div className="text-sm text-rose-600">{err}</div>}

        <div className="grid grid-cols-1 xl:grid-cols-[1.3fr_0.9fr] gap-4" id="journey">
          <section className="card overflow-hidden">
            <div className="bg-[radial-gradient(circle_at_top_left,_rgba(20,116,110,0.18),_transparent_42%),linear-gradient(135deg,#f7fbfa_0%,#edf8f6_36%,#ffffff_100%)] px-5 py-5 md:px-6">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                <div className="max-w-2xl">
                  <div className="text-[11px] uppercase tracking-[0.24em] text-ink-500">Visit Journey</div>
                  <h2 className="mt-2 text-2xl text-ink-900">Your next steps before and after care</h2>
                  <p className="mt-2 text-sm text-ink-600">
                    The portal now highlights what needs attention first: visit readiness, symptom intake, documents, consent, and billing.
                  </p>
                  {nextAppointmentWhen ? (
                    <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/90 px-3 py-1.5 text-xs text-ink-700">
                      Next visit:
                      <span className="font-semibold">{nextAppointmentWhen.local}</span>
                      <span>·</span>
                      <span>{nextAppointment ? clinicianDisplayLabel(nextAppointment.clinicianName, (nextAppointment as any)?.clinicianEmail, nextAppointment.clinicianId) : "Nurse"}</span>
                    </div>
                  ) : (
                    <div className="mt-4 inline-flex items-center rounded-full border border-ink-200 bg-white/90 px-3 py-1.5 text-xs text-ink-600">
                      No upcoming visit booked yet.
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <div className="rounded-2xl bg-white/90 px-4 py-3">
                    <div className="text-[11px] uppercase tracking-wide text-ink-500">Next visit</div>
                    <div className="mt-1 text-sm font-semibold text-ink-900">
                      {nextAppointment ? nextAppointmentActionLabel(nextAppointment, nowMs, telehealthGraceMinutes) : "Not booked"}
                    </div>
                  </div>
                  <div className="rounded-2xl bg-white/90 px-4 py-3">
                    <div className="text-[11px] uppercase tracking-wide text-ink-500">Consents</div>
                    <div className="mt-1 text-2xl font-semibold text-ink-900">{unsignedConsentCount}</div>
                  </div>
                  <div className="rounded-2xl bg-white/90 px-4 py-3">
                    <div className="text-[11px] uppercase tracking-wide text-ink-500">Recent docs</div>
                    <div className="mt-1 text-2xl font-semibold text-ink-900">{recentDocuments.length}</div>
                  </div>
                  <div className="rounded-2xl bg-white/90 px-4 py-3">
                    <div className="text-[11px] uppercase tracking-wide text-ink-500">Billing</div>
                    <div className="mt-1 text-2xl font-semibold text-ink-900">{unpaidInvoiceCount}</div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="card p-5 md:p-4">
            <div className="section-title mb-3">Care checklist</div>
            <div className="space-y-3">
              {journeyChecklist.map((item) => {
                const content = (
                  <div className={`rounded-xl border px-4 py-3 ${journeyCardTone(item.tone)}`}>
                    <div className="text-sm font-semibold text-ink-900">{item.title}</div>
                    <div className="mt-1 text-xs text-ink-600 leading-relaxed">{item.detail}</div>
                  </div>
                );
                if (!item.href) return <div key={item.id}>{content}</div>;
                if (item.href.startsWith("/")) {
                  return (
                    <Link key={item.id} to={item.href}>
                      {content}
                    </Link>
                  );
                }
                return (
                  <a key={item.id} href={item.href}>
                    {content}
                  </a>
                );
              })}
            </div>
          </section>
        </div>

        <div className="card p-5 md:p-4" id="profile">
          <div className="card-header mb-3">
            <div className="section-title">Profile</div>
            <button onClick={() => void load()} className="btn-secondary">
              Refresh
            </button>
          </div>

          {loading ? (
            <div className="text-sm text-ink-500">Loading...</div>
          ) : (
            <div className="text-sm grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-2">
              <div>
                <span className="text-ink-500">Name:</span> {p.fullName || "—"}
              </div>
              <div>
                <span className="text-ink-500">Email:</span> {p.email || user?.email || "—"}
              </div>
              <div>
                <span className="text-ink-500">UR No.:</span> {p.urNumber || "—"}
              </div>
              <div>
                <span className="text-ink-500">Primary ID:</span>{" "}
                {p.primaryId?.type ? `${p.primaryId.type}${p.primaryId.value ? ` • ${p.primaryId.value}` : ""}` : "—"}
              </div>
            </div>
          )}
        </div>

        <div className="card p-5 md:p-4" id="summary">
          <div className="section-title mb-2 text-base">Summary</div>
          {patientSummary ? (
            <div className="text-sm text-ink-700 whitespace-pre-wrap leading-relaxed">{patientSummary}</div>
          ) : (
            <div className="text-sm text-ink-500">No summary yet. Your nurse will add one after the visit.</div>
          )}
          {patientSummaryUpdatedAt ? (
            <div className="text-xs text-ink-500 mt-2">
              Last updated: {formatDateTimeInZone(patientSummaryUpdatedAt, localTz)}
            </div>
          ) : null}
        </div>

        <div className="card p-5 md:p-4" id="appointments">
          <div className="section-title mb-3 text-base">Appointments</div>

          <div className="border border-ink-200 rounded-xl p-4 mb-4 space-y-3">
            <div>
              <div className="text-sm font-semibold">Book a new appointment</div>
              <div className="text-xs text-ink-500">Use your portal to schedule with an available nurse.</div>
            </div>

            {bookingErr ? <div className="text-sm text-rose-600">{bookingErr}</div> : null}
            {bookingMsg ? <div className="text-sm text-emerald-600">{bookingMsg}</div> : null}

            {bookableClinicians.length === 0 ? (
              <div className="text-sm text-ink-500">No nurse booking rosters are available yet.</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="label">Nurse</label>
                  <select
                    className="select"
                    value={bookingClinicianId}
                    onChange={(e) => setBookingClinicianId(e.target.value)}
                    disabled={bookingBusy}
                  >
                    {bookableClinicians.map((clinician) => (
                      <option key={clinician.id} value={clinician.id}>
                        {clinician.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="label">Scheduled (clinic time)</label>
                  <input
                    type="datetime-local"
                    className="input"
                    value={bookingDateTime}
                    onChange={(e) => setBookingDateTime(e.target.value)}
                    disabled={bookingBusy}
                  />
                  <div className="text-[11px] text-ink-500 mt-1">
                    Time zone: {bookingTimeZone}
                  </div>
                </div>

                <div>
                  <label className="label">Mode</label>
                  <select
                    className="select"
                    value={bookingMode}
                    onChange={(e) => setBookingMode(e.target.value as "video" | "phone" | "in_person")}
                    disabled={bookingBusy}
                  >
                    <option value="video">Video</option>
                    <option value="phone">Phone</option>
                    <option value="in_person">In person</option>
                  </select>
                </div>

                <div>
                  <label className="label">Duration (minutes)</label>
                  <input
                    type="number"
                    min={5}
                    max={240}
                    className="input"
                    value={bookingDurationMinutes}
                    onChange={(e) => setBookingDurationMinutes(Number(e.target.value))}
                    disabled={bookingBusy}
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="label">Reason</label>
                  <input
                    type="text"
                    className="input"
                    placeholder="Brief reason for the appointment"
                    value={bookingReason}
                    onChange={(e) => setBookingReason(e.target.value)}
                    disabled={bookingBusy}
                  />
                </div>
              </div>
            )}

            {selectedBookingClinician && bookingAvailabilitySummary ? (
              <div className="text-xs text-ink-600">
                <span className={bookingAvailabilitySummary.available ? "chip chip-success" : "chip chip-warning"}>
                  {bookingAvailabilitySummary.available ? "Within roster" : "Outside roster"}
                </span>
                <span className="ml-2">{bookingAvailabilitySummary.summary}</span>
              </div>
            ) : null}

            <div className="flex justify-end">
              <button
                type="button"
                className="btn-primary"
                onClick={() => void submitBooking()}
                disabled={bookingBusy || bookableClinicians.length === 0}
              >
                {bookingBusy ? "Booking..." : "Book appointment"}
              </button>
            </div>
          </div>

          {loading ? (
            <div className="text-sm text-ink-500">Loading...</div>
          ) : appointments.length === 0 ? (
            <div className="text-sm text-ink-500">No appointments found.</div>
          ) : (
            <div className="space-y-3">
              {appointments.map((a: any) => (
                <div key={a.id} className="border border-ink-200 rounded-xl p-4">
                  <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                    <div>
                      {(() => {
                        const when = formatWhen(a, clinicTz, localTz);
                        if (!when) return <div className="text-sm font-semibold">—</div>;
                        return (
                          <div>
                            <div className="text-sm font-semibold">{when.local}</div>
                            <div className="text-xs text-ink-500 mt-0.5">
                              Local ({localTz}) · Clinic ({when.clinicTz})
                            </div>
                            <div className="text-xs text-ink-500">{when.clinic}</div>
                          </div>
                        );
                      })()}
                      <div className="text-xs text-ink-500 flex flex-wrap items-center gap-2 mt-2">
                        <span className="capitalize">{a.mode}</span>
                        <span className={statusChip(a.status)}>{a.status}</span>
                        <span>
                          Nurse: {clinicianDisplayLabel(a.clinicianName, (a as any)?.clinicianEmail, a.clinicianId)}
                        </span>
                      </div>
                      {a.reason && <div className="text-xs text-ink-500 mt-2">Reason: {a.reason}</div>}
                    </div>

                    <div className="flex gap-2 md:justify-end">
                      {a.mode === "video" && (
                        <Link
                          to={`/call/${a.id}`}
                          className="btn-primary text-xs px-3 py-2 w-full md:w-auto text-center"
                        >
                          Join telehealth
                        </Link>
                      )}
                    </div>
                  </div>
                  {a.status !== "cancelled" ? (
                    <div className="mt-4">
                      <TriageIntakeCard appointment={a} onUpdated={load} />
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-5 md:p-4" id="consents">
          <button
            className="w-full flex items-center justify-between text-left"
            onClick={() => setShowConsents((v) => !v)}
            aria-expanded={showConsents}
          >
            <span className="section-title">Consents</span>
            <span className="chip chip-info">{showConsents ? "Hide" : "Show"}</span>
          </button>
          {showConsents ? (
            <div className="space-y-3 mt-3">
              {CONSENT_FORMS.map((c) => {
                const signed = consents?.[c.id];
                return (
                  <div key={c.id} className="border border-ink-200 rounded-lg p-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="text-sm font-medium">{c.title}</div>
                      <div className="text-xs text-ink-500">Version {c.version}</div>
                      {signed?.signedAt ? (
                        <div className="text-xs text-ink-500 mt-1">
                          Signed
                          {toDateMaybe(signed.signedAt) ? ` ${formatDateTimeInZone(toDateMaybe(signed.signedAt) as Date, localTz)}` : ""}
                        </div>
                      ) : null}
                      {signed?.status === "withdrawn" && signed?.withdrawnAt ? (
                        <div className="text-xs text-rose-600 mt-1">
                          Withdrawn
                          {toDateMaybe(signed.withdrawnAt)
                            ? ` ${formatDateTimeInZone(toDateMaybe(signed.withdrawnAt) as Date, localTz)}`
                            : ""}
                        </div>
                      ) : null}
                    </div>
                    {signed?.status === "withdrawn" ? (
                      <span className="chip chip-danger">Withdrawn</span>
                    ) : signed?.signedAt ? (
                      <div className="flex flex-col gap-2 sm:items-end">
                        <span className="chip chip-success">Signed</span>
                        <button className="btn-secondary text-xs" onClick={() => void withdrawConsent(c.id)}>
                          Withdraw
                        </button>
                      </div>
                    ) : (
                      <button className="btn-primary text-xs" onClick={() => void signConsent(c.id, c.version)}>
                        Sign
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          ) : null}
        </div>

        <div className="card p-5 md:p-4" id="billing">
          <button
            className="w-full flex items-center justify-between text-left"
            onClick={() => setShowBilling((v) => !v)}
            aria-expanded={showBilling}
          >
            <span className="section-title">Billing</span>
            <span className="chip chip-info">{showBilling ? "Hide" : "Show"}</span>
          </button>
          {showBilling ? (
            <div className="mt-3">
              {loading ? (
                <div className="text-sm text-ink-500">Loading...</div>
              ) : invoices.length === 0 ? (
                <div className="text-sm text-ink-500">No invoices yet.</div>
              ) : (
                <div className="space-y-3">
                  {invoices.map((inv) => (
                    <div key={inv.id} className="border border-ink-200 rounded-xl p-4">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <div className="text-sm font-semibold">{inv.description || "Invoice"}</div>
                          <div className="text-xs text-ink-500">
                            Issued: {inv.issuedDate ? formatToDDMMYYYY(inv.issuedDate) : "—"} · Due:{" "}
                            {inv.dueDate ? formatToDDMMYYYY(inv.dueDate) : "—"}
                          </div>
                          <div className="text-xs text-ink-500 mt-1">Invoice ID: {inv.id}</div>
                        </div>
                        <div className="text-left sm:text-right">
                          <div className="text-sm font-semibold">
                            {formatMoney(inv.totalCents || 0, inv.currency || getDefaultCurrency())}
                          </div>
                          <div className="text-xs text-ink-500 capitalize">{inv.status || "unpaid"}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : null}
        </div>

        <div className="card p-5 md:p-4" id="documents">
          <div className="section-title mb-3 text-base">Care documents</div>
          {loading ? (
            <div className="text-sm text-ink-500">Loading...</div>
          ) : documents.length === 0 ? (
            <div className="text-sm text-ink-500">No care documents available yet.</div>
          ) : (
            <div className="space-y-4">
              {filteredDocuments.length === 0 ? (
                <div className="text-sm text-ink-500">No care documents available yet.</div>
              ) : (
                <div className="space-y-3">
                  {filteredDocuments.map((item) => (
                    <div key={item.id} className="border border-ink-200 rounded-xl p-4 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                      <div>
                        <div className="text-sm font-semibold">{item.title || "Clinical document"}</div>
                        <div className="text-xs text-ink-500">
                          Care document
                          {item.createdAt ? ` · ${formatDateTimeInZone(item.createdAt, localTz)}` : ""}
                        </div>
                        <div className="mt-2">
                          <span className={documentStatusChipClass(item)}>{item.statusLabel || fallbackDocumentStatusLabel(item)}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {item.printPath ? (
                          <Link to={item.printPath} className="btn-secondary text-xs px-3 py-2">
                            View / Print
                          </Link>
                        ) : null}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {nextVideoAppt ? (
        <div className="fixed bottom-14 left-0 right-0 z-40 sm:hidden px-4">
          <div className="max-w-6xl mx-auto">
            <Link to={`/call/${nextVideoAppt.id}`} className="btn-primary w-full text-center py-3">
              <div className="flex flex-col">
                <span className="font-semibold">Join Telehealth</span>
                <span className="text-[11px] opacity-90">
                  {(() => {
                    const when = formatWhen(nextVideoAppt, clinicTz, localTz);
                    const who = clinicianDisplayLabel(
                      nextVideoAppt?.clinicianName,
                      (nextVideoAppt as any)?.clinicianEmail,
                      nextVideoAppt?.clinicianId || "Nurse"
                    );
                    return when ? `${when.local} · ${who}` : who;
                  })()}
                </span>
              </div>
            </Link>
          </div>
        </div>
      ) : null}
      <div className="fixed bottom-0 left-0 right-0 z-30 border-t border-ink-200 bg-white/95 backdrop-blur sm:hidden">
        <div className="max-w-6xl mx-auto px-4 py-2 grid grid-cols-4 gap-2 text-xs">
          <a href="#summary" className="btn-secondary text-center py-2">Summary</a>
          <a href="#appointments" className="btn-secondary text-center py-2">Appts</a>
          <a href="#documents" className="btn-secondary text-center py-2">Docs</a>
          <a href="#billing" className="btn-secondary text-center py-2">Billing</a>
        </div>
      </div>
    </MainLayout>
  );
};

export default PatientPortal;
