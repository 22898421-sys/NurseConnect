// src/components/PatientChartPage.tsx
import React, { useEffect, useMemo, useState } from "react";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  deleteField,
  updateDoc,
  where,
} from "firebase/firestore";
import { deleteObject, getDownloadURL, ref as storageRef, uploadBytes } from "firebase/storage";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { db, storage } from "../firebaseConfig";
import { Patient } from "../models/emr";
import { MainLayout } from "./MainLayout";
import { useAuth } from "../contexts/AuthContext";
import { PatientChartHeader } from "./PatientChartHeader";
import { PatientEncountersTab } from "./PatientEncountersTab";
import CarePlansTab from "./CarePlansTab";
import RiskAssessmentsTab from "./RiskAssessmentsTab";
import NursePrescribingTab from "./NursePrescribingTab";
import {
  AUSTRALIAN_PRIVATE_FUNDS,
  formatMoney,
  getDefaultCurrency,
  INSURER_OTHER,
  normalizeCurrency,
  SUPPORTED_CURRENCIES,
} from "../lib/billing";
import { formatToDDMMYYYY } from "../lib/dates";
import { logSensitiveAccess } from "../lib/accessAudit";
import { buildDeidentifiedPatientChartExportBundle, buildPatientChartExportBundle } from "../lib/fhirExport";
import { canNursePrescribe } from "../lib/nurseScope";

type ChartTab =
  | "overview"
  | "timeline"
  | "encounters"
  | "allergies_alerts"
  | "medications"
  | "care_plans"
  | "risk"
  | "documents"
  | "history"
  | "billing";

type AttachmentMeta = {
  id: string;
  name: string;
  contentType: string;
  sizeBytes: number;
  path: string;
  url: string;
  uploadedAt: string;
};

type ClinicalEntry = {
  id: string;
  date: string;
  title: string;
  status: string;
  notes: string;
  attachments: AttachmentMeta[];
  meta?: Record<string, unknown>;
};

type ChartData = {
  overview: {
    summary: string;
    problems: string;
    pastMedicalHistory: string;
    familyHistory: string;
    socialHistory: string;
    carePlan: string;
  };
  allergiesAlerts: {
    allergies: ClinicalEntry[];
    alerts: ClinicalEntry[];
  };
  documents: { items: ClinicalEntry[] };
  history: { items: ClinicalEntry[] };
};

type InvoiceStatus = "draft" | "issued" | "paid" | "void";
type BillingPathway = "out_of_pocket" | "private_cover" | "split";
type ClaimStatus = "not_submitted" | "submitted" | "approved" | "declined" | "paid";

type InvoiceRow = {
  id: string;
  patientId: string;
  appointmentId?: string | null;
  description: string;
  currency: string;
  totalCents: number;
  status: InvoiceStatus;
  issuedDate: string;
  dueDate: string;
  paidDate?: string | null;
  billingPathway?: BillingPathway;
  coverage?: {
    outOfPocketCents?: number;
    privateCoverCents?: number;
  };
  privateCover?: {
    insurerName?: string;
    planName?: string;
    membershipNumber?: string;
    claimReference?: string;
    claimStatus?: ClaimStatus;
  };
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
};

type TimelineItem = {
  id: string;
  kind: "appointment" | "encounter" | "invoice";
  date: Date;
  title: string;
  subtitle?: string;
  href?: string;
};

const CLINICIAN_CHART_TABS: ChartTab[] = [
  "overview",
  "timeline",
  "encounters",
  "allergies_alerts",
  "medications",
  "care_plans",
  "risk",
  "documents",
  "history",
];

const ADMIN_CHART_TABS: ChartTab[] = ["overview", "timeline", "billing"];

const MAX_FILE_BYTES = 5 * 1024 * 1024;

function nowIso() {
  return new Date().toISOString();
}

function makeId(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function todayDateInput() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

function sanitizeFileName(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]/g, "_");
}

function emptyEntry(title = ""): ClinicalEntry {
  return {
    id: makeId("entry"),
    date: todayDateInput(),
    title,
    status: "",
    notes: "",
    attachments: [],
  };
}

function asString(v: unknown): string {
  return typeof v === "string" ? v : "";
}

function asNumber(v: unknown): number {
  const n = Number(v || 0);
  return Number.isFinite(n) ? n : 0;
}

function parseAttachment(a: any): AttachmentMeta | null {
  if (!a || typeof a !== "object") return null;
  const name = asString(a.name);
  const path = asString(a.path);
  const url = asString(a.url);
  if (!name || !path || !url) return null;
  return {
    id: asString(a.id) || makeId("att"),
    name,
    contentType: asString(a.contentType) || "application/octet-stream",
    sizeBytes: asNumber(a.sizeBytes),
    path,
    url,
    uploadedAt: asString(a.uploadedAt) || nowIso(),
  };
}

function parseEntries(raw: any): ClinicalEntry[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((r) => {
      if (!r || typeof r !== "object") return null;
      const meta = r.meta && typeof r.meta === "object" ? { ...(r.meta as Record<string, unknown>) } : undefined;
      return {
        id: asString(r.id) || makeId("entry"),
        date: asString(r.date) || todayDateInput(),
        title: asString(r.title),
        status: asString(r.status),
        notes: asString(r.notes),
        attachments: Array.isArray(r.attachments)
          ? (r.attachments.map(parseAttachment).filter(Boolean) as AttachmentMeta[])
          : [],
        ...(meta ? { meta } : {}),
      } as ClinicalEntry;
    })
    .filter(Boolean) as ClinicalEntry[];
}

function entriesFromLegacyText(raw: any, label: string): ClinicalEntry[] {
  const v = asString(raw).trim();
  if (!v) return [];
  return [{ ...emptyEntry(label), title: label, notes: v }];
}

const EMPTY_CHART_DATA: ChartData = {
  overview: {
    summary: "",
    problems: "",
    pastMedicalHistory: "",
    familyHistory: "",
    socialHistory: "",
    carePlan: "",
  },
  allergiesAlerts: { allergies: [], alerts: [] },
  documents: { items: [] },
  history: { items: [] },
};

function parseChartData(raw: any): ChartData {
  const c = raw && typeof raw === "object" ? raw : {};

  const overviewRaw = c?.overview && typeof c.overview === "object" ? c.overview : {};
  const aaRaw = c?.allergiesAlerts && typeof c.allergiesAlerts === "object" ? c.allergiesAlerts : {};
  const documentsRaw = c?.documents && typeof c.documents === "object" ? c.documents : {};
  const historyRaw = c?.history && typeof c.history === "object" ? c.history : {};

  const allergies = parseEntries(aaRaw?.allergies);
  const alerts = parseEntries(aaRaw?.alerts);

  const documentsItems = parseEntries(documentsRaw?.items);
  const historyItems = parseEntries(historyRaw?.items);

  return {
    overview: {
      summary: asString(overviewRaw.summary),
      problems: asString(overviewRaw.problems),
      pastMedicalHistory: asString(overviewRaw.pastMedicalHistory),
      familyHistory: asString(overviewRaw.familyHistory),
      socialHistory: asString(overviewRaw.socialHistory),
      carePlan: asString(overviewRaw.carePlan),
    },
    allergiesAlerts: {
      allergies: allergies.length ? allergies : entriesFromLegacyText(aaRaw?.allergies, "Allergy"),
      alerts: alerts.length ? alerts : entriesFromLegacyText(aaRaw?.alerts, "Alert"),
    },
    documents: { items: documentsItems.length ? documentsItems : entriesFromLegacyText(documentsRaw?.notes, "Document note") },
    history: { items: historyItems.length ? historyItems : entriesFromLegacyText(historyRaw?.notes, "History note") },
  };
}

function TabButton(props: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      className={`px-3 py-2 rounded-md text-sm border ${props.active ? "bg-gray-900 text-white border-gray-900" : "hover:bg-gray-50"}`}
      onClick={props.onClick}
    >
      {props.children}
    </button>
  );
}

function normalizeSearchText(v: string): string {
  return String(v || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenizeSearchText(v: string): string[] {
  const n = normalizeSearchText(v);
  return n ? n.split(" ").filter(Boolean) : [];
}

function Field(props: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  rows?: number;
}) {
  return (
    <div>
      <label className="block text-xs text-gray-600 mb-1">{props.label}</label>
      <textarea
        className="w-full border rounded-md px-3 py-2 text-sm"
        rows={props.rows ?? 4}
        placeholder={props.placeholder || ""}
        value={props.value}
        onChange={(e) => props.onChange(e.target.value)}
      />
    </div>
  );
}

function metaStr(meta: Record<string, unknown> | undefined, key: string): string {
  const value = meta?.[key];
  return typeof value === "string" ? value : "";
}

function metaStringArray(meta: Record<string, unknown> | undefined, key: string): string[] {
  const value = meta?.[key];
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string" && !!item.trim()) : [];
}

function isStructuredActionEntry(entry: ClinicalEntry): boolean {
  const meta = entry.meta && typeof entry.meta === "object" ? (entry.meta as Record<string, unknown>) : undefined;
  return !!metaStr(meta, "kind");
}

function structuredFieldsFromNotes(notes: string): string[] {
  return String(notes || "")
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => !!line && line.includes(":"));
}

function structuredDetailRows(entry: ClinicalEntry): string[] {
  const meta = entry.meta && typeof entry.meta === "object" ? (entry.meta as Record<string, unknown>) : undefined;
  const kind = metaStr(meta, "kind");
  const selectedPanels = metaStringArray(meta, "selectedPanels");
  const fields = structuredFieldsFromNotes(entry.notes);

  if (kind !== "prescription") return [];

  return fields.filter((field) => {
    if (field.startsWith("Tests / panels:") && selectedPanels.length > 0) return false;
    return !field.startsWith("Priority:");
  });
}

function StructuredEntrySummary({ entry }: { entry: ClinicalEntry }) {
  const meta = entry.meta && typeof entry.meta === "object" ? (entry.meta as Record<string, unknown>) : undefined;
  const kind = metaStr(meta, "kind");
  if (!kind) return null;

  const details: string[] = [];
  const detailRows = structuredDetailRows(entry);
  const priority = metaStr(meta, "priority");
  const sourceAppointmentId = metaStr(meta, "sourceAppointmentId");
  const sourceEncounterId = metaStr(meta, "sourceEncounterId");
  const selectedPanels = metaStringArray(meta, "selectedPanels");

  if (kind === "prescription") {
    details.push(`Prescription draft`);
  } else {
    return null;
  }

  if (sourceAppointmentId) details.push(`Appt: ${sourceAppointmentId}`);
  if (sourceEncounterId) details.push(`Encounter: ${sourceEncounterId}`);

  return (
    <div className="rounded-md border border-teal-200 bg-teal-50 px-3 py-2">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-xs font-medium text-teal-900">Structured clinical action</span>
        {priority ? (
          <span className="rounded-full border border-teal-300 bg-white px-2 py-0.5 text-[11px] text-teal-900">
            Priority: {priority}
          </span>
        ) : null}
      </div>
      <div className="mt-1 text-xs text-teal-800">{details.join(" · ")}</div>
      {selectedPanels.length > 0 ? (
        <div className="mt-2 space-y-1">
          <div className="text-[11px] font-medium text-teal-900">Selections</div>
          <div className="flex flex-wrap gap-1.5">
            {selectedPanels.map((panel) => (
              <span
                key={`${entry.id}-${panel}`}
                className="rounded-full border border-teal-300 bg-white px-2 py-0.5 text-[11px] text-teal-900"
              >
                {panel}
              </span>
            ))}
          </div>
        </div>
      ) : null}
      {detailRows.length ? (
        <div className="mt-2 space-y-1">
          {detailRows.map((field) => (
            <div key={`${entry.id}-${field}`} className="text-[11px] text-teal-900">
              {field}
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

type EntryEditorProps = {
  title: string;
  sectionKey: string;
  entries: ClinicalEntry[];
  onChange: (entries: ClinicalEntry[]) => void;
  canWrite: boolean;
  onUpload: (sectionKey: string, entryId: string, file: File) => Promise<AttachmentMeta>;
  onDeleteAttachment: (path: string) => Promise<void>;
  titleSuggestions?: string[];
  titleHint?: string;
  enableTypeahead?: boolean;
  maxTypeaheadResults?: number;
  renderEntryActions?: (entry: ClinicalEntry) => React.ReactNode;
};

function EntryEditor(props: EntryEditorProps) {
  const {
    title,
    sectionKey,
    entries,
    onChange,
    canWrite,
    onUpload,
    onDeleteAttachment,
    titleSuggestions,
    titleHint,
    enableTypeahead,
    maxTypeaheadResults = 20,
    renderEntryActions,
  } = props;
  const [uploadingFor, setUploadingFor] = useState<string | null>(null);
  const [openSuggestionFor, setOpenSuggestionFor] = useState<string | null>(null);
  const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(0);

  const indexedSuggestions = useMemo(
    () =>
      Array.isArray(titleSuggestions)
        ? titleSuggestions
            .map((value) => ({
              value,
              normalized: normalizeSearchText(value),
              tokens: tokenizeSearchText(value),
            }))
            .filter((x) => x.value && x.normalized)
        : [],
    [titleSuggestions]
  );

  const getSuggestionsForQuery = (query: string): string[] => {
    if (!enableTypeahead) return [];
    const q = normalizeSearchText(query);
    const qTokens = tokenizeSearchText(query);
    if (!q || q.length < 2 || qTokens.length === 0) return [];
    const ranked: Array<{ value: string; score: number }> = [];
    for (const item of indexedSuggestions) {
      const allTokensMatch = qTokens.every((t) => item.normalized.includes(t));
      if (!allTokensMatch) continue;

      let score = 0;
      if (item.normalized === q) score += 1000;
      if (item.normalized.startsWith(q)) score += 600;
      if (item.tokens.some((t) => t.startsWith(q))) score += 350;
      score += qTokens.reduce((s, t) => (item.tokens.some((tok) => tok.startsWith(t)) ? s + 80 : s + 25), 0);
      ranked.push({ value: item.value, score });
    }

    ranked.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return a.value.localeCompare(b.value);
    });

    const out: string[] = [];
    const seen = new Set<string>();
    for (const r of ranked) {
      if (seen.has(r.value)) continue;
      seen.add(r.value);
      out.push(r.value);
      if (out.length >= maxTypeaheadResults) break;
    }
    return out;
  };

  const clampActiveIndex = (idx: number, length: number) => {
    if (length <= 0) return 0;
    if (idx < 0) return length - 1;
    if (idx >= length) return 0;
    return idx;
  };

  const updateEntry = (id: string, patch: Partial<ClinicalEntry>) => {
    onChange(entries.map((e) => (e.id === id ? { ...e, ...patch } : e)));
  };

  const removeEntry = (id: string) => {
    onChange(entries.filter((e) => e.id !== id));
  };

  const addEntry = () => {
    onChange([...entries, emptyEntry()]);
  };

  const addAttachment = async (entryId: string, file: File) => {
    if (!canWrite) return;
    setUploadingFor(entryId);
    try {
      const att = await onUpload(sectionKey, entryId, file);
      onChange(entries.map((e) => (e.id === entryId ? { ...e, attachments: [...(e.attachments || []), att] } : e)));
    } finally {
      setUploadingFor(null);
    }
  };

  const removeAttachment = async (entryId: string, att: AttachmentMeta) => {
    if (!canWrite) return;
    setUploadingFor(entryId);
    try {
      await onDeleteAttachment(att.path);
      onChange(entries.map((e) => (e.id === entryId ? { ...e, attachments: e.attachments.filter((x) => x.id !== att.id) } : e)));
    } finally {
      setUploadingFor(null);
    }
  };

  return (
    <div className="border rounded-xl p-4 bg-white space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold">{title}</div>
        <button
          type="button"
          className="px-3 py-1.5 rounded border text-xs hover:bg-gray-50 disabled:opacity-50"
          onClick={addEntry}
          disabled={!canWrite}
        >
          Add Row
        </button>
      </div>
      {titleHint ? <div className="text-xs text-gray-600">{titleHint}</div> : null}

      {entries.length === 0 ? <div className="text-xs text-gray-500">No rows yet.</div> : null}

      {entries.map((entry) => (
        <div key={entry.id} className="border rounded-lg p-3 space-y-2">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              {isStructuredActionEntry(entry) ? <StructuredEntrySummary entry={entry} /> : null}
            </div>
            {renderEntryActions ? <div className="shrink-0">{renderEntryActions(entry)}</div> : null}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
            <div>
              <label className="block text-[11px] text-gray-600 mb-1">Date</label>
              <input
                type="date"
                className="w-full border rounded px-2 py-1.5 text-sm"
                value={entry.date}
                onChange={(e) => updateEntry(entry.id, { date: e.target.value })}
                disabled={!canWrite}
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-600 mb-1">Title</label>
              <div className="relative">
                <input
                  type="text"
                  className="w-full border rounded px-2 py-1.5 text-sm"
                  value={entry.title}
                  onChange={(e) => {
                    updateEntry(entry.id, { title: e.target.value });
                    if (enableTypeahead) {
                      setOpenSuggestionFor(entry.id);
                      setActiveSuggestionIndex(0);
                    }
                  }}
                  onFocus={() => {
                    if (enableTypeahead) {
                      setOpenSuggestionFor(entry.id);
                      setActiveSuggestionIndex(0);
                    }
                  }}
                  onBlur={() => {
                    if (!enableTypeahead) return;
                    window.setTimeout(() => {
                      setOpenSuggestionFor((cur) => (cur === entry.id ? null : cur));
                      setActiveSuggestionIndex(0);
                    }, 120);
                  }}
                  onKeyDown={(e) => {
                    if (!enableTypeahead || openSuggestionFor !== entry.id) return;
                    const matches = getSuggestionsForQuery(entry.title);
                    if (matches.length === 0) return;
                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      setActiveSuggestionIndex((idx) => clampActiveIndex(idx + 1, matches.length));
                    } else if (e.key === "ArrowUp") {
                      e.preventDefault();
                      setActiveSuggestionIndex((idx) => clampActiveIndex(idx - 1, matches.length));
                    } else if (e.key === "Enter") {
                      e.preventDefault();
                      const idx = clampActiveIndex(activeSuggestionIndex, matches.length);
                      updateEntry(entry.id, { title: matches[idx] });
                      setOpenSuggestionFor(null);
                      setActiveSuggestionIndex(0);
                    } else if (e.key === "Escape") {
                      setOpenSuggestionFor(null);
                      setActiveSuggestionIndex(0);
                    }
                  }}
                  disabled={!canWrite}
                  placeholder="Item title"
                />
                {enableTypeahead && openSuggestionFor === entry.id ? (
                  (() => {
                    const matches = getSuggestionsForQuery(entry.title);
                    if (matches.length === 0) return null;
                    return (
                      <div className="absolute z-20 mt-1 w-full bg-white border rounded-md shadow-sm max-h-52 overflow-auto">
                        {matches.map((suggestion, idx) => (
                          <button
                            key={`${entry.id}-${suggestion}`}
                            type="button"
                            className={`w-full text-left px-2 py-1.5 text-sm border-b last:border-b-0 ${
                              idx === activeSuggestionIndex ? "bg-gray-100" : "hover:bg-gray-50"
                            }`}
                            onMouseDown={(e) => e.preventDefault()}
                            onMouseEnter={() => setActiveSuggestionIndex(idx)}
                            onClick={() => {
                              updateEntry(entry.id, { title: suggestion });
                              setOpenSuggestionFor(null);
                              setActiveSuggestionIndex(0);
                            }}
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    );
                  })()
                ) : null}
              </div>
            </div>
            <div>
              <label className="block text-[11px] text-gray-600 mb-1">Status</label>
              <input
                type="text"
                className="w-full border rounded px-2 py-1.5 text-sm"
                value={entry.status}
                onChange={(e) => updateEntry(entry.id, { status: e.target.value })}
                disabled={!canWrite}
                placeholder="Active / Pending / Complete"
              />
            </div>
            <div className="flex items-end justify-end">
              <button
                type="button"
                className="px-2 py-1.5 rounded border text-xs hover:bg-red-50 text-red-700 disabled:opacity-50"
                onClick={() => removeEntry(entry.id)}
                disabled={!canWrite}
              >
                Remove Row
              </button>
            </div>
          </div>

          {isStructuredActionEntry(entry) ? (
            <details className="rounded-md border border-ink-200 bg-gray-50">
              <summary className="cursor-pointer px-3 py-2 text-[11px] font-medium text-gray-700">
                Edit structured order details
              </summary>
              <div className="px-3 pb-3">
                <label className="block text-[11px] text-gray-600 mb-1">Notes</label>
                <textarea
                  className="w-full border rounded px-2 py-2 text-sm"
                  rows={4}
                  value={entry.notes}
                  onChange={(e) => updateEntry(entry.id, { notes: e.target.value })}
                  disabled={!canWrite}
                  placeholder="Clinical details"
                />
              </div>
            </details>
          ) : (
            <div>
              <label className="block text-[11px] text-gray-600 mb-1">Notes</label>
              <textarea
                className="w-full border rounded px-2 py-2 text-sm"
                rows={3}
                value={entry.notes}
                onChange={(e) => updateEntry(entry.id, { notes: e.target.value })}
                disabled={!canWrite}
                placeholder="Clinical details"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="block text-[11px] text-gray-600">Attachments</label>
            <div className="flex items-center gap-2">
              <input
                type="file"
                className="text-xs"
                disabled={!canWrite || uploadingFor === entry.id}
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  try {
                    await addAttachment(entry.id, file);
                  } finally {
                    e.currentTarget.value = "";
                  }
                }}
              />
              {uploadingFor === entry.id ? <span className="text-xs text-gray-500">Uploading...</span> : null}
            </div>

            {(entry.attachments || []).length === 0 ? (
              <div className="text-xs text-gray-500">No attachments.</div>
            ) : (
              <div className="space-y-1">
                {entry.attachments.map((att) => (
                  <div key={att.id} className="flex items-center justify-between text-xs border rounded px-2 py-1.5">
                    <a className="text-blue-700 hover:underline truncate mr-3" href={att.url} target="_blank" rel="noreferrer">
                      {att.name}
                    </a>
                    <button
                      type="button"
                      className="px-2 py-1 rounded border hover:bg-red-50 text-red-700 disabled:opacity-50"
                      onClick={() => removeAttachment(entry.id, att)}
                      disabled={!canWrite || uploadingFor === entry.id}
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ))}

    </div>
  );
}

export const PatientChartPage: React.FC = () => {
  const { normalizedRole, user, currentUserData } = useAuth() as any;
  const [searchParams] = useSearchParams();

  const isClinicianRole = normalizedRole === "clinician";
  const isAdminRole = false;
  const canUse = isClinicianRole;
  const canWriteClinical = isClinicianRole;
  const canUseBilling = isAdminRole;
  const canUsePrescribing = canNursePrescribe(currentUserData?.nurseType);

  const { patientId } = useParams<{ patientId: string }>();

  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<ChartTab>("overview");
  const [chartData, setChartData] = useState<ChartData>(EMPTY_CHART_DATA);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);
  const [patientSummary, setPatientSummary] = useState("");
  const [patientSummaryUpdatedAt, setPatientSummaryUpdatedAt] = useState<Date | null>(null);
  const [patientSummarySaving, setPatientSummarySaving] = useState(false);
  const [patientSummaryMsg, setPatientSummaryMsg] = useState<string | null>(null);
  const [patientSummaryErr, setPatientSummaryErr] = useState<string | null>(null);
  const [exportMsg, setExportMsg] = useState<string | null>(null);
  const [deidentifiedExportsOnly, setDeidentifiedExportsOnly] = useState(true);

  const [invoices, setInvoices] = useState<InvoiceRow[]>([]);
  const [billingLoading, setBillingLoading] = useState(false);
  const [billingError, setBillingError] = useState<string | null>(null);
  const [billingMsg, setBillingMsg] = useState<string | null>(null);
  const [invoiceDesc, setInvoiceDesc] = useState("");
  const [invoiceCents, setInvoiceCents] = useState<number>(15000);
  const [invoiceCurrency, setInvoiceCurrency] = useState<string>(() => getDefaultCurrency());
  const [invoiceBillingPathway, setInvoiceBillingPathway] = useState<BillingPathway>("out_of_pocket");
  const [invoicePrivateCoverCents, setInvoicePrivateCoverCents] = useState<number>(0);
  const [invoiceInsurerSelection, setInvoiceInsurerSelection] = useState<string>(AUSTRALIAN_PRIVATE_FUNDS[0]);
  const [invoiceInsurerCustom, setInvoiceInsurerCustom] = useState("");
  const [invoicePlanName, setInvoicePlanName] = useState("");
  const [invoiceMembershipNumber, setInvoiceMembershipNumber] = useState("");
  const [invoiceClaimReference, setInvoiceClaimReference] = useState("");
  const [invoiceDueDate, setInvoiceDueDate] = useState(todayDateInput());
  const [invoiceApptId, setInvoiceApptId] = useState("");

  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);
  const [timelineLoading, setTimelineLoading] = useState(false);
  const [timelineError, setTimelineError] = useState<string | null>(null);

  const effectiveInvoiceInsurerName = useMemo(
    () => (invoiceInsurerSelection === INSURER_OTHER ? invoiceInsurerCustom.trim() : invoiceInsurerSelection),
    [invoiceInsurerSelection, invoiceInsurerCustom]
  );

  const patientPath = useMemo(() => (patientId ? `patients/${patientId}` : "patients/<missing>"), [patientId]);

  useEffect(() => {
    const requestedTab = String(searchParams.get("tab") || "").trim().toLowerCase();
    if (!requestedTab) return;
    const allowedTabs = isClinicianRole ? CLINICIAN_CHART_TABS : ADMIN_CHART_TABS;
    const nextTab = allowedTabs.find((candidate) => candidate === requestedTab);
    if (nextTab && nextTab !== tab) {
      setTab(nextTab);
    }
  }, [searchParams, isClinicianRole, tab]);

  useEffect(() => {
    if (isAdminRole && tab !== "overview" && tab !== "billing" && tab !== "timeline") {
      setTab("timeline");
    }
    if (isClinicianRole && tab === "billing") {
      setTab("overview");
    }
  }, [isAdminRole, isClinicianRole, tab]);

  useEffect(() => {
    if (!canUse) {
      setLoading(false);
      return;
    }

    if (!patientId) {
      setError("Missing patient ID.");
      setLoading(false);
      return;
    }

    const load = async () => {
      setLoading(true);
      setError(null);
      setSaveMsg(null);
      setPatientSummaryMsg(null);
      setPatientSummaryErr(null);
      try {
        const snap = await getDoc(doc(db, "patients", patientId));
        if (!snap.exists()) {
          setError("Patient not found.");
          setPatient(null);
          return;
        }

        const patientData = snap.data() as any;
        setPatient({ id: snap.id, ...(patientData as Omit<Patient, "id">) });

        if (user?.uid) {
          void logSensitiveAccess({
            actorUid: user.uid,
            role: normalizedRole,
            action: "read_patient_chart",
            resourceType: "patient_chart",
            resourceId: patientId,
            patientId,
            practiceId: currentUserData?.practiceId || null,
          });
        }

        // Patient-facing summary (plain-language)
        try {
          const summarySnap = await getDoc(doc(db, "patientSummaries", patientId));
          if (summarySnap.exists()) {
            const data = summarySnap.data() as any;
            setPatientSummary(String(data?.summary || ""));
            const dt = data?.updatedAt?.toDate ? data.updatedAt.toDate() : null;
            setPatientSummaryUpdatedAt(dt);
          } else {
            setPatientSummary("");
            setPatientSummaryUpdatedAt(null);
          }
        } catch (e) {
          console.error("Failed to load patient summary:", e);
        }

        try {
          const configSnap = await getDoc(doc(db, "config", "app"));
          if (configSnap.exists()) {
            const configData = configSnap.data() as any;
            setDeidentifiedExportsOnly(configData?.retentionPolicy?.deidentifiedExportsOnly !== false);
          } else {
            setDeidentifiedExportsOnly(true);
          }
        } catch (e) {
          console.error("Failed to load export policy:", e);
          setDeidentifiedExportsOnly(true);
        }

        // Clinicians load clinical chart from dedicated protected collection.
        if (isClinicianRole) {
          const clinicalRef = doc(db, "patientClinicalRecords", patientId);
          const clinicalSnap = await getDoc(clinicalRef);
          if (clinicalSnap.exists()) {
            setChartData(parseChartData((clinicalSnap.data() as any)?.chartData));
          } else {
            const fallback = parseChartData(patientData?.chartData);
            setChartData(fallback);
            // one-time migration from legacy patients/{id}.chartData
            const hasFallbackData =
              JSON.stringify(fallback) !== JSON.stringify(EMPTY_CHART_DATA);
            if (hasFallbackData) {
              await setDoc(
                clinicalRef,
                {
                  patientId,
                  practiceId: currentUserData?.practiceId || null,
                  chartData: fallback,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp(),
                },
                { merge: true }
              );
              // Remove legacy chartData from patient doc to prevent patient access.
              await updateDoc(doc(db, "patients", patientId), {
                chartData: deleteField(),
                updatedAt: serverTimestamp(),
              });
            }
          }
        } else {
          setChartData(EMPTY_CHART_DATA);
        }
      } catch (e: any) {
        console.error("Failed to load patient chart:", e);
        setError(e?.message ?? "Failed to load patient chart.");
        setPatient(null);
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [patientId, canUse, isClinicianRole, currentUserData?.practiceId, normalizedRole, user?.uid]);

  useEffect(() => {
    if (!canUseBilling || !patientId) {
      setInvoices([]);
      return;
    }

    const loadBilling = async () => {
      setBillingLoading(true);
      setBillingError(null);
      try {
        const q = query(
          collection(db, "invoices"),
          where("patientId", "==", patientId),
          orderBy("createdAt", "desc"),
          limit(200)
        );
        const snap = await getDocs(q);
        const rows: InvoiceRow[] = snap.docs.map((d) => {
          const raw = d.data() as any;
          return {
            id: d.id,
            patientId: String(raw?.patientId || ""),
            appointmentId: raw?.appointmentId ?? null,
            description: String(raw?.description || ""),
            currency: normalizeCurrency(String(raw?.currency || getDefaultCurrency())),
            totalCents: Number(raw?.totalCents || 0),
            status: (raw?.status as InvoiceStatus) || "draft",
            issuedDate: String(raw?.issuedDate || todayDateInput()),
            dueDate: String(raw?.dueDate || todayDateInput()),
            paidDate: raw?.paidDate ?? null,
            billingPathway: (raw?.billingPathway as BillingPathway) || "out_of_pocket",
            coverage: raw?.coverage ?? undefined,
            privateCover: raw?.privateCover ?? undefined,
            createdAt: raw?.createdAt,
            updatedAt: raw?.updatedAt,
          };
        });
        setInvoices(rows);
      } catch (e: any) {
        console.error("Failed to load invoices:", e);
        setBillingError(e?.message || "Failed to load invoices.");
      } finally {
        setBillingLoading(false);
      }
    };

    void loadBilling();
  }, [canUseBilling, patientId]);

  useEffect(() => {
    if (tab !== "timeline" || !patientId) return;

    let cancelled = false;
    const loadTimeline = async () => {
      setTimelineLoading(true);
      setTimelineError(null);
      try {
        const items: TimelineItem[] = [];

        const parseDate = (raw?: string | null): Date | null => {
          const v = String(raw || "").trim();
          if (!v) return null;
          const m1 = v.match(/^(\d{4})-([0-1]?\d)-([0-3]?\d)$/);
          if (m1) return new Date(Number(m1[1]), Number(m1[2]) - 1, Number(m1[3]));
          const m2 = v.match(/^([0-3]?\d)-([0-1]?\d)-(\d{4})$/);
          if (m2) return new Date(Number(m2[3]), Number(m2[2]) - 1, Number(m2[1]));
          return null;
        };

        // Appointments
        try {
          const apptBase = isClinicianRole
            ? query(
                collection(db, "appointments"),
                where("patientId", "==", patientId),
                where("clinicianId", "==", user?.uid || "__none__"),
                orderBy("scheduledAt", "desc"),
                limit(50)
              )
            : query(
                collection(db, "appointments"),
                where("patientId", "==", patientId),
                orderBy("scheduledAt", "desc"),
                limit(50)
              );
          const apptSnap = await getDocs(apptBase);
          apptSnap.docs.forEach((d) => {
            const a: any = d.data();
            const dt = a?.scheduledAt?.toDate ? a.scheduledAt.toDate() : null;
            if (!dt) return;
            items.push({
              id: d.id,
              kind: "appointment",
              date: dt,
              title: `Appointment (${a?.mode || "—"})`,
              subtitle: `${a?.status || "—"}${a?.clinicianName ? ` · ${a.clinicianName}` : ""}`,
              href: `/appointments/${d.id}`,
            });
          });
        } catch (e) {
          console.error("Failed to load appointments timeline:", e);
        }

        // Encounters (clinician only)
        if (isClinicianRole) {
          try {
            const myPracticeId = currentUserData?.practiceId;
            const encBase = myPracticeId
              ? query(
                  collection(db, "encounters"),
                  where("patientId", "==", patientId),
                  where("practiceId", "==", myPracticeId),
                  orderBy("createdAt", "desc"),
                  limit(50)
                )
              : query(
                  collection(db, "encounters"),
                  where("patientId", "==", patientId),
                  where("practitionerId", "==", user?.uid || "__none__"),
                  orderBy("createdAt", "desc"),
                  limit(50)
                );

            let encSnap;
            try {
              encSnap = await getDocs(encBase);
            } catch {
              encSnap = await getDocs(
                myPracticeId
                  ? query(
                      collection(db, "encounters"),
                      where("patientId", "==", patientId),
                      where("practiceId", "==", myPracticeId),
                      limit(50)
                    )
                  : query(
                      collection(db, "encounters"),
                      where("patientId", "==", patientId),
                      where("practitionerId", "==", user?.uid || "__none__"),
                      limit(50)
                    )
              );
            }

            encSnap.docs.forEach((d) => {
              const e: any = d.data();
              const dt =
                parseDate(e?.encounterDateISO) ||
                parseDate(e?.encounterDate) ||
                (e?.createdAt?.toDate ? e.createdAt.toDate() : null);
              if (!dt) return;
              items.push({
                id: d.id,
                kind: "encounter",
                date: dt,
                title: `Encounter (${e?.type || "consultation"})`,
                subtitle: e?.reason || "",
                href: `/patients/${patientId}/chart/encounters/${d.id}`,
              });
            });
          } catch (e) {
            console.error("Failed to load encounters timeline:", e);
          }
        }

        // Invoices (admin only)
        if (canUseBilling) {
          invoices.forEach((inv) => {
            const dt = parseDate(inv.issuedDate) || (inv.createdAt?.toDate ? inv.createdAt.toDate() : null);
            if (!dt) return;
            items.push({
              id: inv.id,
              kind: "invoice",
              date: dt,
              title: `Invoice (${inv.status})`,
              subtitle: `${formatMoney(inv.totalCents, inv.currency)} · ${formatToDDMMYYYY(inv.issuedDate)}`,
              href: `/billing?patientId=${patientId}`,
            });
          });
        }

        items.sort((a, b) => b.date.getTime() - a.date.getTime());

        if (!cancelled) setTimelineItems(items);
      } catch (e: any) {
        if (!cancelled) setTimelineError(e?.message || "Failed to load timeline.");
      } finally {
        if (!cancelled) setTimelineLoading(false);
      }
    };

    void loadTimeline();
    return () => {
      cancelled = true;
    };
  }, [tab, patientId, isClinicianRole, canUseBilling, user?.uid, currentUserData?.practiceId, invoices]);

  const saveChartData = async () => {
    if (!canWriteClinical || !patientId) return;
    const practiceId = currentUserData?.practiceId || "";
    if (!practiceId) {
      setSaveMsg("Missing practice ID. Cannot save.");
      return;
    }
    setSaving(true);
    setSaveMsg(null);
    try {
      const clinicalRef = doc(db, "patientClinicalRecords", patientId);
      await runTransaction(db, async (tx) => {
        const snap = await tx.get(clinicalRef);
        const previousChartData = snap.exists() ? (snap.data() as any)?.chartData ?? null : null;
        const auditRef = doc(collection(db, "patientClinicalRecords", patientId, "revisions"));

        tx.set(
          clinicalRef,
          {
            patientId,
            practiceId,
            chartData,
            updatedAt: serverTimestamp(),
            updatedByUid: user?.uid || null,
          },
          { merge: true }
        );
        tx.set(auditRef, {
          patientId,
          practiceId,
          editorId: user?.uid || null,
          editedAt: serverTimestamp(),
          previousChartData,
          nextChartData: chartData,
        });
      });
      setSaveMsg("Saved.");
    } catch (e: any) {
      console.error("Failed to save chart data:", e);
      setSaveMsg(e?.message || "Failed to save.");
    } finally {
      setSaving(false);
    }
  };

  const savePatientSummary = async () => {
    if (!isClinicianRole || !patientId) return;
    const practiceId = currentUserData?.practiceId || "";
    if (!practiceId) {
      setPatientSummaryErr("Missing practice ID. Cannot save summary.");
      return;
    }
    setPatientSummarySaving(true);
    setPatientSummaryMsg(null);
    setPatientSummaryErr(null);
    try {
      const summaryRef = doc(db, "patientSummaries", patientId);
      await runTransaction(db, async (tx) => {
        const snap = await tx.get(summaryRef);
        const previousSummary = snap.exists() ? String((snap.data() as any)?.summary || "") : "";
        const auditRef = doc(collection(db, "patientSummaries", patientId, "revisions"));

        tx.set(
          summaryRef,
          {
            patientId,
            practiceId,
            summary: patientSummary.trim(),
            updatedAt: serverTimestamp(),
            updatedByUid: user?.uid || null,
          },
          { merge: true }
        );
        tx.set(auditRef, {
          patientId,
          practiceId,
          editorId: user?.uid || null,
          editedAt: serverTimestamp(),
          previousSummary,
          nextSummary: patientSummary.trim(),
        });
      });
      setPatientSummaryMsg("Summary saved.");
      setPatientSummaryUpdatedAt(new Date());
    } catch (e: any) {
      console.error("Failed to save patient summary:", e);
      setPatientSummaryErr(e?.message || "Failed to save summary.");
    } finally {
      setPatientSummarySaving(false);
    }
  };

  const createInvoice = async () => {
    if (!canUseBilling || !patientId) return;
    const description = invoiceDesc.trim();
    if (!description) {
      setBillingError("Invoice description is required.");
      return;
    }
    if (!Number.isFinite(invoiceCents) || invoiceCents <= 0) {
      setBillingError("Amount must be greater than 0.");
      return;
    }
    if (invoiceBillingPathway !== "out_of_pocket" && !effectiveInvoiceInsurerName) {
      setBillingError("Insurer name is required for private health cover billing.");
      return;
    }
    if (invoiceBillingPathway !== "out_of_pocket" && !invoiceMembershipNumber.trim()) {
      setBillingError("Membership number is required for private health cover billing.");
      return;
    }

    const total = Math.round(invoiceCents);
    let outOfPocketCents = total;
    let privateCoverCents = 0;
    if (invoiceBillingPathway === "private_cover") {
      outOfPocketCents = 0;
      privateCoverCents = total;
    } else if (invoiceBillingPathway === "split") {
      privateCoverCents = Math.max(0, Math.min(total, Math.round(invoicePrivateCoverCents || 0)));
      outOfPocketCents = total - privateCoverCents;
      if (privateCoverCents <= 0 || outOfPocketCents <= 0) {
        setBillingError("For split billing, both patient and private-cover portions must be greater than 0.");
        return;
      }
    }
    setBillingError(null);
    setBillingMsg(null);
    try {
      await addDoc(collection(db, "invoices"), {
        patientId,
        appointmentId: invoiceApptId.trim() || null,
        description,
        currency: normalizeCurrency(invoiceCurrency),
        totalCents: total,
        billingPathway: invoiceBillingPathway,
        coverage: {
          outOfPocketCents,
          privateCoverCents,
        },
        privateCover:
          invoiceBillingPathway === "out_of_pocket"
            ? null
            : {
                insurerName: effectiveInvoiceInsurerName,
                planName: invoicePlanName.trim() || "",
                membershipNumber: invoiceMembershipNumber.trim(),
                claimReference: invoiceClaimReference.trim() || "",
                claimStatus: "not_submitted",
              },
        status: "issued",
        issuedDate: todayDateInput(),
        dueDate: invoiceDueDate || todayDateInput(),
        paidDate: null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      setBillingMsg("Invoice created.");
      setInvoiceDesc("");
      setInvoiceApptId("");
      setInvoiceBillingPathway("out_of_pocket");
      setInvoicePrivateCoverCents(0);
      setInvoiceInsurerSelection(AUSTRALIAN_PRIVATE_FUNDS[0]);
      setInvoiceInsurerCustom("");
      setInvoicePlanName("");
      setInvoiceMembershipNumber("");
      setInvoiceClaimReference("");

      const q = query(
        collection(db, "invoices"),
        where("patientId", "==", patientId),
        orderBy("createdAt", "desc"),
        limit(200)
      );
      const snap = await getDocs(q);
      setInvoices(
        snap.docs.map((d) => {
          const raw = d.data() as any;
          return {
            id: d.id,
            patientId: String(raw?.patientId || ""),
            appointmentId: raw?.appointmentId ?? null,
            description: String(raw?.description || ""),
            currency: normalizeCurrency(String(raw?.currency || getDefaultCurrency())),
            totalCents: Number(raw?.totalCents || 0),
            status: (raw?.status as InvoiceStatus) || "draft",
            issuedDate: String(raw?.issuedDate || todayDateInput()),
            dueDate: String(raw?.dueDate || todayDateInput()),
            paidDate: raw?.paidDate ?? null,
            billingPathway: (raw?.billingPathway as BillingPathway) || "out_of_pocket",
            coverage: raw?.coverage ?? undefined,
            privateCover: raw?.privateCover ?? undefined,
            createdAt: raw?.createdAt,
            updatedAt: raw?.updatedAt,
          } as InvoiceRow;
        })
      );
    } catch (e: any) {
      console.error("Failed to create invoice:", e);
      setBillingError(e?.message || "Failed to create invoice.");
    }
  };

  const updateInvoiceStatus = async (row: InvoiceRow, status: InvoiceStatus) => {
    if (!canUseBilling) return;
    setBillingError(null);
    setBillingMsg(null);
    try {
      await updateDoc(doc(db, "invoices", row.id), {
        status,
        paidDate: status === "paid" ? todayDateInput() : null,
        updatedAt: serverTimestamp(),
      });
      setInvoices((prev) =>
        prev.map((x) =>
          x.id === row.id ? { ...x, status, paidDate: status === "paid" ? todayDateInput() : null } : x
        )
      );
      setBillingMsg(`Invoice marked ${status}.`);
    } catch (e: any) {
      setBillingError(e?.message || "Failed to update invoice status.");
    }
  };

  const updateInvoiceClaimStatus = async (row: InvoiceRow, claimStatus: ClaimStatus) => {
    if (!canUseBilling) return;
    if (!(row.billingPathway === "private_cover" || row.billingPathway === "split")) return;
    setBillingError(null);
    setBillingMsg(null);
    try {
      const patch: any = {
        "privateCover.claimStatus": claimStatus,
        updatedAt: serverTimestamp(),
      };
      if (claimStatus === "paid" && (row.coverage?.outOfPocketCents || 0) <= 0) {
        patch.status = "paid";
        patch.paidDate = todayDateInput();
      }
      await updateDoc(doc(db, "invoices", row.id), patch);
      setInvoices((prev) =>
        prev.map((x) =>
          x.id === row.id
            ? {
                ...x,
                privateCover: { ...(x.privateCover || {}), claimStatus },
                status:
                  claimStatus === "paid" && (x.coverage?.outOfPocketCents || 0) <= 0
                    ? "paid"
                    : x.status,
                paidDate:
                  claimStatus === "paid" && (x.coverage?.outOfPocketCents || 0) <= 0
                    ? todayDateInput()
                    : x.paidDate,
              }
            : x
        )
      );
      setBillingMsg(`Claim marked ${claimStatus}.`);
    } catch (e: any) {
      setBillingError(e?.message || "Failed to update claim status.");
    }
  };

  const uploadAttachment = async (sectionKey: string, entryId: string, file: File): Promise<AttachmentMeta> => {
    if (!patientId) throw new Error("Missing patient ID.");
    if (file.size > MAX_FILE_BYTES) {
      throw new Error(`File too large. Max ${Math.floor(MAX_FILE_BYTES / (1024 * 1024))}MB.`);
    }
    const safeName = sanitizeFileName(file.name || "attachment");
    const path = `patient-reports/${patientId}/${sectionKey}/${entryId}/${Date.now()}-${safeName}`;
    const ref = storageRef(storage, path);
    await uploadBytes(ref, file);
    const url = await getDownloadURL(ref);
    return {
      id: makeId("att"),
      name: safeName,
      contentType: file.type || "application/octet-stream",
      sizeBytes: file.size,
      path,
      url,
      uploadedAt: nowIso(),
    };
  };

  const removeAttachmentFile = async (path: string) => {
    await deleteObject(storageRef(storage, path)).catch(() => {});
  };

  const downloadExportBundle = async (
    bundle: Record<string, unknown>,
    fileName: string,
    successMessage: string,
    resourceType: string
  ) => {
    const blob = new Blob([JSON.stringify(bundle, null, 2)], {
      type: "application/fhir+json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    if (user?.uid && patient?.id) {
      void logSensitiveAccess({
        actorUid: user.uid,
        role: normalizedRole,
        action: "export_patient_chart",
        resourceType,
        resourceId: patient.id,
        patientId: patient.id,
        practiceId: currentUserData?.practiceId || null,
      });
    }
    setExportMsg(successMessage);
  };

  const exportChartBundle = () => {
    if (!patient) return;
    const bundle = buildPatientChartExportBundle({
      patient,
      chartData,
      patientSummary,
      invoices,
    });
    void downloadExportBundle(
      bundle,
      `${patient.id}-chart-export.fhir.json`,
      "Downloaded standards-shaped patient chart export.",
      "patient_chart_export"
    );
  };

  const exportDeidentifiedChartBundle = () => {
    if (!patient) return;
    const bundle = buildDeidentifiedPatientChartExportBundle({
      patient,
      chartData,
      patientSummary,
      invoices,
    });
    void downloadExportBundle(
      bundle,
      `${patient.id}-chart-export.deidentified.fhir.json`,
      "Downloaded de-identified patient chart export.",
      "patient_chart_export_deidentified"
    );
  };

  if (!canUse) {
    return (
      <MainLayout>
        <div className="p-4 text-sm text-red-600">Access denied.</div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      {loading ? (
        <div className="p-4">Loading chart...</div>
      ) : error ? (
        <div className="p-4 text-red-600">{error}</div>
      ) : !patient ? (
        <div className="p-4">Patient not found.</div>
      ) : (
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h1 className="text-xl font-semibold">Patient chart</h1>
              <div className="text-xs text-gray-500 mt-1">
                Source: <span className="font-mono">{patientPath}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isClinicianRole ? (
                <>
                  {!deidentifiedExportsOnly ? (
                    <button className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50" onClick={exportChartBundle}>
                      Export FHIR JSON
                    </button>
                  ) : null}
                  <button className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50" onClick={exportDeidentifiedChartBundle}>
                    Export De-identified JSON
                  </button>
                </>
              ) : null}
              <Link to={`/patients/${patient.id}`} className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50">
                Details
              </Link>
            </div>
          </div>

          {exportMsg ? <div className="text-sm text-emerald-600">{exportMsg}</div> : null}
          {isClinicianRole && deidentifiedExportsOnly ? (
            <div className="text-xs text-gray-500">
              Export policy currently restricts chart downloads to de-identified datasets.
            </div>
          ) : null}

          <PatientChartHeader patient={patient} />

          <div className="flex flex-wrap gap-2">
            <TabButton active={tab === "overview"} onClick={() => setTab("overview")}>
              Overview
            </TabButton>
            <TabButton active={tab === "timeline"} onClick={() => setTab("timeline")}>
              Timeline
            </TabButton>

            {isClinicianRole ? (
              <>
                <TabButton active={tab === "allergies_alerts"} onClick={() => setTab("allergies_alerts")}>
                  Allergies & Alerts
                </TabButton>
                <TabButton active={tab === "encounters"} onClick={() => setTab("encounters")}>
                  Encounters
                </TabButton>
                {canUsePrescribing ? (
                  <TabButton active={tab === "medications"} onClick={() => setTab("medications")}>
                    Medications
                  </TabButton>
                ) : null}
                <TabButton active={tab === "care_plans"} onClick={() => setTab("care_plans")}>Care Plans</TabButton>
                <TabButton active={tab === "risk"} onClick={() => setTab("risk")}>Home-Care Assessments</TabButton>
                <TabButton active={tab === "documents"} onClick={() => setTab("documents")}>Documents</TabButton>
                <TabButton active={tab === "history"} onClick={() => setTab("history")}>History</TabButton>
              </>
            ) : null}

            {canUseBilling ? (
              <TabButton active={tab === "billing"} onClick={() => setTab("billing")}>
                Billing
              </TabButton>
            ) : null}
          </div>

          {tab === "overview" ? (
            isClinicianRole ? (
              <div className="space-y-4">
                <div className="border rounded-xl p-4 bg-white space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="text-sm font-semibold">Patient-facing summary</div>
                      <div className="text-xs text-gray-600">
                        This is the only clinical summary visible to the patient.
                      </div>
                    </div>
                    <div className="text-right">
                      <button className="btn-primary text-xs" onClick={() => void savePatientSummary()} disabled={patientSummarySaving}>
                        {patientSummarySaving ? "Saving…" : "Save summary"}
                      </button>
                      {patientSummaryUpdatedAt ? (
                        <div className="text-[11px] text-gray-500 mt-1">
                          Updated: {patientSummaryUpdatedAt.toLocaleString()}
                        </div>
                      ) : null}
                    </div>
                  </div>
                  <textarea
                    className="input min-h-[120px]"
                    value={patientSummary}
                    onChange={(e) => setPatientSummary(e.target.value)}
                    placeholder="Plain-language summary for the patient."
                  />
                  {patientSummaryMsg ? <div className="text-xs text-emerald-600">{patientSummaryMsg}</div> : null}
                  {patientSummaryErr ? <div className="text-xs text-red-600">{patientSummaryErr}</div> : null}
                </div>

                <div className="border rounded-xl p-4 bg-white space-y-3">
                  <Field label="Clinical Summary" rows={4} value={chartData.overview.summary} onChange={(v) => setChartData((p) => ({ ...p, overview: { ...p.overview, summary: v } }))} />
                  <Field label="Problem List" rows={4} value={chartData.overview.problems} onChange={(v) => setChartData((p) => ({ ...p, overview: { ...p.overview, problems: v } }))} />
                  <Field label="Past Medical History" rows={4} value={chartData.overview.pastMedicalHistory} onChange={(v) => setChartData((p) => ({ ...p, overview: { ...p.overview, pastMedicalHistory: v } }))} />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Field label="Family History" rows={4} value={chartData.overview.familyHistory} onChange={(v) => setChartData((p) => ({ ...p, overview: { ...p.overview, familyHistory: v } }))} />
                    <Field label="Social History" rows={4} value={chartData.overview.socialHistory} onChange={(v) => setChartData((p) => ({ ...p, overview: { ...p.overview, socialHistory: v } }))} />
                  </div>
                  <Field label="Care Plan" rows={3} value={chartData.overview.carePlan} onChange={(v) => setChartData((p) => ({ ...p, overview: { ...p.overview, carePlan: v } }))} />
                </div>
              </div>
            ) : (
              <div className="border rounded-xl p-4 bg-white space-y-2">
                <div className="text-sm font-semibold">Patient-facing summary</div>
                {patientSummary ? (
                  <div className="text-sm text-gray-700 whitespace-pre-wrap">{patientSummary}</div>
                ) : (
                  <div className="text-sm text-gray-600">No patient-facing summary yet.</div>
                )}
                <div className="text-xs text-gray-600">
                  Clinical chart content is restricted to clinician users.
                </div>
              </div>
            )
          ) : null}

          {tab === "timeline" ? (
            <div className="border rounded-xl p-4 bg-white space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold">Patient timeline</div>
                {!isClinicianRole ? (
                  <div className="text-xs text-gray-500">Clinical encounters hidden for non‑clinicians.</div>
                ) : null}
              </div>

              {timelineLoading ? (
                <div className="text-sm text-gray-600">Loading timeline…</div>
              ) : timelineError ? (
                <div className="text-sm text-red-600">{timelineError}</div>
              ) : timelineItems.length === 0 ? (
                <div className="text-sm text-gray-600">No timeline items yet.</div>
              ) : (
                <div className="space-y-2">
                  {timelineItems.map((item) => {
                    const iso = item.date.toISOString().slice(0, 10);
                    const dateLabel = formatToDDMMYYYY(iso);
                    const timeLabel = item.date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
                    return (
                      <div key={`${item.kind}-${item.id}`} className="border rounded-lg p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="text-xs text-gray-500">
                              {dateLabel} · {timeLabel}
                            </div>
                            <div className="text-sm font-medium">{item.title}</div>
                            {item.subtitle ? <div className="text-xs text-gray-600 mt-1">{item.subtitle}</div> : null}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="chip">{item.kind}</span>
                            {item.href ? (
                              <Link to={item.href} className="text-xs text-blue-600 hover:underline">
                                Open
                              </Link>
                            ) : null}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : null}

          {isClinicianRole && tab === "encounters" ? <PatientEncountersTab patientId={patient.id} canWrite={canWriteClinical} /> : null}

          {isClinicianRole && tab === "care_plans" && patientId && currentUserData?.practiceId && user?.uid ? (
            <CarePlansTab
              patientId={patientId}
              practiceId={currentUserData.practiceId}
              clinicianUid={user.uid}
              clinicianDisplayName={currentUserData?.displayName || currentUserData?.email || user?.email || null}
              chartBasePath={`/patients/${patientId}/chart`}
            />
          ) : null}

          {isClinicianRole && tab === "allergies_alerts" ? (
            <div className="space-y-3">
              <EntryEditor title="Allergies" sectionKey="allergies" entries={chartData.allergiesAlerts.allergies} onChange={(entries) => setChartData((p) => ({ ...p, allergiesAlerts: { ...p.allergiesAlerts, allergies: entries } }))} canWrite={canWriteClinical} onUpload={uploadAttachment} onDeleteAttachment={removeAttachmentFile} />
              <EntryEditor title="Alerts" sectionKey="alerts" entries={chartData.allergiesAlerts.alerts} onChange={(entries) => setChartData((p) => ({ ...p, allergiesAlerts: { ...p.allergiesAlerts, alerts: entries } }))} canWrite={canWriteClinical} onUpload={uploadAttachment} onDeleteAttachment={removeAttachmentFile} />
            </div>
          ) : null}

          {isClinicianRole && tab === "risk" && patientId && currentUserData?.practiceId && user?.uid ? (
            <RiskAssessmentsTab
              patientId={patientId}
              practiceId={currentUserData.practiceId}
              clinicianUid={user.uid}
              clinicianDisplayName={currentUserData?.displayName || currentUserData?.email || user?.email || null}
              chartBasePath={`/patients/${patientId}/chart`}
            />
          ) : null}
          {isClinicianRole && tab === "medications" && patientId && currentUserData?.practiceId && user?.uid && canUsePrescribing ? (
            <NursePrescribingTab
              patientId={patientId}
              practiceId={currentUserData.practiceId}
              prescriberUid={user.uid}
              prescriberLabel={currentUserData?.displayName || currentUserData?.email || user?.email || "Nurse Practitioner"}
            />
          ) : null}
          {isClinicianRole && tab === "documents" ? <EntryEditor title="Documents" sectionKey="documents" entries={chartData.documents.items} onChange={(entries) => setChartData((p) => ({ ...p, documents: { items: entries } }))} canWrite={canWriteClinical} onUpload={uploadAttachment} onDeleteAttachment={removeAttachmentFile} /> : null}
          {isClinicianRole && tab === "history" ? <EntryEditor title="History" sectionKey="history" entries={chartData.history.items} onChange={(entries) => setChartData((p) => ({ ...p, history: { items: entries } }))} canWrite={canWriteClinical} onUpload={uploadAttachment} onDeleteAttachment={removeAttachmentFile} /> : null}

          {tab === "billing" && canUseBilling ? (
            <div className="space-y-3">
              <div className="border rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-sm font-semibold">Patient Billing Ledger</div>
                  <Link
                    to={`/billing?patientId=${patient.id}`}
                    className="px-3 py-1.5 rounded border text-xs hover:bg-gray-50"
                  >
                    Open Full Billing Console
                  </Link>
                </div>
                <div className="text-xs text-gray-600">
                  Quick patient-level billing actions are available here. Portfolio reporting and reconciliation are in the central Billing page.
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-2">
                    <label className="block text-xs text-gray-600 mb-1">Description</label>
                    <input
                      className="w-full border rounded px-3 py-2 text-sm"
                      value={invoiceDesc}
                      onChange={(e) => setInvoiceDesc(e.target.value)}
                      placeholder="e.g. Telehealth consult + care plan"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Amount</label>
                    <input
                      type="number"
                      min={0.01}
                      step={0.01}
                      className="w-full border rounded px-3 py-2 text-sm"
                      value={(invoiceCents / 100).toFixed(2)}
                      onChange={(e) => {
                        const n = Number(e.target.value);
                        setInvoiceCents(Number.isFinite(n) ? Math.round(n * 100) : 0);
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Currency</label>
                    <select
                      className="w-full border rounded px-3 py-2 text-sm"
                      value={invoiceCurrency}
                      onChange={(e) => setInvoiceCurrency(normalizeCurrency(e.target.value))}
                    >
                      {SUPPORTED_CURRENCIES.map((code) => (
                        <option key={code} value={code}>
                          {code}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Billing pathway</label>
                    <select
                      className="w-full border rounded px-3 py-2 text-sm"
                      value={invoiceBillingPathway}
                      onChange={(e) => setInvoiceBillingPathway(e.target.value as BillingPathway)}
                    >
                      <option value="out_of_pocket">Out-of-pocket (private patient)</option>
                      <option value="private_cover">Private health cover</option>
                      <option value="split">Split (cover + out-of-pocket)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Due date</label>
                    <input
                      type="date"
                      className="w-full border rounded px-3 py-2 text-sm"
                      value={invoiceDueDate}
                      onChange={(e) => setInvoiceDueDate(e.target.value)}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs text-gray-600 mb-1">Appointment ID (optional)</label>
                    <input
                      className="w-full border rounded px-3 py-2 text-sm"
                      value={invoiceApptId}
                      onChange={(e) => setInvoiceApptId(e.target.value)}
                      placeholder="Optional link to appointment document id"
                    />
                  </div>
                  {invoiceBillingPathway !== "out_of_pocket" ? (
                    <>
                      <div>
                        <label className="block text-xs text-gray-600 mb-1">Insurer name</label>
                        <select
                          className="w-full border rounded px-3 py-2 text-sm"
                          value={invoiceInsurerSelection}
                          onChange={(e) => setInvoiceInsurerSelection(e.target.value)}
                        >
                          {AUSTRALIAN_PRIVATE_FUNDS.map((name) => (
                            <option key={name} value={name}>
                              {name}
                            </option>
                          ))}
                          <option value={INSURER_OTHER}>Other</option>
                        </select>
                      </div>
                      {invoiceInsurerSelection === INSURER_OTHER ? (
                        <div>
                          <label className="block text-xs text-gray-600 mb-1">Custom insurer name</label>
                          <input
                            className="w-full border rounded px-3 py-2 text-sm"
                            value={invoiceInsurerCustom}
                            onChange={(e) => setInvoiceInsurerCustom(e.target.value)}
                            placeholder="Enter insurer name"
                          />
                        </div>
                      ) : null}
                      <div>
                        <label className="block text-xs text-gray-600 mb-1">Plan name (optional)</label>
                        <input
                          className="w-full border rounded px-3 py-2 text-sm"
                          value={invoicePlanName}
                          onChange={(e) => setInvoicePlanName(e.target.value)}
                          placeholder="e.g. Comprehensive"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-600 mb-1">Membership number</label>
                        <input
                          className="w-full border rounded px-3 py-2 text-sm"
                          value={invoiceMembershipNumber}
                          onChange={(e) => setInvoiceMembershipNumber(e.target.value)}
                          placeholder="Member ID"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-600 mb-1">Claim reference (optional)</label>
                        <input
                          className="w-full border rounded px-3 py-2 text-sm"
                          value={invoiceClaimReference}
                          onChange={(e) => setInvoiceClaimReference(e.target.value)}
                          placeholder="Pre-auth / claim number"
                        />
                      </div>
                      {invoiceBillingPathway === "split" ? (
                        <div>
                          <label className="block text-xs text-gray-600 mb-1">Private cover amount</label>
                          <input
                            type="number"
                            min={0.01}
                            step={0.01}
                            className="w-full border rounded px-3 py-2 text-sm"
                            value={(invoicePrivateCoverCents / 100).toFixed(2)}
                            onChange={(e) => {
                              const n = Number(e.target.value);
                              setInvoicePrivateCoverCents(Number.isFinite(n) ? Math.round(n * 100) : 0);
                            }}
                          />
                        </div>
                      ) : null}
                    </>
                  ) : null}
                </div>

                <div className="flex items-center gap-3">
                  <button type="button" className="px-4 py-2 rounded bg-[#1F9A92] text-white text-sm hover:opacity-95" onClick={() => void createInvoice()}>
                    Create Invoice
                  </button>
                  <div className="text-xs text-gray-600">Preview: {formatMoney(invoiceCents, invoiceCurrency)}</div>
                  {invoiceBillingPathway === "out_of_pocket" ? (
                    <div className="text-xs text-gray-600">Patient pays: {formatMoney(invoiceCents, invoiceCurrency)}</div>
                  ) : invoiceBillingPathway === "private_cover" ? (
                    <div className="text-xs text-gray-600">Cover pays: {formatMoney(invoiceCents, invoiceCurrency)}</div>
                  ) : (
                    <div className="text-xs text-gray-600">
                      Cover: {formatMoney(invoicePrivateCoverCents, invoiceCurrency)} | Patient:{" "}
                      {formatMoney(Math.max(0, invoiceCents - invoicePrivateCoverCents), invoiceCurrency)}
                    </div>
                  )}
                </div>
                {billingError ? <div className="text-xs text-red-600">{billingError}</div> : null}
                {billingMsg ? <div className="text-xs text-green-700">{billingMsg}</div> : null}
              </div>

              <div className="border rounded-xl p-4 bg-white">
                <div className="text-sm font-semibold mb-3">Invoices</div>
                {billingLoading ? (
                  <div className="text-sm text-gray-600">Loading invoices...</div>
                ) : invoices.length === 0 ? (
                  <div className="text-sm text-gray-600">No invoices yet for this patient.</div>
                ) : (
                  <div className="space-y-2">
                    {invoices.map((inv) => (
                      <div key={inv.id} className="border rounded p-3 text-sm">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="font-medium">{inv.description || "Invoice"}</div>
                          <div className="font-semibold">{formatMoney(inv.totalCents, inv.currency || getDefaultCurrency())}</div>
                        </div>
                        <div className="text-xs text-gray-600 mt-1">
                          Status: <span className="font-medium uppercase">{inv.status}</span>
                          <span className="ml-2">Issued: {inv.issuedDate || "-"}</span>
                          <span className="ml-2">Due: {inv.dueDate || "-"}</span>
                          {inv.paidDate ? <span className="ml-2">Paid: {inv.paidDate}</span> : null}
                        </div>
                        <div className="text-xs text-gray-600 mt-1">
                          Billing:{" "}
                          {inv.billingPathway === "private_cover"
                            ? "Private health cover"
                            : inv.billingPathway === "split"
                              ? "Split cover + out-of-pocket"
                              : "Out-of-pocket"}
                          <span className="ml-2">
                            Cover {formatMoney(inv.coverage?.privateCoverCents || 0, inv.currency || getDefaultCurrency())} | Patient{" "}
                            {formatMoney(inv.coverage?.outOfPocketCents || 0, inv.currency || getDefaultCurrency())}
                          </span>
                        </div>
                        {inv.privateCover?.insurerName || inv.privateCover?.membershipNumber ? (
                          <div className="text-xs text-gray-600 mt-1">
                            Insurer: {inv.privateCover?.insurerName || "-"}
                            {inv.privateCover?.membershipNumber ? ` | Member ${inv.privateCover.membershipNumber}` : ""}
                            {inv.privateCover?.claimReference ? ` | Claim ${inv.privateCover.claimReference}` : ""}
                            {inv.privateCover?.claimStatus ? ` | ${inv.privateCover.claimStatus}` : ""}
                          </div>
                        ) : null}
                        {inv.appointmentId ? (
                          <div className="text-xs text-gray-600 mt-1">Appointment ID: <span className="font-mono">{inv.appointmentId}</span></div>
                        ) : null}

                        <div className="mt-2 flex gap-2">
                          <button type="button" className="px-2 py-1 rounded border text-xs hover:bg-gray-50" onClick={() => void updateInvoiceStatus(inv, "issued")}>Mark Issued</button>
                          <button type="button" className="px-2 py-1 rounded border text-xs hover:bg-gray-50" onClick={() => void updateInvoiceStatus(inv, "paid")}>Mark Paid</button>
                          <button type="button" className="px-2 py-1 rounded border text-xs hover:bg-gray-50" onClick={() => void updateInvoiceStatus(inv, "void")}>Void</button>
                        </div>
                        {inv.billingPathway === "private_cover" || inv.billingPathway === "split" ? (
                          <div className="mt-2 flex gap-2 flex-wrap">
                            <button type="button" className="px-2 py-1 rounded border text-xs hover:bg-gray-50" onClick={() => void updateInvoiceClaimStatus(inv, "submitted")}>Claim Submitted</button>
                            <button type="button" className="px-2 py-1 rounded border text-xs hover:bg-gray-50" onClick={() => void updateInvoiceClaimStatus(inv, "approved")}>Claim Approved</button>
                            <button type="button" className="px-2 py-1 rounded border text-xs hover:bg-gray-50" onClick={() => void updateInvoiceClaimStatus(inv, "declined")}>Claim Declined</button>
                            <button type="button" className="px-2 py-1 rounded border text-xs hover:bg-gray-50" onClick={() => void updateInvoiceClaimStatus(inv, "paid")}>Claim Paid</button>
                          </div>
                        ) : null}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : null}

          {isClinicianRole && tab !== "encounters" && tab !== "care_plans" && tab !== "risk" ? (
            <div className="flex items-center gap-3">
              <button
                type="button"
                className="px-4 py-2 rounded-md bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-60"
                onClick={() => void saveChartData()}
                disabled={!canWriteClinical || saving}
              >
                {saving ? "Saving..." : "Save clinical data"}
              </button>
              {saveMsg ? <span className="text-xs text-gray-600">{saveMsg}</span> : null}
            </div>
          ) : null}
        </div>
      )}
    </MainLayout>
  );
};

export default PatientChartPage;
