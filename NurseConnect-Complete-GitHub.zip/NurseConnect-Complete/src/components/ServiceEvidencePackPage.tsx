import React, { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { Link, useParams } from "react-router-dom";
import { db } from "../firebaseConfig";
import { downloadEvidencePackPdf } from "../lib/billingPdf";
import { invoicePrintPath, ServiceInvoiceRecord } from "../lib/billingFacilitation";

const ServiceEvidencePackPage: React.FC = () => {
  const { invoiceId } = useParams<{ invoiceId: string }>();
  const [record, setRecord] = useState<ServiceInvoiceRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const load = async () => {
      if (!invoiceId) return;
      const snap = await getDoc(doc(db, "serviceInvoices", invoiceId));
      if (!active) return;
      setRecord(snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as ServiceInvoiceRecord) : null);
      setLoading(false);
    };
    void load();
    return () => {
      active = false;
    };
  }, [invoiceId]);

  if (loading) return <div className="p-6 text-sm text-gray-600">Loading evidence pack...</div>;
  if (!record) return <div className="p-6 text-sm text-rose-600">Evidence pack not found.</div>;

  return (
    <div className="mx-auto max-w-4xl p-6 space-y-6">
      <div className="flex items-center justify-between gap-3 print:hidden">
        <Link to="/billing" className="btn-secondary">
          Back to billing
        </Link>
        <div className="flex gap-2">
          <Link to={invoicePrintPath(record.id)} className="btn-secondary">
            Invoice
          </Link>
          <button className="btn-secondary" onClick={() => downloadEvidencePackPdf(record)}>
            Download PDF
          </button>
          <button className="btn-primary" onClick={() => window.print()}>
            Print / Save PDF
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-ink-200 bg-white p-8 shadow-soft space-y-6">
        <div>
          <h1 className="text-3xl font-semibold text-ink-900">Evidence pack</h1>
          <p className="mt-2 text-sm text-ink-600">
            Supporting documents for invoice {record.invoiceNumber}. Prepared for relay only on the nurse&apos;s instruction.
          </p>
          <p className="mt-1 text-xs text-ink-500">
            Invoice date: {record.invoiceDate || "Not recorded"} · Due date: {record.dueDate || "Not recorded"}
          </p>
        </div>

        <section className="rounded-2xl border border-ink-200 p-4">
          <h2 className="text-lg font-semibold text-ink-900">1. Booking record</h2>
          <p className="mt-2 text-sm text-ink-700">{record.evidencePack.bookingRecordSummary}</p>
          <div className="mt-2 text-xs text-ink-500">
            Client: {record.patientName} · Service date: {record.serviceDate} · Appointment link: {record.appointmentId || "Directly logged service"}
          </div>
        </section>

        <section className="rounded-2xl border border-ink-200 p-4">
          <h2 className="text-lg font-semibold text-ink-900">2. Nurse credentials snapshot</h2>
          <p className="mt-2 text-sm text-ink-700">{record.evidencePack.credentialsSummary}</p>
          <div className="mt-2 text-xs text-ink-500">
            Nurse: {record.nurseSnapshot.displayName} · ABN: {record.nurseSnapshot.abn || "Not recorded"} · AHPRA: {record.nurseSnapshot.ahpraRegistrationNumber || "Not recorded"}
          </div>
        </section>

        <section className="rounded-2xl border border-ink-200 p-4">
          <h2 className="text-lg font-semibold text-ink-900">3. Visit confirmation</h2>
          <p className="mt-2 text-sm text-ink-700">{record.evidencePack.visitConfirmationSummary}</p>
          <div className="mt-2 text-xs text-ink-500">
            Confirmation recorded at {new Date(record.visitConfirmation.confirmedAt).toLocaleString()}
          </div>
        </section>

        <section className="rounded-2xl border border-ink-200 p-4">
          <h2 className="text-lg font-semibold text-ink-900">4. Service summary</h2>
          <p className="mt-2 text-sm whitespace-pre-wrap text-ink-700">{record.evidencePack.serviceSummary}</p>
        </section>

        {record.evidencePack.documentationNoteSummary ? (
          <section className="rounded-2xl border border-ink-200 p-4">
            <h2 className="text-lg font-semibold text-ink-900">5. Nurse documentation note</h2>
            <p className="mt-2 text-sm whitespace-pre-wrap text-ink-700">{record.evidencePack.documentationNoteSummary}</p>
          </section>
        ) : null}

        <section className="rounded-2xl border border-ink-200 p-4">
          <h2 className="text-lg font-semibold text-ink-900">6. Nurse declaration</h2>
          <p className="mt-2 text-sm text-ink-700">{record.evidencePack.declarationSummary}</p>
          <div className="mt-2 text-xs text-ink-500">
            Declaration recorded at {new Date(record.declarations.declaredAt).toLocaleString()}
          </div>
        </section>

        {record.auditTrail?.length ? (
          <section className="rounded-2xl border border-ink-200 p-4">
            <h2 className="text-lg font-semibold text-ink-900">7. Relay and audit history</h2>
            <div className="mt-3 space-y-2">
              {record.auditTrail.map((entry, index) => (
                <div key={`${entry.at}-${index}`} className="rounded-xl border border-ink-100 px-3 py-2">
                  <div className="text-sm text-ink-800">{entry.note}</div>
                  <div className="text-xs text-ink-500">{new Date(entry.at).toLocaleString()}</div>
                </div>
              ))}
            </div>
          </section>
        ) : null}

        <section className="rounded-2xl border border-sky-200 bg-sky-50 p-4 text-sm text-sky-900">
          NurseConnectCare only prepares and relays this evidence pack as a delivery conduit. It does not assess funding eligibility, submit a claim, approve reimbursement, or receive payment on behalf of the nurse.
        </section>
      </div>
    </div>
  );
};

export default ServiceEvidencePackPage;
