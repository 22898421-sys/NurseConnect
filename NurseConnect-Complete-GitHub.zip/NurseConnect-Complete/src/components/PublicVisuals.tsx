import React from "react";

export function HomeCareIllustration() {
  return (
    <div className="relative overflow-hidden rounded-[32px] border border-ink-200/80 bg-[linear-gradient(135deg,#ffffff_0%,#f4fbf8_45%,#eef4f7_100%)] p-6 shadow-soft">
      <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand-200/40 blur-3xl" />
      <div className="absolute -left-10 bottom-0 h-32 w-32 rounded-full bg-sand-200/70 blur-2xl" />
      <svg viewBox="0 0 420 260" className="relative z-10 w-full" role="img" aria-label="Illustration of a nurse supporting care at home">
        <rect x="36" y="54" width="208" height="148" rx="18" fill="#FFFFFF" stroke="#D6DEE2" />
        <rect x="54" y="72" width="78" height="52" rx="12" fill="#F2F5F7" />
        <rect x="146" y="72" width="78" height="18" rx="9" fill="#9BE6D6" />
        <rect x="146" y="98" width="60" height="12" rx="6" fill="#D6DEE2" />
        <rect x="54" y="138" width="170" height="12" rx="6" fill="#D6DEE2" />
        <rect x="54" y="158" width="122" height="12" rx="6" fill="#D6DEE2" />
        <rect x="266" y="88" width="120" height="116" rx="22" fill="#0E2A3B" />
        <rect x="284" y="104" width="84" height="14" rx="7" fill="#9BE6D6" opacity="0.95" />
        <rect x="284" y="128" width="64" height="10" rx="5" fill="#FFFFFF" opacity="0.85" />
        <rect x="284" y="146" width="78" height="10" rx="5" fill="#FFFFFF" opacity="0.55" />
        <rect x="286" y="40" width="78" height="28" rx="14" fill="#FFFFFF" opacity="0.88" />
        <rect x="300" y="49" width="50" height="10" rx="5" fill="#1F9A92" opacity="0.9" />
        <rect x="70" y="204" width="76" height="24" rx="12" fill="#FFFFFF" stroke="#D6DEE2" />
        <rect x="84" y="211" width="48" height="10" rx="5" fill="#9BE6D6" />
      </svg>
    </div>
  );
}

export function NurseWorkspaceIllustration() {
  return (
    <div className="relative overflow-hidden rounded-[32px] border border-white/10 bg-[linear-gradient(135deg,rgba(255,255,255,0.12)_0%,rgba(255,255,255,0.04)_100%)] p-6 backdrop-blur-sm">
      <div className="absolute -right-8 top-0 h-28 w-28 rounded-full bg-brand-200/20 blur-2xl" />
      <svg viewBox="0 0 420 260" className="relative z-10 w-full" role="img" aria-label="Illustration of a connected nurse workspace">
        <rect x="28" y="38" width="246" height="164" rx="22" fill="#FFFFFF" opacity="0.96" />
        <rect x="48" y="58" width="86" height="16" rx="8" fill="#9BE6D6" />
        <rect x="48" y="86" width="206" height="12" rx="6" fill="#D6DEE2" />
        <rect x="48" y="108" width="158" height="12" rx="6" fill="#D6DEE2" />
        <rect x="48" y="140" width="92" height="42" rx="14" fill="#0E2A3B" />
        <rect x="152" y="140" width="102" height="42" rx="14" fill="#F2F5F7" stroke="#D6DEE2" />
        <rect x="294" y="66" width="98" height="132" rx="20" fill="#1F9A92" />
        <rect x="314" y="90" width="58" height="12" rx="6" fill="#FFFFFF" opacity="0.92" />
        <rect x="314" y="112" width="42" height="10" rx="5" fill="#FFFFFF" opacity="0.72" />
        <rect x="314" y="134" width="58" height="10" rx="5" fill="#FFFFFF" opacity="0.52" />
        <rect x="314" y="158" width="46" height="24" rx="12" fill="#0E2A3B" />
        <circle cx="354" cy="44" r="20" fill="#9BE6D6" />
        <path d="M347 44h14M354 37v14" stroke="#0E2A3B" strokeWidth="3.5" strokeLinecap="round" />
      </svg>
    </div>
  );
}
