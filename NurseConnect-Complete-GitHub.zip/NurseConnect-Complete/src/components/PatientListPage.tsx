// src/components/PatientListPage.tsx
import React, { useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, query, where } from "firebase/firestore";
import { Link } from "react-router-dom";
import { db } from "../firebaseConfig";
import { Patient } from "../models/emr";
import { MainLayout } from "./MainLayout";
import { formatToDDMMYYYY } from "../lib/dates";
import { useAuth } from "../contexts/AuthContext";

function asStr(v: unknown): string {
  return typeof v === "string" ? v : "";
}

function digitsOnly(v: string): string {
  return String(v || "").replace(/\D/g, "");
}

function deriveLastName(raw: any, fullName: string): string {
  const explicit = asStr(raw?.lastName).trim();
  if (explicit) return explicit;
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  return parts.length > 1 ? parts[parts.length - 1] : "";
}

function mapPatientDoc(d: any): Patient {
  const raw = d.data() as any;
  const fullName = String(raw?.fullName || "Unnamed");
  return {
    id: d.id,
    fullName,
    lastName: deriveLastName(raw, fullName),
    email: raw?.email ?? null,
    phone: raw?.phone ?? null,
    phoneNumber: raw?.phoneNumber ?? raw?.mobile ?? null,
    dateOfBirth: raw?.dateOfBirth ?? raw?.dob ?? raw?.DOB ?? null,
    urNumber: raw?.urNumber ?? raw?.ur ?? raw?.UR ?? null,
    medicareCardNumber:
      raw?.medicareCardNumber ?? (raw?.primaryId?.type === "MEDICARE" ? raw?.primaryId?.value ?? null : null),
    omang: raw?.omang ?? raw?.nationalId ?? null,
    idNumber: raw?.idNumber ?? raw?.idNo ?? raw?.id ?? null,
    sex: raw?.sex ?? "unknown",
    address: raw?.address ?? null,
    suburb: raw?.suburb ?? null,
    state: raw?.state ?? null,
    postcode: raw?.postcode ?? null,
    userId: raw?.userId ?? null,
  };
}

async function loadPatients(practiceId: string): Promise<Patient[]> {
  if (!practiceId) return [];
  const snap = await getDocs(query(collection(db, "patients"), where("practiceId", "==", practiceId), limit(500)));
  return snap.docs.map(mapPatientDoc).sort((a, b) => String(a.fullName || "").localeCompare(String(b.fullName || "")));
}

export const PatientListPage: React.FC = () => {
  const { currentUserData, normalizedRole } = useAuth() as any;
  const canUse = normalizedRole === "clinician";
  const practiceId = String(currentUserData?.practiceId || "").trim();

  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    if (!canUse) {
      setLoading(false);
      return;
    }

    let alive = true;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        const rows = await loadPatients(practiceId);
        if (!alive) return;
        setPatients(rows);
      } catch (e: any) {
        if (!alive) return;
        console.error(e);
        setError(e?.message ?? "Failed to load clients.");
      } finally {
        if (!alive) return;
        setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [canUse, practiceId]);

  const filteredPatients = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    if (!q) return patients;
    const qDigits = digitsOnly(q);

    return patients.filter((p) => {
      const fullName = asStr(p.fullName).toLowerCase();
      const lastName = asStr(p.lastName).toLowerCase();
      const ur = asStr(p.urNumber).toLowerCase();
      const medicare = asStr(p.medicareCardNumber).toLowerCase();
      const omang = asStr(p.omang).toLowerCase();
      const idNumber = asStr(p.idNumber).toLowerCase();
      const dob = asStr(p.dateOfBirth).toLowerCase();
      const phone = asStr(p.phone).toLowerCase();
      const phone2 = asStr(p.phoneNumber).toLowerCase();
      const email = asStr(p.email).toLowerCase();
      const patientId = asStr(p.id).toLowerCase();

      if (
        fullName.includes(q) ||
        lastName.includes(q) ||
        ur.includes(q) ||
        medicare.includes(q) ||
        omang.includes(q) ||
        idNumber.includes(q) ||
        dob.includes(q) ||
        phone.includes(q) ||
        phone2.includes(q) ||
        email.includes(q) ||
        patientId.includes(q)
      ) {
        return true;
      }

      if (!qDigits) return false;
      return (
        digitsOnly(medicare).includes(qDigits) ||
        digitsOnly(omang).includes(qDigits) ||
        digitsOnly(idNumber).includes(qDigits) ||
        digitsOnly(phone).includes(qDigits) ||
        digitsOnly(phone2).includes(qDigits)
      );
    });
  }, [patients, searchText]);

  return (
    <MainLayout>
      {!canUse ? (
        <div className="p-4">
          <div className="text-sm text-red-600">Access denied.</div>
        </div>
      ) : loading ? (
        <div className="p-4">
          <div className="text-sm text-gray-600">Loading…</div>
        </div>
      ) : error ? (
        <div className="p-4">
          <div className="text-sm text-red-600">{error}</div>
        </div>
      ) : (
        <div className="p-4 space-y-4">
          {/* Header (local sub-tabs removed; global NavBar is the single source of navigation) */}
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="text-xl font-semibold">Clients</h1>
              <p className="text-sm text-gray-600">Search by UR, Medicare/ID, DOB, last name, or phone.</p>
            </div>
          </div>

          <div className="border rounded-xl p-3 bg-white">
            <label className="block text-xs text-gray-600 mb-1">Find client</label>
            <input
              className="w-full border rounded px-3 py-2 text-sm"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Type name, UR, Medicare, ID number, DOB (DD-MM-YYYY), phone, or Firebase patient ID"
            />
            <div className="text-xs text-gray-500 mt-1">
              Showing {filteredPatients.length} of {patients.length}
            </div>
          </div>

          <div className="overflow-auto border rounded-xl bg-white">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left border-b bg-gray-50">
                  <th className="py-2 px-3">Name</th>
                  <th className="py-2 px-3">UR</th>
                  <th className="py-2 px-3">Medicare / ID</th>
                  <th className="py-2 px-3">DOB</th>
                  <th className="py-2 px-3">Email</th>
                  <th className="py-2 px-3">Phone</th>
                  <th className="py-2 px-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredPatients.map((p) => (
                  <tr key={p.id} className="border-b">
                    <td className="py-2 px-3">
                      <Link className="text-blue-700 hover:underline" to={`/patients/${p.id}/chart`}>
                        {p.fullName || "Unnamed"}
                      </Link>
                    </td>
                    <td className="py-2 px-3">{p.urNumber || "—"}</td>
                    <td className="py-2 px-3">{p.medicareCardNumber || p.idNumber || p.omang || "—"}</td>
                    <td className="py-2 px-3">{p.dateOfBirth ? formatToDDMMYYYY(p.dateOfBirth) : "—"}</td>
                    <td className="py-2 px-3">{p.email || "—"}</td>
                    <td className="py-2 px-3">{p.phone || p.phoneNumber || "—"}</td>
                    <td className="py-2 px-3">
                      <div className="flex items-center gap-3">
                        <Link className="text-blue-700 hover:underline" to={`/patients/${p.id}/chart`}>
                          Open chart
                        </Link>
                        <Link className="text-blue-700 hover:underline" to={`/patients/${p.id}/details`}>
                          Details
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredPatients.length === 0 && (
                  <tr>
                    <td colSpan={8} className="py-6 px-3 text-gray-600">
                      No clients match your search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </MainLayout>
  );
};

export default PatientListPage;
