// src/components/MainLayout.tsx
import React from "react";

type Props = {
  children: React.ReactNode;
};

/**
 * MainLayout is now a container-only layout.
 * Global navigation (including Logout) is handled by the router-mounted NavBar.
 * This prevents duplicate header rows and repeated identity banners.
 */
export const MainLayout: React.FC<Props> = ({ children }) => {
  return (
    <div className="page-shell">
      <main className="page-main">{children}</main>
    </div>
  );
};

export default MainLayout;
