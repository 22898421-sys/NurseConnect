import React, { useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, query, where } from "firebase/firestore";
import { Link } from "react-router-dom";
import { db } from "../firebaseConfig";
import { toPlainLanguageOutcomeMessage } from "../lib/plainLanguage";
import { formatConcernLevel, getHomeCareAssessmentTemplate, HomeCareAssessmentDomain } from "../lib/homeCareAssessments";
import HomeCareAssessmentLauncher from "./HomeCareAssessmentLauncher";

type RiskAssessmentRow = {
  id: string;
  patientId: string;
  practiceId: string;
  tool: string;
  status: string;
  integrationMode?: string | null;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  launchedByDisplayName?: string | null;
  completedAt?: any;
  createdAt?: any;
  resultSummary?: {
    templateKey?: string | null;
    overallConcernLevel?: string | null;
    reviewTimeframe?: string | null;
    carePrioritySummary?: string | null;
    escalationAction?: string | null;
  } | null;
  printableSummary?: string | null;
  questionnairePayload?: {
    visitContext?: string | null;
    domains?: HomeCareAssessmentDomain[] | null;
  } | null;
  scorePayload?: {
    domainCount?: number | null;
    highConcernCount?: number | null;
    urgentConcernCount?: number | null;
  } | null;
  reportStatus?: string | null;
};

function toDateMaybe(value: any): Date | null {
  try {
    if (!value) return null;
    if (typeof value?.toDate === "function") return value.toDate();
    if (typeof value?.seconds === "number") return new Date(value.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

type Props = {
  patientId: string;
  practiceId: string;
  clinicianUid: string;
  clinicianDisplayName?: string | null;
  chartBasePath: string;
};

export const RiskAssessmentsTab: React.FC<Props> = ({
  patientId,
  practiceId,
  clinicianUid,
  clinicianDisplayName,
  chartBasePath,
}) => {
  const [items, setItems] = useState<RiskAssessmentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setErr(null);
      try {
        const snap = await getDocs(
          query(
            collection(db, "riskAssessments"),
            where("patientId", "==", patientId),
            where("practiceId", "==", practiceId),
            limit(100)
          )
        );
        if (cancelled) return;
        const rows: RiskAssessmentRow[] = snap.docs
          .map((row) => ({ id: row.id, ...(row.data() as any) }))
          .sort((a, b) => {
            const aMs =
              toDateMaybe(a.completedAt)?.getTime() ||
              toDateMaybe(a.createdAt)?.getTime() ||
              0;
            const bMs =
              toDateMaybe(b.completedAt)?.getTime() ||
              toDateMaybe(b.createdAt)?.getTime() ||
              0;
            return bMs - aMs;
          });
        setItems(rows);
      } catch (e: any) {
        console.error(e);
        if (!cancelled) setErr(toPlainLanguageOutcomeMessage(e, "We could not load risk assessments right now."));
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, [patientId, practiceId, reloadKey]);

  const latest = items[0] || null;
  const latestDate = useMemo(() => toDateMaybe(latest?.completedAt || latest?.createdAt), [latest]);

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-ink-200 bg-white p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="section-title">Home-care assessments</div>
            <div className="section-subtitle">
              Clinician-only assessment history for in-home nursing risk, safety, and support planning. Patient access remains disabled.
            </div>
          </div>
          <HomeCareAssessmentLauncher
            patientId={patientId}
            practiceId={practiceId}
            clinicianUid={clinicianUid}
            clinicianDisplayName={clinicianDisplayName}
            chartBasePath={chartBasePath}
            buttonLabel="New home-care assessment"
            onAssessmentCreated={() => setReloadKey((value) => value + 1)}
          />
        </div>

        {latest ? (
          <div className="rounded-lg border border-teal-200 bg-teal-50 px-3 py-3">
            <div className="text-xs font-medium text-teal-900">Latest assessment</div>
            <div className="mt-1 text-sm text-teal-950">
              {latest.resultSummary?.templateKey ? `${getHomeCareAssessmentTemplate(latest.resultSummary.templateKey as any).label} · ` : ""}
              {latest.resultSummary?.overallConcernLevel
                ? formatConcernLevel(latest.resultSummary.overallConcernLevel as any)
                : "Summary pending"}
              {latest.resultSummary?.reviewTimeframe ? ` · ${latest.resultSummary.reviewTimeframe}` : ""}
            </div>
            <div className="mt-1 text-xs text-teal-900">
              {latestDate ? latestDate.toLocaleString() : "Date unavailable"}
              {latest.launchedByDisplayName ? ` · ${latest.launchedByDisplayName}` : ""}
              {latest.reportStatus ? ` · Report: ${latest.reportStatus}` : ""}
            </div>
          </div>
        ) : (
          <div className="rounded-lg border border-ink-200 bg-ink-50 px-3 py-3 text-sm text-ink-500">
            No home-care assessment records yet.
          </div>
        )}
      </div>

      <div className="rounded-xl border border-ink-200 bg-white p-4 space-y-3">
        <div className="text-sm font-semibold">Assessment history</div>
        {loading ? (
          <div className="text-sm text-ink-500">Loading home-care assessments…</div>
        ) : err ? (
          <div className="text-sm text-rose-600">{err}</div>
        ) : items.length === 0 ? (
          <div className="text-sm text-ink-500">No home-care assessment records yet.</div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => {
              const completedAt = toDateMaybe(item.completedAt || item.createdAt);
              return (
                <details key={item.id} className="rounded-lg border border-ink-200 p-3">
                  <summary className="cursor-pointer list-none">
                    <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
                      <div>
                        <div className="text-sm font-medium">
                          {item.resultSummary?.templateKey
                            ? getHomeCareAssessmentTemplate(item.resultSummary.templateKey as any).label
                            : "Home-care assessment"}
                          {item.resultSummary?.overallConcernLevel
                            ? ` · ${formatConcernLevel(item.resultSummary.overallConcernLevel as any)} concern`
                            : ""}
                        </div>
                        <div className="text-xs text-ink-500 mt-1">
                          {completedAt ? completedAt.toLocaleString() : "Date unavailable"}
                          {item.resultSummary?.reviewTimeframe ? ` · ${item.resultSummary.reviewTimeframe}` : ""}
                          {item.integrationMode ? ` · ${item.integrationMode}` : ""}
                        </div>
                      </div>
                      <div className="text-xs text-ink-500">
                        {item.reportStatus ? `Report: ${item.reportStatus}` : "Report pending"}
                      </div>
                    </div>
                  </summary>

                  <div className="mt-3 space-y-3">
                    {item.resultSummary?.carePrioritySummary ? (
                      <div className="text-sm text-ink-800">
                        {item.resultSummary.carePrioritySummary}
                      </div>
                    ) : null}

                    {item.resultSummary?.escalationAction ? (
                      <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                        Escalation action: {item.resultSummary.escalationAction}
                      </div>
                    ) : null}

                    {item.printableSummary ? (
                      <div className="rounded-md border border-ink-200 bg-sand-50 px-3 py-2 text-sm whitespace-pre-wrap">
                        {item.printableSummary}
                      </div>
                    ) : null}

                    {Array.isArray(item.questionnairePayload?.domains) && item.questionnairePayload?.domains.length ? (
                      <div className="rounded-md border border-ink-200 bg-white px-3 py-3 space-y-2">
                        <div className="text-xs font-medium text-ink-700">Assessment domains</div>
                        {item.questionnairePayload.domains.map((domain) => (
                          <div key={domain.key} className="rounded-md border border-ink-100 px-3 py-2">
                            <div className="text-sm font-medium text-ink-900">
                              {domain.title} · {formatConcernLevel(domain.concernLevel)}
                            </div>
                            <div className="mt-1 text-sm text-ink-700 whitespace-pre-wrap">{domain.summary}</div>
                          </div>
                        ))}
                      </div>
                    ) : null}

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                      <div>
                        <div className="text-xs font-medium text-ink-700 mb-1">Assessment payload</div>
                        <pre className="max-h-[260px] overflow-auto rounded-md border border-ink-200 bg-ink-950 text-ink-50 p-3 text-[11px]">
                          {JSON.stringify(item.questionnairePayload || {}, null, 2)}
                        </pre>
                      </div>
                      <div>
                        <div className="text-xs font-medium text-ink-700 mb-1">Summary payload</div>
                        <pre className="max-h-[260px] overflow-auto rounded-md border border-ink-200 bg-ink-950 text-ink-50 p-3 text-[11px]">
                          {JSON.stringify(item.scorePayload || {}, null, 2)}
                        </pre>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-3 text-xs text-ink-500">
                      <span>Assessment ID: <span className="font-mono">{item.id}</span></span>
                      {item.sourceEncounterId ? (
                        <Link
                          to={`${chartBasePath}/encounters/${item.sourceEncounterId}`}
                          className="text-brand-500 hover:underline"
                        >
                          Open linked encounter
                        </Link>
                      ) : null}
                      <Link to={`${chartBasePath}?tab=documents`} className="text-brand-500 hover:underline">
                        Open Documents tab
                      </Link>
                    </div>
                  </div>
                </details>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default RiskAssessmentsTab;
