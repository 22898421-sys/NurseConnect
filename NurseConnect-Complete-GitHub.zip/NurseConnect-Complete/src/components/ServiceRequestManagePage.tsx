import React, { useEffect, useState } from "react";
import { doc, getDoc, serverTimestamp, updateDoc } from "firebase/firestore";
import { Link, useParams } from "react-router-dom";
import { db } from "../firebaseConfig";
import PublicSiteChrome from "./PublicSiteChrome";
import {
  formatDeliveryModePreference,
  formatFundingPathway,
  formatOrganisationRole,
  formatServiceRequestStatus,
  formatSupportAtHomeCategory,
  ServiceRequestDoc,
  ServiceRequestStatus,
} from "../lib/serviceRequests";

export default function ServiceRequestManagePage() {
  const { requestId } = useParams<{ requestId: string }>();
  const [record, setRecord] = useState<ServiceRequestDoc | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    async function load() {
      if (!requestId) return;
      try {
        const snap = await getDoc(doc(db, "serviceRequests", requestId));
        if (!active) return;
        setRecord(snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as ServiceRequestDoc) : null);
      } catch (e: any) {
        if (!active) return;
        setError(e?.message || "Could not load the request.");
      } finally {
        if (active) setLoading(false);
      }
    }
    void load();
    return () => {
      active = false;
    };
  }, [requestId]);

  const updateStatus = async (status: ServiceRequestStatus) => {
    if (!requestId) return;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      await updateDoc(doc(db, "serviceRequests", requestId), {
        status,
        filledConfirmedAt: status === "filled" ? new Date().toISOString() : null,
        filledConfirmedBy: "requester_link",
        updatedAt: serverTimestamp(),
      });
      setRecord((current) => (current ? { ...current, status, filledConfirmedAt: status === "filled" ? new Date().toISOString() : null } : current));
      setMessage(status === "filled" ? "Request marked filled. Nurses should stop treating it as available." : "Request withdrawn.");
    } catch (e: any) {
      console.error(e);
      setError(e?.message || "Could not update the request status.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <PublicSiteChrome
      ctaLabel="Post another request"
      ctaTo="/for-organisations/request"
      metaTitle="NurseConnectCare | Manage Service Request"
      metaDescription="Confirm whether an organisation service request is still available, filled or withdrawn."
    >
      <section className="mx-auto w-full max-w-4xl px-4 pb-16 pt-10 sm:px-6 lg:px-8">
        <div className="rounded-[32px] border border-ink-200 bg-white p-8 shadow-soft">
          {loading ? (
            <div className="text-sm text-ink-600">Loading request...</div>
          ) : !record ? (
            <div className="text-sm text-rose-700">Request not found.</div>
          ) : (
            <div className="space-y-6">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Request management</p>
                <h1 className="mt-3 text-4xl text-ink-900">Keep this request current.</h1>
                <p className="mt-4 text-sm leading-7 text-ink-700">
                  Use this page to confirm whether the service request is still available. Marking it filled or withdrawn helps prevent unnecessary nurse enquiries.
                </p>
              </div>

              {message ? <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{message}</div> : null}
              {error ? <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-2xl border border-ink-200 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Status</p>
                  <p className="mt-2 text-lg font-semibold text-ink-900">{formatServiceRequestStatus(record.status)}</p>
                  <p className="mt-2 text-sm text-ink-700">{record.requestType === "direct_request" ? "Direct request" : "Open request"} · {formatOrganisationRole(record.organisationRole)}</p>
                  <p className="mt-2 text-sm text-ink-700">{formatFundingPathway(record.fundingPathway)} · {formatSupportAtHomeCategory(record.supportAtHomeCategory)}</p>
                  <p className="mt-2 text-sm text-ink-700">{formatDeliveryModePreference(record.deliveryModePreference)}</p>
                </div>
                <div className="rounded-2xl border border-ink-200 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Service summary</p>
                  <p className="mt-2 text-sm text-ink-700">{record.serviceTitle}</p>
                  <p className="mt-2 text-sm text-ink-700">{record.suburb}, {record.state} {record.postcode}</p>
                  <p className="mt-2 text-sm text-ink-700">Required nurse level: {record.requiredNurseType}</p>
                  <p className="mt-2 text-sm text-ink-700">Registered provider: {record.registeredProviderName || "Not supplied"}</p>
                  <p className="mt-2 text-sm text-ink-700">Provider/reference ID: {record.registeredProviderId || record.clientReference || "Not supplied"}</p>
                </div>
              </div>

              {Array.isArray(record.responses) && record.responses.length ? (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-700">Requester updates</p>
                  <p className="mt-2 text-sm leading-7 text-emerald-900">
                    {record.responses.length} nurse response{record.responses.length === 1 ? "" : "s"} received. Review the latest responses below.
                  </p>
                </div>
              ) : null}

              <div className="rounded-2xl border border-ink-200 p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Care plan context</p>
                <p className="mt-3 whitespace-pre-wrap text-sm leading-7 text-ink-700">{record.carePlanContext}</p>
              </div>

              {Array.isArray(record.responses) && record.responses.length ? (
                <div className="rounded-2xl border border-ink-200 p-4 space-y-3">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Nurse responses</p>
                  {record.responses
                    .slice()
                    .sort((a, b) => new Date(b.respondedAt).getTime() - new Date(a.respondedAt).getTime())
                    .map((response) => (
                      <div key={`${response.nurseUid}-${response.respondedAt}`} className="rounded-2xl border border-ink-100 bg-sand-100/70 p-4">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="text-sm font-semibold text-ink-900">
                            {response.nurseDisplayName}
                            {response.nurseType ? ` (${response.nurseType})` : ""}
                          </div>
                          <div className="text-xs text-ink-500">{new Date(response.respondedAt).toLocaleString()}</div>
                        </div>
                        <div className="mt-2 text-sm text-ink-700">Response: {response.responseType}</div>
                        {response.note ? <div className="mt-2 whitespace-pre-wrap text-sm leading-7 text-ink-700">{response.note}</div> : null}
                      </div>
                    ))}
                </div>
              ) : (
                <div className="rounded-2xl border border-ink-200 p-4 text-sm text-ink-600">
                  No nurse responses received yet.
                </div>
              )}

              <div className="flex flex-wrap gap-3">
                <button type="button" disabled={busy || record.status === "filled"} onClick={() => void updateStatus("filled")} className="btn-primary">
                  Mark filled
                </button>
                <button type="button" disabled={busy || record.status === "withdrawn"} onClick={() => void updateStatus("withdrawn")} className="btn-secondary">
                  Withdraw request
                </button>
                <Link to="/for-organisations/request" className="btn-secondary">
                  Post another request
                </Link>
              </div>
            </div>
          )}
        </div>
      </section>
    </PublicSiteChrome>
  );
}
