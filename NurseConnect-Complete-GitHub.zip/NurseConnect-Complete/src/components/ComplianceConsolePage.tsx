import React, { useCallback, useEffect, useMemo, useState } from "react";
import MainLayout from "./MainLayout";
import { useAuth } from "../contexts/AuthContext";
import {
  AssociatedProviderRecord,
  ComplianceCredential,
  ComplianceProvider,
  IncidentComplaintRecord,
  AssociatedProviderStatus,
  ComplianceProviderStatus,
  CredentialStatus,
  IncidentComplaintSeverity,
  IncidentComplaintStatus,
  IncidentComplaintType,
  credentialComputedStatus,
  daysUntil,
  listAssociatedProviders,
  listComplianceCredentials,
  listComplianceProviders,
  listIncidentComplaints,
  saveAssociatedProvider,
  saveComplianceCredential,
  saveComplianceProvider,
  saveIncidentComplaint,
  toDateLabel,
  updateAssociatedProviderStatus,
  updateComplianceProviderStatus,
  updateCredentialStatus,
  updateIncidentComplaintStatus,
} from "../lib/compliance";
import { FiAlertCircle, FiBriefcase, FiCheckCircle, FiClipboard, FiFileText, FiShield } from "./PublicIcons";

type TabKey = "overview" | "providers" | "credentials" | "associated" | "incidents";

const providerStatuses: ComplianceProviderStatus[] = ["onboarding", "active", "paused", "closed"];
const credentialStatuses: CredentialStatus[] = ["pending", "verified", "expiring", "expired", "rejected"];
const associatedStatuses: AssociatedProviderStatus[] = ["pending", "approved", "suspended", "ended"];
const incidentStatuses: IncidentComplaintStatus[] = ["open", "in_review", "escalated", "closed"];

function titleCase(value: string) {
  return value
    .split("_")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function statusClass(value: string) {
  if (["active", "approved", "verified", "closed"].includes(value)) return "bg-emerald-50 text-emerald-800 border-emerald-200";
  if (["critical", "high", "expired", "rejected", "suspended", "escalated"].includes(value)) return "bg-rose-50 text-rose-800 border-rose-200";
  if (["expiring", "pending", "onboarding", "in_review"].includes(value)) return "bg-amber-50 text-amber-800 border-amber-200";
  return "bg-ink-50 text-ink-700 border-ink-200";
}

function StatusPill({ value }: { value: string }) {
  return <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${statusClass(value)}`}>{titleCase(value)}</span>;
}

function StatCard({ title, value, detail, tone = "neutral" }: { title: string; value: number | string; detail: string; tone?: "neutral" | "risk" | "good" }) {
  const toneClass = tone === "risk" ? "border-rose-200 bg-rose-50" : tone === "good" ? "border-emerald-200 bg-emerald-50" : "border-ink-200 bg-white";
  return (
    <div className={`rounded-[24px] border p-5 shadow-soft ${toneClass}`}>
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">{title}</p>
      <p className="mt-3 text-3xl font-semibold text-ink-900">{value}</p>
      <p className="mt-2 text-sm leading-6 text-ink-600">{detail}</p>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
    </div>
  );
}

export default function ComplianceConsolePage() {
  const { normalizedRole } = useAuth() as any;
  const [tab, setTab] = useState<TabKey>("overview");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [providers, setProviders] = useState<ComplianceProvider[]>([]);
  const [credentials, setCredentials] = useState<ComplianceCredential[]>([]);
  const [associatedProviders, setAssociatedProviders] = useState<AssociatedProviderRecord[]>([]);
  const [incidents, setIncidents] = useState<IncidentComplaintRecord[]>([]);

  const [providerForm, setProviderForm] = useState({
    name: "",
    registrationId: "",
    contactName: "",
    contactEmail: "",
    serviceCategories: "Clinical supports",
    status: "onboarding" as ComplianceProviderStatus,
    notes: "",
  });
  const [credentialForm, setCredentialForm] = useState({
    subjectName: "",
    subjectType: "nurse" as ComplianceCredential["subjectType"],
    credentialType: "AHPRA registration",
    providerName: "",
    expiryDate: "",
    status: "pending" as CredentialStatus,
    evidenceReference: "",
    notes: "",
  });
  const [associatedForm, setAssociatedForm] = useState({
    organisationName: "",
    providerName: "",
    contactEmail: "",
    serviceCategory: "Clinical supports",
    agreementStatus: "pending" as AssociatedProviderStatus,
    insuranceExpiry: "",
    screeningStatus: "Pending",
    notes: "",
  });
  const [incidentForm, setIncidentForm] = useState({
    type: "incident" as IncidentComplaintType,
    title: "",
    providerName: "",
    participantReference: "",
    severity: "medium" as IncidentComplaintSeverity,
    status: "open" as IncidentComplaintStatus,
    owner: "",
    dueDate: "",
    summary: "",
  });

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [providerRows, credentialRows, associatedRows, incidentRows] = await Promise.all([
        listComplianceProviders(),
        listComplianceCredentials(),
        listAssociatedProviders(),
        listIncidentComplaints(),
      ]);
      setProviders(providerRows);
      setCredentials(credentialRows);
      setAssociatedProviders(associatedRows);
      setIncidents(incidentRows);
    } catch (err: any) {
      console.error("Failed to load compliance console", err);
      setError(err?.message || "Could not load compliance records.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const metrics = useMemo(() => {
    const computedCredentials = credentials.map((item) => ({ ...item, computedStatus: credentialComputedStatus(item) }));
    const expiredCredentials = computedCredentials.filter((item) => item.computedStatus === "expired").length;
    const expiringCredentials = computedCredentials.filter((item) => item.computedStatus === "expiring").length;
    const openIncidents = incidents.filter((item) => item.status !== "closed").length;
    const escalatedIncidents = incidents.filter((item) => item.status === "escalated" || item.severity === "critical").length;
    const pendingAssociated = associatedProviders.filter((item) => item.agreementStatus === "pending").length;
    return {
      activeProviders: providers.filter((item) => item.status === "active").length,
      onboardingProviders: providers.filter((item) => item.status === "onboarding").length,
      expiredCredentials,
      expiringCredentials,
      openIncidents,
      escalatedIncidents,
      pendingAssociated,
    };
  }, [associatedProviders, credentials, incidents, providers]);

  if (normalizedRole !== "system_admin") {
    return (
      <MainLayout>
        <div className="text-sm text-rose-600">Access denied.</div>
      </MainLayout>
    );
  }

  async function runSave(action: () => Promise<unknown>, success: string) {
    setSaving(true);
    setMessage("");
    setError("");
    try {
      await action();
      setMessage(success);
      await refresh();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Could not save compliance record.");
    } finally {
      setSaving(false);
    }
  }

  async function submitProvider(event: React.FormEvent) {
    event.preventDefault();
    if (!providerForm.name.trim()) {
      setError("Provider name is required.");
      return;
    }
    await runSave(
      () =>
        saveComplianceProvider({
          ...providerForm,
          serviceCategories: providerForm.serviceCategories.split(","),
        }),
      "Provider onboarding record created."
    );
    setProviderForm({ name: "", registrationId: "", contactName: "", contactEmail: "", serviceCategories: "Clinical supports", status: "onboarding", notes: "" });
  }

  async function submitCredential(event: React.FormEvent) {
    event.preventDefault();
    if (!credentialForm.subjectName.trim() || !credentialForm.credentialType.trim()) {
      setError("Credential subject and type are required.");
      return;
    }
    await runSave(() => saveComplianceCredential(credentialForm), "Credential record created.");
    setCredentialForm({ subjectName: "", subjectType: "nurse", credentialType: "AHPRA registration", providerName: "", expiryDate: "", status: "pending", evidenceReference: "", notes: "" });
  }

  async function submitAssociated(event: React.FormEvent) {
    event.preventDefault();
    if (!associatedForm.organisationName.trim()) {
      setError("Associated provider organisation name is required.");
      return;
    }
    await runSave(() => saveAssociatedProvider(associatedForm), "Associated-provider record created.");
    setAssociatedForm({ organisationName: "", providerName: "", contactEmail: "", serviceCategory: "Clinical supports", agreementStatus: "pending", insuranceExpiry: "", screeningStatus: "Pending", notes: "" });
  }

  async function submitIncident(event: React.FormEvent) {
    event.preventDefault();
    if (!incidentForm.title.trim()) {
      setError("Incident or complaint title is required.");
      return;
    }
    await runSave(() => saveIncidentComplaint(incidentForm), "Incident/complaint record created.");
    setIncidentForm({ type: "incident", title: "", providerName: "", participantReference: "", severity: "medium", status: "open", owner: "", dueDate: "", summary: "" });
  }

  const tabs: Array<{ key: TabKey; label: string }> = [
    { key: "overview", label: "Audit dashboard" },
    { key: "providers", label: "Providers" },
    { key: "credentials", label: "Credentials" },
    { key: "associated", label: "Associated providers" },
    { key: "incidents", label: "Incidents & complaints" },
  ];

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="card p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Support at Home governance</p>
              <h1 className="section-title mt-2">Compliance console</h1>
              <p className="section-subtitle mt-2 max-w-4xl">
                Track registered provider onboarding, credential expiry, associated-provider compliance, incidents,
                complaints and audit readiness without making NurseConnectCare the care provider or nurse employer.
              </p>
            </div>
            <button type="button" className="btn-secondary" onClick={() => void refresh()} disabled={loading}>
              {loading ? "Refreshing..." : "Refresh"}
            </button>
          </div>
        </div>

        {message ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{message}</div> : null}
        {error ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

        <div className="flex flex-wrap gap-2">
          {tabs.map((item) => (
            <button key={item.key} type="button" className={tab === item.key ? "btn-primary" : "btn-secondary"} onClick={() => setTab(item.key)}>
              {item.label}
            </button>
          ))}
        </div>

        {loading ? <div className="card p-6 text-sm text-ink-600">Loading compliance records...</div> : null}

        {!loading && tab === "overview" ? (
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <StatCard title="Active providers" value={metrics.activeProviders} detail={`${metrics.onboardingProviders} provider onboarding record(s) in progress.`} tone="good" />
              <StatCard title="Credential risk" value={metrics.expiredCredentials + metrics.expiringCredentials} detail={`${metrics.expiredCredentials} expired, ${metrics.expiringCredentials} expiring within 30 days.`} tone={metrics.expiredCredentials + metrics.expiringCredentials > 0 ? "risk" : "good"} />
              <StatCard title="Associated providers" value={associatedProviders.length} detail={`${metrics.pendingAssociated} pending agreement or screening review.`} tone={metrics.pendingAssociated > 0 ? "risk" : "neutral"} />
              <StatCard title="Open incidents" value={metrics.openIncidents} detail={`${metrics.escalatedIncidents} escalated or critical item(s).`} tone={metrics.openIncidents > 0 ? "risk" : "good"} />
            </div>

            <div className="grid gap-6 xl:grid-cols-3">
              <div className="card p-5 xl:col-span-2">
                <div className="flex items-center gap-3">
                  <FiShield className="h-5 w-5 text-brand-700" />
                  <h2 className="text-xl font-semibold text-ink-900">Audit readiness snapshot</h2>
                </div>
                <div className="mt-5 grid gap-3 md:grid-cols-2">
                  {[
                    "Registered provider relationship recorded",
                    "Worker/supplier credentials current",
                    "Associated-provider agreement status visible",
                    "Incident and complaint owner assigned",
                    "Evidence references recorded before expiry",
                    "Open high-risk matters escalated",
                  ].map((item) => (
                    <div key={item} className="flex gap-3 rounded-2xl border border-ink-200 bg-sand-100/70 p-4 text-sm text-ink-700">
                      <FiCheckCircle className="mt-1 h-4 w-4 shrink-0 text-brand-700" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="card p-5">
                <div className="flex items-center gap-3">
                  <FiAlertCircle className="h-5 w-5 text-rose-600" />
                  <h2 className="text-xl font-semibold text-ink-900">Highest priority</h2>
                </div>
                <div className="mt-4 space-y-3 text-sm text-ink-700">
                  {credentials.filter((item) => credentialComputedStatus(item) === "expired").slice(0, 3).map((item) => (
                    <div key={item.id} className="rounded-2xl border border-rose-200 bg-rose-50 p-3">
                      {item.subjectName}: {item.credentialType} expired {toDateLabel(item.expiryDate)}
                    </div>
                  ))}
                  {incidents.filter((item) => item.status === "escalated" || item.severity === "critical").slice(0, 3).map((item) => (
                    <div key={item.id} className="rounded-2xl border border-rose-200 bg-rose-50 p-3">
                      {item.title}: {titleCase(item.severity)} {item.type}
                    </div>
                  ))}
                  {metrics.expiredCredentials === 0 && metrics.escalatedIncidents === 0 ? <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-3">No expired credentials or escalated/critical matters recorded.</div> : null}
                </div>
              </div>
            </div>
          </div>
        ) : null}

        {!loading && tab === "providers" ? (
          <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
            <form className="card p-5 space-y-4" onSubmit={submitProvider}>
              <div className="flex items-center gap-3">
                <FiBriefcase className="h-5 w-5 text-brand-700" />
                <h2 className="text-xl font-semibold text-ink-900">Provider onboarding</h2>
              </div>
              <Field label="Registered provider name"><input className="input" value={providerForm.name} onChange={(e) => setProviderForm((v) => ({ ...v, name: e.target.value }))} /></Field>
              <Field label="Registration/reference ID"><input className="input" value={providerForm.registrationId} onChange={(e) => setProviderForm((v) => ({ ...v, registrationId: e.target.value }))} /></Field>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Contact name"><input className="input" value={providerForm.contactName} onChange={(e) => setProviderForm((v) => ({ ...v, contactName: e.target.value }))} /></Field>
                <Field label="Contact email"><input className="input" value={providerForm.contactEmail} onChange={(e) => setProviderForm((v) => ({ ...v, contactEmail: e.target.value }))} /></Field>
              </div>
              <Field label="Service categories"><input className="input" value={providerForm.serviceCategories} onChange={(e) => setProviderForm((v) => ({ ...v, serviceCategories: e.target.value }))} placeholder="Clinical supports, independence services" /></Field>
              <Field label="Status"><select className="select" value={providerForm.status} onChange={(e) => setProviderForm((v) => ({ ...v, status: e.target.value as ComplianceProviderStatus }))}>{providerStatuses.map((item) => <option key={item} value={item}>{titleCase(item)}</option>)}</select></Field>
              <Field label="Notes"><textarea className="input min-h-[100px]" value={providerForm.notes} onChange={(e) => setProviderForm((v) => ({ ...v, notes: e.target.value }))} /></Field>
              <button className="btn-primary" type="submit" disabled={saving}>{saving ? "Saving..." : "Create provider record"}</button>
            </form>
            <div className="space-y-4">
              {providers.length === 0 ? <div className="card p-5 text-sm text-ink-600">No provider records yet.</div> : providers.map((item) => (
                <div key={item.id} className="card p-5">
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-ink-900">{item.name}</h3>
                      <p className="mt-1 text-sm text-ink-600">{item.registrationId || "No registration/reference recorded"} · {item.contactEmail || "No contact email"}</p>
                      <p className="mt-2 text-sm text-ink-700">{(item.serviceCategories || []).join(", ") || "No service categories recorded"}</p>
                    </div>
                    <StatusPill value={item.status} />
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">{providerStatuses.map((status) => <button key={status} className="btn-secondary text-xs" onClick={() => void runSave(() => updateComplianceProviderStatus(item.id, status), "Provider status updated.")}>{titleCase(status)}</button>)}</div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {!loading && tab === "credentials" ? (
          <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
            <form className="card p-5 space-y-4" onSubmit={submitCredential}>
              <div className="flex items-center gap-3">
                <FiClipboard className="h-5 w-5 text-brand-700" />
                <h2 className="text-xl font-semibold text-ink-900">Credential tracking</h2>
              </div>
              <Field label="Worker/supplier name"><input className="input" value={credentialForm.subjectName} onChange={(e) => setCredentialForm((v) => ({ ...v, subjectName: e.target.value }))} /></Field>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Subject type"><select className="select" value={credentialForm.subjectType} onChange={(e) => setCredentialForm((v) => ({ ...v, subjectType: e.target.value as ComplianceCredential["subjectType"] }))}><option value="nurse">Nurse</option><option value="associated_provider">Associated provider</option><option value="supplier">Supplier</option></select></Field>
                <Field label="Credential type"><input className="input" value={credentialForm.credentialType} onChange={(e) => setCredentialForm((v) => ({ ...v, credentialType: e.target.value }))} /></Field>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Provider/context"><input className="input" value={credentialForm.providerName} onChange={(e) => setCredentialForm((v) => ({ ...v, providerName: e.target.value }))} /></Field>
                <Field label="Expiry date"><input className="input" type="date" value={credentialForm.expiryDate} onChange={(e) => setCredentialForm((v) => ({ ...v, expiryDate: e.target.value }))} /></Field>
              </div>
              <Field label="Status"><select className="select" value={credentialForm.status} onChange={(e) => setCredentialForm((v) => ({ ...v, status: e.target.value as CredentialStatus }))}>{credentialStatuses.map((item) => <option key={item} value={item}>{titleCase(item)}</option>)}</select></Field>
              <Field label="Evidence reference"><input className="input" value={credentialForm.evidenceReference} onChange={(e) => setCredentialForm((v) => ({ ...v, evidenceReference: e.target.value }))} placeholder="Document ID, storage path, external check reference" /></Field>
              <Field label="Notes"><textarea className="input min-h-[90px]" value={credentialForm.notes} onChange={(e) => setCredentialForm((v) => ({ ...v, notes: e.target.value }))} /></Field>
              <button className="btn-primary" type="submit" disabled={saving}>{saving ? "Saving..." : "Create credential record"}</button>
            </form>
            <div className="space-y-4">
              {credentials.length === 0 ? <div className="card p-5 text-sm text-ink-600">No credential records yet.</div> : credentials.map((item) => {
                const computed = credentialComputedStatus(item);
                const remaining = daysUntil(item.expiryDate);
                return (
                  <div key={item.id} className="card p-5">
                    <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-ink-900">{item.subjectName}</h3>
                        <p className="mt-1 text-sm text-ink-600">{item.credentialType} · {titleCase(item.subjectType)}</p>
                        <p className="mt-2 text-sm text-ink-700">Expiry: {toDateLabel(item.expiryDate)}{remaining != null ? ` · ${remaining} day(s)` : ""}</p>
                        {item.evidenceReference ? <p className="mt-1 text-sm text-ink-600">Evidence: {item.evidenceReference}</p> : null}
                      </div>
                      <StatusPill value={computed} />
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">{credentialStatuses.map((status) => <button key={status} className="btn-secondary text-xs" onClick={() => void runSave(() => updateCredentialStatus(item.id, status), "Credential status updated.")}>{titleCase(status)}</button>)}</div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : null}

        {!loading && tab === "associated" ? (
          <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
            <form className="card p-5 space-y-4" onSubmit={submitAssociated}>
              <div className="flex items-center gap-3">
                <FiFileText className="h-5 w-5 text-brand-700" />
                <h2 className="text-xl font-semibold text-ink-900">Associated-provider compliance</h2>
              </div>
              <Field label="Associated provider / supplier"><input className="input" value={associatedForm.organisationName} onChange={(e) => setAssociatedForm((v) => ({ ...v, organisationName: e.target.value }))} /></Field>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Registered provider context"><input className="input" value={associatedForm.providerName} onChange={(e) => setAssociatedForm((v) => ({ ...v, providerName: e.target.value }))} /></Field>
                <Field label="Contact email"><input className="input" value={associatedForm.contactEmail} onChange={(e) => setAssociatedForm((v) => ({ ...v, contactEmail: e.target.value }))} /></Field>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Service category"><input className="input" value={associatedForm.serviceCategory} onChange={(e) => setAssociatedForm((v) => ({ ...v, serviceCategory: e.target.value }))} /></Field>
                <Field label="Agreement status"><select className="select" value={associatedForm.agreementStatus} onChange={(e) => setAssociatedForm((v) => ({ ...v, agreementStatus: e.target.value as AssociatedProviderStatus }))}>{associatedStatuses.map((item) => <option key={item} value={item}>{titleCase(item)}</option>)}</select></Field>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Insurance expiry"><input className="input" type="date" value={associatedForm.insuranceExpiry} onChange={(e) => setAssociatedForm((v) => ({ ...v, insuranceExpiry: e.target.value }))} /></Field>
                <Field label="Screening status"><input className="input" value={associatedForm.screeningStatus} onChange={(e) => setAssociatedForm((v) => ({ ...v, screeningStatus: e.target.value }))} /></Field>
              </div>
              <Field label="Notes"><textarea className="input min-h-[90px]" value={associatedForm.notes} onChange={(e) => setAssociatedForm((v) => ({ ...v, notes: e.target.value }))} /></Field>
              <button className="btn-primary" type="submit" disabled={saving}>{saving ? "Saving..." : "Create associated-provider record"}</button>
            </form>
            <div className="space-y-4">
              {associatedProviders.length === 0 ? <div className="card p-5 text-sm text-ink-600">No associated-provider records yet.</div> : associatedProviders.map((item) => (
                <div key={item.id} className="card p-5">
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-ink-900">{item.organisationName}</h3>
                      <p className="mt-1 text-sm text-ink-600">{item.providerName || "No provider context"} · {item.serviceCategory || "No category"}</p>
                      <p className="mt-2 text-sm text-ink-700">Insurance: {toDateLabel(item.insuranceExpiry)} · Screening: {item.screeningStatus || "Not recorded"}</p>
                    </div>
                    <StatusPill value={item.agreementStatus} />
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">{associatedStatuses.map((status) => <button key={status} className="btn-secondary text-xs" onClick={() => void runSave(() => updateAssociatedProviderStatus(item.id, status), "Associated-provider status updated.")}>{titleCase(status)}</button>)}</div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {!loading && tab === "incidents" ? (
          <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
            <form className="card p-5 space-y-4" onSubmit={submitIncident}>
              <div className="flex items-center gap-3">
                <FiAlertCircle className="h-5 w-5 text-rose-600" />
                <h2 className="text-xl font-semibold text-ink-900">Incident/complaint workflow</h2>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Type"><select className="select" value={incidentForm.type} onChange={(e) => setIncidentForm((v) => ({ ...v, type: e.target.value as IncidentComplaintType }))}><option value="incident">Incident</option><option value="complaint">Complaint</option></select></Field>
                <Field label="Title"><input className="input" value={incidentForm.title} onChange={(e) => setIncidentForm((v) => ({ ...v, title: e.target.value }))} /></Field>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Provider context"><input className="input" value={incidentForm.providerName} onChange={(e) => setIncidentForm((v) => ({ ...v, providerName: e.target.value }))} /></Field>
                <Field label="Participant reference"><input className="input" value={incidentForm.participantReference} onChange={(e) => setIncidentForm((v) => ({ ...v, participantReference: e.target.value }))} /></Field>
              </div>
              <div className="grid gap-3 md:grid-cols-3">
                <Field label="Severity"><select className="select" value={incidentForm.severity} onChange={(e) => setIncidentForm((v) => ({ ...v, severity: e.target.value as IncidentComplaintSeverity }))}>{(["low", "medium", "high", "critical"] as IncidentComplaintSeverity[]).map((item) => <option key={item} value={item}>{titleCase(item)}</option>)}</select></Field>
                <Field label="Status"><select className="select" value={incidentForm.status} onChange={(e) => setIncidentForm((v) => ({ ...v, status: e.target.value as IncidentComplaintStatus }))}>{incidentStatuses.map((item) => <option key={item} value={item}>{titleCase(item)}</option>)}</select></Field>
                <Field label="Due date"><input className="input" type="date" value={incidentForm.dueDate} onChange={(e) => setIncidentForm((v) => ({ ...v, dueDate: e.target.value }))} /></Field>
              </div>
              <Field label="Owner"><input className="input" value={incidentForm.owner} onChange={(e) => setIncidentForm((v) => ({ ...v, owner: e.target.value }))} /></Field>
              <Field label="Summary"><textarea className="input min-h-[100px]" value={incidentForm.summary} onChange={(e) => setIncidentForm((v) => ({ ...v, summary: e.target.value }))} /></Field>
              <button className="btn-primary" type="submit" disabled={saving}>{saving ? "Saving..." : "Create incident/complaint"}</button>
            </form>
            <div className="space-y-4">
              {incidents.length === 0 ? <div className="card p-5 text-sm text-ink-600">No incident or complaint records yet.</div> : incidents.map((item) => (
                <div key={item.id} className="card p-5">
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-ink-900">{item.title}</h3>
                      <p className="mt-1 text-sm text-ink-600">{titleCase(item.type)} · {item.providerName || "No provider context"} · Owner: {item.owner || "Unassigned"}</p>
                      <p className="mt-2 text-sm text-ink-700">Participant: {item.participantReference || "Not recorded"} · Due: {toDateLabel(item.dueDate)}</p>
                      {item.summary ? <p className="mt-3 rounded-2xl bg-sand-100/80 p-3 text-sm leading-6 text-ink-700">{item.summary}</p> : null}
                    </div>
                    <div className="flex flex-col items-start gap-2 md:items-end">
                      <StatusPill value={item.severity} />
                      <StatusPill value={item.status} />
                    </div>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">{incidentStatuses.map((status) => <button key={status} className="btn-secondary text-xs" onClick={() => void runSave(() => updateIncidentComplaintStatus(item.id, status), "Incident/complaint status updated.")}>{titleCase(status)}</button>)}</div>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </MainLayout>
  );
}
