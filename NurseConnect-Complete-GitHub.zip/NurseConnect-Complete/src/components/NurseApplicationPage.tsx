import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  FiArrowRight,
  FiBriefcase,
  FiCalendar,
  FiCheckCircle,
  FiClipboard,
  FiDollarSign,
  FiFileText,
  FiGlobe,
  FiShield,
  FiUsers,
} from "./PublicIcons";
import { submitNurseRegistrationInterest } from "../lib/publicSubmissions";
import { NURSE_TYPE_OPTIONS } from "../lib/nurses";
import EirenixMark from "./EirenixMark";
import PublicSiteChrome from "./PublicSiteChrome";
import { NurseWorkspaceIllustration } from "./PublicVisuals";

const applicationSteps = [
  "Create your nurse account and share your professional details, registration and service focus.",
  "Choose your subscription billing cycle and outline how and where you want to practise.",
  "Move into the secure nurse workspace as your profile and operating details are completed.",
];

const providerBenefits = [
  {
    title: "Be visible without employment dependency",
    body: "Present your own services, service area and professional profile to clients, carers, providers and care managers seeking nursing capacity.",
    icon: FiGlobe,
  },
  {
    title: "Control your practice terms",
    body: "Set your own scope of services, availability, pricing and service terms within applicable rules and provider or funder requirements.",
    icon: FiDollarSign,
  },
  {
    title: "Operate with proper clinical systems",
    body: "Use the connected nurse workspace for documentation, consents, notes and audit-ready records.",
    icon: FiFileText,
  },
  {
    title: "Manage bookings and continuity",
    body: "Coordinate schedules, follow-up, communication and practice operations from one connected environment.",
    icon: FiCalendar,
  },
];

export default function NurseApplicationPage() {
  type FormValues = {
    name: string;
    email: string;
    region: string;
    role: string;
    nurseType: string;
    ahpraRegistrationNumber: string;
    travelRadius: string;
    visitTypes: string[];
    fundingModels: string[];
    focus: string;
  };

  const [formValues, setFormValues] = useState<FormValues>({
    name: "",
    email: "",
    region: "",
    role: "",
    nurseType: "",
    ahpraRegistrationNumber: "",
    travelRadius: "",
    visitTypes: [] as string[],
    fundingModels: [] as string[],
    focus: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  function updateField<K extends keyof FormValues>(field: K, value: FormValues[K]) {
    setFormValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      const next = { ...current };
      delete next[field];
      return next;
    });
    setSubmitted(false);
    setSubmitError("");
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const nextErrors: Record<string, string> = {};

    if (!formValues.name.trim()) nextErrors.name = "Please enter your name.";
    if (!formValues.email.trim()) {
      nextErrors.email = "Please enter your email address.";
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      nextErrors.email = "Please enter a valid email address.";
    }
    if (!formValues.region.trim()) nextErrors.region = "Please enter your primary service region.";
    if (!formValues.role) nextErrors.role = "Please select your professional role.";
    if (!formValues.nurseType) nextErrors.nurseType = "Please select your nurse type.";
    if (!formValues.ahpraRegistrationNumber.trim()) nextErrors.ahpraRegistrationNumber = "Please enter your AHPRA registration number.";
    if (!formValues.travelRadius.trim()) nextErrors.travelRadius = "Please describe your travel radius or service coverage.";
    if (formValues.visitTypes.length === 0) nextErrors.visitTypes = "Please choose at least one visit type.";
    if (formValues.fundingModels.length === 0) nextErrors.fundingModels = "Please choose at least one funding pathway.";
    if (!formValues.focus.trim()) nextErrors.focus = "Please describe your service focus.";

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      setSubmitted(false);
      return;
    }

    setSubmitting(true);
    setSubmitError("");

    try {
      await submitNurseRegistrationInterest({
        fullName: formValues.name,
        email: formValues.email,
        primaryRegion: formValues.region,
        professionalRole: formValues.role,
        nurseType: formValues.nurseType,
        ahpraRegistrationNumber: formValues.ahpraRegistrationNumber,
        travelRadius: formValues.travelRadius,
        visitTypes: formValues.visitTypes,
        fundingModels: formValues.fundingModels,
        serviceFocus: formValues.focus,
      });
      setSubmitted(true);
      setFormValues({
        name: "",
        email: "",
        region: "",
        role: "",
        nurseType: "",
        ahpraRegistrationNumber: "",
        travelRadius: "",
        visitTypes: [],
        fundingModels: [],
        focus: "",
      });
    } catch (error: any) {
      setSubmitted(false);
      setSubmitError(error?.message || "We could not submit your registration interest right now. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <PublicSiteChrome
      ctaLabel="Register as nurse"
      ctaTo="/for-nurses/apply"
      metaTitle="NurseConnectCare | Nurse Registration"
      metaDescription="Learn how independent nurses can register with NurseConnectCare and access the connected EIRENIX Care™ nurse workspace."
    >
      <section className="mx-auto grid w-full max-w-7xl gap-10 px-4 pb-14 pt-8 sm:px-6 lg:grid-cols-[1fr_0.92fr] lg:px-8 lg:pt-14">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-4 py-2 text-sm text-ink-700 shadow-soft backdrop-blur">
            <FiBriefcase className="h-4 w-4 text-brand-700" />
            Nurse registration and onboarding
          </div>
          <h1 className="mt-6 text-4xl leading-tight text-ink-900 sm:text-5xl">
            Build an independent nursing practice with the right infrastructure behind it.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-700">
            NurseConnectCare is for registered nurses, enrolled nurses and nurse practitioners who want visibility,
            booking tools, subscription-based practice access and connected clinical systems while operating independently.
          </p>

          <div className="mt-8 grid gap-4 border-y border-ink-200 py-5 sm:grid-cols-3">
            <div>
              <FiUsers className="h-5 w-5 text-brand-700" />
              <p className="mt-3 text-sm font-semibold text-ink-900">Independent practice</p>
              <p className="mt-2 text-sm leading-6 text-ink-600">Infrastructure, not employment or clinical direction.</p>
            </div>
            <div>
              <FiClipboard className="h-5 w-5 text-brand-700" />
              <p className="mt-3 text-sm font-semibold text-ink-900">Practice operations</p>
              <p className="mt-2 text-sm leading-6 text-ink-600">Availability, bookings, documentation and service pathways.</p>
            </div>
            <div>
              <FiShield className="h-5 w-5 text-brand-700" />
              <p className="mt-3 text-sm font-semibold text-ink-900">Provider-aware requests</p>
              <p className="mt-2 text-sm leading-6 text-ink-600">Client, provider, funding and care-plan context before acceptance.</p>
            </div>
          </div>
        </div>

        <div className="rounded-[28px] border border-ink-200 bg-ink-900 p-6 text-white shadow-lift">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Self-sign-up pathway</p>
          <h2 className="mt-3 text-3xl text-white">Prepare your public practice profile.</h2>
          <p className="mt-4 text-sm leading-7 text-white/70">
            This page now frames nurse self-sign-up, subscription selection and onboarding before the deeper <EirenixMark /> configuration and practice setup.
          </p>

          <div className="mt-6 space-y-4">
            {applicationSteps.map((step, index) => (
              <div key={step} className="border-t border-white/10 p-4">
                <div className="flex gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-sm font-semibold text-brand-200">
                    {index + 1}
                  </div>
                  <p className="text-sm leading-7 text-white/75">{step}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 rounded-[20px] bg-white p-5 text-ink-900">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Secure workspace</p>
            <p className="mt-3 text-xl font-semibold leading-8">Already have an account?</p>
            <p className="mt-2 text-sm leading-6 text-ink-600">
              Use nurse access to create your account or move into the <EirenixMark />-connected nurse practice environment.
            </p>
            <Link to="/clinician-login?mode=signup" className="mt-5 inline-flex items-center gap-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700">
              Create nurse account
              <FiArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/for-nurses/cpd" className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-brand-700 transition hover:text-ink-900">
              View Nurses CPD
              <FiArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="border-y border-ink-200/80 bg-white/80 py-14">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">Why nurses join</p>
            <h2 className="mt-3 text-3xl sm:text-4xl">A provider-facing model with stronger practice foundations.</h2>
            <p className="mt-5 text-lg leading-8 text-ink-700">
              The platform is designed for sole-trader and independent nursing models, with booking, provider-aware requests, visibility and connected records working together.
            </p>
          </div>

          <div className="mt-8 grid gap-4 lg:grid-cols-2">
            {providerBenefits.map(({ title, body, icon: Icon }) => (
              <article key={title} className="border-t border-ink-200 bg-sand-100/80 p-5 shadow-soft">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-brand-700">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 text-xl">{title}</h3>
                <p className="mt-2 text-sm leading-7 text-ink-700">{body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="mx-auto grid w-full max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.92fr_1.08fr] lg:px-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">Application checklist</p>
            <h2 className="mt-3 text-3xl sm:text-4xl">What you will typically need</h2>
            <p className="mt-5 text-lg leading-8 text-ink-700">
              This keeps the website realistic for nurses while making room for the later <EirenixMark /> adaptation.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {[
              "AHPRA registration details",
              "Indemnity and insurance position",
              "Service focus and scope of care",
              "Travel radius and preferred service locations",
              "Availability and appointment preferences",
              "Funding pathways and pricing approach",
            ].map((item) => (
              <div key={item} className="border-t border-ink-200 bg-white p-5 shadow-soft">
                <div className="flex gap-3">
                  <FiCheckCircle className="mt-1 h-5 w-5 shrink-0 text-brand-700" />
                  <p className="text-sm leading-7 text-ink-700">{item}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-6 overflow-hidden rounded-[28px] border border-ink-200/80 bg-[linear-gradient(135deg,rgba(14,42,59,0.96)_0%,rgba(31,154,146,0.9)_100%)] p-8 text-white shadow-lift">
            <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Connected practice environment</p>
                <h2 className="mt-3 text-3xl text-white sm:text-4xl">Registration leads into a more structured clinical workflow.</h2>
                <p className="mt-4 text-lg leading-8 text-white/80">
                  Public registration is the front door. Ongoing scheduling, records, documentation and practice
                  operations connect through the secure <EirenixMark /> environment.
                </p>
              </div>
              <div className="space-y-4">
                <NurseWorkspaceIllustration />
                <div className="grid grid-cols-2 gap-3">
                  <div className="border-t border-white/10 bg-white/10 p-5 backdrop-blur-sm">
                    <p className="text-sm font-semibold text-white">Scheduling</p>
                    <p className="mt-2 text-sm leading-6 text-white/70">Availability, bookings and continuity of care.</p>
                  </div>
                  <div className="border-t border-white/10 bg-white/10 p-5 backdrop-blur-sm">
                    <p className="text-sm font-semibold text-white">Notes</p>
                    <p className="mt-2 text-sm leading-6 text-white/70">Clinical documentation and audit-ready records.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="grid gap-6 rounded-[28px] border border-ink-200 bg-white p-8 shadow-soft lg:grid-cols-[1.05fr_0.95fr]">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">First-use setup details</p>
              <h2 className="mt-3 text-3xl sm:text-4xl">Nurse self-sign-up preparation</h2>
              <p className="mt-4 text-lg leading-8 text-ink-700">
                This public-facing form captures the profile details nurses typically prepare before creating their account and moving into subscription setup.
              </p>
            </div>

            <form className="grid gap-4" noValidate onSubmit={handleSubmit}>
              <div>
                <label htmlFor="nurse-name" className="label">
                  Full name
                </label>
                <input
                  id="nurse-name"
                  className="input"
                  placeholder="Full name"
                  autoComplete="name"
                  value={formValues.name}
                  onChange={(event) => updateField("name", event.target.value)}
                  aria-invalid={errors.name ? "true" : "false"}
                  aria-describedby={errors.name ? "nurse-name-error" : undefined}
                />
                {errors.name ? <p id="nurse-name-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.name}</p> : null}
              </div>
              <div>
                <label htmlFor="nurse-email" className="label">
                  Email address
                </label>
                <input
                  id="nurse-email"
                  className="input"
                  placeholder="Email address"
                  type="email"
                  autoComplete="email"
                  value={formValues.email}
                  onChange={(event) => updateField("email", event.target.value)}
                  aria-invalid={errors.email ? "true" : "false"}
                  aria-describedby={errors.email ? "nurse-email-error" : undefined}
                />
                {errors.email ? <p id="nurse-email-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.email}</p> : null}
              </div>
              <div>
                <label htmlFor="nurse-region" className="label">
                  Primary service region
                </label>
                <input
                  id="nurse-region"
                  className="input"
                  placeholder="Primary service region"
                  value={formValues.region}
                  onChange={(event) => updateField("region", event.target.value)}
                  aria-invalid={errors.region ? "true" : "false"}
                  aria-describedby={errors.region ? "nurse-region-error" : undefined}
                />
                {errors.region ? <p id="nurse-region-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.region}</p> : null}
              </div>
              <div>
                <label htmlFor="nurse-role" className="label">
                  Professional role
                </label>
                <select
                  id="nurse-role"
                  className="select"
                  value={formValues.role}
                  onChange={(event) => updateField("role", event.target.value)}
                  aria-invalid={errors.role ? "true" : "false"}
                  aria-describedby={errors.role ? "nurse-role-error" : undefined}
                >
                  <option value="" disabled>
                    Professional role
                  </option>
                  <option>Registered nurse</option>
                  <option>Enrolled nurse</option>
                  <option>Nurse practitioner</option>
                </select>
                {errors.role ? <p id="nurse-role-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.role}</p> : null}
              </div>
              <div>
                <label htmlFor="nurse-type" className="label">
                  Nurse type
                </label>
                <select
                  id="nurse-type"
                  className="select"
                  value={formValues.nurseType}
                  onChange={(event) => updateField("nurseType", event.target.value)}
                  aria-invalid={errors.nurseType ? "true" : "false"}
                  aria-describedby={errors.nurseType ? "nurse-type-error" : undefined}
                >
                  <option value="" disabled>
                    Select nurse type
                  </option>
                  {NURSE_TYPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                {errors.nurseType ? <p id="nurse-type-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.nurseType}</p> : null}
              </div>
              <div>
                <label htmlFor="nurse-ahpra" className="label">
                  AHPRA registration number
                </label>
                <input
                  id="nurse-ahpra"
                  className="input"
                  placeholder="AHPRA registration number"
                  autoCapitalize="characters"
                  value={formValues.ahpraRegistrationNumber}
                  onChange={(event) => updateField("ahpraRegistrationNumber", event.target.value.toUpperCase())}
                  aria-invalid={errors.ahpraRegistrationNumber ? "true" : "false"}
                  aria-describedby={errors.ahpraRegistrationNumber ? "nurse-ahpra-error nurse-ahpra-hint" : "nurse-ahpra-hint"}
                />
                <p id="nurse-ahpra-hint" className="field-hint">Used as an initial trust and verification signal during onboarding review.</p>
                {errors.ahpraRegistrationNumber ? <p id="nurse-ahpra-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.ahpraRegistrationNumber}</p> : null}
              </div>
              <div>
                <label htmlFor="nurse-travel-radius" className="label">
                  Travel radius or service coverage
                </label>
                <input
                  id="nurse-travel-radius"
                  className="input"
                  placeholder="For example: Melbourne inner north and eastern suburbs"
                  value={formValues.travelRadius}
                  onChange={(event) => updateField("travelRadius", event.target.value)}
                  aria-invalid={errors.travelRadius ? "true" : "false"}
                  aria-describedby={errors.travelRadius ? "nurse-travel-radius-error" : undefined}
                />
                {errors.travelRadius ? <p id="nurse-travel-radius-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.travelRadius}</p> : null}
              </div>
              <fieldset className="grid gap-3">
                <legend className="label">Visit types</legend>
                <div className="grid gap-2 sm:grid-cols-2">
                  {["Home visits", "Telehealth", "Aged care support", "After-hours visits"].map((item) => {
                    const checked = formValues.visitTypes.includes(item);
                    return (
                      <label key={item} className="flex items-center gap-3 rounded-[20px] border border-ink-200 bg-sand-100/70 px-4 py-3 text-sm text-ink-700">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={(event) =>
                            updateField(
                              "visitTypes",
                              event.target.checked
                                ? [...formValues.visitTypes, item]
                                : formValues.visitTypes.filter((value) => value !== item)
                            )
                          }
                        />
                        <span>{item}</span>
                      </label>
                    );
                  })}
                </div>
                {errors.visitTypes ? <p className="text-xs leading-5 text-rose-600">{errors.visitTypes}</p> : null}
              </fieldset>
              <fieldset className="grid gap-3">
                <legend className="label">Funding pathways supported</legend>
                <div className="grid gap-2 sm:grid-cols-2">
                  {["Private pay", "Medicare eligible services", "Private health funding", "Package-funded care"].map((item) => {
                    const checked = formValues.fundingModels.includes(item);
                    return (
                      <label key={item} className="flex items-center gap-3 rounded-[20px] border border-ink-200 bg-sand-100/70 px-4 py-3 text-sm text-ink-700">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={(event) =>
                            updateField(
                              "fundingModels",
                              event.target.checked
                                ? [...formValues.fundingModels, item]
                                : formValues.fundingModels.filter((value) => value !== item)
                            )
                          }
                        />
                        <span>{item}</span>
                      </label>
                    );
                  })}
                </div>
                {errors.fundingModels ? <p className="text-xs leading-5 text-rose-600">{errors.fundingModels}</p> : null}
              </fieldset>
              <div>
                <label htmlFor="nurse-focus" className="label">
                  Service focus and care model
                </label>
                <textarea
                  id="nurse-focus"
                  className="textarea min-h-[120px]"
                  placeholder="Briefly describe your service focus and care model"
                  value={formValues.focus}
                  onChange={(event) => updateField("focus", event.target.value)}
                  aria-invalid={errors.focus ? "true" : "false"}
                  aria-describedby={errors.focus ? "nurse-focus-error nurse-focus-hint" : "nurse-focus-hint"}
                />
                <p id="nurse-focus-hint" className="field-hint">This expression-of-interest form is for general registration enquiries only.</p>
                {errors.focus ? <p id="nurse-focus-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.focus}</p> : null}
              </div>
              <div className="flex flex-col gap-3 sm:flex-row">
                <button type="submit" className="btn-primary" disabled={submitting}>
                  {submitting ? "Submitting..." : "Submit interest"}
                </button>
                <Link to="/clinician-login" className="btn-secondary">
                  Existing nurse login
                </Link>
              </div>
              {submitError ? (
                <div className="rounded-[20px] border border-rose-200 bg-rose-50 px-4 py-3 text-sm leading-6 text-rose-700">
                  {submitError}
                </div>
              ) : null}
              {submitted ? (
                <div className="rounded-[20px] border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm leading-6 text-emerald-800">
                  Your nurse registration interest has been sent successfully and is ready for review in the workflow.
                </div>
              ) : null}
            </form>
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
