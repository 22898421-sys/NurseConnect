// src/components/ProtectedRoute.tsx
import React, { useEffect, useRef } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth, NormalizedRole } from "../contexts/AuthContext";

type ProtectedRouteProps = {
  children: React.ReactNode;
  allowedRoles?: NormalizedRole[];
};

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const { user, currentUserData, normalizedRole, loading, forceLogout } = useAuth() as any;
  const location = useLocation();

  // Prevent multiple forced-logouts from repeated renders.
  const logoutTriggeredRef = useRef(false);

  const role: NormalizedRole = (normalizedRole || "") as NormalizedRole;
  const isInactive = Boolean(currentUserData && currentUserData.active === false);
  const isUnprovisioned = Boolean(user && !role);
  const isForbidden = Boolean(
    user && role && allowedRoles && allowedRoles.length > 0 && !allowedRoles.includes(role)
  );

  useEffect(() => {
    if (loading) return;
    if (!user) return;
    if (logoutTriggeredRef.current) return;

    if (isInactive) {
      logoutTriggeredRef.current = true;
      void forceLogout("inactive");
      return;
    }

    if (isUnprovisioned) {
      logoutTriggeredRef.current = true;
      void forceLogout("unprovisioned");
      return;
    }

    if (isForbidden) {
      logoutTriggeredRef.current = true;
      void forceLogout("forbidden");
    }
  }, [loading, user, isInactive, isUnprovisioned, isForbidden, forceLogout]);

  if (loading) return null;

  if (!user) {
    return <Navigate to="/" replace state={{ from: location.pathname }} />;
  }

  if (!role) {
    return <Navigate to="/" replace state={{ from: location.pathname, reason: "unprovisioned" }} />;
  }

  if (allowedRoles && allowedRoles.length > 0 && !allowedRoles.includes(role)) {
    return <Navigate to="/" replace state={{ from: location.pathname, reason: "forbidden" }} />;
  }

  if (isInactive) {
    return <Navigate to="/" replace state={{ from: location.pathname, reason: "inactive" }} />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;