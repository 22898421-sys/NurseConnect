// src/components/EncounterPrintPage.tsx
import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { collection, doc, getDoc, getDocs, limit, orderBy, query } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { formatProviderLabel, resolveProvider, resolveProviderLabel } from "../lib/provider";
import { Patient } from "../models/emr";
import { formatToDDMMYYYY } from "../lib/dates";
import { useAuth } from "../contexts/AuthContext";
import { logSensitiveAccess } from "../lib/accessAudit";

type RevisionMode = "edit" | "addendum" | "correction_addendum" | "sign_override";

type SoapRevision = {
  id: string;
  editedAt?: any;
  editorId?: string;
  editorDisplayName?: string | null;
  mode: RevisionMode;
  summary?: string | null;
};

type SoapFields = {
  subjective?: string;
  objective?: string;
  assessment?: string;
  plan?: string;
};

type EncounterRecord = {
  id: string;
  patientId: string;
  practitionerId?: string;

  // Step 6 (optional denormalised fields)
  practitionerDisplayName?: string;
  practitionerLabel?: string;

  encounterDate: string; // DD-MM-YYYY
  type?: string;
  reason?: string;

  status?: "draft" | "completed";

  soap?: SoapFields;
  notes?: string;

  breakGlass?: {
    enabled?: boolean;
    enabledBy?: string;
    enabledAt?: any;
    reason?: string;
    resolvedBy?: string;
    resolvedAt?: any;
    correctionReason?: string;
  };

  createdAt?: any;
  updatedAt?: any;
};

function safeStr(v: any): string {
  return typeof v === "string" ? v : "";
}

function toDateStringMaybe(t: any): string {
  try {
    if (!t) return "";
    if (typeof t?.toDate === "function") {
      const d: Date = t.toDate();
      return d.toLocaleString();
    }
    if (typeof t?.seconds === "number") {
      const d = new Date(t.seconds * 1000);
      return d.toLocaleString();
    }
    return "";
  } catch {
    return "";
  }
}

function modeLabel(m: RevisionMode) {
  switch (m) {
    case "edit":
      return "Draft edit";
    case "addendum":
      return "Addendum";
    case "correction_addendum":
      return "Correction addendum (break-glass)";
    case "sign_override":
      return "Signing / override event";
    default:
      return "Revision";
  }
}

function typeLabel(t?: string) {
  if (!t) return "Encounter";
  if (t === "consultation") return "Consultation";
  if (t === "follow_up") return "Follow-up";
  if (t === "procedure") return "Procedure";
  return t;
}

const EncounterPrintPage: React.FC = () => {
  const { patientId, encounterId } = useParams<{ patientId: string; encounterId: string }>();
  const { user, normalizedRole, currentUserData } = useAuth() as any;

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [patient, setPatient] = useState<Patient | null>(null);
  const [encounter, setEncounter] = useState<EncounterRecord | null>(null);

  const [practitionerLabel, setPractitionerLabel] = useState<string>("—");
  const [revisionUserMap, setRevisionUserMap] = useState<Record<string, string>>({});
  const [revisions, setRevisions] = useState<SoapRevision[]>([]);

  const isSigned = useMemo(() => (encounter?.status ?? "draft") === "completed", [encounter?.status]);
  const breakGlassEnabled = useMemo(() => !!encounter?.breakGlass?.enabled, [encounter?.breakGlass?.enabled]);

  useEffect(() => {
    const run = async () => {
      setLoading(true);
      setErr(null);
      setPatient(null);
      setEncounter(null);
      setPractitionerLabel("—");
      setRevisionUserMap({});
      setRevisions([]);

      if (!patientId || !encounterId) {
        setErr("Missing patient or encounter ID.");
        setLoading(false);
        return;
      }

      try {
        // Patient
        const pSnap = await getDoc(doc(db, "patients", patientId));
        if (pSnap.exists()) {
          setPatient({ id: pSnap.id, ...(pSnap.data() as any) });
        }

        // Encounter
        const eSnap = await getDoc(doc(db, "encounters", encounterId));
        if (!eSnap.exists()) {
          setErr("Encounter not found.");
          setLoading(false);
          return;
        }

        const enc = { id: eSnap.id, ...(eSnap.data() as any) } as EncounterRecord;
        setEncounter(enc);

        if (user?.uid) {
          void logSensitiveAccess({
            actorUid: user.uid,
            role: normalizedRole,
            action: "read_encounter",
            resourceType: "encounter_print",
            resourceId: enc.id,
            patientId,
            practiceId: currentUserData?.practiceId || null,
            encounterId: enc.id,
          });
        }

        // Practitioner label (prefer denormalised Step 6 fields, otherwise resolve)
        if (safeStr(enc.practitionerLabel)) {
          setPractitionerLabel(enc.practitionerLabel!);
        } else if (safeStr(enc.practitionerDisplayName)) {
          setPractitionerLabel(enc.practitionerDisplayName!);
        } else if (safeStr(enc.practitionerId)) {
          const ident = await resolveProvider(enc.practitionerId!);
          setPractitionerLabel(formatProviderLabel(ident, { includeRole: true }) || (ident.displayName || "—"));
        }

        // Revisions (audit trail)
        try {
          const revQ = query(
            collection(db, "encounters", encounterId, "soapRevisions"),
            orderBy("editedAt", "desc"),
            limit(200)
          );
          const revSnap = await getDocs(revQ);
          const rows: SoapRevision[] = revSnap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })) as any;
          setRevisions(rows);

          // Resolve editor IDs (labels)
          const uids = Array.from(new Set(rows.map((r) => safeStr(r.editorId)).filter((x) => !!x)));

          const mapped: Record<string, string> = {};
          await Promise.all(
            uids.map(async (uid) => {
              mapped[uid] = await resolveProviderLabel(uid, { includeRole: true });
            })
          );
          setRevisionUserMap(mapped);
        } catch {
          setRevisions([]);
          setRevisionUserMap({});
        }
      } catch (e: any) {
        console.error("Print page load error:", e);
        setErr(e?.message ?? "Failed to load encounter for printing.");
      } finally {
        setLoading(false);
      }
    };

    void run();
  }, [currentUserData?.practiceId, patientId, encounterId, normalizedRole, user?.uid]);

  return (
    <div className="min-h-screen bg-gray-50">
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
        }
      `}</style>

      <div className="no-print sticky top-0 z-10 bg-white border-b">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm text-gray-600">Encounter Report</div>
            <div className="text-base font-semibold truncate">
              {patient?.fullName ? patient.fullName : "Patient"} • {encounter?.encounterDate ?? "—"}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link
              to={`/patients/${patientId}/chart/encounters/${encounterId}`}
              className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
            >
              Back
            </Link>
            <button
              onClick={() => window.print()}
              className="px-3 py-2 rounded-md border text-sm bg-white hover:bg-gray-50"
            >
              Print / Save PDF
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        {loading ? (
          <div className="text-sm text-gray-700">Loading…</div>
        ) : err ? (
          <div className="text-sm text-red-700">{err}</div>
        ) : !encounter ? (
          <div className="text-sm text-gray-700">No encounter data.</div>
        ) : (
          <div className="space-y-6">
            <div className="bg-white border rounded-xl p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-xl font-semibold text-gray-900">
                    {typeLabel(encounter.type)} • {encounter.encounterDate}
                  </div>
                  <div className="mt-1 text-sm text-gray-700">
                    Practitioner: <span className="font-medium">{practitionerLabel}</span>
                  </div>

                  {safeStr(encounter.reason) ? (
                    <div className="mt-2 text-sm text-gray-800">
                      <span className="font-medium">Reason:</span> {encounter.reason}
                    </div>
                  ) : null}

                  <div className="mt-2 text-sm">
                    Status: <span className="font-medium">{isSigned ? "Signed (locked)" : "Draft"}</span>
                    {breakGlassEnabled ? (
                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs border bg-amber-50 border-amber-200 text-amber-800">
                        Break-glass enabled
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="text-sm text-gray-700">
                  {safeStr(patient?.fullName) ? (
                    <div className="font-medium text-gray-900">{patient!.fullName}</div>
                  ) : (
                    <div className="font-medium text-gray-900">Patient</div>
                  )}
                  <div>
                    {safeStr(patient?.dateOfBirth) ? <>DOB: {formatToDDMMYYYY(patient!.dateOfBirth)}</> : null}
                    {safeStr(patient?.sex) ? (
                      <>
                        {safeStr(patient?.dateOfBirth) ? " • " : ""}
                        Sex: {patient!.sex}
                      </>
                    ) : null}
                  </div>
                  <div>
                    {safeStr(patient?.email) ? patient!.email : null}
                    {safeStr(patient?.email) && safeStr(patient?.phone) ? " • " : null}
                    {safeStr(patient?.phone) ? patient!.phone : null}
                  </div>
                </div>
              </div>

              {(encounter.breakGlass?.enabled || encounter.breakGlass?.resolvedBy) ? (
                <div className="mt-4 border-t pt-4 text-sm">
                  <div className="font-semibold text-gray-900">Break-glass record</div>
                  <div className="mt-1 text-gray-800">
                    Enabled: <span className="font-medium">{encounter.breakGlass?.enabled ? "Yes" : "No"}</span>
                    {safeStr(encounter.breakGlass?.enabledBy) ? <> • By: {encounter.breakGlass!.enabledBy}</> : null}
                    {toDateStringMaybe(encounter.breakGlass?.enabledAt) ? (
                      <> • At: {toDateStringMaybe(encounter.breakGlass?.enabledAt)}</>
                    ) : null}
                  </div>
                  {safeStr(encounter.breakGlass?.reason) ? (
                    <div className="mt-1 text-gray-800">
                      Reason: <span className="font-medium">{encounter.breakGlass!.reason}</span>
                    </div>
                  ) : null}

                  {safeStr(encounter.breakGlass?.resolvedBy) ? (
                    <div className="mt-2 text-gray-800">
                      Resolved by: <span className="font-medium">{encounter.breakGlass!.resolvedBy}</span>
                      {toDateStringMaybe(encounter.breakGlass?.resolvedAt) ? (
                        <> • At: {toDateStringMaybe(encounter.breakGlass?.resolvedAt)}</>
                      ) : null}
                    </div>
                  ) : null}

                  {safeStr(encounter.breakGlass?.correctionReason) ? (
                    <div className="mt-1 text-gray-800">
                      Correction reason: <span className="font-medium">{encounter.breakGlass!.correctionReason}</span>
                    </div>
                  ) : null}
                </div>
              ) : null}
            </div>

            <div className="bg-white border rounded-xl p-5">
              <div className="text-lg font-semibold text-gray-900">SOAP</div>

              <div className="mt-4 space-y-4 text-sm text-gray-900">
                <section>
                  <div className="font-semibold">Subjective</div>
                  <div className="mt-1 whitespace-pre-wrap">{safeStr(encounter.soap?.subjective) || "—"}</div>
                </section>

                <section>
                  <div className="font-semibold">Objective</div>
                  <div className="mt-1 whitespace-pre-wrap">{safeStr(encounter.soap?.objective) || "—"}</div>
                </section>

                <section>
                  <div className="font-semibold">Assessment</div>
                  <div className="mt-1 whitespace-pre-wrap">{safeStr(encounter.soap?.assessment) || "—"}</div>
                </section>

                <section>
                  <div className="font-semibold">Plan</div>
                  <div className="mt-1 whitespace-pre-wrap">{safeStr(encounter.soap?.plan) || "—"}</div>
                </section>

                {safeStr(encounter.notes) ? (
                  <section>
                    <div className="font-semibold">Notes</div>
                    <div className="mt-1 whitespace-pre-wrap">{encounter.notes}</div>
                  </section>
                ) : null}
              </div>
            </div>

            <div className="bg-white border rounded-xl p-5">
              <div className="text-lg font-semibold text-gray-900">Audit trail</div>
              <div className="mt-1 text-sm text-gray-700">
                Latest events first. Draft edits, signing, addenda, and correction addenda (break-glass) are recorded here.
              </div>

              {revisions.length === 0 ? (
                <div className="mt-4 text-sm text-gray-700">No revision events found.</div>
              ) : (
                <div className="mt-4 space-y-3">
                  {revisions.map((r) => {
                    const editorUid = safeStr(r.editorId);
                    const stored = safeStr((r as any).editorDisplayName);
                    const editorLabel = stored || (editorUid ? revisionUserMap[editorUid] || editorUid : "—");

                    return (
                      <div key={r.id} className="border rounded-lg p-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="text-sm font-semibold text-gray-900">{modeLabel(r.mode)}</div>
                          <div className="text-xs text-gray-600">{toDateStringMaybe(r.editedAt) || "—"}</div>
                        </div>
                        <div className="mt-1 text-sm text-gray-800">
                          Editor: <span className="font-medium">{editorLabel}</span>
                        </div>
                        {safeStr(r.summary) ? (
                          <div className="mt-2 text-sm text-gray-900 whitespace-pre-wrap">{r.summary}</div>
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="text-xs text-gray-600">
              Generated from EIRENIX Care™ encounter record. Printing should be performed from a signed encounter where possible.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EncounterPrintPage;
