import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { Patient } from "../models/emr";
import { resolveProviderLabel } from "../lib/provider";
import { formatToDDMMYYYY } from "../lib/dates";

type UploadDoc = {
  kind?: string;
  title?: string;
  status?: string;
  practiceId?: string;
  createdByUid?: string;
  printablePayload?: Record<string, any>;
};

function safe(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function patientIdentifier(patient: Patient | null): string {
  if (!patient) return "—";
  return safe(patient.urNumber) || safe(patient.medicareCardNumber) || safe(patient.idNumber) || patient.id;
}

function EirenixMark() {
  return (
    <svg className="h-12 w-12 shrink-0" viewBox="0 0 64 64" role="img" aria-label="EIRENIX Care trademark" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="26" fill="none" stroke="#1F9A92" strokeWidth="4" />
      <path d="M32 18v28" stroke="#1F9A92" strokeWidth="4" strokeLinecap="round" />
      <path d="M18 32h28" stroke="#1F9A92" strokeWidth="4" strokeLinecap="round" />
      <circle cx="32" cy="32" r="2.6" fill="#9BE6D6" />
    </svg>
  );
}

const ClinicalActionPrintPage: React.FC = () => {
  const { patientId, docId } = useParams<{ patientId: string; docId: string }>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [upload, setUpload] = useState<UploadDoc | null>(null);
  const [prescriberLabel, setPrescriberLabel] = useState("—");

  useEffect(() => {
    const run = async () => {
      setLoading(true);
      setError(null);
      try {
        if (!patientId || !docId) throw new Error("Missing patient or document ID.");
        const [patientSnap, uploadSnap] = await Promise.all([
          getDoc(doc(db, "patients", patientId)),
          getDoc(doc(db, "patients", patientId, "portalDocuments", docId)),
        ]);
        if (patientSnap.exists()) setPatient({ id: patientSnap.id, ...(patientSnap.data() as any) });
        if (!uploadSnap.exists()) throw new Error("Document not found.");
        const nextUpload = uploadSnap.data() as UploadDoc;
        if (safe(nextUpload.kind) !== "prescription") {
          throw new Error("This document is not an active prescription printout in the NurseConnectCare build.");
        }
        setUpload(nextUpload);
        const orderedByUid = safe(nextUpload.printablePayload?.orderedByUid || nextUpload.createdByUid);
        if (orderedByUid) setPrescriberLabel(await resolveProviderLabel(orderedByUid, { includeRole: true }));
      } catch (e: any) {
        setError(e?.message || "Failed to load prescription.");
      } finally {
        setLoading(false);
      }
    };
    void run();
  }, [docId, patientId]);

  const payload = upload?.printablePayload || {};
  const issuerLabel = safe(payload.issuingClinicianLabel) || prescriberLabel;
  const title = useMemo(() => safe(upload?.title) || safe(payload.title) || "Prescription", [payload.title, upload?.title]);

  return (
    <div className="min-h-screen bg-gray-50">
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
          .print-shell { max-width: none !important; width: 100% !important; padding: 0 !important; }
        }
      `}</style>

      <div className="no-print sticky top-0 z-10 bg-white border-b">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div>
            <div className="text-sm text-gray-600">Prescription</div>
            <div className="text-base font-semibold">{patient?.fullName || "Patient"} • {title}</div>
          </div>
          <div className="flex items-center gap-2">
            <Link to={patientId ? "/patient" : "/dashboard"} className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50">Back</Link>
            <button onClick={() => window.print()} className="px-3 py-2 rounded-md border text-sm bg-white hover:bg-gray-50">Print / Save PDF</button>
          </div>
        </div>
      </div>

      <div className="print-shell max-w-5xl mx-auto px-4 py-6">
        {loading ? (
          <div className="text-sm text-gray-700">Loading…</div>
        ) : error ? (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">{error}</div>
        ) : !upload ? (
          <div className="text-sm text-gray-700">No prescription data.</div>
        ) : (
          <div className="bg-white border rounded-xl overflow-hidden">
            <div className="border-b bg-gray-50 px-5 py-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3">
                    <EirenixMark />
                    <div>
                      <div className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-600">EIRENIX CARE™</div>
                      <div className="text-xs uppercase tracking-wide text-gray-500">Prescription</div>
                    </div>
                  </div>
                  <div className="mt-3 text-2xl font-semibold text-gray-900">{title}</div>
                  <div className="mt-2 flex flex-wrap gap-2 text-xs">
                    <span className="rounded-full border bg-white px-2 py-0.5">
                      Date: {safe(payload.dateLabel) || (safe(payload.date) ? formatToDDMMYYYY(safe(payload.date)) : "—")}
                    </span>
                    <span className="rounded-full border bg-white px-2 py-0.5">
                      Status: {safe(upload.status) || "active"}
                    </span>
                  </div>
                </div>
                <div className="text-sm text-gray-700 min-w-[220px]">
                  <div><span className="font-medium">Prescriber:</span> {issuerLabel || "—"}</div>
                  <div><span className="font-medium">Practice:</span> {safe(upload.practiceId) || "—"}</div>
                </div>
              </div>
            </div>

            <div className="grid gap-0 md:grid-cols-2">
              <section className="border-b md:border-b-0 md:border-r px-5 py-4">
                <div className="text-xs font-semibold uppercase tracking-wide text-gray-600">Patient identification</div>
                <div className="mt-3 grid grid-cols-1 gap-y-2 text-sm text-gray-800">
                  <div><span className="font-medium">Name:</span> {patient?.fullName || "—"}</div>
                  <div><span className="font-medium">DOB:</span> {patient?.dateOfBirth ? formatToDDMMYYYY(patient.dateOfBirth) : "—"}</div>
                  <div><span className="font-medium">Identifier:</span> {patientIdentifier(patient)}</div>
                </div>
              </section>
              <section className="px-5 py-4">
                <div className="text-xs font-semibold uppercase tracking-wide text-gray-600">Medication instructions</div>
                <div className="mt-3 grid grid-cols-1 gap-y-2 text-sm text-gray-800">
                  <div><span className="font-medium">Medication:</span> {title}</div>
                  <div><span className="font-medium">Strength:</span> {safe(payload.strength) || "—"}</div>
                  <div><span className="font-medium">Dose:</span> {safe(payload.dose) || "—"}</div>
                  <div><span className="font-medium">Route:</span> {safe(payload.route) || "—"}</div>
                  <div><span className="font-medium">Frequency:</span> {safe(payload.frequency) || "—"}</div>
                  <div><span className="font-medium">Duration:</span> {safe(payload.duration) || "—"}</div>
                  <div><span className="font-medium">Quantity:</span> {safe(payload.quantity) || "—"}</div>
                  <div><span className="font-medium">Repeats:</span> {safe(payload.repeats) || "0"}</div>
                  <div><span className="font-medium">Indication:</span> {safe(payload.clinicalQuestion) || "—"}</div>
                </div>
              </section>
            </div>

            {safe(payload.notes) ? (
              <section className="border-t px-5 py-4">
                <div className="text-xs font-semibold uppercase tracking-wide text-gray-600">Additional notes</div>
                <div className="mt-2 whitespace-pre-wrap text-sm text-gray-800">{safe(payload.notes)}</div>
              </section>
            ) : null}

            <section className="border-t px-5 py-4">
              <div className="text-xs font-semibold uppercase tracking-wide text-gray-600">Tracking notice</div>
              <div className="mt-2 text-sm text-gray-800">
                {safe(payload.clinicTrackingDisclaimer) || "Dispense updates recorded here reflect clinic-reported notifications only."}
              </div>
            </section>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClinicalActionPrintPage;
