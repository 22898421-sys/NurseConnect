import React, { useState } from "react";
import { FiMail, FiMessageSquare, FiPhone } from "./PublicIcons";
import { submitPublicContactEnquiry } from "../lib/publicSubmissions";
import PublicSiteChrome from "./PublicSiteChrome";
import nursePatientImage from "../assets/public-site/pexels-nurse-patient.jpg";

export default function ContactPage() {
  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    type: "",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  function updateField(field: string, value: string) {
    setFormValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      const next = { ...current };
      delete next[field];
      return next;
    });
    setSubmitted(false);
    setSubmitError("");
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const nextErrors: Record<string, string> = {};

    if (!formValues.name.trim()) nextErrors.name = "Please enter your name.";
    if (!formValues.email.trim()) {
      nextErrors.email = "Please enter your email address.";
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      nextErrors.email = "Please enter a valid email address.";
    }
    if (!formValues.type) nextErrors.type = "Please select an enquiry type.";
    if (!formValues.message.trim()) nextErrors.message = "Please enter a short message.";

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      setSubmitted(false);
      return;
    }

    setSubmitting(true);
    setSubmitError("");

    try {
      await submitPublicContactEnquiry({
        fullName: formValues.name,
        email: formValues.email,
        enquiryType: formValues.type,
        message: formValues.message,
      });
      setSubmitted(true);
      setFormValues({
        name: "",
        email: "",
        type: "",
        message: "",
      });
    } catch (error: any) {
      setSubmitted(false);
      setSubmitError(error?.message || "We could not send your enquiry right now. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <PublicSiteChrome
      ctaLabel="Contact Us"
      ctaTo="/contact"
      metaTitle="NurseConnectCare | Contact Us"
      metaDescription="Contact NurseConnectCare for patient, carer, nurse registration and general platform enquiries."
    >
      <section className="mx-auto grid w-full max-w-7xl gap-10 px-4 pb-14 pt-8 sm:px-6 lg:grid-cols-[0.95fr_1.05fr] lg:px-8 lg:pt-14">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-4 py-2 text-sm text-ink-700 shadow-soft backdrop-blur">
            <FiMail className="h-4 w-4 text-brand-700" />
            Contact Us
          </div>
          <h1 className="mt-6 text-4xl leading-tight text-ink-900 sm:text-5xl">Get in touch.</h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-700">
            Use this page for client, carer, nurse registration, provider request and general platform enquiries.
          </p>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-ink-600">
            Keep clinical detail out of this public form. Use secure account workflows once a care request or booking is underway.
          </p>
          <div className="mt-8 overflow-hidden rounded-[30px] border border-ink-200 bg-white shadow-soft">
            <img
              src={nursePatientImage}
              alt="A nurse caring for a patient during a home-style consultation"
              className="h-[260px] w-full object-cover"
            />
          </div>
        </div>

        <div className="grid gap-6">
          <div className="rounded-[28px] border border-ink-200 bg-white p-7 shadow-soft">
            <h2 className="text-3xl">Send an enquiry</h2>
            <p className="mt-3 text-sm leading-7 text-ink-600">
              Choose the enquiry type that best matches your question.
            </p>
            <form className="mt-6 grid gap-4" noValidate onSubmit={handleSubmit}>
              <div>
                <label htmlFor="contact-name" className="label">
                  Full name
                </label>
                <input
                  id="contact-name"
                  className="input"
                  placeholder="Full name"
                  autoComplete="name"
                  value={formValues.name}
                  onChange={(event) => updateField("name", event.target.value)}
                  aria-invalid={errors.name ? "true" : "false"}
                  aria-describedby={errors.name ? "contact-name-error" : undefined}
                />
                {errors.name ? <p id="contact-name-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.name}</p> : null}
              </div>
              <div>
                <label htmlFor="contact-email" className="label">
                  Email address
                </label>
                <input
                  id="contact-email"
                  className="input"
                  placeholder="Email address"
                  type="email"
                  autoComplete="email"
                  value={formValues.email}
                  onChange={(event) => updateField("email", event.target.value)}
                  aria-invalid={errors.email ? "true" : "false"}
                  aria-describedby={errors.email ? "contact-email-error" : undefined}
                />
                {errors.email ? <p id="contact-email-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.email}</p> : null}
              </div>
              <div>
                <label htmlFor="contact-type" className="label">
                  Enquiry type
                </label>
                <select
                  id="contact-type"
                  className="select"
                  value={formValues.type}
                  onChange={(event) => updateField("type", event.target.value)}
                  aria-invalid={errors.type ? "true" : "false"}
                  aria-describedby={errors.type ? "contact-type-error" : "contact-type-hint"}
                >
                  <option value="" disabled>
                    Enquiry type
                  </option>
                  <option>Patient or carer enquiry</option>
                  <option>Nurse registration enquiry</option>
                  <option>Provider or organisation request</option>
                  <option>General support</option>
                </select>
                <p id="contact-type-hint" className="field-hint">Choose the option that best matches your question.</p>
                {errors.type ? <p id="contact-type-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.type}</p> : null}
              </div>
              <div>
                <label htmlFor="contact-message" className="label">
                  Message
                </label>
                <textarea
                  id="contact-message"
                  className="textarea min-h-[140px]"
                  placeholder="How can we help?"
                  value={formValues.message}
                  onChange={(event) => updateField("message", event.target.value)}
                  aria-invalid={errors.message ? "true" : "false"}
                  aria-describedby={errors.message ? "contact-message-error contact-message-hint" : "contact-message-hint"}
                />
                <p id="contact-message-hint" className="field-hint">Do not include sensitive clinical information in this public form.</p>
                {errors.message ? <p id="contact-message-error" className="mt-1 text-xs leading-5 text-rose-600">{errors.message}</p> : null}
              </div>
              <button type="submit" className="btn-primary" disabled={submitting}>
                {submitting ? "Sending..." : "Send message"}
              </button>
              {submitError ? (
                <div className="rounded-[20px] border border-rose-200 bg-rose-50 px-4 py-3 text-sm leading-6 text-rose-700">
                  {submitError}
                </div>
              ) : null}
              {submitted ? (
                <div className="rounded-[20px] border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm leading-6 text-emerald-800">
                  Your enquiry has been sent. A record was created successfully and the NurseConnectCare team can now review it.
                </div>
              ) : null}
            </form>
          </div>

          <div className="rounded-[28px] border border-ink-200 bg-ink-900 p-7 text-white shadow-lift">
            <h2 className="text-3xl text-white">Contact details</h2>
            <div className="mt-6 space-y-5 text-sm leading-7 text-white/75">
              <div className="flex gap-3">
                <FiMail className="mt-1 h-5 w-5 shrink-0 text-brand-200" />
                <div>
                  <p className="font-semibold text-white">Email</p>
                  <p>support@nurseconnectcare.com.au</p>
                </div>
              </div>
              <div className="flex gap-3">
                <FiPhone className="mt-1 h-5 w-5 shrink-0 text-brand-200" />
                <div>
                  <p className="font-semibold text-white">Phone</p>
                  <p>0478012751</p>
                </div>
              </div>
              <div className="flex gap-3">
                <FiMessageSquare className="mt-1 h-5 w-5 shrink-0 text-brand-200" />
                <div>
                  <p className="font-semibold text-white">Nurse registration enquiries</p>
                  <p>Use this contact page or the registration page to express interest.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
