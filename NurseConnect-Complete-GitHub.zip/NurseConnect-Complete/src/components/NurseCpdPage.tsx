import React from "react";
import { Link } from "react-router-dom";
import {
  FiArrowRight,
  FiBriefcase,
  FiCheckCircle,
  FiDollarSign,
  FiFileText,
  FiMonitor,
  FiShield,
} from "./PublicIcons";
import PublicSiteChrome from "./PublicSiteChrome";

const cpdModules = [
  {
    title: "Understanding Support at Home and independent nursing",
    duration: "30 mins",
    body: "A practical overview of Support at Home context, independent-provider boundaries and where NurseConnectCare fits as workflow infrastructure.",
    icon: FiBriefcase,
  },
  {
    title: "Clinical governance, documentation and risk",
    duration: "45 mins",
    body: "How to think about scope, documentation quality, escalation, consent, incident awareness and audit-ready nursing records.",
    icon: FiShield,
  },
  {
    title: "Setting up for safe independent practice",
    duration: "45 mins",
    body: "Foundational practice setup covering registration details, insurance position, service focus, client communication and safe operating limits.",
    icon: FiCheckCircle,
  },
  {
    title: "Introduction to practice financial management",
    duration: "45 mins",
    body: "Introductory finance concepts for independent nurses, including pricing, invoice readiness, records, cash-flow awareness and separating platform tools from payment decisions.",
    icon: FiDollarSign,
  },
  {
    title: "Setting up a well-governed independent practice",
    duration: "45 mins",
    body: "Governance basics for running a professional nursing practice: policies, evidence, provider expectations, complaints, privacy and review cycles.",
    icon: FiFileText,
  },
  {
    title: "AI-driven tools for patient monitoring",
    duration: "45 mins",
    body: "An introduction to using AI-assisted tools carefully for monitoring prompts, pattern recognition, documentation support and escalation awareness without replacing clinical judgement.",
    icon: FiMonitor,
  },
];

const outcomes = [
  "Understand the NurseConnectCare infrastructure-only model",
  "Prepare stronger evidence and documentation habits",
  "Set clearer boundaries before accepting care requests",
  "Build confidence in independent practice operations",
];

export default function NurseCpdPage() {
  return (
    <PublicSiteChrome
      ctaLabel="Register as nurse"
      ctaTo="/for-nurses/apply"
      metaTitle="NurseConnectCare | Nurses CPD"
      metaDescription="Short CPD-style learning modules for nurses preparing for independent care-at-home practice through NurseConnectCare."
    >
      <section className="mx-auto grid w-full max-w-7xl gap-10 px-4 pb-14 pt-8 sm:px-6 lg:grid-cols-[0.95fr_1.05fr] lg:px-8 lg:pt-14">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-4 py-2 text-sm text-ink-700 shadow-soft backdrop-blur">
            <FiFileText className="h-4 w-4 text-brand-700" />
            Nurses CPD
          </div>
          <h1 className="mt-6 text-4xl leading-tight text-ink-900 sm:text-5xl">
            Practical learning for nurses building independent care-at-home practice.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-700">
            NurseConnectCare CPD introduces the business, governance, documentation and technology foundations nurses
            need when working independently with clients, carers, care managers and registered-provider workflows.
          </p>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-ink-600">
            CPD payments are intended to contribute as partial credit toward NurseConnectCare nurse subscriptions,
            helping nurses move from learning into the connected practice workflow with less duplicated cost.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/for-nurses/apply" className="btn-primary">
              Register interest
            </Link>
            <Link to="/clinician-login?mode=signup" className="btn-secondary">
              Create nurse account
            </Link>
          </div>
        </div>

        <div className="rounded-[28px] border border-ink-200 bg-ink-900 p-6 text-white shadow-lift">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Learning focus</p>
          <h2 className="mt-3 text-3xl text-white">Designed to support readiness, not replace professional judgement.</h2>
          <div className="mt-6 grid gap-3">
            {outcomes.map((item) => (
              <div key={item} className="flex gap-3 border-t border-white/10 pt-3">
                <FiCheckCircle className="mt-1 h-5 w-5 shrink-0 text-brand-200" />
                <p className="text-sm leading-7 text-white/75">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-y border-ink-200/80 bg-white/80 py-14">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">Module pathway</p>
            <h2 className="mt-3 text-3xl sm:text-4xl">Short topics nurses can complete around onboarding.</h2>
            <p className="mt-5 text-lg leading-8 text-ink-700">
              The pathway gives nurses a clearer view of independent practice expectations before they publish a
              profile, accept requests or use the secure practice workspace.
            </p>
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {cpdModules.map(({ title, duration, body, icon: Icon }) => (
              <article key={title} className="border-t border-ink-200 bg-sand-100/80 p-5 shadow-soft">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-brand-700">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="rounded-full border border-brand-200 bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-700">
                    {duration}
                  </span>
                </div>
                <h3 className="mt-4 text-xl">{title}</h3>
                <p className="mt-2 text-sm leading-7 text-ink-700">{body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-16 pt-14">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="overflow-hidden rounded-[34px] border border-ink-200 bg-[linear-gradient(135deg,#0E2A3B_0%,#12546B_48%,#1F9A92_100%)] p-8 text-white shadow-lift">
            <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Nurse onboarding</p>
                <h2 className="mt-3 text-3xl text-white sm:text-4xl">Use CPD as the front door into safer practice setup.</h2>
                <p className="mt-4 max-w-2xl text-lg leading-8 text-white/80">
                  Nurses can start with the learning pathway, prepare their registration and operating details, then move
                  into NurseConnectCare's connected workflow environment.
                </p>
              </div>
              <Link to="/for-nurses/apply" className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-medium text-ink-900 transition hover:bg-sand-100">
                Register as nurse
                <FiArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
