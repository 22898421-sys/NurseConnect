import React from "react";
import { Link } from "react-router-dom";
import { FiArrowRight, FiCheckCircle, FiClipboard, FiHome, FiShield } from "./PublicIcons";
import PublicSiteChrome from "./PublicSiteChrome";

const steps = [
  { title: "Request care", body: "A client, carer or organisation describes the nursing support needed, including location, service type and relevant care context.", icon: FiHome },
  { title: "Review the pathway", body: "NurseConnectCare helps route the request to the appropriate independent-nurse or provider-aware workflow.", icon: FiClipboard },
  { title: "Manage securely in EIRENIX Care", body: "Authorised nurses use the secure EIRENIX Care environment to review requests, manage bookings, document care and coordinate follow-up.", icon: FiShield },
  { title: "Evidence and continuity", body: "Care records, service evidence, invoice documentation and clinically appropriate follow-up remain connected to the service trail.", icon: FiCheckCircle },
];

export default function HowItWorksPage() {
  return (
    <PublicSiteChrome
      metaTitle="NurseConnectCare | How It Works"
      metaDescription="See how public care requests move from NurseConnectCare into the secure EIRENIX Care workflow."
    >
      <section className="bg-gradient-to-br from-sand-100 via-white to-brand-50">
        <div className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
          <p className="text-xs font-extrabold uppercase tracking-[0.24em] text-brand-700">How it works</p>
          <h1 className="mt-4 max-w-4xl text-4xl font-extrabold leading-tight sm:text-6xl">One connected care pathway.</h1>
          <p className="mt-6 max-w-3xl text-lg leading-8 text-ink-500">
            NurseConnectCare is the public-facing entry point. EIRENIX Care is the secure operational environment used by authorised nurses and staff behind the service.
          </p>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-5 lg:grid-cols-4">
          {steps.map(({ title, body, icon: Icon }, index) => (
            <article key={title} className={`rounded-[24px] p-6 ${index === 2 ? "bg-brand-900 text-white" : "border border-ink-200 bg-white"}`}>
              <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${index === 2 ? "bg-white/10 text-brand-200" : "bg-brand-50 text-brand-700"}`}>
                <Icon className="h-5 w-5" />
              </div>
              <p className={`mt-5 text-xs font-extrabold uppercase tracking-[0.2em] ${index === 2 ? "text-brand-200" : "text-brand-700"}`}>Step {index + 1}</p>
              <h2 className={`mt-2 text-xl font-extrabold ${index === 2 ? "text-white" : "text-ink-900"}`}>{title}</h2>
              <p className={`mt-3 text-sm leading-7 ${index === 2 ? "text-white/70" : "text-ink-500"}`}>{body}</p>
            </article>
          ))}
        </div>

        <div className="mt-12 rounded-[30px] bg-sand-200 p-7 sm:p-9">
          <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-brand-700">Who uses which part?</p>
          <div className="mt-5 grid gap-5 lg:grid-cols-2">
            <div className="rounded-[24px] bg-white p-6">
              <h2 className="text-2xl font-extrabold">NurseConnectCare</h2>
              <p className="mt-3 text-sm leading-7 text-ink-500">For clients, carers, organisations and the public.</p>
              <ul className="mt-5 space-y-2 text-sm text-ink-700">
                <li>• Explore services and independent nurse options</li>
                <li>• Request nursing support</li>
                <li>• Record provider and funding context where relevant</li>
                <li>• Access client/carer account workflows</li>
              </ul>
            </div>
            <div className="rounded-[24px] bg-brand-900 p-6 text-white">
              <h2 className="text-2xl font-extrabold text-white">EIRENIX Care</h2>
              <p className="mt-3 text-sm leading-7 text-white/70">For independent nurses and authorised staff.</p>
              <ul className="mt-5 space-y-2 text-sm text-white/75">
                <li>• Review incoming service requests</li>
                <li>• Manage bookings, rosters and availability</li>
                <li>• Maintain patient charts and encounter records</li>
                <li>• Support prescribing, billing, evidence and telehealth workflows</li>
              </ul>
            </div>
          </div>

          <div className="mt-7 flex flex-wrap gap-3">
            <Link to="/request-care" className="inline-flex items-center gap-2 rounded-full bg-brand-700 px-5 py-3 text-sm font-bold text-white">Request Care <FiArrowRight className="h-4 w-4" /></Link>
            <Link to="/clinician-login?mode=signup" className="inline-flex items-center gap-2 rounded-full bg-brand-900 px-5 py-3 text-sm font-bold text-white"><FiShield className="h-4 w-4" /> EIRENIX Care</Link>
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
