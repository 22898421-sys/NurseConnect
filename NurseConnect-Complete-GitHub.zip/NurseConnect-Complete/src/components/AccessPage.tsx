//src/components/Login.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { RecaptchaVerifier, signInWithPhoneNumber, sendPasswordResetEmail } from "firebase/auth";
import { auth } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { getBootstrapStatus } from "../lib/bootstrap";
import { NURSE_TYPE_OPTIONS, getNurseTypeOption, normalizeNurseType } from "../lib/nurses";
import EirenixMark from "./EirenixMark";

type AccessMode = "login" | "signup";

function normalizeRole(role?: string): string {
  return role || "";
}

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const isPatientEntry = location.pathname === "/patient-login";
  const entryLabel = isPatientEntry ? "Client/Carer Access" : "Nurse Access";
  const entryHeading = isPatientEntry
    ? "Log in or create your client/carer account"
    : "Log in or create your nurse account";
  const entryDescription = isPatientEntry
    ? "First-time clients and carers can create an account here, then request visits, manage appointments and stay connected with their nurse."
    : "Independent nurses can create an account on first use, choose a subscription billing cycle, start with a free first week, and then move into the connected EIRENIX Care™ nurse workspace.";

  const {
    user,
    currentUserData,
    login,
    registerPatient,
    registerNurse,
    loading,
  } = useAuth() as any;

  const [mode, setMode] = useState<AccessMode>(isPatientEntry ? "signup" : "login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [signupName, setSignupName] = useState("");
  const [signupPhone, setSignupPhone] = useState("");
  const [signupNurseType, setSignupNurseType] = useState("");
  const [signupAhpra, setSignupAhpra] = useState("");
  const [signupBillingCycle, setSignupBillingCycle] = useState("monthly");

  const [resetEmail, setResetEmail] = useState("");
  const [resetMsg, setResetMsg] = useState<string | null>(null);
  const [phoneLogin, setPhoneLogin] = useState("");
  const [phoneOtp, setPhoneOtp] = useState("");
  const [phoneMsg, setPhoneMsg] = useState<string | null>(null);
  const [phoneBusy, setPhoneBusy] = useState(false);
  const [phoneConfirmation, setPhoneConfirmation] = useState<any>(null);

  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showBootstrapHint, setShowBootstrapHint] = useState(false);
  const recaptchaRef = useRef<RecaptchaVerifier | null>(null);

  const role = useMemo(() => normalizeRole(currentUserData?.role), [currentUserData]);

  function friendlyReason(reason?: string): string {
    const r = (reason || "").toString();
    if (r === "inactive") return "Your account is inactive. Please contact an administrator.";
    if (r === "unprovisioned") return "Your account is not yet provisioned for EIRENIX Care™. Please contact an administrator.";
    if (r === "forbidden") return "You do not have access to that page.";
    if (r === "profile_error") return "We could not validate your access profile. Please try again.";
    return "";
  }

  useEffect(() => {
    setMode(isPatientEntry ? "signup" : "login");
  }, [isPatientEntry]);

  useEffect(() => {
    const state = location.state as any;
    const stateReason = state?.reason as string | undefined;

    let storedReason = "";
    try {
      storedReason = window.sessionStorage.getItem("eirenix_logout_reason") || "";
      if (storedReason) window.sessionStorage.removeItem("eirenix_logout_reason");
    } catch {
      // ignore
    }

    const msg = friendlyReason(stateReason || storedReason);
    if (msg) {
      setError(null);
      setResetMsg(msg);
    }
  }, [location.state]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const requestedMode = (params.get("mode") || "").trim().toLowerCase();
    if (requestedMode === "signup" || requestedMode === "login") {
      setMode(requestedMode);
    }
  }, [location.search]);

  useEffect(() => {
    if (loading) return;
    if (!user) return;

    const state = location.state as any;
    const fromPath = state?.from?.pathname as string | undefined;

    if (fromPath) {
      navigate(fromPath, { replace: true });
      return;
    }

    if (role === "system_admin") navigate("/system-admin", { replace: true });
    else if (role === "clinician" && currentUserData?.subscriptionStatus === "pending_payment") navigate("/nurse-subscription", { replace: true });
    else if (role === "clinician") navigate("/schedule", { replace: true });
    else if (role === "patient") navigate("/patient", { replace: true });
    else navigate("/dashboard", { replace: true });
  }, [user, role, loading, navigate, location.state, currentUserData?.subscriptionStatus]);

  useEffect(() => {
    if (recaptchaRef.current) return;
    try {
      recaptchaRef.current = new RecaptchaVerifier(auth, "recaptcha-container", {
        size: "invisible",
      });
    } catch {
      // ignore duplicate init
    }
  }, []);

  useEffect(() => {
    let active = true;
    if (isPatientEntry) return undefined;
    getBootstrapStatus()
      .then((status) => {
        if (!active) return;
        setShowBootstrapHint(Boolean(status.bootstrapAllowed && status.requiresBootstrap));
      })
      .catch(() => {
        if (!active) return;
        setShowBootstrapHint(false);
      });
    return () => {
      active = false;
    };
  }, [isPatientEntry]);

  function normalizePhone(input: string) {
    const raw = (input || "").toString().trim();
    if (!raw) return "";
    const keepPlus = raw.startsWith("+");
    const digits = raw.replace(/[^\d]/g, "");
    if (!digits) return "";
    return keepPlus ? `+${digits}` : digits;
  }

  const onLogin = async () => {
    setError(null);
    setResetMsg(null);

    const em = email.trim().toLowerCase();
    if (!em || !password) {
      setError("Please enter your email and password.");
      return;
    }

    setBusy(true);
    try {
      await login(em, password);
    } catch (e: any) {
      setError(e?.message ?? "Login failed.");
    } finally {
      setBusy(false);
    }
  };

  const onSignUp = async () => {
    setError(null);
    setResetMsg(null);

    const em = email.trim().toLowerCase();
    if (!signupName.trim()) {
      setError("Please enter your full name.");
      return;
    }
    if (!em || !password) {
      setError("Please enter your email and password.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setBusy(true);
    try {
      if (isPatientEntry) {
        await registerPatient({
          displayName: signupName.trim(),
          email: em,
          password,
          phoneNumber: signupPhone,
        });
      } else {
        const nurseType = normalizeNurseType(signupNurseType);
        const nurseTypeOption = getNurseTypeOption(nurseType);
        if (!nurseType) {
          throw new Error("Please select your nurse type.");
        }
        if (nurseTypeOption?.requiresAhpra && !signupAhpra.trim()) {
          throw new Error("Please enter your AHPRA registration number.");
        }
        await registerNurse({
          displayName: signupName.trim(),
          email: em,
          password,
          nurseType,
          ahpraRegistrationNumber: signupAhpra.trim(),
          subscriptionBillingCycle: signupBillingCycle,
        });
      }
    } catch (e: any) {
      setError(e?.message ?? "Sign up failed.");
    } finally {
      setBusy(false);
    }
  };

  const onResetPassword = async () => {
    setResetMsg(null);
    setError(null);

    const em = (resetEmail || "").trim().toLowerCase();
    if (!em) {
      setResetMsg("Enter your email first.");
      return;
    }

    try {
      await sendPasswordResetEmail(auth, em);
      setResetMsg("Password reset email sent.");
    } catch (e: any) {
      setResetMsg(e?.message ?? "Failed to send reset email.");
    }
  };

  const sendPhoneOtp = async () => {
    setPhoneMsg(null);
    setError(null);
    const phone = normalizePhone(phoneLogin);
    if (!phone) {
      setPhoneMsg("Enter a valid phone number.");
      return;
    }
    if (!recaptchaRef.current) {
      setPhoneMsg("ReCAPTCHA not ready. Please refresh and try again.");
      return;
    }
    setPhoneBusy(true);
    try {
      const confirmation = await signInWithPhoneNumber(auth, phone, recaptchaRef.current);
      setPhoneConfirmation(confirmation);
      setPhoneMsg("OTP sent. Check your phone.");
    } catch (e: any) {
      setPhoneMsg(e?.message ?? "Failed to send OTP.");
    } finally {
      setPhoneBusy(false);
    }
  };

  const verifyPhoneOtp = async () => {
    setPhoneMsg(null);
    setError(null);
    if (!phoneConfirmation) {
      setPhoneMsg("Send the OTP first.");
      return;
    }
    if (!phoneOtp.trim()) {
      setPhoneMsg("Enter the OTP code.");
      return;
    }
    setPhoneBusy(true);
    try {
      await phoneConfirmation.confirm(phoneOtp.trim());
    } catch (e: any) {
      setPhoneMsg(e?.message ?? "OTP verification failed.");
    } finally {
      setPhoneBusy(false);
    }
  };

  const subscriptionOptions = [
    { value: "monthly", label: "Monthly" },
    { value: "quarterly", label: "Quarterly" },
    { value: "half_yearly", label: "Half-yearly" },
    { value: "annually", label: "Annually" },
  ];

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-start justify-center px-4 py-10 bg-gradient-to-b from-sand-100 via-white to-brand-50">
      <div className="w-full max-w-md card p-6 space-y-5">
        <div className="space-y-4">
          <div className="inline-flex rounded-full border border-brand-200 bg-brand-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
            {entryLabel}
          </div>

          {isPatientEntry ? (
            <div className="space-y-2">
              <h1 className="text-3xl">NurseConnectCare</h1>
              <p className="text-base font-medium text-ink-900">{entryHeading}</p>
              <p className="text-sm leading-6 text-ink-600">{entryDescription}</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="w-full max-w-[440px] h-[72px] overflow-hidden sm:h-[80px]">
                <img src="/eirenix-care-logo.jpg" alt="EIRENIX Care trademark" className="h-full w-full object-contain object-left" />
              </div>
              <div>
                <p className="text-base font-medium text-ink-900">{entryHeading}</p>
                <p className="text-sm leading-6 text-ink-600">{entryDescription}</p>
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-2 bg-sand-100 rounded-xl p-1">
          <button
            onClick={() => setMode("login")}
            className={`flex-1 px-3 py-2 rounded-lg text-sm transition ${mode === "login" ? "bg-white font-semibold text-ink-900 shadow-soft" : "bg-transparent text-ink-500"}`}
          >
            Login
          </button>
          <button
            onClick={() => setMode("signup")}
            className={`flex-1 px-3 py-2 rounded-lg text-sm transition ${mode === "signup" ? "bg-white font-semibold text-ink-900 shadow-soft" : "bg-transparent text-ink-500"}`}
          >
            Create account
          </button>
        </div>

        {error && <div className="text-sm text-rose-600">{error}</div>}
        {resetMsg && <div className="text-sm text-ink-700">{resetMsg}</div>}
        {showBootstrapHint ? (
          <div className="rounded-2xl border border-brand-200 bg-brand-50 px-4 py-3 text-sm leading-6 text-ink-700">
            This local environment has not been bootstrapped yet.
            <Link to="/bootstrap/setup" className="ml-1 font-medium text-brand-700 underline">
              Create the first system admin
            </Link>
            .
          </div>
        ) : null}

        <div className="space-y-3">
          {mode === "signup" ? (
            <>
              <div>
                <label className="label">Full name</label>
                <input value={signupName} onChange={(e) => setSignupName(e.target.value)} className="input" placeholder={isPatientEntry ? "e.g. Emily Citizen" : "e.g. Nurse Jane Smith"} autoComplete="name" />
              </div>
              {isPatientEntry ? (
                <div>
                  <label className="label">Phone number</label>
                  <input value={signupPhone} onChange={(e) => setSignupPhone(e.target.value)} className="input" placeholder="+614..." autoComplete="tel" />
                </div>
              ) : (
                <>
                  <div>
                    <label className="label">Nurse type</label>
                    <select value={signupNurseType} onChange={(e) => setSignupNurseType(e.target.value)} className="select">
                      <option value="">Select nurse type</option>
                      {NURSE_TYPE_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="label">AHPRA registration number</label>
                    <input value={signupAhpra} onChange={(e) => setSignupAhpra(e.target.value.toUpperCase())} className="input" placeholder="e.g. NMW0001234567" />
                  </div>
                  <div>
                    <label className="label">Subscription billing cycle</label>
                    <div className="grid grid-cols-2 gap-2">
                      {subscriptionOptions.map((option) => (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() => setSignupBillingCycle(option.value)}
                          className={`rounded-xl border px-3 py-3 text-sm text-left transition ${signupBillingCycle === option.value ? "border-brand-500 bg-brand-50 text-ink-900" : "border-ink-200 bg-white text-ink-600 hover:border-brand-300"}`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                    <div className="mt-2 text-[11px] leading-5 text-ink-500">
                      Self sign-up records your preferred billing cycle first. Your first 7 days are free, and billing starts after the trial period based on your selected subscription type.
                    </div>
                  </div>
                </>
              )}
            </>
          ) : null}

          <div>
            <label className="label">Email</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} className="input" placeholder="name@example.com" autoComplete="email" />
          </div>

          <div>
            <label className="label">Password</label>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input"
              type="password"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
            />
          </div>

          <button onClick={mode === "login" ? onLogin : onSignUp} disabled={busy} className="w-full btn-primary">
            {busy ? (mode === "login" ? "Logging in…" : "Creating account…") : mode === "login" ? "Log in" : "Create account"}
          </button>
        </div>

        <div className="border-t border-ink-200 pt-4 space-y-2">
          <div className="text-sm font-semibold text-ink-900">Forgot password?</div>
          <input value={resetEmail} onChange={(e) => setResetEmail(e.target.value)} className="input" placeholder="Enter your email" autoComplete="email" />
          <button onClick={onResetPassword} className="w-full btn-secondary">
            Send reset email
          </button>
          <div className="text-xs text-ink-500">
            {isPatientEntry ? "Clients and carers can still use phone login below." : "Nurses can also use phone login below."}
          </div>
        </div>

        <div className="border-t border-ink-200 pt-4 space-y-2">
          <div className="text-sm font-semibold text-ink-900">Phone login (OTP)</div>
          <input value={phoneLogin} onChange={(e) => setPhoneLogin(e.target.value)} className="input" placeholder="+614..." autoComplete="tel" />
          <button onClick={sendPhoneOtp} className="w-full btn-secondary" disabled={phoneBusy}>
            {phoneBusy ? "Sending…" : "Send OTP"}
          </button>
          <input value={phoneOtp} onChange={(e) => setPhoneOtp(e.target.value)} className="input" placeholder="OTP code" />
          <button onClick={verifyPhoneOtp} className="w-full btn-primary" disabled={phoneBusy}>
            {phoneBusy ? "Verifying…" : "Verify & Login"}
          </button>
          {phoneMsg ? <div className="text-xs text-ink-600">{phoneMsg}</div> : null}
        </div>

        <div className="border-t border-ink-200 pt-4 text-xs leading-6 text-ink-500">
          {isPatientEntry ? (
            "Client and carer accounts can be created on first use for booking requests, appointment updates and communication."
          ) : (
            <>
              Nurse self sign-up creates your independent nurse account, starts a 7-day free trial, records your subscription cycle, and connects you to the secure <EirenixMark /> workspace for rosters, records, provider-aware requests, evidence packs, and Support at Home aligned workflows.
            </>
          )}
        </div>

        <div id="recaptcha-container" />
      </div>
    </div>
  );
};

export default Login;
