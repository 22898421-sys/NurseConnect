// src/components/EncounterDetailPage.tsx
import React, { useEffect, useMemo, useState, useCallback } from "react";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  setDoc,
} from "firebase/firestore";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { db } from "../firebaseConfig";
import { buildEncounterHeader } from "../lib/encounterHeaders";
import { MainLayout } from "./MainLayout";
import { useAuth } from "../contexts/AuthContext";
import { formatProviderLabel, resolveProvider } from "../lib/provider";
import { formatToDDMMYYYY } from "../lib/dates";
import CarePlanLauncher from "./CarePlanLauncher";
import HomeCareAssessmentLauncher from "./HomeCareAssessmentLauncher";
import { logSensitiveAccess } from "../lib/accessAudit";

type EncounterType = "consultation" | "follow_up" | "procedure";
type EncounterStatus = "draft" | "completed";

type SoapFields = {
  subjective?: string;
  objective?: string;
  assessment?: string;
  plan?: string;
};

type SoapVersion = {
  id: string;
  version: number;
  soap: {
    subjective: string;
    objective: string;
    assessment: string;
    plan: string;
  };
  authorUid: string;
  authorDisplayName?: string;
  createdAt?: any;
  reason?: string | null;
};

type BreakGlassState = {
  enabled?: boolean;
  enabledBy?: string;
  enabledAt?: any;
  reason?: string;

  resolvedBy?: string;
  resolvedAt?: any;
  correctionReason?: string;
};

type EncounterDoc = {
  patientId: string;
  practitionerId?: string;
  practiceId?: string | null;

  encounterDate: string; // DD-MM-YYYY
  encounterDateISO?: string; // YYYY-MM-DD (optional ordering)
  type: EncounterType;
  reason: string;

  status?: EncounterStatus; // defaults to draft if missing
  breakGlass?: BreakGlassState;

  soap?: SoapFields;
  notes?: string;

  currentSoapVersion?: number;
  lastEditedAt?: any;
  lastEditedByUid?: string;

  createdAt?: any;
  createdBy?: string;
  updatedAt?: any;
  updatedBy?: string;
};

type EncounterHeaderDoc = {
  patientId: string;
  practitionerId?: string;
  practiceId?: string | null;
  practitionerDisplayName?: string | null;
  practitionerLabel?: string | null;
  encounterDate: string;
  encounterDateISO?: string | null;
  type?: string;
  reason?: string | null;
  status?: EncounterStatus;
  breakGlass?: BreakGlassState;
  createdAt?: any;
  updatedAt?: any;
  updatedBy?: string | null;
};

type DiffChunk = { kind: "same" | "add" | "remove"; line: string };

type PatientDoc = {
  fullName?: string;
  email?: string;
  phone?: string;
  dateOfBirth?: string;
  sex?: string;
};

type RevisionMode = "edit" | "addendum" | "correction_addendum" | "sign_override";

type SoapRevision = {
  id: string;
  encounterId: string;
  editorId: string;
  editorDisplayName?: string | null;
  editorRole?: string;
  editedAt?: any;
  mode: RevisionMode;

  // Draft edit
  previous?: { soap: SoapFields; notes: string };
  next?: { soap: SoapFields; notes: string };

  // Addenda / correction addenda
  addendumText?: string | null;
  addendumReason?: string | null;
  correctionReason?: string | null;

  // Signing override guardrail
  signOverrideReason?: string | null;
  soapCompletionAtSign?: { filled: number; total: number } | null;
};

function safeStr(v: any): string {
  return typeof v === "string" ? v : "";
}

function trimOrEmpty(v: any): string {
  return safeStr(v).trim();
}

function toDateMaybe(t: any): Date | null {
  try {
    if (!t) return null;
    if (typeof t?.toDate === "function") return t.toDate();
    if (typeof t?.seconds === "number") return new Date(t.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

function typeLabel(t: EncounterType) {
  switch (t) {
    case "consultation":
      return "Consultation";
    case "follow_up":
      return "Follow-up";
    case "procedure":
      return "Procedure";
    default:
      return "Encounter";
  }
}

function encStatusLabel(s: EncounterStatus) {
  return s === "completed" ? "Signed" : "Draft";
}

function nonEmpty(v: any) {
  return typeof v === "string" && v.trim().length > 0;
}

function getSoapCompletion(soap?: SoapFields): { filled: number; total: number; label: string; complete: boolean } {
  const s = soap ?? {};
  const filled = [s.subjective, s.objective, s.assessment, s.plan].filter(nonEmpty).length;
  const total = 4;
  const label = filled === 0 ? "Draft" : filled === total ? "Complete" : "In progress";
  return { filled, total, label, complete: filled === total };
}

function modeLabel(m: RevisionMode) {
  if (m === "correction_addendum") return "Correction addendum";
  if (m === "addendum") return "Addendum";
  if (m === "sign_override") return "Sign override";
  return "Edit";
}

function splitLines(s: string): string[] {
  const t = safeStr(s);
  if (!t) return [""];
  return t.replace(/\r\n/g, "\n").split("\n");
}

// Simple line-based diff (LCS) suitable for small SOAP sections.
function diffByLines(prevText: string, nextText: string): DiffChunk[] {
  const a = splitLines(prevText);
  const b = splitLines(nextText);

  const n = a.length;
  const m = b.length;

  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      if (a[i] === b[j]) dp[i][j] = dp[i + 1][j + 1] + 1;
      else dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }

  const out: DiffChunk[] = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      out.push({ kind: "same", line: a[i] });
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      out.push({ kind: "remove", line: a[i] });
      i++;
    } else {
      out.push({ kind: "add", line: b[j] });
      j++;
    }
  }
  while (i < n) out.push({ kind: "remove", line: a[i++] });
  while (j < m) out.push({ kind: "add", line: b[j++] });

  const hasContent = out.some((c) => (c.line ?? "").trim().length > 0 && c.kind !== "same");
  if (!hasContent && trimOrEmpty(prevText) === "" && trimOrEmpty(nextText) === "") {
    return [{ kind: "same", line: "" }];
  }
  return out;
}

const SoapSection: React.FC<{
  title: string;
  subtitle?: string;
  value: string;
  editable: boolean;
  onChange?: (v: string) => void;
  disabled?: boolean;
}> = ({ title, subtitle, value, editable, onChange, disabled }) => {
  return (
    <section className="rounded-xl border bg-white overflow-hidden">
      <div className="flex items-start justify-between gap-3 px-4 py-3 bg-gray-50 border-b">
        <div className="min-w-0">
          <div className="flex items-center gap-3">
            <div className="w-1.5 h-6 rounded-full bg-gray-900" aria-hidden="true" />
            <div>
              <div className="text-lg font-semibold text-gray-900">{title}</div>
              {subtitle ? <div className="text-xs text-gray-600 mt-0.5">{subtitle}</div> : null}
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-4">
        {editable ? (
          <textarea
            className="w-full border rounded-md px-3 py-2 min-h-[130px] no-print"
            value={value}
            onChange={(e) => onChange?.(e.target.value)}
            disabled={!!disabled}
          />
        ) : null}

        <div className="whitespace-pre-wrap text-gray-900 leading-relaxed">
          {trimOrEmpty(value) ? value : <span className="text-gray-500">—</span>}
        </div>
      </div>
    </section>
  );
};

export const EncounterDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const { patientId, encounterId } = useParams<{ patientId: string; encounterId: string }>();
  const [searchParams] = useSearchParams();

  const { normalizedRole, user, currentUserData } = useAuth() as any;
  const roleNorm: string = (normalizedRole ?? "").toLowerCase();

  const canUse = useMemo(() => {
    return roleNorm === "clinician" || roleNorm === "system_admin";
  }, [roleNorm]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [patient, setPatient] = useState<(PatientDoc & { id: string }) | null>(null);
  const [encounter, setEncounter] = useState<(EncounterDoc & { id: string }) | null>(null);
  const [encounterHeader, setEncounterHeader] = useState<(EncounterHeaderDoc & { id: string }) | null>(null);

  const [practitionerName, setPractitionerName] = useState<string>("—");
  const [practitionerLabel, setPractitionerLabel] = useState<string>("—");

  const [currentUserName, setCurrentUserName] = useState<string>("—");

  const [editMode, setEditMode] = useState(false);

  // Editable fields (DRAFT ONLY)
  const [sSubjective, setSSubjective] = useState("");
  const [sObjective, setSObjective] = useState("");
  const [sAssessment, setSAssessment] = useState("");
  const [sPlan, setSPlan] = useState("");
  const [notes, setNotes] = useState("");

  // Baseline for dirty-check
  const [bSubjective, setBSubjective] = useState("");
  const [bObjective, setBObjective] = useState("");
  const [bAssessment, setBAssessment] = useState("");
  const [bPlan, setBPlan] = useState("");
  const [bNotes, setBNotes] = useState("");

  // Revisions
  const [revisions, setRevisions] = useState<SoapRevision[]>([]);
  const [revisionUserMap, setRevisionUserMap] = useState<Record<string, string>>({});

  // SOAP versions
  const [soapVersions, setSoapVersions] = useState<SoapVersion[]>([]);
  const [soapVersionUserMap, setSoapVersionUserMap] = useState<Record<string, string>>({});

  const backToChartHref = useMemo(() => {
    return patientId ? `/patients/${patientId}/chart` : "/patients";
  }, [patientId]);

  const encounterStatus: EncounterStatus = useMemo(() => {
    const s = encounter?.status ?? encounterHeader?.status;
    return s === "completed" ? "completed" : "draft";
  }, [encounter?.status, encounterHeader?.status]);

  const breakGlassEnabled = useMemo(() => {
    return !!(encounter?.breakGlass?.enabled ?? encounterHeader?.breakGlass?.enabled);
  }, [encounter?.breakGlass?.enabled, encounterHeader?.breakGlass?.enabled]);

  const isAuthoringClinician = useMemo(() => {
    const uid = user?.uid ?? "";
    const pid = encounter?.practitionerId ?? "";
    return roleNorm === "clinician" && !!uid && !!pid && uid === pid;
  }, [roleNorm, user?.uid, encounter?.practitionerId]);

  // Step 2: Draft-only editing; signed snapshot immutable.
  const canEditDraft = isAuthoringClinician && encounterStatus !== "completed";
  const canEnterEditMode = canEditDraft;

  const canEnableBreakGlass = useMemo(() => {
    return roleNorm === "system_admin" && encounterStatus === "completed" && !breakGlassEnabled && !saving;
  }, [roleNorm, encounterStatus, breakGlassEnabled, saving]);

  const canAddAddendum = useMemo(() => {
    return isAuthoringClinician && encounterStatus === "completed" && !saving;
  }, [isAuthoringClinician, encounterStatus, saving]);

  const canAddCorrectionAddendum = useMemo(() => {
    return isAuthoringClinician && encounterStatus === "completed" && breakGlassEnabled && !saving;
  }, [isAuthoringClinician, encounterStatus, breakGlassEnabled, saving]);

  const createdAtDate = useMemo(() => toDateMaybe((encounter as any)?.createdAt), [encounter]);
  const updatedAtDate = useMemo(() => toDateMaybe((encounter as any)?.updatedAt), [encounter]);
  const isRestrictedAdminView = useMemo(() => {
    return roleNorm === "system_admin" && !encounter && !!encounterHeader;
  }, [roleNorm, encounter, encounterHeader]);

  const soapCompletion = useMemo(() => {
    const soap = editMode
      ? { subjective: sSubjective, objective: sObjective, assessment: sAssessment, plan: sPlan }
      : encounter?.soap;
    return getSoapCompletion(soap);
  }, [editMode, sSubjective, sObjective, sAssessment, sPlan, encounter?.soap]);

  const hasUnsavedChanges = useMemo(() => {
    if (!editMode) return false;
    return (
      trimOrEmpty(sSubjective) !== trimOrEmpty(bSubjective) ||
      trimOrEmpty(sObjective) !== trimOrEmpty(bObjective) ||
      trimOrEmpty(sAssessment) !== trimOrEmpty(bAssessment) ||
      trimOrEmpty(sPlan) !== trimOrEmpty(bPlan) ||
      trimOrEmpty(notes) !== trimOrEmpty(bNotes)
    );
  }, [editMode, sSubjective, sObjective, sAssessment, sPlan, notes, bSubjective, bObjective, bAssessment, bPlan, bNotes]);

  const confirmDiscardIfNeeded = () => {
    if (!hasUnsavedChanges) return true;
    return window.confirm("You have unsaved changes. Discard them?");
  };

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 2500);
  }, []);

  const loadRevisions = async (encId: string) => {
    try {
      const revQ = query(collection(db, "encounters", encId, "soapRevisions"), orderBy("editedAt", "desc"), limit(50));
      const snap = await getDocs(revQ);
      const rows: SoapRevision[] = snap.docs.map((d: any) => ({ id: d.id, ...(d.data() as any) }));
      setRevisions(rows);

      const editorIds = Array.from(new Set(rows.map((r) => r.editorId).filter(Boolean)));

      // Prefer stored editorDisplayName when present (medico-legal "as-at" naming)
      const mapped: Record<string, string> = {};
      for (const r of rows) {
        if (r.editorId && typeof (r as any).editorDisplayName === "string" && (r as any).editorDisplayName.trim()) {
          mapped[r.editorId] = (r as any).editorDisplayName.trim();
        }
      }

      const needLookup = editorIds.filter((uid) => !mapped[uid]);
      await Promise.all(
        needLookup.map(async (uid) => {
          const ident = await resolveProvider(uid);
          mapped[uid] = ident.displayName;
        })
      );

      setRevisionUserMap(mapped);
    } catch {
      setRevisions([]);
      setRevisionUserMap({});
    }
  };

  const loadSoapVersions = async (encId: string) => {
    try {
      const vQ = query(collection(db, "encounters", encId, "soapVersions"), orderBy("version", "desc"), limit(25));
      const snap = await getDocs(vQ);
      const rows: SoapVersion[] = snap.docs.map((d: any) => {
        const data = d.data() as any;
        return {
          id: d.id,
          version: typeof data.version === "number" ? data.version : 0,
          soap: {
            subjective: safeStr(data?.soap?.subjective),
            objective: safeStr(data?.soap?.objective),
            assessment: safeStr(data?.soap?.assessment),
            plan: safeStr(data?.soap?.plan),
          },
          authorUid: safeStr(data.authorUid),
          authorDisplayName: typeof data.authorDisplayName === "string" ? data.authorDisplayName : undefined,
          createdAt: data.createdAt,
          reason: typeof data.reason === "string" ? data.reason : data.reason === null ? null : undefined,
        };
      });

      const clean = rows.filter((r) => r.version > 0);
      setSoapVersions(clean);

      const authorIds = Array.from(new Set(clean.map((r) => r.authorUid).filter(Boolean)));
      const mapped: Record<string, string> = {};
      await Promise.all(
        authorIds.map(async (uid) => {
          const ident = await resolveProvider(uid);
          mapped[uid] = ident.displayName;
        })
      );
      setSoapVersionUserMap(mapped);
    } catch {
      setSoapVersions([]);
      setSoapVersionUserMap({});
    }
  };

  const load = useCallback(async () => {
    if (!canUse) {
      setLoading(false);
      return;
    }
    if (!patientId || !encounterId) {
      setError("Missing patient or encounter identifier.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    setToast(null);
    setEncounterHeader(null);

    try {
      const encRef = doc(db, "encounters", encounterId);
      let encSnap;
      try {
        encSnap = await getDoc(encRef);
      } catch (e: any) {
        if (roleNorm === "system_admin") {
          const headerSnap = await getDoc(doc(db, "encounterHeaders", encounterId));
          if (headerSnap.exists()) {
            setEncounterHeader({ id: headerSnap.id, ...(headerSnap.data() as any) });
            setEncounter(null);
            setPatient(null);
            setEditMode(false);
            setLoading(false);
            return;
          }
        }
        throw e;
      }

      if (!encSnap.exists()) {
        setError("Encounter not found.");
        setLoading(false);
        return;
      }

      const encData = encSnap.data() as any;
      const enc: EncounterDoc & { id: string } = { id: encSnap.id, ...(encData as EncounterDoc) };
      setEncounterHeader({
        id: enc.id,
        ...buildEncounterHeader({
          patientId: enc.patientId,
          practitionerId: enc.practitionerId || "",
          practiceId: enc.practiceId ?? null,
          practitionerDisplayName: (enc as any).practitionerDisplayName ?? null,
          practitionerLabel: (enc as any).practitionerLabel ?? null,
          encounterDate: enc.encounterDate,
          encounterDateISO: enc.encounterDateISO ?? null,
          type: enc.type,
          reason: enc.reason,
          status: enc.status ?? "draft",
          breakGlass: enc.breakGlass,
          createdAt: enc.createdAt,
          updatedAt: enc.updatedAt,
          updatedBy: enc.updatedBy ?? null,
        }),
      });

      if (enc.patientId && enc.patientId !== patientId) {
        setError("Encounter does not belong to this patient.");
        setLoading(false);
        return;
      }

      setEncounter(enc);

      if (user?.uid) {
        void logSensitiveAccess({
          actorUid: user.uid,
          role: roleNorm,
          action: "read_encounter",
          resourceType: "encounter",
          resourceId: enc.id,
          patientId,
          practiceId: enc.practiceId ?? null,
          encounterId: enc.id,
        });
      }

      // Current user identity (for audited writes)
      try {
        if (user?.uid) {
          const me = await resolveProvider(user.uid);
          setCurrentUserName(me.displayName || "—");
        } else {
          setCurrentUserName("—");
        }
      } catch {
        setCurrentUserName("—");
      }

      // Provider resolution
      if (enc.practitionerId) {
        const ident = await resolveProvider(enc.practitionerId);
        setPractitionerName(ident.displayName || "—");
        setPractitionerLabel(formatProviderLabel(ident, { includeRole: true }) || (ident.displayName || "—"));
      } else {
        setPractitionerName("—");
        setPractitionerLabel("—");
      }

      // Hydrate fields
      const soap = (enc.soap ?? {}) as SoapFields;
      const subj = safeStr(soap.subjective);
      const obj = safeStr(soap.objective);
      const ass = safeStr(soap.assessment);
      const pln = safeStr(soap.plan);
      const n = safeStr(enc.notes);

      setSSubjective(subj);
      setSObjective(obj);
      setSAssessment(ass);
      setSPlan(pln);
      setNotes(n);

      setBSubjective(subj);
      setBObjective(obj);
      setBAssessment(ass);
      setBPlan(pln);
      setBNotes(n);

      // Load patient
      const patRef = doc(db, "patients", patientId);
      const patSnap = await getDoc(patRef);
      setPatient(patSnap.exists() ? ({ id: patSnap.id, ...(patSnap.data() as any) } as any) : null);

      // Load audit history + versions
      await loadRevisions(encounterId);
      await loadSoapVersions(encounterId);

      // Auto-open edit only if requested AND permitted AND draft
      const openEditRequested = searchParams.get("edit") === "1";
      if (openEditRequested && enc.status !== "completed" && isAuthoringClinician) {
        setEditMode(true);
      } else {
        setEditMode(false);
      }
    } catch (e: any) {
      console.error("Failed to load encounter:", e);
      setError(e?.message ?? "Failed to load encounter.");
    } finally {
      setLoading(false);
    }
  }, [canUse, patientId, encounterId, isAuthoringClinician, searchParams, user?.uid, roleNorm]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (!hasUnsavedChanges) return;
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [hasUnsavedChanges]);

  const handleBack = () => {
    if (!confirmDiscardIfNeeded()) return;
    navigate(backToChartHref);
  };

  const toggleEdit = () => {
    if (editMode) {
      if (!confirmDiscardIfNeeded()) return;

      setSSubjective(bSubjective);
      setSObjective(bObjective);
      setSAssessment(bAssessment);
      setSPlan(bPlan);
      setNotes(bNotes);

      setEditMode(false);
      return;
    }

    if (!canEnterEditMode) return;
    setEditMode(true);
  };

  const enableBreakGlass = async () => {
    if (!encounterId || !canEnableBreakGlass || !encounterHeader) return;

    const reason = window.prompt("Break-glass unlock requires a reason. This will be recorded.\n\nEnter reason:", "");
    if (!reason || !reason.trim()) return;

    setSaving(true);
    setError(null);

    try {
      const payload = {
        breakGlass: {
          enabled: true,
          enabledBy: user?.uid ?? "",
          enabledAt: serverTimestamp(),
          reason: reason.trim(),
        },
        updatedAt: serverTimestamp(),
        updatedBy: user?.uid ?? "",
      } as any;

      await Promise.all([
        updateDoc(doc(db, "encounters", encounterId), payload),
        setDoc(
          doc(db, "encounterHeaders", encounterId),
          buildEncounterHeader({
            ...payload,
            patientId: encounterHeader.patientId,
            practitionerId: encounterHeader.practitionerId ?? "",
            practiceId: encounterHeader.practiceId ?? null,
            encounterDate: encounterHeader.encounterDate,
            encounterDateISO: encounterHeader.encounterDateISO ?? null,
            type: encounterHeader.type ?? "consultation",
            status: encounterHeader.status ?? "completed",
            practitionerDisplayName: encounterHeader.practitionerDisplayName ?? null,
            practitionerLabel: encounterHeader.practitionerLabel ?? null,
            createdAt: encounterHeader.createdAt ?? null,
          }),
          { merge: true }
        ),
      ]);

      if (user?.uid) {
        void logSensitiveAccess({
          actorUid: user.uid,
          role: roleNorm,
          action: "break_glass_enable",
          resourceType: "encounter",
          resourceId: encounterId,
          patientId: encounterHeader.patientId,
          practiceId: encounterHeader.practiceId ?? null,
          encounterId,
        });
      }

      await load();
      showToast("Break-glass enabled.");
    } catch (e: any) {
      console.error("Failed to enable break-glass:", e);
      setError(e?.message ?? "Failed to enable break-glass.");
    } finally {
      setSaving(false);
    }
  };

  const signEncounter = async () => {
    if (!encounterId || !isAuthoringClinician || !encounter) return;

    const completionNow = getSoapCompletion(encounter.soap);
    let overrideReason: string | null = null;

    if (!completionNow.complete) {
      const ok = window.confirm(`SOAP is incomplete (${completionNow.filled}/${completionNow.total}).\n\nSign anyway?`);
      if (!ok) return;

      overrideReason = window.prompt("Override reason (required). This will be permanently recorded:", "");
      if (!overrideReason || !overrideReason.trim()) return;
    } else {
      const ok = window.confirm(
        "Sign this encounter? Once signed, the SOAP snapshot is locked.\n\nYou may add Addenda. Corrections require break-glass."
      );
      if (!ok) return;
    }

    setSaving(true);
    setError(null);

    try {
      const encRef = doc(db, "encounters", encounterId);

      await runTransaction(db, async (tx: any) => {
        const encSnap = await tx.get(encRef);
        if (!encSnap.exists()) throw new Error("Encounter not found.");

        const encData = encSnap.data() as any;
        const currentVersion = typeof encData.currentSoapVersion === "number" ? encData.currentSoapVersion : 0;

        // Ensure there is at least one immutable SOAP version at signing.
        if (currentVersion <= 0) {
          const vRef = doc(collection(db, "encounters", encounterId, "soapVersions"));
          tx.set(vRef, {
            version: 1,
            soap: {
              subjective: safeStr(encData?.soap?.subjective).trim(),
              objective: safeStr(encData?.soap?.objective).trim(),
              assessment: safeStr(encData?.soap?.assessment).trim(),
              plan: safeStr(encData?.soap?.plan).trim(),
            },
            authorUid: user?.uid ?? "",
            authorDisplayName: practitionerName,
            createdAt: serverTimestamp(),
            reason: "Initial version at signing",
          } as any);

          tx.update(encRef, {
            currentSoapVersion: 1,
            lastEditedAt: serverTimestamp(),
            lastEditedByUid: user?.uid ?? "",
          } as any);
        }

        if (overrideReason) {
          const revRef = doc(collection(db, "encounters", encounterId, "soapRevisions"));
          tx.set(revRef, {
            encounterId,
            editorId: user?.uid ?? "",
            editorDisplayName: currentUserName !== "—" ? currentUserName : null,
            editorRole: roleNorm ?? "",
            editedAt: serverTimestamp(),
            mode: "sign_override",
            signOverrideReason: overrideReason.trim(),
            soapCompletionAtSign: { filled: completionNow.filled, total: completionNow.total },
          } as any);
        }

        tx.update(encRef, {
          status: "completed",
          updatedAt: serverTimestamp(),
          updatedBy: user?.uid ?? "",
        } as any);

        const headerRef = doc(db, "encounterHeaders", encounterId);
        tx.set(
          headerRef,
          buildEncounterHeader({
            patientId: encData.patientId,
            practitionerId: encData.practitionerId ?? "",
            practiceId: encData.practiceId ?? null,
            practitionerDisplayName: encData.practitionerDisplayName ?? null,
            practitionerLabel: encData.practitionerLabel ?? null,
            encounterDate: encData.encounterDate,
            encounterDateISO: encData.encounterDateISO ?? null,
            type: encData.type ?? "consultation",
            status: "completed",
            breakGlass: encData.breakGlass ?? { enabled: false },
            createdAt: encData.createdAt ?? null,
            updatedAt: serverTimestamp(),
            updatedBy: user?.uid ?? "",
          }),
          { merge: true }
        );
      });

      await load();
      showToast("Encounter signed.");
    } catch (e: any) {
      console.error("Failed to sign encounter:", e);
      setError(e?.message ?? "Failed to sign encounter.");
    } finally {
      setSaving(false);
    }
  };

  const saveDraft = async () => {
    if (!encounterId || !patientId || !encounter) return;
    if (!canEnterEditMode) return;

    setSaving(true);
    setError(null);

    try {
      const nextSoap: SoapFields = {
        subjective: trimOrEmpty(sSubjective),
        objective: trimOrEmpty(sObjective),
        assessment: trimOrEmpty(sAssessment),
        plan: trimOrEmpty(sPlan),
      };
      const nextNotes = trimOrEmpty(notes);

      const encRef = doc(db, "encounters", encounterId);

      await runTransaction(db, async (tx: any) => {
        const encSnap = await tx.get(encRef);
        if (!encSnap.exists()) throw new Error("Encounter not found.");

        const encData = encSnap.data() as any;

        if ((encData?.status ?? "draft") === "completed") {
          throw new Error("Encounter is signed and cannot be edited. Use an addendum.");
        }

        const prevSoap: SoapFields = (encData.soap ?? {}) as any;
        const prevNotes = safeStr(encData.notes);

        const currentVersion = typeof encData.currentSoapVersion === "number" ? encData.currentSoapVersion : 0;
        const nextVersion = currentVersion + 1;

        // 1) Append immutable SOAP version
        const vRef = doc(collection(db, "encounters", encounterId, "soapVersions"));
        tx.set(vRef, {
          version: nextVersion,
          soap: {
            subjective: safeStr(nextSoap.subjective).trim(),
            objective: safeStr(nextSoap.objective).trim(),
            assessment: safeStr(nextSoap.assessment).trim(),
            plan: safeStr(nextSoap.plan).trim(),
          },
          authorUid: user?.uid ?? "",
          authorDisplayName: practitionerName,
          createdAt: serverTimestamp(),
          reason: null,
        } as any);

        // 2) Append audit revision (draft edit)
        const revRef = doc(collection(db, "encounters", encounterId, "soapRevisions"));
        tx.set(revRef, {
          encounterId,
          editorId: user?.uid ?? "",
          editorDisplayName: currentUserName !== "—" ? currentUserName : null,
          editorRole: roleNorm ?? "",
          editedAt: serverTimestamp(),
          mode: "edit",
          previous: { soap: prevSoap, notes: prevNotes },
          next: { soap: nextSoap, notes: nextNotes },
        } as any);

        // 3) Update encounter snapshot (draft only)
        tx.update(encRef, {
          soap: nextSoap,
          notes: nextNotes,
          currentSoapVersion: nextVersion,
          lastEditedAt: serverTimestamp(),
          lastEditedByUid: user?.uid ?? "",
          updatedAt: serverTimestamp(),
          updatedBy: user?.uid ?? "",
        } as any);

        const headerRef = doc(db, "encounterHeaders", encounterId);
        tx.set(
          headerRef,
          buildEncounterHeader({
            patientId: encData.patientId,
            practitionerId: encData.practitionerId ?? "",
            practiceId: encData.practiceId ?? null,
            practitionerDisplayName: encData.practitionerDisplayName ?? null,
            practitionerLabel: encData.practitionerLabel ?? null,
            encounterDate: encData.encounterDate,
            encounterDateISO: encData.encounterDateISO ?? null,
            type: encData.type ?? "consultation",
            status: encData.status ?? "draft",
            breakGlass: encData.breakGlass ?? { enabled: false },
            createdAt: encData.createdAt ?? null,
            updatedAt: serverTimestamp(),
            updatedBy: user?.uid ?? "",
          }),
          { merge: true }
        );
      });

      await load();
      setEditMode(false);
      showToast("Saved (audited).");
    } catch (e: any) {
      console.error("Failed to save:", e);
      setError(e?.message ?? "Failed to save.");
    } finally {
      setSaving(false);
    }
  };

  const appendPlanLineToDraftEncounter = useCallback(
    async (planLine: string) => {
      if (!encounterId || !patientId || !encounter) return;
      if (!canEnterEditMode) return;

      const cleanLine = trimOrEmpty(planLine);
      if (!cleanLine) return;

      setSaving(true);
      setError(null);

      try {
        const encRef = doc(db, "encounters", encounterId);
        await runTransaction(db, async (tx: any) => {
          const encSnap = await tx.get(encRef);
          if (!encSnap.exists()) throw new Error("Encounter not found.");

          const encData = encSnap.data() as any;
          if ((encData?.status ?? "draft") === "completed") {
            throw new Error("Encounter is signed and cannot be edited.");
          }

          const prevSoap: SoapFields = (encData.soap ?? {}) as any;
          const prevNotes = safeStr(encData.notes);
          const currentVersion = typeof encData.currentSoapVersion === "number" ? encData.currentSoapVersion : 0;
          const nextVersion = currentVersion + 1;
          const draftSoap: SoapFields =
            editMode
              ? {
                  subjective: trimOrEmpty(sSubjective),
                  objective: trimOrEmpty(sObjective),
                  assessment: trimOrEmpty(sAssessment),
                  plan: trimOrEmpty(sPlan),
                }
              : prevSoap;
          const draftNotes = editMode ? trimOrEmpty(notes) : prevNotes;

          const nextSoap: SoapFields = {
            subjective: safeStr(draftSoap.subjective).trim(),
            objective: safeStr(draftSoap.objective).trim(),
            assessment: safeStr(draftSoap.assessment).trim(),
            plan: [safeStr(draftSoap.plan).trim(), `- ${cleanLine}`].filter(Boolean).join("\n"),
          };

          const versionRef = doc(collection(db, "encounters", encounterId, "soapVersions"));
          tx.set(versionRef, {
            version: nextVersion,
            soap: nextSoap,
            authorUid: user?.uid ?? "",
            authorDisplayName: practitionerName,
            createdAt: serverTimestamp(),
            reason: "Clinical action saved",
          } as any);

          const revisionRef = doc(collection(db, "encounters", encounterId, "soapRevisions"));
          tx.set(revisionRef, {
            encounterId,
            editorId: user?.uid ?? "",
            editorDisplayName: currentUserName !== "—" ? currentUserName : null,
            editorRole: roleNorm ?? "",
            editedAt: serverTimestamp(),
            mode: "edit",
            previous: { soap: prevSoap, notes: prevNotes },
            next: { soap: nextSoap, notes: draftNotes },
          } as any);

          tx.update(encRef, {
            soap: nextSoap,
            notes: draftNotes,
            currentSoapVersion: nextVersion,
            lastEditedAt: serverTimestamp(),
            lastEditedByUid: user?.uid ?? "",
            updatedAt: serverTimestamp(),
            updatedBy: user?.uid ?? "",
          } as any);

          const headerRef = doc(db, "encounterHeaders", encounterId);
          tx.set(
            headerRef,
            buildEncounterHeader({
              patientId: encData.patientId,
              practitionerId: encData.practitionerId ?? "",
              practiceId: encData.practiceId ?? null,
              practitionerDisplayName: encData.practitionerDisplayName ?? null,
              practitionerLabel: encData.practitionerLabel ?? null,
              encounterDate: encData.encounterDate,
              encounterDateISO: encData.encounterDateISO ?? null,
              type: encData.type ?? "consultation",
              status: encData.status ?? "draft",
              breakGlass: encData.breakGlass ?? { enabled: false },
              createdAt: encData.createdAt ?? null,
              updatedAt: serverTimestamp(),
              updatedBy: user?.uid ?? "",
            }),
            { merge: true }
          );
        });

        await load();
        showToast("Clinical action added to plan.");
      } catch (e: any) {
        console.error("Failed to append clinical action to plan:", e);
        setError(e?.message ?? "Failed to append action to encounter plan.");
      } finally {
        setSaving(false);
      }
    },
    [
      canEnterEditMode,
      currentUserName,
      encounter,
      encounterId,
      load,
      patientId,
      practitionerName,
      roleNorm,
      sAssessment,
      sObjective,
      sPlan,
      sSubjective,
      showToast,
      user?.uid,
      notes,
      editMode,
    ]
  );

  const addAddendum = async () => {
    if (!encounterId || !encounter || !canAddAddendum) return;

    const text = window.prompt(
      "Addendum text (required).\n\nThis appends to the audit trail without changing the signed SOAP snapshot:",
      ""
    );
    if (!text || !text.trim()) return;

    const reason = window.prompt(
      "Addendum reason (recommended).\n\nExamples: late entry, clarification, additional information received after signing.",
      ""
    );

    setSaving(true);
    setError(null);

    try {
      const revRef = doc(collection(db, "encounters", encounterId, "soapRevisions"));

      const addendumDoc: any = {
        encounterId,
        editorId: user?.uid ?? "",
        editorRole: roleNorm ?? "",
        editedAt: serverTimestamp(),
        mode: "addendum",
        addendumText: text.trim(),
        addendumReason: reason && reason.trim() ? reason.trim() : null,
      };

      await setDoc(revRef, addendumDoc);

      await load();
      showToast("Addendum saved (audited).");
    } catch (e: any) {
      console.error("Failed to save addendum:", e);
      setError(e?.message ?? "Failed to save addendum.");
    } finally {
      setSaving(false);
    }
  };

  const addCorrectionAddendum = async () => {
    if (!encounterId || !encounter || !canAddCorrectionAddendum) return;

    const text = window.prompt(
      "Correction addendum text (required).\n\nThis appends to the audit trail. The signed SOAP snapshot remains unchanged:",
      ""
    );
    if (!text || !text.trim()) return;

    const correctionReason = window.prompt(
      "Correction reason (required).\n\nThis is permanently recorded and break-glass will be resolved:",
      ""
    );
    if (!correctionReason || !correctionReason.trim()) return;

    setSaving(true);
    setError(null);

    try {
      const encRef = doc(db, "encounters", encounterId);

      await runTransaction(db, async (tx: any) => {
        const encSnap = await tx.get(encRef);
        if (!encSnap.exists()) throw new Error("Encounter not found.");

        const encData = encSnap.data() as any;

        if ((encData?.status ?? "draft") !== "completed") throw new Error("Encounter is not signed.");
        if (!encData?.breakGlass?.enabled) throw new Error("Break-glass is not enabled.");
        if ((encData?.practitionerId ?? "") !== (user?.uid ?? "")) {
          throw new Error("Only the authoring clinician can record a correction addendum.");
        }

        // 1) Append correction addendum
        const revRef = doc(collection(db, "encounters", encounterId, "soapRevisions"));
        tx.set(revRef, {
          encounterId,
          editorId: user?.uid ?? "",
          editorDisplayName: currentUserName !== "—" ? currentUserName : null,
          editorRole: roleNorm ?? "",
          editedAt: serverTimestamp(),
          mode: "correction_addendum",
          addendumText: text.trim(),
          correctionReason: correctionReason.trim(),
        } as any);

        // 2) Resolve break-glass (no snapshot change)
        tx.update(encRef, {
          breakGlass: {
            ...(encData.breakGlass ?? {}),
            enabled: false,
            resolvedBy: user?.uid ?? "",
            resolvedAt: serverTimestamp(),
            correctionReason: correctionReason.trim(),
          },
          updatedAt: serverTimestamp(),
          updatedBy: user?.uid ?? "",
        } as any);

        const headerRef = doc(db, "encounterHeaders", encounterId);
        tx.set(
          headerRef,
          buildEncounterHeader({
            patientId: encData.patientId,
            practitionerId: encData.practitionerId ?? "",
            practiceId: encData.practiceId ?? null,
            practitionerDisplayName: encData.practitionerDisplayName ?? null,
            practitionerLabel: encData.practitionerLabel ?? null,
            encounterDate: encData.encounterDate,
            encounterDateISO: encData.encounterDateISO ?? null,
            type: encData.type ?? "consultation",
            status: encData.status ?? "completed",
            breakGlass: {
              ...(encData.breakGlass ?? {}),
              enabled: false,
              resolvedBy: user?.uid ?? "",
              resolvedAt: serverTimestamp(),
              correctionReason: correctionReason.trim(),
            },
            createdAt: encData.createdAt ?? null,
            updatedAt: serverTimestamp(),
            updatedBy: user?.uid ?? "",
          }),
          { merge: true }
        );
      });

      await load();
      showToast("Correction addendum saved (audited). Break-glass resolved.");
    } catch (e: any) {
      console.error("Failed to save correction addendum:", e);
      setError(e?.message ?? "Failed to save correction addendum.");
    } finally {
      setSaving(false);
    }
  };

  if (!canUse) {
    return (
      <MainLayout>
        <div className="p-4 text-sm text-red-600">Access denied.</div>
      </MainLayout>
    );
  }

  if (loading) {
    return (
      <MainLayout>
        <div className="p-4 text-sm text-gray-700">Loading encounter…</div>
      </MainLayout>
    );
  }

  if (error) {
    return (
      <MainLayout>
        <div className="p-4 text-sm">
          <div className="text-red-600">{error}</div>
          <button className="mt-3 px-3 py-2 rounded-md border text-sm hover:bg-gray-50" onClick={handleBack}>
            Back to chart
          </button>
        </div>
      </MainLayout>
    );
  }

  if (!encounter) {
    if (isRestrictedAdminView && encounterHeader) {
      return (
        <MainLayout>
          <div className="p-4 space-y-4">
            <div className="border rounded-xl bg-white p-4">
              <div className="text-lg font-semibold">Encounter Access Restricted</div>
              <div className="mt-2 text-sm text-gray-700">
                Clinical content is not shown to system administrators by default.
              </div>
              <div className="mt-2 text-sm text-gray-700">
                You can enable break-glass for this signed encounter, which will be audited and then allow temporary review.
              </div>
            </div>

            <div className="border rounded-xl bg-white p-4 space-y-2">
              <div className="text-sm"><span className="font-medium">Encounter ID:</span> {encounterHeader.id}</div>
              <div className="text-sm"><span className="font-medium">Patient ID:</span> {encounterHeader.patientId}</div>
              <div className="text-sm"><span className="font-medium">Practitioner ID:</span> {encounterHeader.practitionerId || "—"}</div>
              <div className="text-sm"><span className="font-medium">Date:</span> {encounterHeader.encounterDate}</div>
              <div className="text-sm"><span className="font-medium">Type:</span> {encounterHeader.type || "consultation"}</div>
              <div className="text-sm"><span className="font-medium">Status:</span> {encStatusLabel(encounterStatus)}</div>
              <div className="text-sm"><span className="font-medium">Break-glass:</span> {breakGlassEnabled ? "Enabled" : "Not enabled"}</div>
            </div>

            <div className="flex items-center gap-2">
              <button className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50" onClick={handleBack}>
                Back to chart
              </button>
              {canEnableBreakGlass ? (
                <button
                  className="px-3 py-2 rounded-md border border-red-300 bg-red-50 text-sm text-red-700 hover:bg-red-100 disabled:opacity-60"
                  onClick={enableBreakGlass}
                  disabled={saving}
                >
                  Break-glass unlock
                </button>
              ) : null}
            </div>
          </div>
        </MainLayout>
      );
    }

    return (
      <MainLayout>
        <div className="p-4 text-sm">
          Encounter not found.
          <button className="mt-3 px-3 py-2 rounded-md border text-sm hover:bg-gray-50" onClick={handleBack}>
            Back to chart
          </button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <style>{`
        @media print {
          .no-print { display: none !important; }
          .print-container { padding: 0 !important; }
          body { background: #ffffff !important; }
        }
      `}</style>

      <div className="p-4 space-y-4 print-container">
        {/* SOAP completion banner */}
        <div
          className={`border rounded-xl px-4 py-3 text-sm ${
            soapCompletion.complete ? "bg-green-50 border-green-200 text-green-800" : "bg-amber-50 border-amber-200 text-amber-800"
          }`}
        >
          SOAP completion: <span className="font-medium">{soapCompletion.filled}/{soapCompletion.total}</span> ·{" "}
          <span className="font-medium">{encStatusLabel(encounterStatus)}</span>
        </div>

        {/* Patient banner */}
        <div className="border rounded-xl bg-white p-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            <div className="min-w-0">
              <div className="text-xs text-gray-600">Patient</div>
              <div className="text-lg font-semibold truncate">{patient?.fullName ?? "Unknown patient"}</div>

              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-gray-700">
                <span className="px-2 py-0.5 rounded-full border bg-gray-50">ID: {patientId}</span>
                {patient?.dateOfBirth ? (
                  <span className="px-2 py-0.5 rounded-full border bg-gray-50">
                    DOB: {formatToDDMMYYYY(patient.dateOfBirth)}
                  </span>
                ) : null}
                {patient?.sex ? (
                  <span className="px-2 py-0.5 rounded-full border bg-gray-50">Sex: {patient.sex}</span>
                ) : null}
              </div>
            </div>

            <div className="flex items-center gap-2 no-print">
              <button className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50" onClick={handleBack}>
                Back to chart
              </button>

              <Link
                to={`/patients/${patientId}/chart/encounters/${encounterId}/print`}
                className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
                title="Open a printable encounter report (use browser Print to Save as PDF)"
              >
                Print / Save PDF
              </Link>

              {isAuthoringClinician && encounterStatus !== "completed" && !editMode ? (
                <button
                  className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50 disabled:opacity-60"
                  onClick={signEncounter}
                  disabled={saving}
                  title="Sign encounter (locks SOAP snapshot). If SOAP incomplete, override reason required."
                >
                  Sign encounter
                </button>
              ) : null}

              <button
                className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50 disabled:opacity-60"
                onClick={toggleEdit}
                disabled={!canEnterEditMode || saving}
                title={!canEnterEditMode ? "Only the authoring clinician may edit this encounter while it is Draft." : "Toggle edit mode"}
              >
                {editMode ? "Exit edit" : "Edit"}
              </button>

              {editMode ? (
                <button
                  className="px-3 py-2 rounded-md bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-60"
                  onClick={saveDraft}
                  disabled={saving || !canEnterEditMode}
                >
                  {saving ? "Saving…" : "Save"}
                </button>
              ) : null}

              {encounterStatus === "completed" && !editMode && canAddAddendum ? (
                <button
                  className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50 disabled:opacity-60"
                  onClick={addAddendum}
                  disabled={saving}
                  title="Add an addendum without modifying the signed SOAP snapshot"
                >
                  Add addendum
                </button>
              ) : null}

              {encounterStatus === "completed" && !editMode && canAddCorrectionAddendum ? (
                <button
                  className="px-3 py-2 rounded-md border border-red-300 bg-red-50 text-sm text-red-700 hover:bg-red-100 disabled:opacity-60"
                  onClick={addCorrectionAddendum}
                  disabled={saving}
                  title="Record a correction addendum and resolve break-glass (snapshot remains unchanged)"
                >
                  Record correction addendum
                </button>
              ) : null}

              {canEnableBreakGlass ? (
                <button
                  className="px-3 py-2 rounded-md border border-red-300 bg-red-50 text-sm text-red-700 hover:bg-red-100 disabled:opacity-60"
                  onClick={enableBreakGlass}
                  disabled={saving}
                  title="Enable break-glass so the authoring clinician can record a correction addendum (snapshot remains unchanged)"
                >
                  Break-glass unlock
                </button>
              ) : null}
            </div>
          </div>

          {toast ? <div className="mt-3 text-xs text-green-700 no-print">{toast}</div> : null}

          {encounterStatus === "completed" && !breakGlassEnabled ? (
            <div className="mt-3 text-xs text-gray-700 border border-gray-200 bg-gray-50 rounded-lg px-3 py-2">
              This encounter is <span className="font-medium">Signed</span>. SOAP snapshot is locked. Addenda are permitted.
            </div>
          ) : null}

          {breakGlassEnabled ? (
            <div className="mt-3 text-xs text-red-800 border border-red-200 bg-red-50 rounded-lg px-3 py-2">
              Break-glass is <span className="font-medium">ENABLED</span>. The signed SOAP snapshot remains locked.
              The authoring clinician may record a <span className="font-medium">correction addendum</span>, which will be
              audited and will resolve break-glass.
            </div>
          ) : null}

          {editMode && hasUnsavedChanges ? (
            <div className="mt-3 text-xs text-amber-800 border border-amber-200 bg-amber-50 rounded-lg px-3 py-2 no-print">
              You have unsaved changes.
            </div>
          ) : null}
        </div>

        {/* Encounter metadata */}
        <div className="border rounded-xl p-4 bg-white text-sm space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs px-2 py-0.5 rounded-full border bg-gray-50">{typeLabel(encounter.type)}</span>
            <span className="text-xs px-2 py-0.5 rounded-full border bg-gray-50">Date: {encounter.encounterDate || "—"}</span>
            <span className="text-xs px-2 py-0.5 rounded-full border bg-gray-50">Status: {encStatusLabel(encounterStatus)}</span>
            <span className="text-xs px-2 py-0.5 rounded-full border bg-gray-50">
              SOAP: {soapCompletion.label} ({soapCompletion.filled}/{soapCompletion.total})
            </span>
          </div>

          <div>
            <span className="font-medium">Reason:</span> {encounter.reason || "—"}
          </div>

          <div className="text-xs text-gray-600">
            <div>
              Practitioner: <span className="font-medium text-gray-800">{practitionerLabel}</span>
            </div>
            <div>
              Encounter ID: <span className="font-medium text-gray-800">{encounter.id}</span>
            </div>
          </div>

          <div className="text-xs text-gray-600">
            {createdAtDate ? (
              <div>
                Created: <span className="font-medium text-gray-800">{createdAtDate.toLocaleString()}</span>
              </div>
            ) : null}
            {updatedAtDate ? (
              <div>
                Updated: <span className="font-medium text-gray-800">{updatedAtDate.toLocaleString()}</span>
              </div>
            ) : null}
          </div>
        </div>

        {roleNorm === "clinician" && patientId && currentUserData?.practiceId && user?.uid ? (
          <div className="space-y-4">
            <CarePlanLauncher
              patientId={patientId}
              practiceId={currentUserData.practiceId}
              clinicianUid={user.uid}
              clinicianDisplayName={currentUserData?.displayName || currentUserData?.email || user?.email || null}
              sourceEncounterId={encounter.id}
              sourceAppointmentId={null}
              chartBasePath={`/patients/${patientId}/chart`}
              buttonLabel="Create care plan from encounter"
              onCarePlanCreated={({ planLine }) => appendPlanLineToDraftEncounter(planLine)}
            />
            <HomeCareAssessmentLauncher
              patientId={patientId}
              practiceId={currentUserData.practiceId}
              clinicianUid={user.uid}
              clinicianDisplayName={currentUserData?.displayName || currentUserData?.email || user?.email || null}
              sourceEncounterId={encounter.id}
              sourceAppointmentId={null}
              chartBasePath={`/patients/${patientId}/chart`}
              buttonLabel="Run home-care assessment from encounter"
              onAssessmentCreated={({ planLine }) => appendPlanLineToDraftEncounter(planLine)}
            />
          </div>
        ) : null}

        {/* SOAP snapshot (improved headings) */}
        <div className="border rounded-xl p-4 bg-white text-sm space-y-4">
          <div className="flex items-end justify-between gap-3">
            <div>
              <div className="text-xl font-semibold text-gray-900">SOAP note</div>
              <div className="text-xs text-gray-600 mt-1">Snapshot (draft editable; signed is locked)</div>
            </div>
            <div className="text-xs text-gray-600">
              Sections: <span className="font-medium text-gray-900">S</span> / <span className="font-medium text-gray-900">O</span> /{" "}
              <span className="font-medium text-gray-900">A</span> / <span className="font-medium text-gray-900">P</span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <SoapSection
              title="Subjective"
              subtitle="History, symptoms, concerns"
              value={sSubjective}
              editable={editMode}
              onChange={setSSubjective}
              disabled={saving}
            />
            <SoapSection
              title="Objective"
              subtitle="Exam findings, vitals, tests"
              value={sObjective}
              editable={editMode}
              onChange={setSObjective}
              disabled={saving}
            />
            <SoapSection
              title="Assessment"
              subtitle="Problem list, impression, differentials"
              value={sAssessment}
              editable={editMode}
              onChange={setSAssessment}
              disabled={saving}
            />
            <SoapSection
              title="Plan"
              subtitle="Investigations, treatment, follow-up, safety-netting"
              value={sPlan}
              editable={editMode}
              onChange={setSPlan}
              disabled={saving}
            />
          </div>
        </div>

        {/* Notes snapshot */}
        <div className="border rounded-xl p-4 bg-white text-sm space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-base font-semibold text-gray-900">Notes</div>
            <div className="text-xs text-gray-500">Free-text (legacy-compatible)</div>
          </div>

          {editMode ? (
            <textarea
              className="w-full border rounded-md px-3 py-2 min-h-[140px] no-print"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              disabled={saving}
            />
          ) : null}

          <div className="whitespace-pre-wrap text-gray-900 leading-relaxed">
            {trimOrEmpty(notes) ? notes : <span className="text-gray-500">No notes.</span>}
          </div>
        </div>

        {/* SOAP version diffs */}
        <div className="border rounded-xl p-4 bg-white text-sm space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-base font-semibold text-gray-900">SOAP version history</div>
            <div className="text-xs text-gray-500">Clinician-friendly diffs</div>
          </div>

          <div className="text-xs text-gray-600">
            Each draft save creates an immutable version. Diffs are shown vs the prior version (S/O/A/P).
          </div>

          {soapVersions.length === 0 ? (
            <div className="text-xs text-gray-500 mt-2">No versions recorded yet.</div>
          ) : (
            <div className="space-y-2 mt-2">
              {(() => {
                const newestFirst = [...soapVersions].sort((a, b) => (b.version ?? 0) - (a.version ?? 0));
                const byVersion = new Map<number, SoapVersion>();
                newestFirst.forEach((v) => byVersion.set(v.version, v));

                const renderDiff = (chunks: DiffChunk[]) => {
                  const meaningful = chunks.some((c) => c.kind !== "same" && (c.line ?? "").trim().length > 0);
                  if (!meaningful) return <div className="text-xs text-gray-500">No change</div>;
                  return (
                    <div className="space-y-0.5">
                      {chunks.map((c, idx) => {
                        if (c.kind === "same") return null;
                        const prefix = c.kind === "add" ? "+" : "-";
                        const cls = c.kind === "add" ? "text-green-700" : "text-red-700 line-through";
                        return (
                          <div key={idx} className={`font-mono text-xs whitespace-pre-wrap ${cls}`}>{`${prefix} ${c.line}`}</div>
                        );
                      })}
                    </div>
                  );
                };

                return newestFirst.map((v) => {
                  const when = toDateMaybe(v.createdAt)?.toLocaleString() ?? "—";
                  const who = soapVersionUserMap[v.authorUid] ?? v.authorDisplayName ?? v.authorUid ?? "—";

                  const prev = byVersion.get(v.version - 1);
                  const prevSoap = prev?.soap ?? { subjective: "", objective: "", assessment: "", plan: "" };
                  const nextSoap = v.soap ?? { subjective: "", objective: "", assessment: "", plan: "" };

                  const subjDiff = prev ? diffByLines(prevSoap.subjective, nextSoap.subjective) : diffByLines("", nextSoap.subjective);
                  const objDiff = prev ? diffByLines(prevSoap.objective, nextSoap.objective) : diffByLines("", nextSoap.objective);
                  const assDiff = prev ? diffByLines(prevSoap.assessment, nextSoap.assessment) : diffByLines("", nextSoap.assessment);
                  const planDiff = prev ? diffByLines(prevSoap.plan, nextSoap.plan) : diffByLines("", nextSoap.plan);

                  return (
                    <details key={v.id} className="border rounded-lg p-3 bg-gray-50">
                      <summary className="cursor-pointer select-none">
                        <span className="font-medium">Version {v.version}</span>
                        <span className="ml-2 text-gray-700">{when}</span>
                        <span className="ml-2 text-gray-700">by</span>
                        <span className="ml-1 font-medium">{who}</span>
                        {v.reason ? <span className="ml-2 text-gray-600">· {v.reason}</span> : null}
                      </summary>

                      <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="border rounded-md p-3 bg-white">
                          <div className="text-xs font-medium text-gray-700 mb-1">Subjective</div>
                          {renderDiff(subjDiff)}
                        </div>
                        <div className="border rounded-md p-3 bg-white">
                          <div className="text-xs font-medium text-gray-700 mb-1">Objective</div>
                          {renderDiff(objDiff)}
                        </div>
                        <div className="border rounded-md p-3 bg-white">
                          <div className="text-xs font-medium text-gray-700 mb-1">Assessment</div>
                          {renderDiff(assDiff)}
                        </div>
                        <div className="border rounded-md p-3 bg-white">
                          <div className="text-xs font-medium text-gray-700 mb-1">Plan</div>
                          {renderDiff(planDiff)}
                        </div>
                      </div>

                      {!prev ? <div className="mt-3 text-xs text-gray-600">Initial version (no prior version to diff).</div> : null}
                    </details>
                  );
                });
              })()}
            </div>
          )}
        </div>

        {/* Audit history */}
        <div className="border rounded-xl p-4 bg-white text-sm space-y-2">
          <div className="text-base font-semibold text-gray-900">Audit history</div>
          <div className="text-xs text-gray-600">
            Signed encounters are immutable. Use addenda (or correction addenda under break-glass).
          </div>

          {revisions.length === 0 ? (
            <div className="text-xs text-gray-500 mt-2">No revisions recorded yet.</div>
          ) : (
            <div className="space-y-2 mt-2">
              {revisions.map((r) => {
                const when = toDateMaybe(r.editedAt)?.toLocaleString() ?? "—";
                const who = safeStr((r as any).editorDisplayName) || revisionUserMap[r.editorId] || r.editorId || "—";

                return (
                  <details key={r.id} className="border rounded-lg p-3 bg-gray-50">
                    <summary className="cursor-pointer select-none">
                      <span className="font-medium">{modeLabel(r.mode)}</span>
                      <span className="ml-2 text-gray-700">{when}</span>
                      <span className="ml-2 text-gray-700">by</span>
                      <span className="ml-1 font-medium">{who}</span>
                    </summary>

                    {r.mode === "sign_override" ? (
                      <div className="mt-3 border rounded-md p-3 bg-white">
                        <div className="text-xs font-medium text-gray-700 mb-1">Override reason</div>
                        <div className="whitespace-pre-wrap text-sm text-gray-900">
                          {r.signOverrideReason ? r.signOverrideReason : <span className="text-gray-500">—</span>}
                        </div>
                        {r.soapCompletionAtSign ? (
                          <div className="mt-2 text-xs text-gray-700">
                            SOAP completion at sign: {r.soapCompletionAtSign.filled}/{r.soapCompletionAtSign.total}
                          </div>
                        ) : null}
                      </div>
                    ) : null}

                    {r.mode === "addendum" || r.mode === "correction_addendum" ? (
                      <div className="mt-3 border rounded-md p-3 bg-white">
                        <div className="text-xs font-medium text-gray-700 mb-1">Text</div>
                        <div className="whitespace-pre-wrap text-sm text-gray-900">
                          {r.addendumText ? r.addendumText : <span className="text-gray-500">—</span>}
                        </div>

                        {r.mode === "addendum" ? (
                          <div className="mt-2 text-xs text-gray-700">
                            Reason: {r.addendumReason ? r.addendumReason : <span className="text-gray-500">—</span>}
                          </div>
                        ) : (
                          <div className="mt-2 text-xs text-red-700">
                            Correction reason: {r.correctionReason ? r.correctionReason : <span className="text-gray-500">—</span>}
                          </div>
                        )}
                      </div>
                    ) : null}

                    {r.mode === "edit" ? (
                      <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="border rounded-md p-2 bg-white">
                          <div className="text-xs font-medium text-gray-700 mb-1">Previous</div>
                          <div className="text-xs text-gray-600 mb-1">SOAP</div>
                          <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(r.previous?.soap ?? {}, null, 2)}</pre>
                          <div className="text-xs text-gray-600 mt-2 mb-1">Notes</div>
                          <pre className="text-xs whitespace-pre-wrap">{r.previous?.notes ?? ""}</pre>
                        </div>

                        <div className="border rounded-md p-2 bg-white">
                          <div className="text-xs font-medium text-gray-700 mb-1">New</div>
                          <div className="text-xs text-gray-600 mb-1">SOAP</div>
                          <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(r.next?.soap ?? {}, null, 2)}</pre>
                          <div className="text-xs text-gray-600 mt-2 mb-1">Notes</div>
                          <pre className="text-xs whitespace-pre-wrap">{r.next?.notes ?? ""}</pre>
                        </div>

                        <div className="md:col-span-2 border rounded-md p-3 bg-white">
                          <div className="text-xs font-medium text-gray-700 mb-1">Subjective diff</div>
                          <div className="space-y-0.5">
                            {diffByLines(safeStr(r.previous?.soap?.subjective), safeStr(r.next?.soap?.subjective)).map((c, idx) => {
                              if (c.kind === "same") return null;
                              const prefix = c.kind === "add" ? "+" : "-";
                              const cls = c.kind === "add" ? "text-green-700" : "text-red-700 line-through";
                              return (
                                <div key={idx} className={`font-mono text-xs whitespace-pre-wrap ${cls}`}>{`${prefix} ${c.line}`}</div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    ) : null}
                  </details>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default EncounterDetailPage;
