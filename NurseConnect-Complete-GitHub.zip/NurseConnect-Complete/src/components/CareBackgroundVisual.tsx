import React from "react";

export default function CareBackgroundVisual() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-x-0 top-0 -z-10 hidden h-[640px] overflow-hidden lg:block"
    >
      <div className="absolute right-[8%] top-12 h-72 w-72 rounded-full bg-brand-200/35 blur-3xl motion-drift-slow" />
      <div className="absolute right-[22%] top-28 h-56 w-56 rounded-full bg-sand-200/60 blur-3xl motion-float-soft" />
      <div className="absolute right-[5%] top-40 h-40 w-40 rounded-full bg-white/70 blur-2xl motion-pulse-soft" />

      <svg
        viewBox="0 0 760 560"
        className="absolute right-0 top-0 h-full w-[56%] min-w-[520px]"
        fill="none"
      >
        <defs>
          <linearGradient id="careShell" x1="130" y1="70" x2="600" y2="450" gradientUnits="userSpaceOnUse">
            <stop stopColor="white" stopOpacity="0.92" />
            <stop offset="1" stopColor="#EEF6F3" stopOpacity="0.88" />
          </linearGradient>
          <linearGradient id="careStroke" x1="200" y1="60" x2="590" y2="500" gradientUnits="userSpaceOnUse">
            <stop stopColor="#9BE6D6" />
            <stop offset="1" stopColor="#1F9A92" />
          </linearGradient>
        </defs>

        <g opacity="0.95">
          <path
            d="M332 98c80-24 194 3 243 78 48 72 35 194-44 264-78 69-216 85-308 22-91-64-125-210-60-299 33-45 98-55 169-65Z"
            fill="url(#careShell)"
            stroke="rgba(14,42,59,0.08)"
          />
        </g>

        <g className="motion-float-soft" opacity="0.9">
          <rect x="418" y="106" width="136" height="168" rx="32" fill="white" fillOpacity="0.84" />
          <path d="M448 186h76" stroke="#D6DEE2" strokeWidth="12" strokeLinecap="round" />
          <path d="M486 148v76" stroke="#1F9A92" strokeWidth="12" strokeLinecap="round" />
          <path d="M446 236h82" stroke="#D6DEE2" strokeWidth="10" strokeLinecap="round" opacity="0.85" />
        </g>

        <g className="motion-drift-slow" opacity="0.95">
          <path
            d="M166 300l114-98 112 96"
            stroke="url(#careStroke)"
            strokeWidth="13"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M200 284v114c0 18 14 32 32 32h92c18 0 32-14 32-32V284"
            fill="white"
            fillOpacity="0.84"
            stroke="#D6DEE2"
            strokeWidth="8"
          />
          <path d="M254 430V342c0-17 14-30 30-30h8c17 0 30 13 30 30v88" stroke="#D6DEE2" strokeWidth="8" />
          <path d="M228 328h28" stroke="#9BE6D6" strokeWidth="8" strokeLinecap="round" />
        </g>

        <g className="motion-pulse-soft">
          <path
            d="M118 384h76l22-42 31 78 28-55 26 42h104"
            stroke="#1F9A92"
            strokeWidth="9"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>

        <g opacity="0.9">
          <circle cx="560" cy="330" r="54" fill="white" fillOpacity="0.78" />
          <path
            className="motion-draw-loop"
            d="M536 332c0-17 12-29 27-29 11 0 18 7 24 16 6-9 13-16 24-16 15 0 27 12 27 29 0 28-27 44-51 62-25-18-51-34-51-62Z"
            stroke="#0E2A3B"
            strokeWidth="7"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </svg>
    </div>
  );
}
