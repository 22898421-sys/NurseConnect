import React, { useCallback, useEffect, useMemo, useState } from "react";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { MainLayout } from "./MainLayout";
import { ClinicianRosterBlocksEditor } from "./ClinicianRosterBlocksEditor";
import {
  AvailabilityDateBlock,
  ClinicianAvailabilityDoc,
  createAvailabilityDateBlock,
  sanitizeDateBlocks,
} from "../lib/clinicianAvailability";
import { formatNurseProfileLabel } from "../lib/nurses";

export const ClinicianRosterPage: React.FC = () => {
  const { user, normalizedRole, currentUserData } = useAuth() as any;
  const canUse = normalizedRole === "clinician";

  const [dateBlocks, setDateBlocks] = useState<AvailabilityDateBlock[]>([createAvailabilityDateBlock()]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const practiceId = currentUserData?.practiceId || "";
  const clinicianLabel = useMemo(
    () =>
      formatNurseProfileLabel({
        displayName: currentUserData?.displayName?.trim() || user?.displayName?.trim() || "",
        designation: currentUserData?.designation || null,
        nurseType: currentUserData?.nurseType || null,
        email: currentUserData?.email || user?.email || "",
        fallback: user?.uid || "",
      }),
    [currentUserData?.designation, currentUserData?.displayName, currentUserData?.email, currentUserData?.nurseType, user?.displayName, user?.email, user?.uid]
  );

  useEffect(() => {
    const loadAvailability = async () => {
      if (!canUse || !user?.uid) {
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        const snap = await getDoc(doc(db, "clinicianAvailability", user.uid));
        if (!snap.exists()) {
          setDateBlocks([createAvailabilityDateBlock()]);
          return;
        }
        const raw = snap.data() as ClinicianAvailabilityDoc;
        const nextBlocks = sanitizeDateBlocks(raw?.dateBlocks);
        setDateBlocks(nextBlocks.length > 0 ? nextBlocks : [createAvailabilityDateBlock()]);
      } catch (e: any) {
        console.error(e);
        setErr(e?.message ?? "Failed to load roster.");
      } finally {
        setLoading(false);
      }
    };

    void loadAvailability();
  }, [canUse, user?.uid]);

  const addBlock = useCallback(() => {
    setDateBlocks((prev) => [...prev, createAvailabilityDateBlock()]);
  }, []);

  const removeBlock = useCallback((blockId: string) => {
    setDateBlocks((prev) => prev.filter((block) => block.id !== blockId));
  }, []);

  const changeBlockField = useCallback(
    (blockId: string, field: "startDate" | "endDate", value: string) => {
      setDateBlocks((prev) =>
        prev.map((block) => (block.id === blockId ? { ...block, [field]: value } : block))
      );
    },
    []
  );

  const toggleBlockDay = useCallback((blockId: string, dayOfWeek: number, enabled: boolean) => {
    setDateBlocks((prev) =>
      prev.map((block) => {
        if (block.id !== blockId) return block;
        const daysOfWeek = enabled
          ? Array.from(new Set([...block.daysOfWeek, dayOfWeek])).sort((a, b) => a - b)
          : block.daysOfWeek.filter((day) => day !== dayOfWeek);
        return { ...block, daysOfWeek };
      })
    );
  }, []);

  const changeWindow = useCallback(
    (blockId: string, windowIndex: number, field: "start" | "end", value: string) => {
      setDateBlocks((prev) =>
        prev.map((block) => {
          if (block.id !== blockId) return block;
          return {
            ...block,
            windows: block.windows.map((window, index) =>
              index === windowIndex ? { ...window, [field]: value } : window
            ),
          };
        })
      );
    },
    []
  );

  const addWindow = useCallback((blockId: string) => {
    setDateBlocks((prev) =>
      prev.map((block) =>
        block.id === blockId
          ? { ...block, windows: [...block.windows, { start: "08:00", end: "17:00" }] }
          : block
      )
    );
  }, []);

  const removeWindow = useCallback((blockId: string, windowIndex: number) => {
    setDateBlocks((prev) =>
      prev.map((block) =>
        block.id === blockId
          ? { ...block, windows: block.windows.filter((_, index) => index !== windowIndex) }
          : block
      )
    );
  }, []);

  const save = useCallback(async () => {
    if (!user?.uid) return;
    if (!practiceId) {
      setErr("Your nurse profile is missing a practice ID.");
      return;
    }

    setBusy(true);
    setMsg(null);
    setErr(null);

    try {
      const nextDateBlocks = sanitizeDateBlocks(dateBlocks);
      if (nextDateBlocks.length === 0) {
        throw new Error("Add at least one valid dated roster block.");
      }

      await setDoc(
        doc(db, "clinicianAvailability", user.uid),
        {
          clinicianId: user.uid,
          practiceId,
          clinicianName: clinicianLabel || null,
          clinicianEmail: currentUserData?.email || user.email || null,
          nurseType: currentUserData?.nurseType || null,
          designation: currentUserData?.designation || null,
          timeZone: currentUserData?.practiceTimeZone || currentUserData?.timeZone || null,
          weekly: [],
          dateBlocks: nextDateBlocks,
          updatedAt: serverTimestamp(),
          updatedByUid: user.uid,
        },
        { merge: true }
      );

      setDateBlocks(nextDateBlocks);
      setMsg("Roster saved.");
    } catch (e: any) {
      console.error(e);
      setErr(e?.message ?? "Failed to save roster.");
    } finally {
      setBusy(false);
    }
  }, [
    clinicianLabel,
    currentUserData?.designation,
    currentUserData?.email,
    currentUserData?.nurseType,
    currentUserData?.practiceTimeZone,
    currentUserData?.timeZone,
    dateBlocks,
    practiceId,
    user?.email,
    user?.uid,
  ]);

  if (!canUse) {
    return (
      <MainLayout>
        <div className="text-sm text-red-600">Access denied.</div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4 max-w-4xl">
        <div>
          <h1 className="text-2xl font-semibold">My Roster</h1>
          <p className="section-subtitle">Manage your nursing availability for future bookings.</p>
        </div>

        {msg && <div className="text-sm text-emerald-700">{msg}</div>}
        {err && <div className="text-sm text-rose-600">{err}</div>}

        <div className="card p-4 space-y-4">
          <div className="card-header">
            <div>
              <div className="section-title">Availability blocks</div>
              <div className="section-subtitle">
                Create date ranges, select weekdays within those ranges, and publish the time windows patients can book with you.
              </div>
            </div>
            <button className="btn-primary" onClick={() => void save()} disabled={loading || busy}>
              {busy ? "Saving…" : "Save roster"}
            </button>
          </div>

          {loading ? (
            <div className="text-sm text-ink-500">Loading roster…</div>
          ) : (
            <ClinicianRosterBlocksEditor
              blocks={dateBlocks}
              disabled={busy}
              onAddBlock={addBlock}
              onRemoveBlock={removeBlock}
              onChangeBlockField={changeBlockField}
              onToggleDay={toggleBlockDay}
              onChangeWindow={changeWindow}
              onAddWindow={addWindow}
              onRemoveWindow={removeWindow}
            />
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default ClinicianRosterPage;
