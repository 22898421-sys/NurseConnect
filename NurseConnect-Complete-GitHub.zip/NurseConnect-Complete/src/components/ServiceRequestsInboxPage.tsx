import React, { useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, orderBy, query, serverTimestamp, updateDoc, doc } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { MainLayout } from "./MainLayout";
import {
  formatDeliveryModePreference,
  formatFundingPathway,
  formatOrganisationRole,
  formatServiceRequestStatus,
  formatSupportAtHomeCategory,
  ServiceRequestDoc,
  ServiceRequestResponse,
} from "../lib/serviceRequests";

function matchesRequest(currentUserData: any, request: ServiceRequestDoc, uid: string) {
  if (request.status === "filled" || request.status === "withdrawn") return false;
  if (request.requestType === "direct_request") return request.targetNurseUid === uid;

  const nurseType = String(currentUserData?.nurseType || "");
  const basePostcode = String(currentUserData?.publicBasePostcode || "");
  const servicePostcodes = Array.isArray(currentUserData?.publicServicePostcodes) ? currentUserData.publicServicePostcodes.map((item: unknown) => String(item || "")) : [];
  const visitTypes = Array.isArray(currentUserData?.publicVisitTypes) ? currentUserData.publicVisitTypes.map((item: unknown) => String(item || "").toLowerCase()) : [];
  const serviceKeywords = Array.isArray(currentUserData?.publicServiceFocusKeywords)
    ? currentUserData.publicServiceFocusKeywords.map((item: unknown) => String(item || "").toLowerCase())
    : [];
  const requestKeywords = Array.isArray(request.serviceKeywords) ? request.serviceKeywords.map((item) => String(item || "").toLowerCase()) : [];
  const nurseTypeMatch = !request.requiredNurseType || !nurseType || request.requiredNurseType === nurseType;
  const postcodeMatch = !request.postcode || request.postcode === basePostcode || servicePostcodes.includes(request.postcode);
  const keywordMatch =
    requestKeywords.length === 0 ||
    requestKeywords.some((keyword) =>
      serviceKeywords.some((item: string) => item.includes(keyword) || keyword.includes(item))
    );
  const deliveryModeMatch =
    request.deliveryModePreference === "hybrid"
      ? visitTypes.some((item: string) => item.includes("hybrid"))
      : request.deliveryModePreference === "telehealth"
        ? visitTypes.some((item: string) => item.includes("telehealth"))
        : visitTypes.some((item: string) => item.includes("home") || item.includes("person") || item.includes("visit"));
  return nurseTypeMatch && postcodeMatch && keywordMatch && deliveryModeMatch;
}

export default function ServiceRequestsInboxPage() {
  const { user, currentUserData, normalizedRole } = useAuth() as any;
  const [records, setRecords] = useState<ServiceRequestDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [notes, setNotes] = useState<Record<string, string>>({});

  useEffect(() => {
    let active = true;
    async function load() {
      if (!user?.uid) return;
      setLoading(true);
      setError("");
      try {
        const snap = await getDocs(query(collection(db, "serviceRequests"), orderBy("createdAt", "desc"), limit(200)));
        if (!active) return;
        setRecords(snap.docs.map((row) => ({ id: row.id, ...(row.data() as any) })) as ServiceRequestDoc[]);
      } catch (e: any) {
        console.error(e);
        if (!active) return;
        setError(e?.message || "Could not load service requests.");
      } finally {
        if (active) setLoading(false);
      }
    }
    void load();
    return () => {
      active = false;
    };
  }, [user?.uid]);

  const visibleRecords = useMemo(
    () => records.filter((record) => matchesRequest(currentUserData, record, user?.uid || "")),
    [currentUserData, records, user?.uid]
  );

  const respond = async (record: ServiceRequestDoc, responseType: ServiceRequestResponse["responseType"]) => {
    if (!user?.uid) return;
    setError("");
    setMessage("");
    try {
      const nextResponse: ServiceRequestResponse = {
        nurseUid: user.uid,
        nurseDisplayName: currentUserData?.displayName || currentUserData?.email || user.email || "Nurse",
        nurseEmail: currentUserData?.email || user.email || null,
        nurseType: currentUserData?.nurseType || null,
        responseType,
        note: (notes[record.id] || "").trim() || null,
        respondedAt: new Date().toISOString(),
      };
      const existing = Array.isArray(record.responses) ? record.responses.filter((item) => item.nurseUid !== user.uid) : [];
      const nextResponses = [...existing, nextResponse];
      const nextStatus =
        responseType === "accepted"
          ? "accepted"
          : record.requestType === "direct_request"
            ? "direct_declined"
            : "interest_received";
      await updateDoc(doc(db, "serviceRequests", record.id), {
        responses: nextResponses,
        responseCount: nextResponses.length,
        status: nextStatus,
        acceptedByNurseUid: responseType === "accepted" ? user.uid : record.acceptedByNurseUid || null,
        acceptedAt: responseType === "accepted" ? new Date().toISOString() : record.acceptedAt || null,
        updatedByUid: user.uid,
        updatedAt: serverTimestamp(),
      });
      setRecords((current) =>
        current.map((item) =>
          item.id === record.id
            ? {
                ...item,
                responses: nextResponses,
                responseCount: nextResponses.length,
                status: nextStatus as any,
                acceptedByNurseUid: responseType === "accepted" ? user.uid : item.acceptedByNurseUid || null,
                acceptedAt: responseType === "accepted" ? new Date().toISOString() : item.acceptedAt || null,
              }
            : item
        )
      );
      setMessage(responseType === "interest" ? "Interest recorded." : responseType === "accepted" ? "Request accepted." : "Request declined.");
    } catch (e: any) {
      console.error(e);
      setError(e?.message || "Could not update the service request.");
    }
  };

  if (normalizedRole !== "clinician") {
    return (
      <MainLayout>
        <div className="text-sm text-rose-600">Access denied.</div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-semibold">Service requests</h1>
          <p className="section-subtitle">
            Review provider, care-manager, participant and carer requests in your service area, plus direct requests sent to you. Accept only work that fits your scope, availability and any provider or funder requirements.
          </p>
        </div>
        {message ? <div className="text-sm text-emerald-700">{message}</div> : null}
        {error ? <div className="text-sm text-rose-600">{error}</div> : null}
        {loading ? (
          <div className="text-sm text-ink-600">Loading service requests...</div>
        ) : visibleRecords.length === 0 ? (
          <div className="card p-4 text-sm text-ink-600">No current service requests match your profile, nurse type, or target requests yet.</div>
        ) : (
          <div className="space-y-4">
            {visibleRecords.map((record) => {
              const myResponse = Array.isArray(record.responses) ? record.responses.find((item) => item.nurseUid === user?.uid) : null;
              return (
                <div key={record.id} className="card p-4 space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="text-lg font-semibold text-ink-900">{record.serviceTitle}</div>
                      <div className="mt-1 text-sm text-ink-600">
                        {record.organisationName} · {record.suburb}, {record.state} {record.postcode}
                      </div>
                      <div className="mt-1 text-sm text-ink-600">
                        {record.requestType === "direct_request" ? "Direct request" : "Open request"} · {formatOrganisationRole(record.organisationRole)} · {record.requiredNurseType} · {formatFundingPathway(record.fundingPathway)}
                      </div>
                      <div className="mt-1 text-sm text-ink-600">
                        {formatSupportAtHomeCategory(record.supportAtHomeCategory)} · {formatDeliveryModePreference(record.deliveryModePreference)}
                        {Array.isArray(record.serviceKeywords) && record.serviceKeywords.length ? ` · ${record.serviceKeywords.join(", ")}` : ""}
                      </div>
                    </div>
                    <span className="chip">{formatServiceRequestStatus(record.status)}</span>
                  </div>

                  <div className="grid gap-3 md:grid-cols-2 text-sm text-ink-700">
                    <div>
                      <div className="font-medium text-ink-900">Timeframe</div>
                      <div className="mt-1">{record.timeframe}</div>
                    </div>
                    <div>
                      <div className="font-medium text-ink-900">Visit count</div>
                      <div className="mt-1">{record.requestedVisits || "Not specified"}</div>
                    </div>
                    <div>
                      <div className="font-medium text-ink-900">Registered provider</div>
                      <div className="mt-1">{record.registeredProviderName || "Not supplied"}</div>
                    </div>
                    <div>
                      <div className="font-medium text-ink-900">Provider/reference ID</div>
                      <div className="mt-1">{record.registeredProviderId || record.clientReference || "Not supplied"}</div>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-ink-200 bg-sand-100/80 p-4 text-sm leading-7 text-ink-700">
                    <div className="font-medium text-ink-900">Care-plan context</div>
                    <div className="mt-2 whitespace-pre-wrap">{record.carePlanContext}</div>
                  </div>

                  {record.requestType === "direct_request" && record.targetNurseName ? (
                    <div className="text-sm text-ink-700">
                      Sent directly to: {record.targetNurseName} {record.targetNurseType ? `(${record.targetNurseType})` : ""}
                      {record.status === "direct_declined" ? " · Direct request declined" : ""}
                    </div>
                  ) : null}

                  <div>
                    <label className="label">Response note</label>
                    <textarea
                      className="input min-h-[90px]"
                      value={notes[record.id] || ""}
                      onChange={(e) => setNotes((current) => ({ ...current, [record.id]: e.target.value }))}
                      placeholder="Optional note for the requester. Pricing and final terms can still be agreed off-platform or later via messaging."
                    />
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {record.requestType === "open_request" ? (
                      <button className="btn-primary" onClick={() => void respond(record, "interest")}>
                        Express interest
                      </button>
                    ) : (
                      <>
                        <button className="btn-primary" onClick={() => void respond(record, "accepted")}>
                          Accept request
                        </button>
                        <button className="btn-secondary" onClick={() => void respond(record, "declined")}>
                          Decline
                        </button>
                      </>
                    )}
                  </div>

                  {myResponse ? (
                    <div className="text-xs text-ink-500">
                      Your latest response: {myResponse.responseType} · {new Date(myResponse.respondedAt).toLocaleString()}
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
