import React, { useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, query } from "firebase/firestore";
import { Link } from "react-router-dom";
import {
  FiArrowRight,
  FiClock,
  FiFilter,
  FiMapPin,
  FiSearch,
  FiStar,
} from "./PublicIcons";
import { db } from "../firebaseConfig";
import PublicSiteChrome from "./PublicSiteChrome";
import {
  GeoPointLike,
  distanceKm,
  hasUsableCoordinates,
  parseCoordinate,
  resolvePostcodeCentroid,
} from "../lib/geoMatching";

const specialties = [
  "Medication support",
  "Wound and skin care",
  "Chronic disease management",
  "Post-hospital care",
  "Continence and catheter care",
  "Palliative support",
];

const locations = [
  "Australian Capital Territory",
  "New South Wales",
  "Northern Territory",
  "Queensland",
  "South Australia",
  "Tasmania",
  "Victoria",
  "Western Australia",
];

type PublicNurseProfile = {
  id: string;
  displayName: string;
  designation?: string | null;
  nurseType?: string | null;
  ahpraVerified?: boolean;
  ahpraRegistrationNumber?: string | null;
  serviceFocus: string;
  serviceFocusKeywords: string[];
  primaryRegion: string;
  travelRadius?: string | null;
  basePostcode?: string | null;
  baseLatitude?: number | null;
  baseLongitude?: number | null;
  servicePostcodes: string[];
  serviceRadiusKm?: number | null;
  visitTypes: string[];
  fundingModels: string[];
  responseTime?: string | null;
  headline?: string | null;
};

type MatchedProfile = PublicNurseProfile & {
  distanceKm?: number | null;
  matchType: "postcode" | "radius" | "location" | "general";
};

const radiusOptions = [5, 10, 25, 50, 100];

export default function PatientBookingPage() {
  const [selectedSpecialty, setSelectedSpecialty] = useState("Medication support");
  const [selectedLocation, setSelectedLocation] = useState("All locations");
  const [servicePostcode, setServicePostcode] = useState("");
  const [searchRadiusKm, setSearchRadiusKm] = useState(25);
  const [clientLocation, setClientLocation] = useState<GeoPointLike | null>(null);
  const [clientLocationLabel, setClientLocationLabel] = useState("");
  const [locationMessage, setLocationMessage] = useState("");
  const [careMode, setCareMode] = useState("Home visit");
  const [profiles, setProfiles] = useState<PublicNurseProfile[]>([]);
  const [loadingProfiles, setLoadingProfiles] = useState(true);
  const [profilesError, setProfilesError] = useState("");

  useEffect(() => {
    let active = true;

    async function loadProfiles() {
      setLoadingProfiles(true);
      setProfilesError("");
      try {
        const snap = await getDocs(query(collection(db, "publicNurseProfiles"), limit(100)));
        if (!active) return;
        setProfiles(
          snap.docs.map((row) => {
            const raw = row.data() as any;
            return {
              id: row.id,
              displayName: String(raw?.displayName || ""),
              designation: String(raw?.designation || ""),
              nurseType: String(raw?.nurseType || ""),
              ahpraVerified: raw?.ahpraVerified === true,
              ahpraRegistrationNumber: String(raw?.ahpraRegistrationNumber || ""),
              serviceFocus: String(raw?.serviceFocus || ""),
              serviceFocusKeywords: Array.isArray(raw?.serviceFocusKeywords) ? raw.serviceFocusKeywords.map((item: unknown) => String(item || "")) : [],
              primaryRegion: String(raw?.primaryRegion || ""),
              travelRadius: String(raw?.travelRadius || ""),
              basePostcode: String(raw?.basePostcode || ""),
              baseLatitude: parseCoordinate(raw?.baseLatitude),
              baseLongitude: parseCoordinate(raw?.baseLongitude),
              servicePostcodes: Array.isArray(raw?.servicePostcodes) ? raw.servicePostcodes.map((item: unknown) => String(item || "")) : [],
              serviceRadiusKm: typeof raw?.serviceRadiusKm === "number" ? raw.serviceRadiusKm : null,
              visitTypes: Array.isArray(raw?.visitTypes) ? raw.visitTypes.map((item: unknown) => String(item || "")) : [],
              fundingModels: Array.isArray(raw?.fundingModels) ? raw.fundingModels.map((item: unknown) => String(item || "")) : [],
              responseTime: String(raw?.responseTime || ""),
              headline: String(raw?.headline || ""),
            };
          })
        );
      } catch (error: any) {
        if (!active) return;
        setProfilesError(error?.message || "Could not load public nurse profiles right now.");
      } finally {
        if (active) setLoadingProfiles(false);
      }
    }

    void loadProfiles();
    return () => {
      active = false;
    };
  }, []);

  const clientSearchPoint = useMemo(() => {
    if (clientLocation) return clientLocation;
    return resolvePostcodeCentroid(servicePostcode);
  }, [clientLocation, servicePostcode]);

  const featuredProfiles = useMemo<MatchedProfile[]>(() => {
    const normalizedServicePostcode = servicePostcode.replace(/[^\d]/g, "").slice(0, 4);
    return profiles
      .map((profile) => {
      const locationMatch = profile.primaryRegion === selectedLocation || selectedLocation === "All locations";
      const exactPostcodeMatch =
        !normalizedServicePostcode ||
        profile.basePostcode === normalizedServicePostcode ||
        profile.servicePostcodes.includes(normalizedServicePostcode);
      const profilePoint = { lat: profile.baseLatitude ?? NaN, lng: profile.baseLongitude ?? NaN };
      const profileHasPoint = hasUsableCoordinates(profilePoint);
      const distance = clientSearchPoint && profileHasPoint ? distanceKm(clientSearchPoint, profilePoint) : null;
      const profileRadius = profile.serviceRadiusKm || searchRadiusKm;
      const radiusMatch = distance != null && distance <= Math.max(searchRadiusKm, profileRadius);
      const specialtyMatch =
        !selectedSpecialty ||
        profile.serviceFocus.toLowerCase().includes(selectedSpecialty.toLowerCase()) ||
        profile.serviceFocusKeywords.some((item) => item.toLowerCase().includes(selectedSpecialty.toLowerCase())) ||
        (profile.headline || "").toLowerCase().includes(selectedSpecialty.toLowerCase());
      const careModeMatch =
        careMode === "Hybrid care"
          ? profile.visitTypes.some((item) => item.toLowerCase().includes("hybrid"))
          : profile.visitTypes.some((item) => item.toLowerCase().includes(careMode.toLowerCase().replace(" visit", "")));
      const geographyMatch = exactPostcodeMatch || radiusMatch || (!normalizedServicePostcode && !clientSearchPoint);
      const matchType: MatchedProfile["matchType"] = exactPostcodeMatch && normalizedServicePostcode
        ? "postcode"
        : radiusMatch
          ? "radius"
          : locationMatch
            ? "location"
            : "general";
      return {
        ...profile,
        distanceKm: distance,
        matchType,
        isMatch: locationMatch && geographyMatch && specialtyMatch && (careModeMatch || careMode === "Home visit"),
      };
    })
      .filter((profile) => profile.isMatch)
      .sort((a, b) => {
        const ad = typeof a.distanceKm === "number" ? a.distanceKm : Number.POSITIVE_INFINITY;
        const bd = typeof b.distanceKm === "number" ? b.distanceKm : Number.POSITIVE_INFINITY;
        if (ad !== bd) return ad - bd;
        return a.displayName.localeCompare(b.displayName);
      })
      .map(({ isMatch, ...profile }) => profile);
  }, [careMode, clientSearchPoint, profiles, searchRadiusKm, selectedLocation, selectedSpecialty, servicePostcode]);

  const mapProfiles = useMemo(
    () => featuredProfiles.filter((profile) => hasUsableCoordinates({ lat: profile.baseLatitude ?? NaN, lng: profile.baseLongitude ?? NaN })),
    [featuredProfiles]
  );

  function useCurrentLocation() {
    setLocationMessage("");
    if (!navigator.geolocation) {
      setLocationMessage("Current-location search is not available in this browser.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const next = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        if (!hasUsableCoordinates(next)) {
          setLocationMessage("The detected location is outside the supported Australian search area.");
          return;
        }
        setClientLocation(next);
        setClientLocationLabel("Using your current location");
        setLocationMessage("Current location added to the search.");
      },
      () => {
        setLocationMessage("Location permission was not granted. You can still search by postcode.");
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
    );
  }

  function clearCurrentLocation() {
    setClientLocation(null);
    setClientLocationLabel("");
    setLocationMessage("");
  }

  function formatDistance(value?: number | null) {
    if (typeof value !== "number" || !Number.isFinite(value)) return "";
    return value < 10 ? `${value.toFixed(1)} km away` : `${Math.round(value)} km away`;
  }

  function matchLabel(profile: MatchedProfile) {
    if (profile.matchType === "postcode") return "Postcode match";
    if (profile.matchType === "radius") return "Within service radius";
    if (profile.matchType === "location") return "Region match";
    return "Available profile";
  }

  function mapPosition(profile: PublicNurseProfile) {
    const lat = profile.baseLatitude ?? 0;
    const lng = profile.baseLongitude ?? 0;
    const allPoints = [
      ...mapProfiles.map((item) => ({ lat: item.baseLatitude ?? 0, lng: item.baseLongitude ?? 0 })),
      ...(clientSearchPoint ? [clientSearchPoint] : []),
    ];
    const latValues = allPoints.map((item) => item.lat);
    const lngValues = allPoints.map((item) => item.lng);
    const minLat = Math.min(...latValues);
    const maxLat = Math.max(...latValues);
    const minLng = Math.min(...lngValues);
    const maxLng = Math.max(...lngValues);
    const latRange = Math.max(maxLat - minLat, 0.04);
    const lngRange = Math.max(maxLng - minLng, 0.04);
    return {
      x: 12 + ((lng - minLng) / lngRange) * 76,
      y: 88 - ((lat - minLat) / latRange) * 76,
    };
  }

  function clientMapPosition() {
    if (!clientSearchPoint || mapProfiles.length === 0) return null;
    const allPoints = [
      ...mapProfiles.map((item) => ({ lat: item.baseLatitude ?? 0, lng: item.baseLongitude ?? 0 })),
      clientSearchPoint,
    ];
    const latValues = allPoints.map((item) => item.lat);
    const lngValues = allPoints.map((item) => item.lng);
    const minLat = Math.min(...latValues);
    const maxLat = Math.max(...latValues);
    const minLng = Math.min(...lngValues);
    const maxLng = Math.max(...lngValues);
    const latRange = Math.max(maxLat - minLat, 0.04);
    const lngRange = Math.max(maxLng - minLng, 0.04);
    return {
      x: 12 + ((clientSearchPoint.lng - minLng) / lngRange) * 76,
      y: 88 - ((clientSearchPoint.lat - minLat) / latRange) * 76,
    };
  }

  return (
    <PublicSiteChrome
      ctaLabel="Client/Carer Access"
      ctaTo="/patient-login"
      metaTitle="NurseConnectCare | Find or Request Care"
      metaDescription="Search care-at-home options, review independent nurse profiles and route requests with provider, funder or private-care context."
    >
      <section className="mx-auto grid w-full max-w-7xl gap-8 px-4 pb-12 pt-8 sm:px-6 lg:grid-cols-[0.82fr_1fr] lg:px-8 lg:pt-12">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-4 py-2 text-sm text-ink-700 shadow-soft backdrop-blur">
            <FiSearch className="h-4 w-4 text-brand-700" />
            Care discovery and request routing
          </div>
          <h1 className="mt-6 text-4xl leading-tight text-ink-900 sm:text-5xl">
            Find nursing support and route care requests properly.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-700">
            Search by service type, service postcode, location and care model, then move into your client account or an
            organisation request workflow to record care needs, provider context and booking updates securely.
          </p>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-ink-600">
            NurseConnectCare is being designed for national operation across Australia, with nurse profile coverage expanding by state and territory.
          </p>
          <div className="mt-6 flex flex-wrap gap-3" aria-label="Care request options">
            {["Home visits", "Telehealth where appropriate", "Provider-aware requests"].map((item) => (
              <span key={item} className="rounded-full border border-brand-200 bg-brand-50 px-4 py-2 text-sm text-ink-800">
                {item}
              </span>
            ))}
          </div>
        </div>

        <div className="rounded-[28px] border border-ink-200 bg-ink-900 p-6 text-white shadow-lift">
          <div className="flex items-center gap-3">
            <FiFilter className="h-5 w-5 text-brand-200" />
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-200">Find a nurse</p>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <label className="label !text-white/70">Service type</label>
              <select value={selectedSpecialty} onChange={(e) => setSelectedSpecialty(e.target.value)} className="select !border-white/15 !bg-white !text-ink-900">
                {specialties.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label !text-white/70">Service postcode</label>
              <input
                value={servicePostcode}
                onChange={(e) => {
                  setServicePostcode(e.target.value.replace(/[^\d]/g, "").slice(0, 4));
                  clearCurrentLocation();
                }}
                className="input !border-white/15 !bg-white !text-ink-900"
                placeholder="e.g. 3000"
                inputMode="numeric"
              />
            </div>
            <div>
              <label className="label !text-white/70">Search radius</label>
              <select value={searchRadiusKm} onChange={(e) => setSearchRadiusKm(Number(e.target.value))} className="select !border-white/15 !bg-white !text-ink-900">
                {radiusOptions.map((item) => (
                  <option key={item} value={item}>
                    Within {item} km
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label !text-white/70">Location</label>
              <select value={selectedLocation} onChange={(e) => setSelectedLocation(e.target.value)} className="select !border-white/15 !bg-white !text-ink-900">
                <option>All locations</option>
                {locations.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label !text-white/70">Care mode</label>
              <select value={careMode} onChange={(e) => setCareMode(e.target.value)} className="select !border-white/15 !bg-white !text-ink-900">
                <option>Home visit</option>
                <option>Telehealth</option>
                <option>Hybrid care</option>
              </select>
            </div>
          </div>

          <div className="mt-5 rounded-[24px] border border-white/10 bg-white/5 p-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-semibold text-white">Use current location</p>
                <p className="mt-1 text-xs leading-5 text-white/65">
                  Optional. Used only in this browser session to sort nearby nurse profiles.
                </p>
              </div>
              <button
                type="button"
                onClick={clientLocation ? clearCurrentLocation : useCurrentLocation}
                className="inline-flex items-center justify-center rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/20"
              >
                {clientLocation ? "Clear location" : "Use my location"}
              </button>
            </div>
            {clientLocationLabel || locationMessage ? (
              <p className="mt-3 text-xs leading-5 text-white/75">{clientLocationLabel || locationMessage}</p>
            ) : null}
          </div>

          <div className="mt-6 rounded-[24px] bg-white p-5 text-ink-900">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Ready to book</p>
              <p className="mt-3 text-xl font-semibold leading-8">Create your patient/carer account or log in to request care.</p>
            <p className="mt-3 text-sm leading-6 text-ink-600">
              NurseConnectCare supports first-use account creation for care enquiries, appointment requests, scheduling updates and secure communication after care is arranged.
            </p>
            <Link to="/patient-login" className="mt-5 inline-flex items-center gap-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700">
              Client/Carer Access
              <FiArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="border-y border-ink-200/80 bg-white/80 py-12">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-6">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">Suggested matches</p>
              <h2 className="mt-3 text-3xl">Matches for {selectedSpecialty.toLowerCase()}.</h2>
              <p className="mt-4 text-lg leading-8 text-ink-700">
                Profiles show nurse type, service area, funding pathway and response expectations before a client,
                carer, provider or care manager routes a request.
              </p>
              <p className="mt-3 text-sm leading-7 text-ink-600">
                Postcode matching checks declared service postcodes first, then uses nurse base coordinates and service radius where available.
              </p>
            </div>
            <div className="hidden rounded-full border border-brand-200 bg-brand-50 px-4 py-2 text-sm text-ink-700 lg:block">
              {(clientLocation ? "Current location" : servicePostcode ? `${servicePostcode}` : "No postcode") + ` • ${selectedLocation} • ${careMode} • ${searchRadiusKm} km`}
            </div>
          </div>

          {clientSearchPoint && featuredProfiles.length ? (
            <div className="mt-8 grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
              <div className="rounded-[28px] border border-ink-200 bg-white p-6 shadow-soft">
                <div className="flex items-center gap-3">
                  <FiMapPin className="h-5 w-5 text-brand-700" />
                  <h3 className="text-2xl font-semibold text-ink-900">Approximate service area</h3>
                </div>
                <p className="mt-3 text-sm leading-7 text-ink-600">
                  Map points are approximate and based on nurse-published base coordinates, not live nurse locations.
                </p>
                <div className="mt-5 overflow-hidden rounded-[24px] border border-ink-200 bg-sand-100">
                  <svg viewBox="0 0 100 100" className="h-72 w-full" role="img" aria-label="Approximate nearby nurse profile map">
                    <defs>
                      <linearGradient id="care-map-bg" x1="0" x2="1" y1="0" y2="1">
                        <stop offset="0%" stopColor="#f9f6f1" />
                        <stop offset="100%" stopColor="#d9f4ef" />
                      </linearGradient>
                    </defs>
                    <rect width="100" height="100" fill="url(#care-map-bg)" />
                    <path d="M8 68 C25 54, 30 74, 47 58 S72 45, 92 32" fill="none" stroke="#9bded6" strokeWidth="2" />
                    <path d="M14 28 C31 35, 42 18, 62 26 S77 23, 89 15" fill="none" stroke="#d6c7a6" strokeWidth="1.5" />
                    {clientMapPosition() ? (
                      <g>
                        <circle cx={clientMapPosition()?.x} cy={clientMapPosition()?.y} r="8" fill="#0E2A3B" opacity="0.12" />
                        <circle cx={clientMapPosition()?.x} cy={clientMapPosition()?.y} r="4" fill="#0E2A3B" />
                      </g>
                    ) : null}
                    {mapProfiles.map((profile, index) => {
                      const point = mapPosition(profile);
                      return (
                        <g key={profile.id}>
                          <circle cx={point.x} cy={point.y} r="4.5" fill="#1F9A92" stroke="#ffffff" strokeWidth="1.5" />
                          <text x={point.x + 5} y={point.y + 1.5} fontSize="4" fill="#0B1F2A">
                            {index + 1}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>
              </div>
              <div className="rounded-[28px] border border-ink-200 bg-white p-6 shadow-soft">
                <h3 className="text-2xl font-semibold text-ink-900">Closest matches</h3>
                <div className="mt-5 space-y-3">
                  {featuredProfiles.slice(0, 5).map((profile, index) => (
                    <div key={profile.id} className="flex items-center justify-between gap-4 rounded-[20px] bg-sand-100/80 px-4 py-3">
                      <div>
                        <p className="text-sm font-semibold text-ink-900">
                          {index + 1}. {profile.displayName}
                        </p>
                        <p className="mt-1 text-xs text-ink-600">{matchLabel(profile)}</p>
                      </div>
                      <div className="text-right text-sm font-medium text-brand-700">
                        {formatDistance(profile.distanceKm) || profile.primaryRegion}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : null}

          {profilesError ? (
            <div className="mt-10 rounded-[28px] border border-rose-200 bg-rose-50 p-6 text-sm text-rose-700">
              {profilesError}
            </div>
          ) : null}

          {loadingProfiles ? (
            <div className="mt-10 rounded-[28px] border border-ink-200 bg-white p-6 text-sm text-ink-600">
              Loading published nurse profiles...
            </div>
          ) : featuredProfiles.length === 0 ? (
            <div className="mt-10 rounded-[28px] border border-ink-200 bg-white p-6 text-sm leading-7 text-ink-600">
              No published nurse profiles match the current filters yet. As nurses complete and publish their profiles, they will appear here.
            </div>
          ) : (
            <div className="mt-10 grid gap-6 lg:grid-cols-3">
              {featuredProfiles.map((profile) => {
                return (
                  <article key={profile.id} className="rounded-[30px] border border-ink-200 bg-sand-100/80 p-6 shadow-soft">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="text-2xl">{profile.displayName}</h3>
                          <span className="rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-700">
                            {profile.designation || profile.nurseType || "Nurse"}
                          </span>
                          <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-ink-600">
                            {matchLabel(profile)}
                          </span>
                        </div>
                        <p className="mt-2 flex items-center gap-2 text-sm text-ink-600">
                          <FiMapPin className="h-4 w-4 text-brand-700" />
                          {profile.primaryRegion}
                        </p>
                      </div>
                      <div className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-medium text-ink-700 shadow-soft">
                        <FiStar className="h-3.5 w-3.5 text-brand-700" />
                        {formatDistance(profile.distanceKm) || (profile.ahpraVerified ? "AHPRA verified" : "Registration supplied")}
                      </div>
                    </div>

                    {profile.headline ? <p className="mt-5 text-sm font-medium leading-7 text-ink-900">{profile.headline}</p> : null}
                    {profile.serviceFocusKeywords.length ? (
                      <div className="mt-4 flex flex-wrap gap-2">
                        {profile.serviceFocusKeywords.map((tag) => (
                          <span key={tag} className="rounded-full border border-ink-200 bg-white px-3 py-1 text-xs text-ink-700">
                            {tag}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="mt-3 text-sm leading-7 text-ink-700">{profile.serviceFocus}</p>
                    )}

                    <div className="mt-5 grid gap-3">
                      <div className="rounded-2xl bg-white p-4">
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Coverage</p>
                        <p className="mt-2 text-sm leading-6 text-ink-700">{profile.travelRadius || profile.primaryRegion}</p>
                        {profile.basePostcode || profile.servicePostcodes.length ? (
                          <p className="mt-2 text-xs leading-5 text-ink-500">
                            {profile.servicePostcodes.length
                              ? `Postcodes: ${profile.servicePostcodes.join(", ")}`
                              : `Base postcode: ${profile.basePostcode}`}
                            {profile.serviceRadiusKm ? ` · ${profile.serviceRadiusKm} km radius stored` : ""}
                          </p>
                        ) : null}
                      </div>
                      <div className="flex items-center gap-3 rounded-2xl bg-white p-4">
                        <FiClock className="h-4 w-4 text-brand-700" />
                        <span className="text-sm text-ink-700">{profile.responseTime || "Response time shared after booking enquiry"}</span>
                      </div>
                    </div>

                    <div className="mt-5 grid gap-3 sm:grid-cols-2">
                      <div className="rounded-2xl border border-brand-200 bg-white px-4 py-3 text-sm text-ink-700">
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Registration</p>
                        <p className="mt-2">
                          {profile.ahpraVerified
                            ? "AHPRA manually verified"
                            : profile.ahpraRegistrationNumber
                              ? "AHPRA registration supplied"
                              : "Registration details pending"}
                        </p>
                      </div>
                      <div className="rounded-2xl border border-brand-200 bg-white px-4 py-3 text-sm text-ink-700">
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Funding</p>
                        <p className="mt-2">{profile.fundingModels.length ? profile.fundingModels.join(", ") : "Funding details shared on enquiry"}</p>
                      </div>
                    </div>

                    <div className="mt-5 flex flex-wrap gap-2">
                      {profile.visitTypes.map((tag) => (
                        <span key={tag} className="rounded-full border border-brand-200 bg-brand-50 px-3 py-1 text-xs text-ink-700">
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="mt-6 flex gap-3">
                      <Link to="/patient-login?mode=signup" className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-brand-700">
                        Request care
                        <FiArrowRight className="h-4 w-4" />
                      </Link>
                      <Link to={`/for-organisations/request?mode=direct&nurseId=${profile.id}`} className="rounded-full border border-ink-200 bg-white px-4 py-2 text-sm font-medium text-ink-700 transition hover:border-brand-500 hover:text-brand-700">
                        Request for organisation
                      </Link>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="overflow-hidden rounded-[34px] border border-ink-200 bg-[linear-gradient(135deg,#0E2A3B_0%,#12546B_48%,#1F9A92_100%)] p-8 text-white shadow-lift">
            <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Patient account</p>
                <h2 className="mt-3 text-3xl text-white sm:text-4xl">Ready to request care?</h2>
                <p className="mt-4 max-w-2xl text-lg leading-8 text-white/80">
                  Create your patient or carer account on first use, then request care, review approved schedules and stay in touch after care is arranged.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <Link to="/patient-login?mode=signup" className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-medium text-ink-900 transition hover:bg-sand-100">
                  Client/Carer Access
                  <FiArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/for-organisations/request" className="inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 py-3 text-sm font-medium text-white transition hover:bg-white/20">
                  Organisation request
                  <FiArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
