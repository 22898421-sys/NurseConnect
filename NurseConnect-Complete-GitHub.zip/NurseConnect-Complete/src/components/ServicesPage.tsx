import React from "react";
import { Link } from "react-router-dom";
import { FiActivity, FiArrowRight, FiCheckCircle, FiHome, FiMonitor, FiShield } from "./PublicIcons";
import PublicSiteChrome from "./PublicSiteChrome";

const services = [
  { title: "Medication support", body: "Medication administration, injections and adherence support delivered within the independent nurse's scope of practice.", icon: FiActivity },
  { title: "Wound and skin care", body: "Dressings, wound reviews, skin checks and follow-up support in the home.", icon: FiShield },
  { title: "Chronic disease management", body: "Ongoing monitoring and nursing support for chronic conditions at home.", icon: FiCheckCircle },
  { title: "Post-hospital care", body: "Recovery reviews and short-term nursing support after discharge from hospital.", icon: FiHome },
  { title: "Continence and catheter care", body: "Home-based nursing support for continence needs and catheter-related care where clinically appropriate.", icon: FiActivity },
  { title: "Palliative support", body: "Person-centred nursing support that complements the wider palliative and care team.", icon: FiShield },
  { title: "Telehealth follow-up", body: "Video or message-based follow-up where clinically appropriate and agreed by the nurse and client.", icon: FiMonitor },
  { title: "Provider-aware requests", body: "Care requests can record registered-provider, care-plan and funding context so the right workflow follows the request.", icon: FiCheckCircle },
];

export default function ServicesPage() {
  return (
    <PublicSiteChrome
      metaTitle="NurseConnectCare | Services"
      metaDescription="Explore care-at-home nursing support available through NurseConnectCare."
    >
      <section className="bg-gradient-to-br from-sand-100 via-white to-brand-50">
        <div className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
          <p className="text-xs font-extrabold uppercase tracking-[0.24em] text-brand-700">Our services</p>
          <h1 className="mt-4 max-w-4xl text-4xl font-extrabold leading-tight text-ink-900 sm:text-6xl">Home nursing support built around the person.</h1>
          <p className="mt-6 max-w-3xl text-lg leading-8 text-ink-500">
            NurseConnectCare helps people discover independent nursing support, understand available care options and move into the correct request, booking and follow-up pathway.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/request-care" className="inline-flex items-center gap-2 rounded-full bg-brand-700 px-6 py-3 text-sm font-bold text-white">
              Request Care <FiArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/for-organisations/request" className="inline-flex items-center gap-2 rounded-full border border-ink-200 bg-white px-6 py-3 text-sm font-bold text-ink-900">
              Organisation Request
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {services.map(({ title, body, icon: Icon }) => (
            <article key={title} className="rounded-[24px] border border-ink-200 bg-white p-6 shadow-soft">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-700">
                <Icon className="h-5 w-5" />
              </div>
              <h2 className="mt-5 text-xl font-extrabold">{title}</h2>
              <p className="mt-3 text-sm leading-7 text-ink-500">{body}</p>
            </article>
          ))}
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          <div className="rounded-[28px] border border-ink-200 bg-white p-7">
            <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-brand-700">Care model</p>
            <h2 className="mt-3 text-3xl font-extrabold">Independent nurse-led care</h2>
            <p className="mt-4 text-sm leading-7 text-ink-500">
              NurseConnectCare is a connection and workflow platform. Independent nurses remain responsible for clinical care, scope of practice and documentation decisions. Where a registered provider, care manager or funder is involved, their approval, funding and governance responsibilities remain with them.
            </p>
          </div>
          <div className="rounded-[28px] bg-brand-900 p-7 text-white">
            <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-brand-200">Secure operations</p>
            <h2 className="mt-3 text-3xl font-extrabold text-white">Connected to EIRENIX Care</h2>
            <p className="mt-4 text-sm leading-7 text-white/70">
              Once a request moves into the care workflow, authorised nurses use EIRENIX Care for requests, bookings, records, service evidence, billing support and care coordination.
            </p>
            <Link to="/clinician-login?mode=signup" className="mt-6 inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-bold text-brand-900">
              Clinician Access <FiArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
