import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PublicSiteChrome from "./PublicSiteChrome";
import { bootstrapInitialSystemAdmin, getBootstrapStatus, type BootstrapStatus } from "../lib/bootstrap";

const initialStatus: BootstrapStatus = {
  bootstrapAllowed: false,
  requiresBootstrap: false,
  hasSystemAdmin: false,
  hasUsers: false,
};

export default function BootstrapSetupPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<BootstrapStatus>(initialStatus);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [formValues, setFormValues] = useState({
    displayName: "System Admin",
    email: "admin@nurseconnectcare.local",
    password: "",
  });

  useEffect(() => {
    let active = true;
    async function loadStatus() {
      setLoadingStatus(true);
      try {
        const next = await getBootstrapStatus();
        if (!active) return;
        setStatus(next);
      } catch (err: any) {
        if (!active) return;
        setError(err?.message || "Could not check bootstrap status.");
      } finally {
        if (active) setLoadingStatus(false);
      }
    }
    void loadStatus();
    return () => {
      active = false;
    };
  }, []);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setSuccess("");
    setBusy(true);
    try {
      await bootstrapInitialSystemAdmin(formValues);
      setSuccess("Initial system admin created. You can now log in.");
      setTimeout(() => navigate("/clinician-login", { replace: true }), 900);
    } catch (err: any) {
      setError(err?.message || "Bootstrap setup failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <PublicSiteChrome
      ctaLabel="Nurse Login"
      ctaTo="/clinician-login"
      metaTitle="NurseConnectCare | Initial Setup"
      metaDescription="Create the first local system admin for a fresh NurseConnectCare emulator environment."
    >
      <section className="mx-auto w-full max-w-3xl px-4 pb-16 pt-10 sm:px-6 lg:px-8 lg:pt-16">
        <div className="rounded-[32px] border border-ink-200 bg-white p-8 shadow-soft">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Initial local setup</p>
          <h1 className="mt-3 text-4xl">Create the first system admin</h1>
          <p className="mt-4 text-lg leading-8 text-ink-700">
            Use this once on a fresh local emulator to bootstrap the first admin account without creating manual Auth and Firestore records.
          </p>

          {loadingStatus ? (
            <div className="mt-6 rounded-2xl border border-ink-200 bg-sand-100/80 px-4 py-3 text-sm text-ink-600">
              Checking bootstrap status...
            </div>
          ) : null}
          {error ? (
            <div className="mt-6 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>
          ) : null}
          {success ? (
            <div className="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{success}</div>
          ) : null}

          {!loadingStatus && !status.bootstrapAllowed ? (
            <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
              Bootstrap setup is only available in the local emulator environment.
            </div>
          ) : null}

          {!loadingStatus && status.bootstrapAllowed && !status.requiresBootstrap ? (
            <div className="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
              A system admin already exists. Continue to <Link to="/clinician-login" className="font-medium underline">Nurse Login</Link>.
            </div>
          ) : null}

          {!loadingStatus && status.bootstrapAllowed && status.requiresBootstrap ? (
            <form className="mt-8 grid gap-4" onSubmit={handleSubmit}>
              <div>
                <label className="label" htmlFor="bootstrap-display-name">Display name</label>
                <input
                  id="bootstrap-display-name"
                  className="input"
                  value={formValues.displayName}
                  onChange={(event) => setFormValues((current) => ({ ...current, displayName: event.target.value }))}
                />
              </div>
              <div>
                <label className="label" htmlFor="bootstrap-email">Email address</label>
                <input
                  id="bootstrap-email"
                  className="input"
                  type="email"
                  autoComplete="email"
                  value={formValues.email}
                  onChange={(event) => setFormValues((current) => ({ ...current, email: event.target.value }))}
                />
              </div>
              <div>
                <label className="label" htmlFor="bootstrap-password">Password</label>
                <input
                  id="bootstrap-password"
                  className="input"
                  type="password"
                  autoComplete="new-password"
                  value={formValues.password}
                  onChange={(event) => setFormValues((current) => ({ ...current, password: event.target.value }))}
                />
                <p className="field-hint">Use at least 8 characters. This account is local to the isolated NurseConnectCare emulator.</p>
              </div>
              <div className="flex flex-col gap-3 sm:flex-row">
                <button type="submit" className="btn-primary" disabled={busy}>
                  {busy ? "Creating admin..." : "Create initial admin"}
                </button>
                <Link to="/clinician-login" className="btn-secondary">
                  Back to login
                </Link>
              </div>
            </form>
          ) : null}
        </div>
      </section>
    </PublicSiteChrome>
  );
}
