import React from "react";
import PublicSiteChrome from "./PublicSiteChrome";

const sections = [
  {
    title: "Information collected",
    body: "NurseConnectCare may collect contact information, enquiry details, account details, provider/request context, booking-related information and records submitted through the website and connected account workflows.",
  },
  {
    title: "How information is used",
    body: "Information is used to operate the platform, respond to enquiries, support account access, route care requests, facilitate bookings, prepare evidence records and maintain secure connected workflows.",
  },
  {
    title: "Clinical responsibility",
    body: "Clinical care remains the responsibility of the independent nurse. Support at Home approval, funding and care-plan responsibilities remain with the relevant registered provider, care manager or funder where applicable. NurseConnectCare acts as connector and workflow infrastructure rather than the provider of care.",
  },
  {
    title: "Security and access",
    body: "Reasonable steps are taken to secure platform access and connected records, including secure login pathways for the nurse environment.",
  },
];

export default function PrivacyPolicyPage() {
  return (
    <PublicSiteChrome
      ctaLabel="Contact Us"
      ctaTo="/contact"
      metaTitle="NurseConnectCare | Privacy Policy"
      metaDescription="Read the draft privacy policy for the NurseConnectCare public website and connected workflows."
    >
      <section className="mx-auto w-full max-w-5xl px-4 pb-16 pt-8 sm:px-6 lg:px-8 lg:pt-14">
        <div className="border-t border-ink-200 bg-white p-8 shadow-soft sm:p-10">
          <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">Draft privacy policy</p>
          <h1 className="mt-4 text-4xl leading-tight text-ink-900 sm:text-5xl">Privacy and information handling.</h1>
          <p className="mt-6 text-lg leading-8 text-ink-700">
            This draft explains how the current public website and connected workflows handle information. Final legal
            wording should be reviewed before production launch, especially where provider, participant, clinical,
            complaint, incident or Support at Home records are handled.
          </p>

          <div className="mt-10 space-y-8">
            {sections.map((section) => (
              <section key={section.title}>
                <h2 className="text-2xl">{section.title}</h2>
                <p className="mt-3 text-sm leading-7 text-ink-700">{section.body}</p>
              </section>
            ))}
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
