// src/components/NavBar.tsx
import React, { useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { collection, getDocs, limit, orderBy, query, where } from "firebase/firestore";
import { db } from "../firebaseConfig";
import EirenixMarkWord from "./EirenixMark";

function normalizeRole(role?: string): string {
  return role || "";
}

const EirenixMark: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 64 64"
      role="img"
      aria-label="EIRENIX Care trademark"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="32" cy="32" r="26" fill="none" stroke="#1F9A92" strokeWidth="4" />
      <path d="M32 18v28" stroke="#1F9A92" strokeWidth="4" strokeLinecap="round" />
      <path d="M18 32h28" stroke="#1F9A92" strokeWidth="4" strokeLinecap="round" />
      <circle cx="32" cy="32" r="2.6" fill="#9BE6D6" />
    </svg>
  );
};

export const NavBar: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, currentUserData, logout } = useAuth() as any;

  const role = normalizeRole(currentUserData?.role);
  const displayName =
    currentUserData?.fullName ||
    currentUserData?.name ||
    currentUserData?.email ||
    user?.email ||
    "";
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  const isActive = (path: string) => location.pathname === path;
  const [taskCounts, setTaskCounts] = useState<{ clinician: number; admin: number }>({
    clinician: 0,
    admin: 0,
  });

  useEffect(() => {
    if (!menuOpen) return;
    const handleClick = (event: MouseEvent) => {
      if (!menuRef.current) return;
      if (!menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [menuOpen]);

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/");
    } catch (e) {
      console.error("Logout failed", e);
    }
  };

  const linkBase = "px-3 py-2 rounded-md text-sm font-medium transition-colors";

  // Role helpers
  const isSystemAdmin = role === "system_admin";
  const isClinician = role === "clinician";

  const canSeePatients = isClinician;
  const canSeeBilling = isClinician;
  const canSeeServiceRequests = isClinician;
  const canSeePublicEnquiries = isSystemAdmin;
  const needsSubscriptionSetup =
    isClinician &&
    (currentUserData?.subscriptionStatus === "pending_payment" || currentUserData?.subscriptionStatus === "trial_active");
  const accountMenuItems = [
    isClinician
      ? {
          label: needsSubscriptionSetup ? "Manage subscription" : "Subscription setup",
          path: "/nurse-subscription",
        }
      : null,
    {
      label: "Profile settings",
      path: "/profile",
    },
    {
      label: isSystemAdmin ? "System admin home" : role === "patient" ? "Client portal" : "Nurse workspace",
      path: isSystemAdmin ? "/system-admin" : role === "patient" ? "/patient" : "/schedule",
    },
  ].filter(Boolean) as Array<{ label: string; path: string }>;

  useEffect(() => {
    const loadCounts = async () => {
      if (!user?.uid) return;
      try {
        if (role === "clinician") {
          const qEnc = query(
            collection(db, "encounters"),
            where("practitionerId", "==", user.uid),
            where("status", "==", "draft"),
            orderBy("createdAt", "desc"),
            limit(50)
          );
          const snap = await getDocs(qEnc);
          setTaskCounts((prev) => ({ ...prev, clinician: snap.size }));
        } else if (role === "system_admin") {
          const qInv = query(
            collection(db, "invoices"),
            where("status", "==", "issued"),
            orderBy("issuedDate", "desc"),
            limit(50)
          );
          const invSnap = await getDocs(qInv);
          setTaskCounts((prev) => ({ ...prev, admin: invSnap.size }));
        }
      } catch (e) {
        console.error("Failed to load task counts", e);
      }
    };
    void loadCounts();
  }, [role, user?.uid]);

  return (
    <nav className="w-full bg-brand-900 border-b border-brand-900">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Brand pill: keep as the primary "home" action. */}
        {/* It points to /dashboard which redirects by role, per Dashboard.tsx. */}
        <Link
          to="/dashboard"
          className="flex items-center gap-3 bg-white/95 rounded-full px-3 py-2 shadow-soft hover:bg-white transition-colors"
        >
          <EirenixMark className="h-8 w-8 shrink-0" />
          <EirenixMarkWord className="text-lg sm:text-xl font-semibold tracking-wide text-brand-900" />
        </Link>

        {/* Navigation */}
        <div className="flex items-center gap-1 sm:gap-2">
          {user ? (
            <>
              {isClinician && (
                <>
                  <Link
                    to="/schedule"
                    className={`${linkBase} ${
                      isActive("/schedule") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                    }`}
                  >
                    <span className="relative">
                      Nurse Workspace
                      {taskCounts.clinician > 0 && (
                        <span className="ml-2 inline-flex items-center justify-center rounded-full bg-brand-200 text-brand-900 text-[10px] font-semibold px-2">
                          {taskCounts.clinician}
                        </span>
                      )}
                    </span>
                  </Link>
                  <Link
                    to="/my-roster"
                    className={`${linkBase} ${
                      isActive("/my-roster") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                    }`}
                  >
                    My Roster
                  </Link>
                </>
              )}

              {canSeePatients && (
                <Link
                  to="/patients"
                  className={`${linkBase} ${
                    isActive("/patients") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                  }`}
                >
                  Clients
                </Link>
              )}

              {canSeeBilling && (
                <Link
                  to="/billing"
                  className={`${linkBase} ${
                    isActive("/billing") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                  }`}
                >
                  Billing
                </Link>
              )}

              {canSeeServiceRequests && (
                <Link
                  to="/service-requests"
                  className={`${linkBase} ${
                    isActive("/service-requests") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                  }`}
                >
                  Service Requests
                </Link>
              )}

              {isClinician && (
                <Link
                  to="/support-access"
                  className={`${linkBase} ${
                    isActive("/support-access") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                  }`}
                >
                  Support Access
                </Link>
              )}

              {canSeePublicEnquiries && (
                <Link
                  to="/public-enquiries"
                  className={`${linkBase} ${
                    isActive("/public-enquiries") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                  }`}
                >
                  Public Enquiries
                </Link>
              )}

              {isSystemAdmin && (
                <>
                  <Link
                    to="/compliance"
                    className={`${linkBase} ${
                      isActive("/compliance") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                    }`}
                  >
                    Compliance
                  </Link>
                  <Link
                    to="/support-access"
                    className={`${linkBase} ${
                      isActive("/support-access") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                    }`}
                  >
                    Support Access
                  </Link>
                  <Link
                    to="/system-admin"
                    className={`${linkBase} ${
                      isActive("/system-admin") ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"
                    }`}
                  >
                    <span className="relative">
                      System Admin
                      {taskCounts.admin > 0 && (
                        <span className="ml-2 inline-flex items-center justify-center rounded-full bg-brand-200 text-brand-900 text-[10px] font-semibold px-2">
                          {taskCounts.admin}
                        </span>
                      )}
                    </span>
                  </Link>
                </>
              )}

              {displayName && (
                <div className="relative hidden sm:block" ref={menuRef}>
                  <button
                    onClick={() => setMenuOpen((prev) => !prev)}
                    className={`${linkBase} ${menuOpen ? "bg-brand-500 text-white shadow-soft" : "text-brand-50 hover:bg-white/10"}`}
                    aria-haspopup="menu"
                    aria-expanded={menuOpen}
                  >
                    <span className="truncate max-w-[160px]">Profile settings</span>
                  </button>

                  {menuOpen && (
                    <div className="absolute right-0 mt-2 w-44 rounded-xl border border-ink-200 bg-white shadow-soft overflow-hidden z-50">
                      {accountMenuItems.map((item) => (
                        <button
                          key={item.path}
                          className="w-full text-left px-3 py-2 text-sm text-ink-700 hover:bg-ink-200/40"
                          onClick={() => {
                            setMenuOpen(false);
                            navigate(item.path);
                          }}
                        >
                          {item.label}
                        </button>
                      ))}
                      <button
                        className="w-full text-left px-3 py-2 text-sm text-ink-700 hover:bg-ink-200/40"
                        onClick={async () => {
                          setMenuOpen(false);
                          await handleLogout();
                        }}
                      >
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              )}

              <button
                onClick={handleLogout}
                className={`${linkBase} text-brand-50 border border-white/20 hover:bg-white/10`}
              >
                Logout
              </button>
            </>
          ) : (
            <Link to="/" className={`${linkBase} text-brand-50 hover:bg-white/10`}>
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
