import React from "react";
import PublicSiteChrome from "./PublicSiteChrome";

const sections = [
  {
    title: "Platform role",
    body: "NurseConnectCare operates as a connector and infrastructure platform that supports care enquiries, provider-aware service requests, booking workflows, documentation support and records infrastructure for independent nursing practice.",
  },
  {
    title: "Independent providers",
    body: "Nurses using the platform act as independent providers and remain responsible for their own scope of practice, professional obligations, insurance, care delivery and documentation decisions.",
  },
  {
    title: "Requests, bookings and agreements",
    body: "Client and carer requests may be routed to independent nurses, care managers, funders or registered providers. Service approval, funding decisions and care-plan responsibility remain with the relevant nurse, provider, care manager or funder as applicable. Platform tools may support communication, booking management and evidence preparation.",
  },
  {
    title: "Website content",
    body: "Public-facing content is provided for general information about the platform and available service models. It is not a substitute for clinical advice or professional judgement.",
  },
];

export default function TermsPage() {
  return (
    <PublicSiteChrome
      ctaLabel="Contact Us"
      ctaTo="/contact"
      metaTitle="NurseConnectCare | Terms of Use"
      metaDescription="Read the draft terms for the NurseConnectCare public website and platform model."
    >
      <section className="mx-auto w-full max-w-5xl px-4 pb-16 pt-8 sm:px-6 lg:px-8 lg:pt-14">
        <div className="border-t border-ink-200 bg-white p-8 shadow-soft sm:p-10">
          <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">Draft terms</p>
          <h1 className="mt-4 text-4xl leading-tight text-ink-900 sm:text-5xl">Website and platform terms.</h1>
          <p className="mt-6 text-lg leading-8 text-ink-700">
            These draft terms describe the current NurseConnectCare platform model and should be replaced with final
            reviewed legal wording before production launch.
          </p>

          <div className="mt-10 space-y-8">
            {sections.map((section) => (
              <section key={section.title}>
                <h2 className="text-2xl">{section.title}</h2>
                <p className="mt-3 text-sm leading-7 text-ink-700">{section.body}</p>
              </section>
            ))}
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
