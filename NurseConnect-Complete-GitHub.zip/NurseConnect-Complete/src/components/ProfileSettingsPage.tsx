// src/components/ProfileSettingsPage.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { RecaptchaVerifier, linkWithPhoneNumber } from "firebase/auth";
import { doc, serverTimestamp, updateDoc } from "firebase/firestore";
import { Link } from "react-router-dom";
import { auth, db } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { MainLayout } from "./MainLayout";
import { getIanaTimeZones, getLocalTimeZone } from "../lib/time";
import { NURSE_TYPE_OPTIONS, NurseType, normalizeNurseType } from "../lib/nurses";

export const ProfileSettingsPage: React.FC = () => {
  const { user, currentUserData, loading } = useAuth() as any;
  const [displayName, setDisplayName] = useState("");
  const [designation, setDesignation] = useState("");
  const [nurseType, setNurseType] = useState<NurseType | "">("");
  const [ahpraRegistrationNumber, setAhpraRegistrationNumber] = useState("");
  const [publicProfileEnabled, setPublicProfileEnabled] = useState(false);
  const [publicHeadline, setPublicHeadline] = useState("");
  const [publicServiceFocusKeywordsText, setPublicServiceFocusKeywordsText] = useState("");
  const [publicPrimaryRegion, setPublicPrimaryRegion] = useState("");
  const [publicTravelRadius, setPublicTravelRadius] = useState("");
  const [publicBasePostcode, setPublicBasePostcode] = useState("");
  const [publicBaseLatitude, setPublicBaseLatitude] = useState("");
  const [publicBaseLongitude, setPublicBaseLongitude] = useState("");
  const [publicServicePostcodesText, setPublicServicePostcodesText] = useState("");
  const [publicServiceRadiusKm, setPublicServiceRadiusKm] = useState("");
  const [publicVisitTypes, setPublicVisitTypes] = useState<string[]>([]);
  const [publicFundingModels, setPublicFundingModels] = useState<string[]>([]);
  const [publicResponseTime, setPublicResponseTime] = useState("");
  const [billingBusinessName, setBillingBusinessName] = useState("");
  const [billingAbn, setBillingAbn] = useState("");
  const [billingEmail, setBillingEmail] = useState("");
  const [billingPhone, setBillingPhone] = useState("");
  const [billingAddress, setBillingAddress] = useState("");
  const [timeZone, setTimeZone] = useState("");
  const [tzQuery, setTzQuery] = useState("");
  const [tzOpen, setTzOpen] = useState(false);
  const [tzActiveIndex, setTzActiveIndex] = useState(0);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const tzContainerRef = useRef<HTMLDivElement | null>(null);
  const recaptchaRef = useRef<RecaptchaVerifier | null>(null);
  const [phoneInput, setPhoneInput] = useState("");
  const [phoneOtp, setPhoneOtp] = useState("");
  const [phoneMsg, setPhoneMsg] = useState<string | null>(null);
  const [phoneBusy, setPhoneBusy] = useState(false);
  const [phoneConfirmation, setPhoneConfirmation] = useState<any>(null);

  useEffect(() => {
    setDisplayName(currentUserData?.displayName || "");
    setDesignation(currentUserData?.designation || "");
    setNurseType(normalizeNurseType(currentUserData?.nurseType));
    setAhpraRegistrationNumber(currentUserData?.ahpraRegistrationNumber || "");
    setPublicProfileEnabled(Boolean(currentUserData?.publicProfileEnabled));
    setPublicHeadline(currentUserData?.publicHeadline || "");
    setPublicServiceFocusKeywordsText(
      Array.isArray(currentUserData?.publicServiceFocusKeywords) && currentUserData.publicServiceFocusKeywords.length
        ? currentUserData.publicServiceFocusKeywords.join(", ")
        : currentUserData?.publicServiceFocus || ""
    );
    setPublicPrimaryRegion(currentUserData?.publicPrimaryRegion || "");
    setPublicTravelRadius(currentUserData?.publicTravelRadius || "");
    setPublicBasePostcode(currentUserData?.publicBasePostcode || "");
    setPublicBaseLatitude(
      typeof currentUserData?.publicBaseLatitude === "number" && Number.isFinite(currentUserData.publicBaseLatitude)
        ? String(currentUserData.publicBaseLatitude)
        : ""
    );
    setPublicBaseLongitude(
      typeof currentUserData?.publicBaseLongitude === "number" && Number.isFinite(currentUserData.publicBaseLongitude)
        ? String(currentUserData.publicBaseLongitude)
        : ""
    );
    setPublicServicePostcodesText(Array.isArray(currentUserData?.publicServicePostcodes) ? currentUserData.publicServicePostcodes.join(", ") : "");
    setPublicServiceRadiusKm(
      typeof currentUserData?.publicServiceRadiusKm === "number" && Number.isFinite(currentUserData.publicServiceRadiusKm)
        ? String(currentUserData.publicServiceRadiusKm)
        : ""
    );
    setPublicVisitTypes(Array.isArray(currentUserData?.publicVisitTypes) ? currentUserData.publicVisitTypes : []);
    setPublicFundingModels(Array.isArray(currentUserData?.publicFundingModels) ? currentUserData.publicFundingModels : []);
    setPublicResponseTime(currentUserData?.publicResponseTime || "");
    setBillingBusinessName(currentUserData?.billingBusinessName || "");
    setBillingAbn(currentUserData?.billingAbn || "");
    setBillingEmail(currentUserData?.billingEmail || currentUserData?.email || "");
    setBillingPhone(currentUserData?.billingPhone || currentUserData?.phoneNumber || "");
    setBillingAddress(currentUserData?.billingAddress || "");
    setTimeZone(currentUserData?.timeZone || "");
    setTzQuery(currentUserData?.timeZone || "");
  }, [currentUserData]);

  useEffect(() => {
    if (recaptchaRef.current) return;
    try {
      recaptchaRef.current = new RecaptchaVerifier(auth, "recaptcha-container-link", {
        size: "invisible",
      });
    } catch {
      // ignore duplicate init
    }
  }, []);

  const roleLabel = useMemo(() => {
    const r = currentUserData?.role || "";
    return r ? String(r).replace("_", " ") : "—";
  }, [currentUserData?.role]);
  const needsSubscriptionSetup =
    currentUserData?.role === "clinician" &&
    (currentUserData?.subscriptionStatus === "pending_payment" || currentUserData?.subscriptionStatus === "trial_active");

  const localTz = useMemo(() => getLocalTimeZone(), []);
  const tzOptions = useMemo(() => getIanaTimeZones(), []);
  const tzFiltered = useMemo(() => {
    const q = (tzQuery || "").trim().toLowerCase();
    const base = q ? tzOptions.filter((tz) => tz.toLowerCase().includes(q)) : tzOptions.slice();
    const recommended = localTz ? [localTz] : [];
    const deduped = [
      ...recommended,
      ...base.filter((tz) => tz !== localTz),
    ];
    return deduped.slice(0, 50);
  }, [tzOptions, tzQuery, localTz]);

  const tzGrouped = useMemo(() => {
    const groups: Record<string, string[]> = {};
    const remaining = tzFiltered.filter((tz) => tz !== localTz);
    for (const tz of remaining) {
      const region = tz.split("/")[0] || "Other";
      if (!groups[region]) groups[region] = [];
      groups[region].push(tz);
    }
    const order = ["Recommended", "Africa", "America", "Antarctica", "Asia", "Atlantic", "Australia", "Europe", "Pacific", "Indian", "Other"];
    const entries = Object.entries(groups);
    entries.sort((a, b) => {
      const ai = order.indexOf(a[0]);
      const bi = order.indexOf(b[0]);
      if (ai === -1 && bi === -1) return a[0].localeCompare(b[0]);
      if (ai === -1) return 1;
      if (bi === -1) return -1;
      return ai - bi;
    });
    const result: Array<[string, string[]]> = [];
    if (localTz) result.push(["Recommended", [localTz]]);
    return result.concat(entries);
  }, [tzFiltered, localTz]);

  const onSave = async () => {
    if (!user?.uid) return;
    setMsg(null);
    setErr(null);
    setBusy(true);
    const normalizedBasePostcode = publicBasePostcode.replace(/[^\d]/g, "").slice(0, 4);
    const normalizedServicePostcodes = publicServicePostcodesText
      .split(",")
      .map((item) => item.replace(/[^\d]/g, "").slice(0, 4))
      .filter((item, index, array) => item.length === 4 && array.indexOf(item) === index);
    const normalizedServiceRadiusKm = Number(publicServiceRadiusKm);
    const normalizedBaseLatitude = Number(publicBaseLatitude);
    const normalizedBaseLongitude = Number(publicBaseLongitude);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        displayName: displayName.trim(),
        designation: designation.trim() || null,
        nurseType: nurseType || null,
        ahpraRegistrationNumber: ahpraRegistrationNumber.trim().toUpperCase() || null,
        publicProfileEnabled,
        publicHeadline: publicHeadline.trim() || null,
        publicServiceFocus: publicServiceFocusKeywordsText.trim() || null,
        publicServiceFocusKeywords: publicServiceFocusKeywordsText
          .split(",")
          .map((item) => item.trim())
          .filter((item, index, array) => item && array.indexOf(item) === index),
        publicPrimaryRegion: publicPrimaryRegion.trim() || null,
        publicTravelRadius: publicTravelRadius.trim() || null,
        publicBasePostcode: normalizedBasePostcode || null,
        publicBaseLatitude: Number.isFinite(normalizedBaseLatitude) ? normalizedBaseLatitude : null,
        publicBaseLongitude: Number.isFinite(normalizedBaseLongitude) ? normalizedBaseLongitude : null,
        publicServicePostcodes: normalizedServicePostcodes,
        publicServiceRadiusKm: Number.isFinite(normalizedServiceRadiusKm) && normalizedServiceRadiusKm > 0 ? Math.round(normalizedServiceRadiusKm) : null,
        publicVisitTypes,
        publicFundingModels,
        publicResponseTime: publicResponseTime.trim() || null,
        billingBusinessName: billingBusinessName.trim() || null,
        billingAbn: billingAbn.replace(/[^\d]/g, "").slice(0, 11) || null,
        billingEmail: billingEmail.trim().toLowerCase() || null,
        billingPhone: billingPhone.trim() || null,
        billingAddress: billingAddress.trim() || null,
        timeZone: (timeZone || tzQuery).trim() || null,
        updatedAt: serverTimestamp(),
      });
      setMsg("Profile updated.");
    } catch (e: any) {
      setErr(e?.message ?? "Failed to update profile.");
    } finally {
      setBusy(false);
    }
  };

  function normalizePhone(input: string) {
    const raw = (input || "").toString().trim();
    if (!raw) return "";
    const keepPlus = raw.startsWith("+");
    const digits = raw.replace(/[^\d]/g, "");
    if (!digits) return "";
    return keepPlus ? `+${digits}` : digits;
  }

  const sendPhoneOtp = async () => {
    setPhoneMsg(null);
    setErr(null);
    const phone = normalizePhone(phoneInput);
    if (!phone) {
      setPhoneMsg("Enter a valid phone number.");
      return;
    }
    if (!user?.uid) {
      setPhoneMsg("You must be signed in to link a phone number.");
      return;
    }
    if (!recaptchaRef.current) {
      setPhoneMsg("ReCAPTCHA not ready. Please refresh and try again.");
      return;
    }
    setPhoneBusy(true);
    try {
      const confirmation = await linkWithPhoneNumber(user, phone, recaptchaRef.current);
      setPhoneConfirmation(confirmation);
      setPhoneMsg("OTP sent. Check your phone.");
    } catch (e: any) {
      setPhoneMsg(e?.message ?? "Failed to send OTP.");
    } finally {
      setPhoneBusy(false);
    }
  };

  const verifyPhoneOtp = async () => {
    setPhoneMsg(null);
    setErr(null);
    if (!phoneConfirmation) {
      setPhoneMsg("Send the OTP first.");
      return;
    }
    if (!phoneOtp.trim()) {
      setPhoneMsg("Enter the OTP code.");
      return;
    }
    setPhoneBusy(true);
    try {
      const res = await phoneConfirmation.confirm(phoneOtp.trim());
      const linkedPhone = normalizePhone(res?.user?.phoneNumber || phoneInput);
      if (linkedPhone) {
        await updateDoc(doc(db, "users", user.uid), {
          phoneNumber: linkedPhone,
          updatedAt: serverTimestamp(),
        });
      }
      setPhoneMsg("Phone number linked.");
      setPhoneOtp("");
    } catch (e: any) {
      setPhoneMsg(e?.message ?? "OTP verification failed.");
    } finally {
      setPhoneBusy(false);
    }
  };

  function toggleSelection(current: string[], value: string, checked: boolean) {
    if (checked) return current.includes(value) ? current : [...current, value];
    return current.filter((item) => item !== value);
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-semibold">Profile settings</h1>
          <p className="section-subtitle">Update your display name, nurse credentials, registration details, and public service profile.</p>
        </div>

        {needsSubscriptionSetup ? (
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
            <div className="font-medium">
              {currentUserData?.subscriptionStatus === "trial_active" ? "Free trial is active." : "Subscription setup is still pending."}
            </div>
            <div className="mt-1">
              {currentUserData?.subscriptionStatus === "trial_active"
                ? "Review your subscription settings before billing begins at the end of the first 7 days."
                : "Finish your nurse subscription setup to complete the onboarding flow."}
            </div>
            <div className="mt-3">
              <Link to="/nurse-subscription" className="btn-secondary inline-flex">
                Manage subscription
              </Link>
            </div>
          </div>
        ) : null}

        {err && <div className="text-sm text-rose-600">{err}</div>}
        {msg && <div className="text-sm text-emerald-600">{msg}</div>}

        <div className="card p-4 space-y-4 max-w-2xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="label">Display name</label>
              <input
                className="input"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                disabled={loading}
              />
            </div>
            <div>
              <label className="label">Designation</label>
              <input
                className="input"
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                disabled={loading}
                placeholder="e.g. RN, EN, NP, Clinical Nurse Consultant"
              />
            </div>
          </div>

          {currentUserData?.role === "clinician" ? (
            <div className="rounded-2xl border border-ink-200 bg-sand-100/70 p-4 space-y-4">
              <div>
                <h2 className="text-lg font-semibold text-ink-900">Public service profile</h2>
                <p className="mt-1 text-sm text-ink-600">
                  These fields publish a safe public profile to NurseConnectCare. Private account details remain in your internal user record.
                </p>
              </div>

              <label className="flex items-center gap-3 rounded-xl bg-white px-4 py-3 text-sm text-ink-700">
                <input
                  type="checkbox"
                  checked={publicProfileEnabled}
                  onChange={(e) => setPublicProfileEnabled(e.target.checked)}
                  disabled={loading}
                />
                <span>Publish my nurse profile for public and provider request workflows</span>
              </label>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="label">Public headline</label>
                  <input
                    className="input"
                    value={publicHeadline}
                    onChange={(e) => setPublicHeadline(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. Home-based chronic disease and recovery support"
                  />
                </div>
                <div>
                  <label className="label">Primary service region</label>
                  <input
                    className="input"
                    value={publicPrimaryRegion}
                    onChange={(e) => setPublicPrimaryRegion(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. Melbourne Metro"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="label">Travel radius or coverage</label>
                  <input
                    className="input"
                    value={publicTravelRadius}
                    onChange={(e) => setPublicTravelRadius(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. Inner north, CBD and eastern suburbs"
                  />
                </div>
                <div>
                  <label className="label">Typical response time</label>
                  <input
                    className="input"
                    value={publicResponseTime}
                    onChange={(e) => setPublicResponseTime(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. Usually replies within 2 hours"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="label">Base postcode</label>
                  <input
                    className="input"
                    value={publicBasePostcode}
                    onChange={(e) => setPublicBasePostcode(e.target.value.replace(/[^\d]/g, "").slice(0, 4))}
                    disabled={loading}
                    placeholder="e.g. 3000"
                    inputMode="numeric"
                  />
                </div>
                <div>
                  <label className="label">Service postcodes</label>
                  <input
                    className="input"
                    value={publicServicePostcodesText}
                    onChange={(e) => setPublicServicePostcodesText(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. 3000, 3002, 3004"
                  />
                </div>
                <div>
                  <label className="label">Service radius (km)</label>
                  <input
                    className="input"
                    value={publicServiceRadiusKm}
                    onChange={(e) => setPublicServiceRadiusKm(e.target.value.replace(/[^\d]/g, "").slice(0, 3))}
                    disabled={loading}
                    placeholder="e.g. 25"
                    inputMode="numeric"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="label">Base latitude</label>
                  <input
                    className="input"
                    value={publicBaseLatitude}
                    onChange={(e) => setPublicBaseLatitude(e.target.value.replace(/[^\d.-]/g, "").slice(0, 12))}
                    disabled={loading}
                    placeholder="e.g. -37.8136"
                    inputMode="decimal"
                  />
                </div>
                <div>
                  <label className="label">Base longitude</label>
                  <input
                    className="input"
                    value={publicBaseLongitude}
                    onChange={(e) => setPublicBaseLongitude(e.target.value.replace(/[^\d.-]/g, "").slice(0, 12))}
                    disabled={loading}
                    placeholder="e.g. 144.9631"
                    inputMode="decimal"
                  />
                </div>
              </div>
              <p className="field-hint">
                Use postcode coverage for exact matching. Add base coordinates and service radius to support nearest-nurse distance matching.
              </p>

              <div>
                <label className="label">Public service focus keywords</label>
                <input
                  className="input"
                  value={publicServiceFocusKeywordsText}
                  onChange={(e) => setPublicServiceFocusKeywordsText(e.target.value)}
                  disabled={loading}
                  placeholder="e.g. wound care, chronic disease, aged care, medication support"
                />
                <p className="field-hint">Enter multiple keywords separated by commas. These appear on the public service profile and support future filtering.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <fieldset className="space-y-2">
                  <legend className="label">Visit types</legend>
                  {["Home visits", "Telehealth", "Hybrid care", "After-hours visits"].map((item) => (
                    <label key={item} className="flex items-center gap-3 rounded-xl bg-white px-4 py-3 text-sm text-ink-700">
                      <input
                        type="checkbox"
                        checked={publicVisitTypes.includes(item)}
                        onChange={(e) => setPublicVisitTypes((current) => toggleSelection(current, item, e.target.checked))}
                        disabled={loading}
                      />
                      <span>{item}</span>
                    </label>
                  ))}
                </fieldset>

                <fieldset className="space-y-2">
                  <legend className="label">Funding pathways</legend>
                  {["Private pay", "Medicare eligible services", "Private health funding", "Package-funded care"].map((item) => (
                    <label key={item} className="flex items-center gap-3 rounded-xl bg-white px-4 py-3 text-sm text-ink-700">
                      <input
                        type="checkbox"
                        checked={publicFundingModels.includes(item)}
                        onChange={(e) => setPublicFundingModels((current) => toggleSelection(current, item, e.target.checked))}
                        disabled={loading}
                      />
                      <span>{item}</span>
                    </label>
                  ))}
                </fieldset>
              </div>
            </div>
          ) : null}

          {currentUserData?.role === "clinician" ? (
            <div className="rounded-2xl border border-ink-200 bg-white p-4 space-y-4">
              <div>
                <h2 className="text-lg font-semibold text-ink-900">Billing facilitation profile</h2>
                <p className="mt-1 text-sm text-ink-600">
                  These details populate nurse-owned invoices and evidence packs. NurseConnectCare only helps you prepare and relay billing documents. It does not process payments, approve claims, or hold funds.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="label">Business or trading name</label>
                  <input
                    className="input"
                    value={billingBusinessName}
                    onChange={(e) => setBillingBusinessName(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. Jane Smith Nursing Services"
                  />
                </div>
                <div>
                  <label className="label">ABN</label>
                  <input
                    className="input"
                    value={billingAbn}
                    onChange={(e) => setBillingAbn(e.target.value.replace(/[^\d]/g, "").slice(0, 11))}
                    disabled={loading}
                    placeholder="11-digit ABN"
                    inputMode="numeric"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="label">Billing email</label>
                  <input
                    className="input"
                    value={billingEmail}
                    onChange={(e) => setBillingEmail(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. invoices@yourpractice.com.au"
                  />
                </div>
                <div>
                  <label className="label">Billing phone</label>
                  <input
                    className="input"
                    value={billingPhone}
                    onChange={(e) => setBillingPhone(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. +614..."
                  />
                </div>
              </div>

              <div>
                <label className="label">Billing address</label>
                <textarea
                  className="input min-h-[96px]"
                  value={billingAddress}
                  onChange={(e) => setBillingAddress(e.target.value)}
                  disabled={loading}
                  placeholder="Postal or business address to appear on invoices"
                />
              </div>
            </div>
          ) : null}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="label">Nurse type</label>
              <select
                className="input"
                value={nurseType}
                onChange={(e) => setNurseType(e.target.value as NurseType | "")}
                disabled={loading}
              >
                <option value="">Select nurse type</option>
                {NURSE_TYPE_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
              <div>
                <label className="label">AHPRA registration number</label>
                <input
                className="input"
                value={ahpraRegistrationNumber}
                onChange={(e) => setAhpraRegistrationNumber(e.target.value.toUpperCase())}
                disabled={loading}
                  placeholder="e.g. NMW0001234567"
                />
                <p className="field-hint mt-1">
                  Verification is completed separately by NurseConnectCare support after checking the public AHPRA register.
                </p>
                <p className="mt-2 text-xs text-ink-600">
                  Current verification status:{" "}
                  <span className={currentUserData?.ahpraVerified ? "font-semibold text-emerald-700" : "font-semibold text-amber-700"}>
                    {currentUserData?.ahpraVerified ? "Verified" : "Pending support review"}
                  </span>
                </p>
              </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="label">Phone</label>
              <input className="input" value={currentUserData?.phoneNumber || user?.phoneNumber || ""} disabled />
            </div>
            <div>
              <label className="label">Link phone number</label>
              <input
                className="input"
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                placeholder="+614..."
                autoComplete="tel"
              />
              <div className="flex gap-2 mt-2">
                <button className="btn-secondary text-xs" onClick={sendPhoneOtp} disabled={phoneBusy || !user?.uid}>
                  {phoneBusy ? "Sending…" : "Send OTP"}
                </button>
                <button className="btn-primary text-xs" onClick={verifyPhoneOtp} disabled={phoneBusy || !user?.uid}>
                  {phoneBusy ? "Verifying…" : "Verify & Link"}
                </button>
              </div>
              {phoneMsg ? <div className="text-xs text-ink-500 mt-1">{phoneMsg}</div> : null}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="label">Email</label>
              <input className="input" value={currentUserData?.email || user?.email || ""} disabled />
            </div>
            <div>
              <label className="label">Role</label>
              <input className="input" value={roleLabel} disabled />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="label">Time zone</label>
              <div className="relative" ref={tzContainerRef}>
                <input
                  className="input"
                  value={tzQuery}
                  onChange={(e) => {
                    setTzQuery(e.target.value);
                    setTimeZone(e.target.value);
                    setTzOpen(true);
                    setTzActiveIndex(0);
                  }}
                  onFocus={() => setTzOpen(true)}
                  onBlur={() => setTimeout(() => setTzOpen(false), 100)}
                  onKeyDown={(e) => {
                    if (!tzOpen) return;
                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      setTzActiveIndex((i) => Math.min(i + 1, tzFiltered.length - 1));
                    } else if (e.key === "ArrowUp") {
                      e.preventDefault();
                      setTzActiveIndex((i) => Math.max(i - 1, 0));
                    } else if (e.key === "Enter") {
                      e.preventDefault();
                      const picked = tzFiltered[tzActiveIndex];
                      if (picked) {
                        setTzQuery(picked);
                        setTimeZone(picked);
                        setTzOpen(false);
                      }
                    } else if (e.key === "Escape") {
                      setTzOpen(false);
                    }
                  }}
                  disabled={loading}
                  placeholder={localTz}
                />
                {tzOpen && tzFiltered.length > 0 && (
                  <div className="absolute z-20 mt-1 w-full max-h-56 overflow-auto rounded-lg border border-ink-200 bg-white shadow-soft">
                    {tzGrouped.map(([region, items]) => {
                      const header = region;
                      return (
                        <div key={region}>
                          <div className="px-3 py-1 text-[11px] font-medium text-ink-500 bg-sand-100">
                            {header}
                          </div>
                          {items.map((tz) => {
                            const idx = tzFiltered.indexOf(tz);
                            const isRecommended = tz === localTz;
                            return (
                              <button
                                key={tz}
                                type="button"
                                className={`w-full text-left px-3 py-2 text-sm hover:bg-ink-200/40 ${
                                  idx === tzActiveIndex ? "bg-ink-200/40" : ""
                                }`}
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => {
                                  setTzQuery(tz);
                                  setTimeZone(tz);
                                  setTzOpen(false);
                                }}
                              >
                                <span>{tz}</span>
                                {isRecommended && (
                                  <span className="ml-2 text-[11px] text-emerald-600">Recommended</span>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              <div className="text-xs text-ink-500 mt-1">Recommended: {localTz}</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button className="btn-primary" onClick={onSave} disabled={busy || loading || !user?.uid}>
              {busy ? "Saving…" : "Save changes"}
            </button>
            <div className="text-xs text-ink-500">Changes apply to your profile only.</div>
          </div>
        </div>
        <div id="recaptcha-container-link" />
      </div>
    </MainLayout>
  );
};

export default ProfileSettingsPage;
