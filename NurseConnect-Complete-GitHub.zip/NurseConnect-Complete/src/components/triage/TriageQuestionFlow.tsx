import React, { useState } from "react";
import { TriageQuestion } from "../../models/triage";

type Props = {
  question: TriageQuestion;
  progress?: { answered: number; totalEstimated: number } | null;
  busy?: boolean;
  error?: string | null;
  onSubmit: (value: string) => Promise<void> | void;
};

export const TriageQuestionFlow: React.FC<Props> = ({ question, progress, busy, error, onSubmit }) => {
  const initial =
    question.inputType === "yes_no" ? "no" : question.options?.[0]?.value || "";
  const [value, setValue] = useState(initial);

  return (
    <div className="border border-ink-200 rounded-xl p-4 space-y-3 bg-white">
      <div className="flex items-center justify-between gap-3">
        <div className="text-sm font-semibold">Symptom intake</div>
        {progress ? (
          <div className="text-xs text-ink-500">
            {progress.answered} / {progress.totalEstimated}
          </div>
        ) : null}
      </div>
      <div className="text-sm text-ink-800">{question.text}</div>
      <div className="text-xs text-ink-500">
        If you have severe chest pain, severe trouble breathing, collapse, stroke-like symptoms, or heavy bleeding, seek urgent emergency care immediately.
      </div>
      {question.inputType === "free_text" ? (
        <textarea
          className="input min-h-[110px]"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Type your answer"
          disabled={busy}
        />
      ) : (
        <div className="space-y-2">
          {((question.inputType === "yes_no"
            ? [
                { value: "yes", label: "Yes" },
                { value: "no", label: "No" },
              ]
            : question.options) || []
          ).map((option) => (
            <label key={option.value} className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                name={question.id}
                value={option.value}
                checked={value === option.value}
                onChange={(e) => setValue(e.target.value)}
                disabled={busy}
              />
              <span>{option.label}</span>
            </label>
          ))}
        </div>
      )}
      {error ? <div className="text-sm text-rose-600">{error}</div> : null}
      <div className="flex justify-end">
        <button
          type="button"
          className="btn-primary"
          onClick={() => void onSubmit(value)}
          disabled={busy || !String(value || "").trim()}
        >
          {busy ? "Saving..." : "Continue"}
        </button>
      </div>
    </div>
  );
};

export default TriageQuestionFlow;
