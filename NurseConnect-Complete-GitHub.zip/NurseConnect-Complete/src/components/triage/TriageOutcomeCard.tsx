import React from "react";
import { TriageOutcome } from "../../models/triage";

function urgencyChip(urgency?: string | null) {
  if (urgency === "emergency_now") return "chip chip-danger";
  if (urgency === "urgent_callback") return "chip chip-warning";
  if (urgency === "priority_review") return "chip chip-info";
  return "chip chip-success";
}

type Props = {
  outcome: TriageOutcome;
};

export const TriageOutcomeCard: React.FC<Props> = ({ outcome }) => {
  return (
    <div className="border border-ink-200 rounded-xl p-4 space-y-2 bg-white">
      <div className="flex items-center gap-2">
        <div className="text-sm font-semibold">Symptom intake completed</div>
        <span className={urgencyChip(outcome.urgencyTier)}>{outcome.urgencyTier.replace(/_/g, " ")}</span>
      </div>
      <div className="text-sm text-ink-700">{outcome.patientMessage}</div>
      {outcome.callbackBy ? (
        <div className="text-xs text-ink-500">Callback target: {new Date(outcome.callbackBy).toLocaleString()}</div>
      ) : null}
    </div>
  );
};

export default TriageOutcomeCard;
