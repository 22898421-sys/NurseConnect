import React, { useState } from "react";
import { Appointment } from "../../models/emr";
import { TriageOutcome, TriageQuestion } from "../../models/triage";
import { finalizeTriageSession, startTriageSession, submitTriageAnswer } from "../../lib/triage";
import { toPlainLanguageOutcomeMessage } from "../../lib/plainLanguage";
import TriageOutcomeCard from "./TriageOutcomeCard";
import TriageQuestionFlow from "./TriageQuestionFlow";

type Props = {
  appointment: Appointment;
  onUpdated?: () => Promise<void> | void;
};

export const TriageIntakeCard: React.FC<Props> = ({ appointment, onUpdated }) => {
  const [sessionId, setSessionId] = useState<string | null>((appointment as any)?.triageSessionId || null);
  const [question, setQuestion] = useState<TriageQuestion | null>(null);
  const [progress, setProgress] = useState<{ answered: number; totalEstimated: number } | null>(null);
  const [outcome, setOutcome] = useState<TriageOutcome | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const begin = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await startTriageSession(appointment.id, "portal");
      setSessionId(res.triageSessionId);
      setProgress(res.progress);
      setQuestion(res.question);
      if (res.outcome?.urgencyTier && res.outcome.patientMessage) {
        setOutcome({
          urgencyTier: res.outcome.urgencyTier,
          patientMessage: res.outcome.patientMessage,
        });
      }
      if (!res.question && onUpdated) await onUpdated();
    } catch (e: any) {
      setError(toPlainLanguageOutcomeMessage(e, "We could not start the symptom questions just now."));
    } finally {
      setBusy(false);
    }
  };

  const answer = async (value: string) => {
    if (!sessionId || !question) return;
    setBusy(true);
    setError(null);
    try {
      const res = await submitTriageAnswer(sessionId, question.id, value);
      setProgress(res.progress || null);
      if (res.status === "active" && res.nextQuestion) {
        setQuestion(res.nextQuestion);
        return;
      }
      const final = await finalizeTriageSession(sessionId);
      setQuestion(null);
      setOutcome(final);
      if (onUpdated) await onUpdated();
    } catch (e: any) {
      setError(toPlainLanguageOutcomeMessage(e, "We could not save that answer just now."));
    } finally {
      setBusy(false);
    }
  };

  if (outcome) return <TriageOutcomeCard outcome={outcome} />;

  if (question) {
    return (
      <TriageQuestionFlow
        key={question.id}
        question={question}
        progress={progress}
        busy={busy}
        error={error}
        onSubmit={answer}
      />
    );
  }

  const status = ((appointment as any)?.triageStatus || "").toString();

  return (
    <div className="border border-ink-200 rounded-xl p-4 bg-white space-y-3">
      <div>
        <div className="text-sm font-semibold">Optional symptom questions</div>
        <div className="text-xs text-ink-500">
          Help the clinician prepare for this appointment. If your answers suggest earlier review is needed, the practice can contact you sooner.
        </div>
        <div className="text-xs text-amber-700 mt-2">
          This symptom intake supports appointment preparation only. It is not a diagnosis service and should not be used instead of emergency care.
        </div>
      </div>
      {status ? (
        <div className="text-xs text-ink-500">Current triage status: {status.replace(/_/g, " ")}</div>
      ) : null}
      {error ? <div className="text-sm text-rose-600">{error}</div> : null}
      <div className="flex gap-2">
        <button type="button" className="btn-secondary" onClick={() => void begin()} disabled={busy}>
          {busy ? "Starting..." : sessionId ? "Resume symptom intake" : "Start symptom intake"}
        </button>
      </div>
    </div>
  );
};

export default TriageIntakeCard;
