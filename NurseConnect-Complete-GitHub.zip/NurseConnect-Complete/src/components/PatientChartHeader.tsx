// src/components/PatientChartHeader.tsx
import React from "react";
import { Patient } from "../models/emr";

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

function parseDateFlexible(s: string): Date | null {
  const v = String(s || "").trim();
  if (!v) return null;

  // Preferred: DD-MM-YYYY
  const m1 = v.match(/^([0-3]?\d)-([0-1]?\d)-(\d{4})$/);
  if (m1) {
    const d = Number(m1[1]);
    const mo = Number(m1[2]);
    const y = Number(m1[3]);
    const dt = new Date(y, mo - 1, d);
    if (dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d) return dt;
  }

  // Legacy: YYYY-MM-DD
  const m2 = v.match(/^(\d{4})-([0-1]?\d)-([0-3]?\d)$/);
  if (m2) {
    const y = Number(m2[1]);
    const mo = Number(m2[2]);
    const d = Number(m2[3]);
    const dt = new Date(y, mo - 1, d);
    if (dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d) return dt;
  }

  return null;
}

function formatDDMMYYYY(dt: Date): string {
  return `${pad2(dt.getDate())}-${pad2(dt.getMonth() + 1)}-${dt.getFullYear()}`;
}

function calcAge(dob: Date, asOf = new Date()): number {
  let age = asOf.getFullYear() - dob.getFullYear();
  const m = asOf.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && asOf.getDate() < dob.getDate())) age -= 1;
  return Math.max(0, age);
}

export type PatientChartHeaderProps = {
  patient: Patient;
  rightSlot?: React.ReactNode;
};

export const PatientChartHeader: React.FC<PatientChartHeaderProps> = ({ patient, rightSlot }) => {
  const dobDate = patient.dateOfBirth ? parseDateFlexible(patient.dateOfBirth) : null;
  const dobDisplay = dobDate ? formatDDMMYYYY(dobDate) : patient.dateOfBirth ?? "Not recorded";
  const age = dobDate ? calcAge(dobDate) : null;
  const sexDisplay = patient.sex ? String(patient.sex) : "Not recorded";

  return (
    <div className="border rounded-xl p-4 bg-white">
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
        <div>
          <div className="text-xl font-semibold">{patient.fullName || "Unnamed"}</div>
          <div className="text-sm text-gray-700 mt-1 flex flex-wrap gap-x-4 gap-y-1">
            <span>
              <span className="font-medium">DOB:</span> {dobDisplay}
              {age !== null ? <span className="text-gray-500"> ({age}y)</span> : null}
            </span>
            <span>
              <span className="font-medium">Sex:</span> {sexDisplay}
            </span>
            {patient.phone ? (
              <span>
                <span className="font-medium">Phone:</span> {patient.phone}
              </span>
            ) : null}
            {patient.email ? (
              <span>
                <span className="font-medium">Email:</span> {patient.email}
              </span>
            ) : null}
          </div>
          {patient.address ? <div className="text-xs text-gray-600 mt-2">Address: {patient.address}</div> : null}
        </div>

        {rightSlot ? <div className="flex items-center gap-2">{rightSlot}</div> : null}
      </div>
    </div>
  );
};

export default PatientChartHeader;
