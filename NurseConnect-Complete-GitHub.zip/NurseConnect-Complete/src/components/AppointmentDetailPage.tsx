// src/components/AppointmentDetailPage.tsx
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { collection, doc, getDoc, serverTimestamp, Timestamp, updateDoc, writeBatch } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { MainLayout } from "./MainLayout";
import { AppointmentMode, AppointmentStatus } from "../models/emr";
import { buildEncounterHeader } from "../lib/encounterHeaders";
import { formatDateTimeInZone, getClinicTimeZone, getLocalTimeZone } from "../lib/time";
import { useAuth } from "../contexts/AuthContext";
import { resolveProvider, resolveProviderLabel } from "../lib/provider";

type AppointmentDoc = {
  patientId: string;
  patientName?: string | null;
  patientEmail?: string | null;

  clinicianId: string;
  clinicianName?: string | null;

  scheduledAt: Timestamp;
  durationMinutes?: number | null;

  date?: string | null; // "DD-MM-YYYY"
  time?: string | null; // "HH:MM"

  mode: AppointmentMode;
  status: AppointmentStatus;

  reason?: string | null;
  consultationNotes?: string | null;
  encounterId?: string | null;

  createdAt?: Timestamp;
  updatedAt?: Timestamp;
};

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function formatDDMMYYYY(d: Date): string {
  return `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()}`;
}

function formatHHMM(d: Date): string {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

export const AppointmentDetailPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const localTz = useMemo(() => getLocalTimeZone(), []);
  const { normalizedRole, user, currentUserData } = useAuth() as any;
  const isClinician = normalizedRole === "clinician";

  const [row, setRow] = useState<(AppointmentDoc & { id: string }) | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [encounterBusy, setEncounterBusy] = useState(false);
  const [encounterMsg, setEncounterMsg] = useState<string | null>(null);
  const [encounterErr, setEncounterErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!id) {
      setErr("Missing appointment ID.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setErr(null);

    try {
      const snap = await getDoc(doc(db, "appointments", id));
      if (!snap.exists()) {
        setRow(null);
        setErr("Appointment not found.");
        return;
      }

      const raw = snap.data() as any;

      const scheduledAt: Timestamp =
        raw?.scheduledAt instanceof Timestamp ? raw.scheduledAt : Timestamp.fromDate(new Date());
      const dt = scheduledAt.toDate();

      const date = raw?.date ?? formatDDMMYYYY(dt);
      const time = raw?.time ?? formatHHMM(dt);

      setRow({
        id: snap.id,
        ...raw,
        scheduledAt,
        date,
        time,
      } as AppointmentDoc & { id: string });
    } catch (e: any) {
      console.error(e);
      setErr(e?.message ?? "Failed to load appointment.");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  const whenText = useMemo(() => {
    if (!row) return null;
    const dt = row.scheduledAt.toDate();
    const clinicTz = getClinicTimeZone((row as any)?.practiceTimeZone, (row as any)?.timeZone) || localTz;
    return {
      local: formatDateTimeInZone(dt, localTz),
      clinic: formatDateTimeInZone(dt, clinicTz),
      clinicTz,
    };
  }, [row, localTz]);

  const cancelAppointment = async () => {
    if (!row) return;

    setBusy(true);
    setErr(null);
    try {
      await updateDoc(doc(db, "appointments", row.id), {
        status: "cancelled",
        updatedAt: serverTimestamp(),
      });
      await load();
    } catch (e: any) {
      console.error(e);
      setErr(e?.message ?? "Failed to cancel appointment.");
    } finally {
      setBusy(false);
    }
  };

  const markCompleted = async () => {
    if (!row) return;

    setBusy(true);
    setErr(null);
    try {
      await updateDoc(doc(db, "appointments", row.id), {
        status: "completed",
        updatedAt: serverTimestamp(),
      });
      await load();
    } catch (e: any) {
      console.error(e);
      setErr(e?.message ?? "Failed to update status.");
    } finally {
      setBusy(false);
    }
  };

  const createEncounterFromAppointment = async () => {
    if (!row || !user?.uid) return;
    if (!isClinician) return;

    setEncounterErr(null);
    setEncounterMsg(null);
    const practiceId = currentUserData?.practiceId;
    if (!practiceId) {
      setEncounterErr("Your profile is missing practiceId. Set users/{uid}.practiceId to enable encounter creation.");
      return;
    }

    if (!row.patientId) {
      setEncounterErr("Appointment is missing patientId.");
      return;
    }

    setEncounterBusy(true);
    try {
      const ident = await resolveProvider(user.uid);
      const practitionerDisplayName = ident.displayName || user.uid;
      const practitionerLabel = await resolveProviderLabel(user.uid, { includeRole: true });

      const dt = row.scheduledAt.toDate();
      const encounterDate = formatDDMMYYYY(dt);
      const now = serverTimestamp();

      const encounterRef = doc(collection(db, "encounters"));
      const encounterPayload = {
        patientId: row.patientId,
        practitionerId: user.uid,
        practiceId,
        practitionerDisplayName,
        practitionerLabel,
        encounterDate,
        encounterDateISO: "",
        type: "consultation",
        reason: row.reason || "Appointment",
        soap: { subjective: "", objective: "", assessment: "", plan: "" },
        notes: "",
        status: "draft",
        breakGlass: { enabled: false },
        appointmentId: row.id,
        createdAt: now,
        createdBy: user.uid,
        updatedAt: now,
        updatedBy: user.uid,
      };
      const batch = writeBatch(db);
      batch.set(encounterRef, encounterPayload);
      batch.set(
        doc(db, "encounterHeaders", encounterRef.id),
        buildEncounterHeader({
          ...encounterPayload,
          status: "draft",
        })
      );
      batch.update(doc(db, "appointments", row.id), {
        encounterId: encounterRef.id,
        status: row.status === "scheduled" ? "in_progress" : row.status,
        updatedAt: now,
        updatedBy: user.uid,
      });
      await batch.commit();

      setEncounterMsg("Encounter created.");
      await load();
    } catch (e: any) {
      console.error(e);
      setEncounterErr(e?.message ?? "Failed to create encounter.");
    } finally {
      setEncounterBusy(false);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-semibold">Appointment</h1>
            <div className="text-sm text-gray-600">Detail view</div>
          </div>

          <div className="flex items-center gap-2">
            <button
              className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
              onClick={() => navigate(-1)}
            >
              Back
            </button>
          </div>
        </div>

        {err && <div className="text-sm text-red-600">{err}</div>}
        {encounterErr && <div className="text-sm text-red-600">{encounterErr}</div>}
        {encounterMsg && <div className="text-sm text-green-700">{encounterMsg}</div>}

        {loading ? (
          <div className="text-sm text-gray-600">Loading…</div>
        ) : !row ? (
          <div className="text-sm text-gray-600">No appointment loaded.</div>
        ) : (
          <div className="border rounded-xl bg-white p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <div className="text-xs text-gray-500">When</div>
                <div className="font-medium">{whenText ? whenText.local : "—"}</div>
                {whenText && (
                  <div className="text-xs text-gray-500 mt-1">
                    Local ({localTz}) · Clinic ({whenText.clinicTz}) · {whenText.clinic}
                  </div>
                )}
                <div className="text-xs text-gray-500 mt-1">
                  Stored: <span className="font-mono">{row.date}</span>{" "}
                  <span className="font-mono">{row.time}</span>
                </div>
              </div>

              <div>
                <div className="text-xs text-gray-500">Status</div>
                <div className="inline-flex items-center px-2 py-1 rounded border text-xs">
                  {row.status}
                </div>
              </div>

              <div>
                <div className="text-xs text-gray-500">Encounter</div>
                {row.encounterId ? (
                  <Link
                    to={`/patients/${row.patientId}/chart/encounters/${row.encounterId}?edit=1`}
                    className="text-sm text-blue-600 hover:underline"
                  >
                    Open encounter
                  </Link>
                ) : isClinician ? (
                  <button
                    className="px-3 py-1.5 rounded border text-xs hover:bg-gray-50 disabled:opacity-60"
                    onClick={() => void createEncounterFromAppointment()}
                    disabled={encounterBusy}
                  >
                    {encounterBusy ? "Creating…" : "Create encounter"}
                  </button>
                ) : (
                  <div className="text-sm text-gray-500">No encounter linked.</div>
                )}
              </div>

              <div>
                <div className="text-xs text-gray-500">Patient</div>
                <div className="font-medium">{row.patientName || row.patientEmail || row.patientId}</div>
                <div className="text-xs text-gray-500 mt-1">
                  Patient ID: <span className="font-mono">{row.patientId}</span>
                </div>
              </div>

              <div>
                <div className="text-xs text-gray-500">Nurse</div>
                <div className="font-medium">{row.clinicianName || row.clinicianId}</div>
                <div className="text-xs text-gray-500 mt-1">
                  Nurse ID: <span className="font-mono">{row.clinicianId}</span>
                </div>
              </div>

              <div>
                <div className="text-xs text-gray-500">Mode</div>
                <div className="font-medium">{row.mode}</div>
              </div>

              <div>
                <div className="text-xs text-gray-500">Duration</div>
                <div className="font-medium">{row.durationMinutes ?? 15} minutes</div>
              </div>

              <div className="md:col-span-2">
                <div className="text-xs text-gray-500">Reason</div>
                <div className="font-medium">{row.reason || "-"}</div>
              </div>

              <div className="md:col-span-2">
                <div className="text-xs text-gray-500">Consultation notes</div>
                <div className="whitespace-pre-wrap text-sm">{row.consultationNotes || "-"}</div>
              </div>

              <div className="md:col-span-2">
                <div className="text-xs text-gray-500">Appointment ID</div>
                <div className="font-mono text-sm">{row.id}</div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2 border-t">
              <button
                className="px-4 py-2 rounded bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-50"
                onClick={markCompleted}
                disabled={busy || row.status === "completed"}
              >
                {busy ? "Working…" : "Mark completed"}
              </button>

              <button
                className="px-4 py-2 rounded border text-sm hover:bg-gray-50 disabled:opacity-50"
                onClick={cancelAppointment}
                disabled={busy || row.status === "cancelled"}
              >
                Cancel appointment
              </button>

              <button
                className="px-4 py-2 rounded border text-sm hover:bg-gray-50 disabled:opacity-50"
                onClick={load}
                disabled={busy}
              >
                Refresh
              </button>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default AppointmentDetailPage;
