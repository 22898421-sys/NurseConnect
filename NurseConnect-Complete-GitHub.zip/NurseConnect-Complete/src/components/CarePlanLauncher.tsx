import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  CARE_PLAN_TEMPLATES,
  CarePlanPayload,
  CarePlanStatus,
  CarePlanTemplateKey,
  createManualCarePlan,
  formatCarePlanStatus,
  getCarePlanTemplate,
} from "../lib/carePlans";
import { toPlainLanguageOutcomeMessage } from "../lib/plainLanguage";

type Props = {
  patientId: string;
  practiceId: string;
  clinicianUid: string;
  clinicianDisplayName?: string | null;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  chartBasePath?: string;
  buttonLabel?: string;
  buttonClassName?: string;
  compact?: boolean;
  onCarePlanCreated?: (payload: {
    carePlanId: string;
    planLine: string;
    documentEntryTitle: string;
  }) => void;
};

type DraftState = CarePlanPayload & {
  status: CarePlanStatus;
  goalSummary: string;
  outcomeTargets: string;
  reviewTimeframe: string;
  agreedServiceDays: string;
  evaluationPlan: string;
  agreedWithPatientOrRepresentative: boolean;
  agreementName: string;
};

function emptyDraft(templateKey: CarePlanTemplateKey): DraftState {
  const template = getCarePlanTemplate(templateKey);
  return {
    visitContext: template.suggestedVisitContext,
    personalPreferences: "",
    clinicalAssessmentSummary: "",
    clinicalNeeds: "",
    personalCareNeeds: "",
    shortTermGoals: "",
    longTermGoals: "",
    identifiedRisks: "",
    nursingInterventions: "",
    personalCareInterventions: "",
    equipmentRequirements: "",
    delegationPlan: "",
    visitSchedule: "",
    monitoringParameters: "",
    referralsAndTeam: "",
    escalationTriggers: "",
    transitionConsiderations: "",
    status: "active",
    goalSummary: template.suggestedGoalSummary,
    outcomeTargets: "",
    reviewTimeframe: template.defaultReviewTimeframe,
    agreedServiceDays: "",
    evaluationPlan: "",
    agreedWithPatientOrRepresentative: false,
    agreementName: "",
  };
}

const STATUS_OPTIONS: CarePlanStatus[] = ["active", "review_due", "completed", "superseded"];

const CarePlanLauncher: React.FC<Props> = ({
  patientId,
  practiceId,
  clinicianUid,
  clinicianDisplayName,
  sourceEncounterId = null,
  sourceAppointmentId = null,
  chartBasePath,
  buttonLabel = "Create care plan",
  buttonClassName = "btn-secondary text-sm px-3 py-2",
  compact = false,
  onCarePlanCreated,
}) => {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [latestCarePlanId, setLatestCarePlanId] = useState<string | null>(null);
  const [templateKey, setTemplateKey] = useState<CarePlanTemplateKey>("comprehensive_home_care");
  const [draft, setDraft] = useState<DraftState>(() => emptyDraft("comprehensive_home_care"));

  const chartCarePlanPath = useMemo(() => (chartBasePath ? `${chartBasePath}?tab=care_plans` : ""), [chartBasePath]);
  const selectedTemplate = useMemo(() => getCarePlanTemplate(templateKey), [templateKey]);

  const applyTemplate = (nextTemplateKey: CarePlanTemplateKey) => {
    setTemplateKey(nextTemplateKey);
    setDraft(emptyDraft(nextTemplateKey));
  };

  const updateDraft = (patch: Partial<DraftState>) => {
    setDraft((current) => ({ ...current, ...patch }));
  };

  const resetDraft = () => {
    setTemplateKey("comprehensive_home_care");
    setDraft(emptyDraft("comprehensive_home_care"));
  };

  const handleSave = async () => {
    setBusy(true);
    setErr(null);
    setMsg(null);

    if (!draft.clinicalAssessmentSummary.trim()) {
      setErr("Add a clinical assessment summary before saving the care plan.");
      setBusy(false);
      return;
    }
    if (!draft.goalSummary.trim() || (!draft.shortTermGoals.trim() && !draft.longTermGoals.trim())) {
      setErr("Add the agreed goals for care before saving.");
      setBusy(false);
      return;
    }
    if (!draft.identifiedRisks.trim()) {
      setErr("Document the identified risks and mitigation priorities before saving.");
      setBusy(false);
      return;
    }
    if (!draft.nursingInterventions.trim() && !draft.personalCareInterventions.trim()) {
      setErr("Add at least one planned intervention before saving.");
      setBusy(false);
      return;
    }
    if (!draft.reviewTimeframe.trim()) {
      setErr("Add a review timeframe before saving.");
      setBusy(false);
      return;
    }

    try {
      const result = await createManualCarePlan({
        templateKey,
        patientId,
        practiceId,
        clinicianUid,
        clinicianDisplayName,
        sourceEncounterId,
        sourceAppointmentId,
        planPayload: {
          visitContext: draft.visitContext?.trim() || null,
          personalPreferences: draft.personalPreferences?.trim() || null,
          clinicalAssessmentSummary: draft.clinicalAssessmentSummary.trim(),
          clinicalNeeds: draft.clinicalNeeds.trim(),
          personalCareNeeds: draft.personalCareNeeds.trim(),
          shortTermGoals: draft.shortTermGoals.trim(),
          longTermGoals: draft.longTermGoals.trim(),
          identifiedRisks: draft.identifiedRisks.trim(),
          nursingInterventions: draft.nursingInterventions.trim(),
          personalCareInterventions: draft.personalCareInterventions.trim(),
          equipmentRequirements: draft.equipmentRequirements.trim(),
          delegationPlan: draft.delegationPlan.trim(),
          visitSchedule: draft.visitSchedule.trim(),
          monitoringParameters: draft.monitoringParameters.trim(),
          referralsAndTeam: draft.referralsAndTeam.trim(),
          escalationTriggers: draft.escalationTriggers.trim(),
          transitionConsiderations: draft.transitionConsiderations.trim(),
        },
        resultSummary: {
          templateKey,
          status: draft.status,
          goalSummary: draft.goalSummary.trim(),
          outcomeTargets: draft.outcomeTargets.trim() || null,
          reviewTimeframe: draft.reviewTimeframe.trim(),
          agreedServiceDays: draft.agreedServiceDays.trim() || null,
          evaluationPlan: draft.evaluationPlan.trim() || null,
          agreedWithPatientOrRepresentative: draft.agreedWithPatientOrRepresentative,
          agreementName: draft.agreementName.trim() || null,
        },
        printableSummary: [
          `Care plan: ${selectedTemplate.label}`,
          `Status: ${formatCarePlanStatus(draft.status)}`,
          `Goal summary: ${draft.goalSummary.trim()}`,
          draft.outcomeTargets.trim() ? `Outcome targets: ${draft.outcomeTargets.trim()}` : "",
          draft.reviewTimeframe.trim() ? `Review timeframe: ${draft.reviewTimeframe.trim()}` : "",
          draft.agreedServiceDays.trim() ? `Agreed service days: ${draft.agreedServiceDays.trim()}` : "",
          draft.evaluationPlan.trim() ? `Evaluation plan: ${draft.evaluationPlan.trim()}` : "",
          draft.agreedWithPatientOrRepresentative
            ? `Agreement: Agreed with patient/representative${draft.agreementName.trim() ? ` (${draft.agreementName.trim()})` : ""}`
            : "Agreement: Clinician draft pending patient/representative discussion",
        ]
          .filter(Boolean)
          .join("\n"),
      });

      setLatestCarePlanId(result.carePlanId);
      setMsg("Care plan saved.");
      onCarePlanCreated?.(result);
      resetDraft();
      setOpen(false);
    } catch (e: any) {
      console.error(e);
      setErr(toPlainLanguageOutcomeMessage(e, "We could not save that care plan just now."));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className={compact ? "space-y-2" : "rounded-xl border border-ink-200 bg-white p-4 space-y-3"}>
      {!compact ? (
        <div>
          <div className="section-title">Structured care plan</div>
          <div className="section-subtitle">
            Person-centred nursing care plan aligned to assessment findings, agreed goals, risks, interventions, monitoring, and review.
          </div>
        </div>
      ) : null}

      {msg ? <div className="text-xs text-emerald-700">{msg}</div> : null}
      {err ? <div className="text-xs text-rose-600">{err}</div> : null}

      <div className="flex flex-wrap items-center gap-2">
        <button type="button" className={buttonClassName} onClick={() => setOpen(true)} disabled={busy}>
          {busy ? "Saving…" : buttonLabel}
        </button>
        {chartCarePlanPath ? (
          <Link to={chartCarePlanPath} className="text-xs text-brand-500 hover:underline">
            Open Care Plans tab
          </Link>
        ) : null}
        {latestCarePlanId ? (
          <span className="text-xs text-ink-500">
            Latest ID: <span className="font-mono">{latestCarePlanId}</span>
          </span>
        ) : null}
      </div>

      {open ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4">
          <div className="w-full max-w-5xl rounded-xl border border-ink-200 bg-white p-4 shadow-lift space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="section-title">Structured Care Plan</div>
                <div className="text-xs text-ink-500">
                  Capture agreed goals, interventions, review cycles, and care-delivery instructions in a clinician-only plan.
                </div>
              </div>
              <button type="button" className="btn-secondary" onClick={() => setOpen(false)} disabled={busy}>
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="label">Care-plan template</label>
                <select className="input" value={templateKey} onChange={(e) => applyTemplate(e.target.value as CarePlanTemplateKey)}>
                  {CARE_PLAN_TEMPLATES.map((template) => (
                    <option key={template.key} value={template.key}>
                      {template.label}
                    </option>
                  ))}
                </select>
                <p className="mt-2 text-xs text-ink-500">{selectedTemplate.description}</p>
              </div>
              <div>
                <label className="label">Status</label>
                <select className="input" value={draft.status} onChange={(e) => updateDraft({ status: e.target.value as CarePlanStatus })}>
                  {STATUS_OPTIONS.map((option) => (
                    <option key={option} value={option}>
                      {formatCarePlanStatus(option)}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Visit context</label>
                <input className="input" value={draft.visitContext || ""} onChange={(e) => updateDraft({ visitContext: e.target.value })} />
              </div>
              <div>
                <label className="label">Review timeframe</label>
                <input className="input" value={draft.reviewTimeframe} onChange={(e) => updateDraft({ reviewTimeframe: e.target.value })} />
              </div>
              <div>
                <label className="label">Goal summary</label>
                <input className="input" value={draft.goalSummary} onChange={(e) => updateDraft({ goalSummary: e.target.value })} />
              </div>
              <div>
                <label className="label">Agreed service days / timeframes</label>
                <input className="input" value={draft.agreedServiceDays} onChange={(e) => updateDraft({ agreedServiceDays: e.target.value })} placeholder="e.g. Mon/Wed/Fri mornings, twice weekly for 4 weeks" />
              </div>
            </div>

            <div>
              <label className="label">Personal preferences, communication needs, cultural or family considerations</label>
              <textarea className="input min-h-[88px]" value={draft.personalPreferences || ""} onChange={(e) => updateDraft({ personalPreferences: e.target.value })} placeholder="Preferred name, family/carer involvement, communication needs, cultural preferences, spiritual support, treatment preferences." />
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
              <div>
                <label className="label">Clinical assessment summary</label>
                <textarea className="input min-h-[110px]" value={draft.clinicalAssessmentSummary} onChange={(e) => updateDraft({ clinicalAssessmentSummary: e.target.value })} placeholder="Summarise assessment findings, diagnoses, comorbidities, current presentation, and what is driving the nursing plan." />
              </div>
              <div>
                <label className="label">Clinical care needs identified</label>
                <textarea className="input min-h-[110px]" value={draft.clinicalNeeds} onChange={(e) => updateDraft({ clinicalNeeds: e.target.value })} placeholder="Medication support, wound care, chronic disease monitoring, symptom review, injections, catheter support, education needs." />
              </div>
              <div>
                <label className="label">Personal care and ADL needs</label>
                <textarea className="input min-h-[110px]" value={draft.personalCareNeeds} onChange={(e) => updateDraft({ personalCareNeeds: e.target.value })} placeholder="Mobility, continence, hygiene, nutrition/hydration, dressing, transfers, skin care, home supports." />
              </div>
              <div>
                <label className="label">Identified risks and mitigation priorities</label>
                <textarea className="input min-h-[110px]" value={draft.identifiedRisks} onChange={(e) => updateDraft({ identifiedRisks: e.target.value })} placeholder="Falls, pressure injury, infection, cognitive risk, medication risk, carer strain, deterioration triggers, home hazards." />
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
              <div>
                <label className="label">Short-term goals</label>
                <textarea className="input min-h-[96px]" value={draft.shortTermGoals} onChange={(e) => updateDraft({ shortTermGoals: e.target.value })} placeholder="Immediate or early goals for symptom control, wound progress, adherence, safe function, or recovery." />
              </div>
              <div>
                <label className="label">Long-term goals</label>
                <textarea className="input min-h-[96px]" value={draft.longTermGoals} onChange={(e) => updateDraft({ longTermGoals: e.target.value })} placeholder="Ongoing goals for stability, independence, recovery, comfort, chronic disease support, or transition planning." />
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
              <div>
                <label className="label">Nursing interventions</label>
                <textarea className="input min-h-[120px]" value={draft.nursingInterventions} onChange={(e) => updateDraft({ nursingInterventions: e.target.value })} placeholder="Clinical interventions, evidence-based treatment actions, education, review requirements, and escalation steps." />
              </div>
              <div>
                <label className="label">Personal care interventions</label>
                <textarea className="input min-h-[120px]" value={draft.personalCareInterventions} onChange={(e) => updateDraft({ personalCareInterventions: e.target.value })} placeholder="Personal care tasks, positioning, skin care routines, continence support, hydration prompts, and home-care support steps." />
              </div>
              <div>
                <label className="label">Equipment and resources required</label>
                <textarea className="input min-h-[96px]" value={draft.equipmentRequirements} onChange={(e) => updateDraft({ equipmentRequirements: e.target.value })} placeholder="Dressings, PPE, mobility aids, continence products, medication aids, wound products, oxygen, educational resources." />
              </div>
              <div>
                <label className="label">Delegation and personnel level</label>
                <textarea className="input min-h-[96px]" value={draft.delegationPlan} onChange={(e) => updateDraft({ delegationPlan: e.target.value })} placeholder="RN/EN/NSS roles, supervision expectations, what must remain with the RN, and any scope limits." />
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
              <div>
                <label className="label">Visit schedule and delivery instructions</label>
                <textarea className="input min-h-[96px]" value={draft.visitSchedule} onChange={(e) => updateDraft({ visitSchedule: e.target.value })} placeholder="Visit frequency, planned duration, preferred timing windows, and practical care-delivery instructions." />
              </div>
              <div>
                <label className="label">Monitoring parameters and review cues</label>
                <textarea className="input min-h-[96px]" value={draft.monitoringParameters} onChange={(e) => updateDraft({ monitoringParameters: e.target.value })} placeholder="What to observe, review frequency, parameters for deterioration, wound progress markers, symptom or functional review measures." />
              </div>
              <div>
                <label className="label">People involved and referrals</label>
                <textarea className="input min-h-[96px]" value={draft.referralsAndTeam} onChange={(e) => updateDraft({ referralsAndTeam: e.target.value })} placeholder="Family/carers, GP, specialists, allied health, pharmacy, care coordinator, support services, and referral actions." />
              </div>
              <div>
                <label className="label">Escalation triggers and actions</label>
                <textarea className="input min-h-[96px]" value={draft.escalationTriggers} onChange={(e) => updateDraft({ escalationTriggers: e.target.value })} placeholder="Red flags, after-hours advice, GP review, ambulance/ED triggers, palliative escalation, or urgent deterioration response." />
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
              <div>
                <label className="label">Outcome targets</label>
                <textarea className="input min-h-[88px]" value={draft.outcomeTargets} onChange={(e) => updateDraft({ outcomeTargets: e.target.value })} placeholder="How success or progress will be recognised for this plan." />
              </div>
              <div>
                <label className="label">Evaluation and review plan</label>
                <textarea className="input min-h-[88px]" value={draft.evaluationPlan} onChange={(e) => updateDraft({ evaluationPlan: e.target.value })} placeholder="Who reviews, when review occurs, how the plan will be modified, and what documentation/re-signoff may be needed." />
              </div>
              <div className="xl:col-span-2">
                <label className="label">Transition or discharge considerations</label>
                <textarea className="input min-h-[88px]" value={draft.transitionConsiderations} onChange={(e) => updateDraft({ transitionConsiderations: e.target.value })} placeholder="Expected transition destination, services needed for handover, medication reconciliation points, closure criteria, or discharge instructions." />
              </div>
            </div>

            <div className="rounded-lg border border-ink-200 bg-sand-50 p-3 space-y-3">
              <label className="flex items-start gap-3 text-sm text-ink-800">
                <input
                  type="checkbox"
                  className="mt-1"
                  checked={draft.agreedWithPatientOrRepresentative}
                  onChange={(e) => updateDraft({ agreedWithPatientOrRepresentative: e.target.checked })}
                />
                <span>Plan developed in collaboration with the patient or authorised representative.</span>
              </label>
              <div>
                <label className="label">Patient or representative name</label>
                <input className="input" value={draft.agreementName} onChange={(e) => updateDraft({ agreementName: e.target.value })} placeholder="Optional name for agreement traceability" />
              </div>
            </div>

            <div className="rounded-md border border-ink-200 bg-ink-50 px-3 py-2 text-xs text-ink-600">
              This creates a clinician-only structured care-plan record and mirrors a summary into the patient chart Documents tab. PDF generation remains pending until a later report workflow is added.
            </div>

            <div className="flex flex-wrap justify-end gap-2">
              <button type="button" className="btn-secondary" onClick={() => setOpen(false)} disabled={busy}>
                Cancel
              </button>
              <button type="button" className="btn-primary" onClick={() => void handleSave()} disabled={busy}>
                {busy ? "Saving…" : "Save care plan"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default CarePlanLauncher;
