// src/components/ClinicianPortal.tsx
import React, { useEffect, useState, useCallback, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  collection,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
  limit,
} from "firebase/firestore";
import { db } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { Appointment, AppointmentStatus } from "../models/emr";
import { MainLayout } from "./MainLayout";
import { formatDateTimeInZone, getClinicTimeZone, getLocalTimeZone } from "../lib/time";
import { toPlainLanguageOutcomeMessage } from "../lib/plainLanguage";

type PracticeTask = {
  id: string;
  type?: string | null;
  priority?: "high" | "medium" | "low" | null;
  status?: "open" | "claimed" | "done" | "cancelled" | null;
  patientId?: string | null;
  appointmentId?: string | null;
  summary?: string | null;
  dueAt?: any;
};

function toDateMaybe(t: any): Date | null {
  try {
    if (!t) return null;
    if (typeof t?.toDate === "function") return t.toDate();
    if (typeof t?.seconds === "number") return new Date(t.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

function formatWhen(a: Appointment, clinicTz: string | null, localTz: string) {
  const d = toDateMaybe((a as any).scheduledAt);
  if (!d) return null;
  const effectiveClinicTz = clinicTz || localTz;
  return {
    local: formatDateTimeInZone(d, localTz),
    clinic: formatDateTimeInZone(d, effectiveClinicTz),
    clinicTz: effectiveClinicTz,
  };
}

function isPermissionDenied(e: any): boolean {
  // Firebase v9 errors usually carry `.code === "permission-denied"`
  const code = e?.code || e?.error?.code;
  if (code === "permission-denied") return true;

  const msg = String(e?.message || "");
  return msg.toLowerCase().includes("permission") && msg.toLowerCase().includes("denied");
}

function statusChip(status?: string) {
  if (status === "completed") return "chip chip-success";
  if (status === "in_progress") return "chip chip-info";
  if (status === "cancelled") return "chip chip-danger";
  return "chip chip-warning";
}

function taskPriorityChip(priority?: string | null) {
  if (priority === "high") return "chip chip-danger";
  if (priority === "medium") return "chip chip-warning";
  return "chip chip-info";
}

function startOfToday() {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return now;
}

function endOfToday() {
  const now = startOfToday();
  now.setDate(now.getDate() + 1);
  return now;
}

export const ClinicianPortal: React.FC = () => {
  const { user, normalizedRole, loading: authLoading, currentUserData } = useAuth() as any;
  const canUse = normalizedRole === "clinician";
  const localTz = useMemo(() => getLocalTimeZone(), []);
  const clinicTz = useMemo(
    () =>
      getClinicTimeZone(
        currentUserData?.practiceTimeZone,
        currentUserData?.timeZone
      ),
    [currentUserData]
  );

  const [items, setItems] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [tasks, setTasks] = useState<{ id: string; title: string; href: string }[]>([]);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [practiceTasks, setPracticeTasks] = useState<PracticeTask[]>([]);
  const [reviewMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    setErr(null);

    // Do not call Firestore until auth is resolved AND user is clinician.
    if (authLoading) return;
    if (!canUse) {
      setItems([]);
      setLoading(false);
      return;
    }
    if (!user?.uid) {
      setItems([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const q = query(
        collection(db, "appointments"),
        where("clinicianId", "==", user.uid),
        orderBy("scheduledAt", "asc"),
        limit(200)
      );

      const snap = await getDocs(q);
      const rows: Appointment[] = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as any),
      }));
      setItems(rows);
    } catch (e: any) {
      console.error(e);

      // Critical: Do not let PERMISSION_DENIED cascade into the broader app state.
      if (isPermissionDenied(e)) {
        setItems([]);
        setErr(
          "Access denied by Firestore security rules. This typically means appointments 'list' is not permitted for nurses, " +
            "or the query is missing limit(...). Confirm firestore.rules and restart emulators."
        );
        return;
      }

      setErr(toPlainLanguageOutcomeMessage(e, "We could not load appointments right now."));
    } finally {
      setLoading(false);
    }
  }, [authLoading, canUse, user?.uid]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const loadTasks = async () => {
      if (!canUse || !user?.uid) return;
      setTasksLoading(true);
      try {
        const qEnc = query(
          collection(db, "encounters"),
          where("practitionerId", "==", user.uid),
          where("status", "==", "draft"),
          orderBy("createdAt", "desc"),
          limit(5)
        );
        const snap = await getDocs(qEnc);
        const rows = snap.docs.map((d) => {
          const raw = d.data() as any;
          const reason = raw?.reason ? `: ${raw.reason}` : "";
          return {
            id: d.id,
            title: `Unsigned encounter${reason}`,
            href: `/patients/${raw.patientId}/chart/encounters/${d.id}?edit=1`,
          };
        });
        setTasks(rows);

        const practiceId = String(currentUserData?.practiceId || "").trim();
        if (practiceId) {
          const qPracticeTasks = query(
            collection(db, "practiceTasks"),
            where("practiceId", "==", practiceId),
            orderBy("createdAt", "desc"),
            limit(20)
          );
          const practiceTaskSnap = await getDocs(qPracticeTasks);
          const triageRows = practiceTaskSnap.docs
            .map((d) => ({ id: d.id, ...(d.data() as any) }) as PracticeTask)
            .filter((row) => row.status === "open" || row.status === "claimed");
          setPracticeTasks(triageRows);

        } else {
          setPracticeTasks([]);
        }
      } catch (e) {
        console.error("Failed to load tasks", e);
        setPracticeTasks([]);
      } finally {
        setTasksLoading(false);
      }
    };
    void loadTasks();
  }, [canUse, currentUserData?.practiceId, user?.uid]);

  const setStatus = async (id: string, status: AppointmentStatus) => {
    try {
      if (!user?.uid) return;

      await updateDoc(doc(db, "appointments", id), {
        status,
        updatedAt: serverTimestamp(),
        updatedBy: user.uid,
      });

      await load();
    } catch (e: any) {
      console.error(e);
      if (isPermissionDenied(e)) {
        setErr(
          "Access denied by Firestore security rules while updating an appointment. " +
            "If you are a nurse, confirm rules allow update on your own appointments (status + consultationNotes + timestamps only)."
        );
        return;
      }
      setErr(toPlainLanguageOutcomeMessage(e, "We could not update that appointment just now."));
    }
  };

  if (!canUse) {
    return (
      <MainLayout>
        <div className="text-sm text-red-600">Access denied.</div>
      </MainLayout>
    );
  }

  const now = new Date();
  const todayStart = startOfToday();
  const todayEnd = endOfToday();

  const todayAppointments = items.filter((a) => {
    const when = toDateMaybe((a as any).scheduledAt);
    return !!when && when >= todayStart && when < todayEnd && a.status !== "cancelled";
  });

  const upcomingAppointments = items.filter((a) => {
    const when = toDateMaybe((a as any).scheduledAt);
    return !!when && when >= now && a.status !== "cancelled";
  });

  const inProgressAppointments = items.filter((a) => a.status === "in_progress");
  const overdueAppointments = items.filter((a) => {
    const when = toDateMaybe((a as any).scheduledAt);
    return !!when && when < now && a.status === "scheduled";
  });

  const highPriorityPracticeTasks = practiceTasks.filter((task) => task.priority === "high");
  const nextAppointment = upcomingAppointments[0] || null;
  const clinicianLabel =
    currentUserData?.displayName?.trim() ||
    currentUserData?.email ||
    user?.email ||
    "Nurse";

  return (
    <MainLayout>
      <div className="space-y-4">
        <section className="card overflow-hidden">
          <div className="bg-[radial-gradient(circle_at_top_left,_rgba(31,154,146,0.22),_transparent_42%),linear-gradient(135deg,#103634_0%,#1b5854_38%,#f5fbfa_100%)] px-5 py-6 md:px-6">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
              <div className="max-w-2xl">
                <div className="text-[11px] uppercase tracking-[0.24em] text-white/70">Nurse Workspace</div>
                <h1 className="mt-2 text-3xl text-white">Today&apos;s care, triage, and follow-up</h1>
                <p className="mt-2 text-sm text-white/80">
                  {clinicianLabel} · {formatDateTimeInZone(now, clinicTz || localTz)}
                </p>
                {nextAppointment ? (
                  <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs text-white">
                    Next appointment:
                    <span className="font-semibold">
                      {nextAppointment.patientName || nextAppointment.patientId}
                    </span>
                    <span>·</span>
                    <span>{formatWhen(nextAppointment, clinicTz, localTz)?.clinic || "—"}</span>
                  </div>
                ) : (
                  <div className="mt-4 inline-flex items-center rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs text-white">
                    No upcoming appointments scheduled.
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="rounded-2xl bg-white/90 px-4 py-3">
                  <div className="text-[11px] uppercase tracking-wide text-ink-500">Today</div>
                  <div className="mt-1 text-2xl font-semibold text-ink-900">{todayAppointments.length}</div>
                </div>
                <div className="rounded-2xl bg-white/90 px-4 py-3">
                  <div className="text-[11px] uppercase tracking-wide text-ink-500">In progress</div>
                  <div className="mt-1 text-2xl font-semibold text-ink-900">{inProgressAppointments.length}</div>
                </div>
                <div className="rounded-2xl bg-white/90 px-4 py-3">
                  <div className="text-[11px] uppercase tracking-wide text-ink-500">Unsigned</div>
                  <div className="mt-1 text-2xl font-semibold text-ink-900">{tasks.length}</div>
                </div>
                <div className="rounded-2xl bg-white/90 px-4 py-3">
                  <div className="text-[11px] uppercase tracking-wide text-ink-500">High priority</div>
                  <div className="mt-1 text-2xl font-semibold text-ink-900">{highPriorityPracticeTasks.length}</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {err && <div className="text-sm text-rose-600">{err}</div>}
        {reviewMsg ? <div className="text-sm text-emerald-600">{reviewMsg}</div> : null}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-4 space-y-4">
            <div className="card p-4">
              <div className="section-title mb-2">Action board</div>
              <div className="grid grid-cols-1 gap-2">
                <Link to="/patients" className="rounded-xl border border-ink-200 bg-sand-50 px-3 py-3 text-sm hover:bg-sand-100">
                  Open client charts
                </Link>
                <Link to="/my-roster" className="rounded-xl border border-ink-200 bg-sand-50 px-3 py-3 text-sm hover:bg-sand-100">
                  Manage roster
                </Link>
                {nextAppointment?.mode === "video" ? (
                  <Link to={`/call/${nextAppointment.id}`} className="rounded-xl border border-brand-200 bg-brand-50 px-3 py-3 text-sm hover:bg-brand-100">
                    Join next telehealth consult
                  </Link>
                ) : null}
              </div>
            </div>

            <div className="card p-4">
              <div className="section-title mb-2">Unsigned work</div>
              {tasksLoading ? (
                <div className="text-sm text-ink-500">Loading tasks…</div>
              ) : tasks.length === 0 ? (
                <div className="text-sm text-ink-500">No pending tasks.</div>
              ) : (
                <div className="space-y-2">
                  {tasks.map((t) => (
                    <Link key={t.id} to={t.href} className="block rounded-xl border border-ink-200 px-3 py-3 text-sm text-ink-800 hover:bg-ink-50">
                      {t.title}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div className="card p-4">
              <div className="section-title mb-2">Triage queue</div>
              {tasksLoading ? (
                <div className="text-sm text-ink-500">Loading triage…</div>
              ) : practiceTasks.length === 0 ? (
                <div className="text-sm text-ink-500">No active practice tasks.</div>
              ) : (
                <div className="space-y-2">
                  {practiceTasks.slice(0, 6).map((task) => (
                    <div key={task.id} className="rounded-xl border border-ink-200 px-3 py-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-sm font-medium text-ink-900">{task.summary || task.type || "Practice task"}</div>
                        <span className={taskPriorityChip(task.priority)}>{task.priority || "routine"}</span>
                      </div>
                      <div className="mt-1 text-xs text-ink-500">
                        Patient: {task.patientId || "—"}
                        {task.dueAt ? ` · Due ${toDateMaybe(task.dueAt)?.toLocaleString() || ""}` : ""}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-8 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="card p-4">
                <div className="text-xs uppercase tracking-wide text-ink-500">Due now</div>
                <div className="mt-2 text-3xl font-semibold text-ink-900">{overdueAppointments.length}</div>
                <div className="mt-1 text-sm text-ink-500">Scheduled appointments already past start time.</div>
              </div>
              <div className="card p-4">
                <div className="text-xs uppercase tracking-wide text-ink-500">Video today</div>
                <div className="mt-2 text-3xl font-semibold text-ink-900">
                  {todayAppointments.filter((a) => a.mode === "video").length}
                </div>
                <div className="mt-1 text-sm text-ink-500">Telehealth consults in today&apos;s list.</div>
              </div>
              <div className="card p-4">
                <div className="text-xs uppercase tracking-wide text-ink-500">Completed today</div>
                <div className="mt-2 text-3xl font-semibold text-ink-900">
                  {todayAppointments.filter((a) => a.status === "completed").length}
                </div>
                <div className="mt-1 text-sm text-ink-500">Appointments already closed out today.</div>
              </div>
              <div className="card p-4">
                <div className="text-xs uppercase tracking-wide text-ink-500">Triage items</div>
                <div className="mt-2 text-3xl font-semibold text-ink-900">{practiceTasks.length}</div>
                <div className="mt-1 text-sm text-ink-500">Active nurse triage and follow-up items in the queue.</div>
              </div>
            </div>

            <div className="card p-4">
              <div className="card-header mb-3">
                <div>
                  <div className="section-title">Today&apos;s schedule</div>
                  <div className="section-subtitle">Clinic time and local time shown together for smoother telehealth handoff.</div>
                </div>
                <button onClick={() => void load()} className="btn-secondary">
                  Refresh
                </button>
              </div>

              {loading ? (
                <div className="text-sm text-ink-500">Loading…</div>
              ) : todayAppointments.length === 0 ? (
                <div className="text-sm text-ink-500">No appointments on today&apos;s list.</div>
              ) : (
                <div className="space-y-3">
                  {todayAppointments.map((a) => (
                    <div key={a.id} className="border border-ink-200 rounded-xl p-3">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                        <div>
                          <div className="text-sm font-semibold">{a.patientName || a.patientId}</div>
                          {(() => {
                            const when = formatWhen(a, clinicTz, localTz);
                            return (
                              <div className="text-xs text-ink-500 mt-1 space-y-1">
                                <div className="flex flex-wrap items-center gap-2">
                                  <span>{when ? when.local : "—"}</span>
                                  <span className="capitalize">{a.mode}</span>
                                  <span className={statusChip(a.status)}>{a.status}</span>
                                </div>
                                {when && (
                                  <div>
                                    Local ({localTz}) · Clinic ({when.clinicTz}) · {when.clinic}
                                  </div>
                                )}
                              </div>
                            );
                          })()}
                          {a.reason && <div className="text-xs text-ink-500 mt-1">Reason: {a.reason}</div>}
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {a.mode === "video" && (
                            <Link to={`/call/${a.id}`} className="btn-primary text-xs px-3 py-2">
                              Join telehealth
                            </Link>
                          )}

                          <button
                            onClick={() => void setStatus(a.id, "in_progress")}
                            className="btn-secondary text-xs px-3 py-2"
                          >
                            In progress
                          </button>

                          <button
                            onClick={() => void setStatus(a.id, "completed")}
                            className="btn-secondary text-xs px-3 py-2"
                          >
                            Completed
                          </button>

                          <button
                            onClick={() => void setStatus(a.id, "cancelled")}
                            className="btn-secondary text-xs px-3 py-2"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>

                      <div className="mt-2 text-xs text-ink-500">
                        Appointment ID: <span className="font-mono">{a.id}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="card p-4">
              <div className="card-header mb-3">
                <div>
                  <div className="section-title">Care coordination focus</div>
                  <div className="section-subtitle">This workspace is centred on appointments, encounters, triage, and patient chart follow-up.</div>
                </div>
              </div>
              <div className="text-sm text-ink-500">
                Investigation ordering, referrals, and medical certificate workflows have been removed from the nurse workspace. Prescription workflow is available only to nurse practitioners where it is within scope.
              </div>
            </div>

            <div className="card p-4">
              <div className="card-header mb-3">
                <div>
                  <div className="section-title">Upcoming queue</div>
                  <div className="section-subtitle">Next appointments beyond the immediate day view.</div>
                </div>
              </div>
              {loading ? (
                <div className="text-sm text-ink-500">Loading…</div>
              ) : upcomingAppointments.length === 0 ? (
                <div className="text-sm text-ink-500">No future appointments queued.</div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {upcomingAppointments.slice(0, 6).map((a) => (
                    <div key={a.id} className="rounded-xl border border-ink-200 px-3 py-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-sm font-medium text-ink-900">{a.patientName || a.patientId}</div>
                        <span className={statusChip(a.status)}>{a.status}</span>
                      </div>
                      <div className="mt-1 text-xs text-ink-500">
                        {formatWhen(a, clinicTz, localTz)?.clinic || "—"} · {a.mode}
                      </div>
                      {a.mode === "video" ? (
                        <div className="mt-3">
                          <Link to={`/call/${a.id}`} className="btn-secondary text-xs px-3 py-2">
                            Open consult room
                          </Link>
                        </div>
                      ) : null}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default ClinicianPortal;
