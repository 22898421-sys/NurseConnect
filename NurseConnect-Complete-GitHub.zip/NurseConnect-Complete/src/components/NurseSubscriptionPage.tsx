import React, { useMemo, useState } from "react";
import { doc, serverTimestamp, updateDoc } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { Link, useLocation } from "react-router-dom";
import { db, functions } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { getNurseTypeOption } from "../lib/nurses";
import {
  SUBSCRIPTION_BILLING_OPTIONS,
  SUBSCRIPTION_TRIAL_DAYS,
  computeSubscriptionChargeCents,
  formatCurrencyAUD,
  formatLongDate,
} from "../lib/subscriptions";
import { MainLayout } from "./MainLayout";

const paymentMethodOptions = [
  { value: "card", label: "Debit or credit card" },
  { value: "direct_debit", label: "Direct debit" },
];

export const NurseSubscriptionPage: React.FC = () => {
  const { user, currentUserData } = useAuth() as any;
  const location = useLocation();
  const [selectedCycle, setSelectedCycle] = useState(currentUserData?.subscriptionBillingCycle || "monthly");
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(currentUserData?.subscriptionPaymentMethod || "card");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const gatewayMode = process.env.REACT_APP_SUBSCRIPTION_GATEWAY || "demo";
  const demoBillingEnabled = process.env.REACT_APP_ENABLE_DEMO_BILLING === "true" || process.env.REACT_APP_USE_EMULATORS === "true";
  const isStripeCheckoutEnabled = gatewayMode === "stripe";
  const canRunDemoActivation = demoBillingEnabled;
  const queryState = new URLSearchParams(location.search).get("checkout");
  const nurseTypeOption = getNurseTypeOption(currentUserData?.nurseType);
  const baseMonthlyFeeCents = nurseTypeOption?.monthlyFeeCents ?? 5000;
  const trialEndsAtRaw = currentUserData?.subscriptionTrialEndsAt?.toDate?.() || currentUserData?.subscriptionTrialEndsAt || null;
  const trialEndsAtLabel = formatLongDate(trialEndsAtRaw);
  const currentPricing = useMemo(
    () => computeSubscriptionChargeCents(baseMonthlyFeeCents, selectedCycle),
    [baseMonthlyFeeCents, selectedCycle]
  );
  const billingOptions = useMemo(
    () =>
      SUBSCRIPTION_BILLING_OPTIONS.map((cycle) => {
        const pricing = computeSubscriptionChargeCents(baseMonthlyFeeCents, cycle.value);
        return {
          ...cycle,
          price: formatCurrencyAUD(pricing.discountedCents),
          savings: pricing.discountPercent > 0 ? `${pricing.discountPercent}% off` : "",
        };
      }),
    [baseMonthlyFeeCents]
  );

  const statusLabel = useMemo(() => {
    const raw = String(currentUserData?.subscriptionStatus || "pending_payment");
    return raw.replace(/_/g, " ");
  }, [currentUserData?.subscriptionStatus]);
  const checkoutBanner = useMemo(() => {
    if (queryState === "success") {
      return {
        type: "success" as const,
        text: "Stripe checkout completed. Subscription confirmation will be finalised as soon as webhook handling is connected.",
      };
    }
    if (queryState === "cancel") {
      return {
        type: "error" as const,
        text: "Stripe checkout was cancelled. Your subscription preferences were kept and you can try again when ready.",
      };
    }
    return null;
  }, [queryState]);

  async function saveCycle() {
    if (!user?.uid) return;
    setBusy(true);
    setMessage(null);
    setError(null);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        subscriptionBillingCycle: selectedCycle,
        subscriptionPaymentMethod: selectedPaymentMethod,
        subscriptionDiscountPercent: currentPricing.discountPercent,
        subscriptionCurrentPriceCents: currentPricing.discountedCents,
        updatedAt: serverTimestamp(),
      });
      setMessage("Subscription setup preferences updated.");
    } catch (e: any) {
      setError(e?.message || "Could not update subscription setup.");
    } finally {
      setBusy(false);
    }
  }

  async function activateDemoSubscription() {
    if (!user?.uid) return;
    setBusy(true);
    setMessage(null);
    setError(null);
    try {
      const call = httpsCallable(functions, "activateDemoSubscription");
      await call({
        subscriptionBillingCycle: selectedCycle,
        subscriptionPaymentMethod: selectedPaymentMethod,
      });
      setMessage("Demo subscription activation completed. This is a placeholder checkout flow for testing and deployment demos.");
    } catch (e: any) {
      setError(e?.message || "Could not activate demo subscription.");
    } finally {
      setBusy(false);
    }
  }

  async function startStripeCheckout() {
    if (!user?.uid) return;
    setBusy(true);
    setMessage(null);
    setError(null);
    try {
      const call = httpsCallable(functions, "createStripeCheckoutSession");
      const result: any = await call({
        subscriptionBillingCycle: selectedCycle,
        subscriptionPaymentMethod: selectedPaymentMethod,
        origin: window.location.origin,
      });
      const checkoutUrl = result?.data?.url;
      if (!checkoutUrl) {
        throw new Error("Stripe checkout session did not return a redirect URL.");
      }
      window.location.assign(checkoutUrl);
    } catch (e: any) {
      setError(e?.message || "Could not start Stripe checkout.");
      setBusy(false);
    }
  }

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        <div className="card p-6">
          <h1 className="section-title">Nurse Subscription Setup</h1>
          <p className="section-subtitle mt-2">
            New nurse accounts start with a free first week. Billing begins after the trial period using the subscription type you choose here.
          </p>
        </div>

        {checkoutBanner?.type === "success" ? (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{checkoutBanner.text}</div>
        ) : null}
        {checkoutBanner?.type === "error" ? (
          <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{checkoutBanner.text}</div>
        ) : null}
        {message ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{message}</div> : null}
        {error ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="card p-6 space-y-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Billing cycle</p>
              <h2 className="mt-2 text-2xl font-semibold text-ink-900">Choose how the nurse subscription is billed</h2>
              <p className="mt-3 text-sm leading-7 text-ink-600">
                Choose the subscription cadence and payment method NurseConnectCare should use when billing starts after your free first week.
              </p>
            </div>

            <div className="rounded-2xl border border-ink-200 bg-white px-4 py-4 text-sm leading-7 text-ink-700">
              Current cadre: <span className="font-medium text-ink-900">{nurseTypeOption?.label || "Registered Nurse (RN)"}</span>.
              Base monthly fee:{" "}
              <span className="font-medium text-ink-900">
                {new Intl.NumberFormat("en-AU", {
                  style: "currency",
                  currency: "AUD",
                  minimumFractionDigits: 2,
                }).format(baseMonthlyFeeCents / 100)}
              </span>
              .
            </div>

            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-4 text-sm leading-7 text-emerald-900">
              First 7 days free. Your first charge of <span className="font-medium">{formatCurrencyAUD(currentPricing.discountedCents)}</span>
              {" "}for the {currentPricing.label.toLowerCase()} plan is scheduled for <span className="font-medium">{trialEndsAtLabel}</span>.
            </div>

            <div className="rounded-2xl border border-brand-200 bg-brand-50 px-4 py-4 text-sm leading-7 text-ink-700">
              Gateway mode: <span className="font-medium text-ink-900">{gatewayMode}</span>.
              {isStripeCheckoutEnabled
                ? " Stripe Checkout is enabled for real subscription sign-up. Subscription activation and renewals still need webhook handling to keep Firestore in sync after payment events."
                : " Demo mode is active for deployment testing and demonstrations. No real payment is processed."}
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              {billingOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setSelectedCycle(option.value)}
                  className={`rounded-2xl border px-4 py-4 text-left transition ${
                    selectedCycle === option.value
                      ? "border-brand-500 bg-brand-50 text-ink-900"
                      : "border-ink-200 bg-white text-ink-600 hover:border-brand-300"
                  }`}
                  >
                    <div className="text-sm font-semibold">{option.label}</div>
                    <div className="mt-1 text-xs text-ink-500">{option.price} per billing cycle</div>
                    {option.savings ? <div className="mt-1 text-xs font-medium text-emerald-700">{option.savings}</div> : null}
                  </button>
                ))}
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Payment method</p>
                <h3 className="mt-2 text-lg font-semibold text-ink-900">Preferred gateway payment option</h3>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {paymentMethodOptions.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setSelectedPaymentMethod(option.value)}
                    className={`rounded-2xl border px-4 py-4 text-left transition ${
                      selectedPaymentMethod === option.value
                        ? "border-brand-500 bg-brand-50 text-ink-900"
                        : "border-ink-200 bg-white text-ink-600 hover:border-brand-300"
                    }`}
                  >
                    <div className="text-sm font-semibold">{option.label}</div>
                    <div className="mt-1 text-xs text-ink-500">Saved as your default subscription payment preference</div>
                  </button>
                ))}
              </div>
            </div>

            <button type="button" className="btn-primary" onClick={saveCycle} disabled={busy}>
              {busy ? "Saving..." : "Save subscription setup"}
            </button>

            {isStripeCheckoutEnabled ? (
              <button type="button" className="btn-primary" onClick={startStripeCheckout} disabled={busy}>
                {busy ? "Redirecting..." : "Continue to secure checkout"}
              </button>
            ) : null}

            {canRunDemoActivation ? (
              <button type="button" className="btn-secondary" onClick={activateDemoSubscription} disabled={busy}>
                {busy ? "Activating..." : "Run demo checkout"}
              </button>
            ) : null}
          </div>

          <div className="card p-6 space-y-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Subscription status</p>
              <h2 className="mt-2 text-2xl font-semibold text-ink-900 capitalize">{statusLabel}</h2>
            </div>
            <div className="rounded-2xl border border-brand-200 bg-brand-50 px-4 py-4 text-sm leading-7 text-ink-700">
              This page records the nurse subscription cadence and preferred payment method before handing off to Stripe. Webhook handling is still the next required step so subscription status changes, first successful billing, renewals, and failed payments stay synced into Firestore automatically.
            </div>
            <div className="rounded-2xl border border-ink-200 bg-white px-4 py-4 text-sm leading-7 text-ink-600">
              Current billing cycle: <span className="font-medium text-ink-900">{selectedCycle.replace(/_/g, " ")}</span>
            </div>
            <div className="rounded-2xl border border-ink-200 bg-white px-4 py-4 text-sm leading-7 text-ink-600">
              Current discount: <span className="font-medium text-ink-900">{currentPricing.discountPercent}%</span>
            </div>
            <div className="rounded-2xl border border-ink-200 bg-white px-4 py-4 text-sm leading-7 text-ink-600">
              Preferred payment method: <span className="font-medium text-ink-900">{selectedPaymentMethod.replace(/_/g, " ")}</span>
            </div>
            <div className="rounded-2xl border border-ink-200 bg-white px-4 py-4 text-sm leading-7 text-ink-600">
              Trial period: <span className="font-medium text-ink-900">{SUBSCRIPTION_TRIAL_DAYS} days free</span>
            </div>
            <Link to="/schedule" className="btn-secondary w-full text-center">
              Continue to nurse workspace
            </Link>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default NurseSubscriptionPage;
