// src/components/encounters/index.ts
export { default as EncounterList } from "./EncounterList";
export { default as NewEncounterDialog } from "./NewEncounterDialog";
export { default as EncounterSummaryCard } from "./EncounterSummaryCard";

export type { EncounterRecord, EncounterType } from "./EncounterSummaryCard";
