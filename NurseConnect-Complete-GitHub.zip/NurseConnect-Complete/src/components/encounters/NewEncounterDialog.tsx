// src/components/encounters/NewEncounterDialog.tsx
import React, { useMemo, useState } from "react";
import { collection, doc, serverTimestamp, writeBatch } from "firebase/firestore";
import { db } from "../../firebaseConfig";
import { EncounterType } from "./EncounterSummaryCard";
import { buildEncounterHeader } from "../../lib/encounterHeaders";
import { resolveProvider, resolveProviderLabel } from "../../lib/provider";

export type NewEncounterDialogProps = {
  open: boolean;
  onClose: () => void;

  patientId: string;
  practitionerId: string;
  practiceId?: string | null;

  onCreated?: (encounterId: string) => void;
};

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function formatDDMMYYYY(d: Date) {
  const dd = pad2(d.getDate());
  const mm = pad2(d.getMonth() + 1);
  const yyyy = d.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

function toISODateString(ddmmyyyy: string): string {
  const raw = (ddmmyyyy ?? "").trim();
  const m = raw.match(/^([0-3]?\d)-([0-1]?\d)-(\d{4})$/);
  if (!m) return "";
  const dd = Number(m[1]);
  const mm = Number(m[2]);
  const yyyy = Number(m[3]);
  if (!yyyy || mm < 1 || mm > 12 || dd < 1 || dd > 31) return "";
  const dt = new Date(yyyy, mm - 1, dd);
  if (dt.getFullYear() !== yyyy || dt.getMonth() !== mm - 1 || dt.getDate() !== dd) return "";
  return `${String(yyyy).padStart(4, "0")}-${pad2(mm)}-${pad2(dd)}`;
}

export const NewEncounterDialog: React.FC<NewEncounterDialogProps> = ({
  open,
  onClose,
  patientId,
  practitionerId,
  practiceId = null,
  onCreated,
}) => {
  const today = useMemo(() => formatDDMMYYYY(new Date()), []);
  const [encounterDate, setEncounterDate] = useState<string>(today);
  const [type, setType] = useState<EncounterType>("consultation");
  const [reason, setReason] = useState<string>("");
  const [notes, setNotes] = useState<string>("");

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canSave = useMemo(() => {
    return !!patientId && !!practitionerId && !!encounterDate.trim() && !!reason.trim() && !saving;
  }, [patientId, practitionerId, encounterDate, reason, saving]);

  const reset = () => {
    setEncounterDate(today);
    setType("consultation");
    setReason("");
    setNotes("");
    setError(null);
    setSaving(false);
  };

  const handleClose = () => {
    if (saving) return;
    reset();
    onClose();
  };

  const save = async () => {
    if (!canSave) return;

    setSaving(true);
    setError(null);

    try {
      const encounterDateISO = toISODateString(encounterDate);
      const now = serverTimestamp();

      // Step 6: stamp denormalised clinician identity at creation time
      // - displayName: for quick use / fallbacks
      // - practitionerLabel: canonical label (supports future designation/specialty)
      const ident = await resolveProvider(practitionerId);
      const practitionerDisplayName = ident.displayName || practitionerId;

      const practitionerLabel = await resolveProviderLabel(practitionerId, { includeRole: true });

      const encounterRef = doc(collection(db, "encounters"));
      const batch = writeBatch(db);
      const encounterPayload = {
        patientId,
        practitionerId,
        practiceId: practiceId ?? null,

        // Step 6: denormalised clinician identity for fast lists/prints
        practitionerDisplayName,
        practitionerLabel,

        encounterDate: encounterDate.trim(), // DD-MM-YYYY
        encounterDateISO, // YYYY-MM-DD (optional ordering)
        type,
        reason: reason.trim(),
        notes: notes?.trim() ? notes.trim() : "",

        status: "draft",
        breakGlass: { enabled: false },

        createdAt: now,
        createdBy: practitionerId,
        updatedAt: now,
        updatedBy: practitionerId,
      };

      batch.set(encounterRef, encounterPayload);
      batch.set(
        doc(db, "encounterHeaders", encounterRef.id),
        buildEncounterHeader({
          ...encounterPayload,
          status: "draft",
        })
      );
      await batch.commit();

      handleClose();
      onCreated?.(encounterRef.id);
    } catch (e: any) {
      console.error("Failed to create encounter:", e);
      setError(e?.message ?? "Failed to create encounter.");
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/30" onClick={handleClose} />

      <div className="relative w-[92vw] max-w-xl rounded-2xl bg-white shadow-lg border p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold">New encounter</h3>
            <p className="text-xs text-gray-600 mt-1">Create the encounter, then complete SOAP on the next screen.</p>
          </div>

          <button
            className="px-2 py-1 rounded-md text-sm border hover:bg-gray-50"
            onClick={handleClose}
            disabled={saving}
          >
            Close
          </button>
        </div>

        <div className="mt-4 space-y-3 text-sm">
          {error ? <div className="text-red-600">{error}</div> : null}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="block">
              <div className="text-xs font-medium text-gray-700 mb-1">Encounter date (DD-MM-YYYY)</div>
              <input
                className="w-full border rounded-md px-3 py-2"
                value={encounterDate}
                onChange={(e) => setEncounterDate(e.target.value)}
                placeholder="DD-MM-YYYY"
                disabled={saving}
              />
            </label>

            <label className="block">
              <div className="text-xs font-medium text-gray-700 mb-1">Type</div>
              <select
                className="w-full border rounded-md px-3 py-2"
                value={type}
                onChange={(e) => setType(e.target.value as EncounterType)}
                disabled={saving}
              >
                <option value="consultation">Consultation</option>
                <option value="follow_up">Follow-up</option>
                <option value="procedure">Procedure</option>
              </select>
            </label>
          </div>

          <label className="block">
            <div className="text-xs font-medium text-gray-700 mb-1">Reason (required)</div>
            <input
              className="w-full border rounded-md px-3 py-2"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g., headache for 2 weeks"
              disabled={saving}
            />
          </label>

          <label className="block">
            <div className="text-xs font-medium text-gray-700 mb-1">Notes</div>
            <textarea
              className="w-full border rounded-md px-3 py-2 min-h-[120px]"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Optional free-text notes…"
              disabled={saving}
            />
          </label>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
              onClick={handleClose}
              disabled={saving}
            >
              Cancel
            </button>
            <button
              className="px-3 py-2 rounded-md bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-60"
              onClick={save}
              disabled={!canSave}
            >
              {saving ? "Saving…" : "Create encounter"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewEncounterDialog;
