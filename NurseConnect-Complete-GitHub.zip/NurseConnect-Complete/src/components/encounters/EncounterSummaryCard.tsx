// src/components/encounters/EncounterSummaryCard.tsx
import React from "react";

export type EncounterType = "consultation" | "follow_up" | "procedure";
export type EncounterStatus = "draft" | "completed";

export type EncounterRecord = {
  id: string;
  patientId: string;
  practiceId?: string | null;
  practitionerId?: string;

  // Step 6: denormalised clinician identity (optional)
  practitionerDisplayName?: string;
  practitionerLabel?: string;

  encounterDate: string; // DD-MM-YYYY
  encounterDateISO?: string; // YYYY-MM-DD (optional ordering field)
  type: EncounterType;
  reason: string;

  status?: EncounterStatus;
  notes?: string;

  breakGlass?: {
    enabled?: boolean;
  };

  soap?: {
    subjective?: string;
    objective?: string;
    assessment?: string;
    plan?: string;
  };

  createdAt?: any;
  updatedAt?: any;
};

type SoapStatus = "draft" | "in_progress" | "complete";

function nonEmpty(v: any) {
  return typeof v === "string" && v.trim().length > 0;
}

function getSoapCompletion(enc: EncounterRecord): { status: SoapStatus; filled: number; total: number } {
  const s = enc.soap ?? {};
  const filled = [s.subjective, s.objective, s.assessment, s.plan].filter(nonEmpty).length;
  const total = 4;
  if (filled === 0) return { status: "draft", filled, total };
  if (filled === total) return { status: "complete", filled, total };
  return { status: "in_progress", filled, total };
}

function statusLabel(s: SoapStatus) {
  switch (s) {
    case "draft":
      return "Draft";
    case "in_progress":
      return "In progress";
    case "complete":
      return "Complete";
    default:
      return "Draft";
  }
}

function typeLabel(t: EncounterType) {
  switch (t) {
    case "consultation":
      return "Consultation";
    case "follow_up":
      return "Follow-up";
    case "procedure":
      return "Procedure";
    default:
      return "Encounter";
  }
}

function encounterStatusLabel(s?: EncounterStatus) {
  return s === "completed" ? "Signed" : "Draft";
}

type Props = {
  encounter: EncounterRecord;
  providerName?: string;
  onOpen?: (encounterId: string) => void;
};

export const EncounterSummaryCard: React.FC<Props> = ({ encounter, providerName, onOpen }) => {
  const clickable = typeof onOpen === "function";
  const completion = getSoapCompletion(encounter);

  const summaryText = (() => {
    const subj = typeof encounter.soap?.subjective === "string" ? encounter.soap.subjective : "";
    const legacy = typeof encounter.notes === "string" ? encounter.notes : "";
    const raw = (subj || legacy || "").trim();
    if (!raw) return "";
    const oneLine = raw.replace(/\s+/g, " ").trim();
    return oneLine.length > 160 ? `${oneLine.slice(0, 160)}…` : oneLine;
  })();

  const isSigned = (encounter.status ?? "draft") === "completed";
  const breakGlass = !!encounter.breakGlass?.enabled;

  return (
    <div
      className={[
        "border rounded-xl p-4 bg-white shadow-sm",
        clickable ? "hover:shadow-md transition cursor-pointer" : "",
      ].join(" ")}
      onClick={() => {
        if (clickable) onOpen!(encounter.id);
      }}
      role={clickable ? "button" : undefined}
      tabIndex={clickable ? 0 : -1}
      onKeyDown={(e) => {
        if (!clickable) return;
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onOpen!(encounter.id);
        }
      }}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <div className="text-base font-semibold text-gray-900">
              {typeLabel(encounter.type)} • {encounter.encounterDate}
            </div>

            <span
              className={[
                "inline-flex items-center px-2 py-0.5 rounded-full text-xs border",
                isSigned ? "bg-green-50 border-green-200 text-green-800" : "bg-gray-50 border-gray-200 text-gray-700",
              ].join(" ")}
              title={isSigned ? "Encounter is signed (locked)." : "Encounter is in draft."}
            >
              {encounterStatusLabel(encounter.status)}
            </span>

            {breakGlass ? (
              <span
                className="inline-flex items-center px-2 py-0.5 rounded-full text-xs border bg-amber-50 border-amber-200 text-amber-800"
                title="Break-glass is enabled for this signed encounter."
              >
                Break-glass
              </span>
            ) : null}

            <span
              className={[
                "inline-flex items-center px-2 py-0.5 rounded-full text-xs border",
                completion.status === "complete"
                  ? "bg-blue-50 border-blue-200 text-blue-800"
                  : completion.status === "in_progress"
                  ? "bg-purple-50 border-purple-200 text-purple-800"
                  : "bg-gray-50 border-gray-200 text-gray-700",
              ].join(" ")}
              title={`SOAP completion: ${completion.filled}/${completion.total}`}
            >
              SOAP: {statusLabel(completion.status)} ({completion.filled}/{completion.total})
            </span>
          </div>

          {providerName ? (
            <div className="mt-2 text-sm text-gray-700">
              Practitioner: <span className="font-medium text-gray-800">{providerName}</span>
            </div>
          ) : null}

          {encounter.reason ? (
            <div className="mt-2">
              <span className="font-medium">Reason:</span> {encounter.reason}
            </div>
          ) : null}

          {summaryText ? (
            <div className="mt-2 text-gray-800">
              <span className="font-medium">Summary:</span> {summaryText}
            </div>
          ) : null}
        </div>

        {clickable ? (
          <button
            className="shrink-0 px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onOpen!(encounter.id);
            }}
          >
            View
          </button>
        ) : null}
      </div>
    </div>
  );
};

export default EncounterSummaryCard;