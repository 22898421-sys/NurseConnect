// src/components/encounters/EncounterList.tsx
import React, { useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, orderBy, query, where } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { db } from "../../firebaseConfig";
import EncounterSummaryCard, { EncounterRecord } from "./EncounterSummaryCard";
import { resolveProviderLabel } from "../../lib/provider";
import { useAuth } from "../../contexts/AuthContext";

type Props = {
  patientId: string;
  refreshToken?: number;
};

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`Encounter query timed out after ${ms}ms`)), ms);
    p.then((v) => {
      clearTimeout(t);
      resolve(v);
    }).catch((e) => {
      clearTimeout(t);
      reject(e);
    });
  });
}

function safeStr(v: any): string {
  return typeof v === "string" ? v : "";
}

const EncountersAccessRestricted: React.FC = () => {
  return (
    <div className="border rounded-xl bg-white p-4">
      <div className="text-base font-semibold">Clinical encounters are restricted</div>
      <div className="mt-1 text-sm text-gray-700">
        For privacy and medico-legal reasons, encounter notes are available to clinicians within the same practice.
      </div>
      <div className="mt-2 text-sm text-gray-700">
        Administrators do not have routine access to clinical encounters.
      </div>
    </div>
  );
};

export const EncounterList: React.FC<Props> = ({ patientId, refreshToken = 0 }) => {
  const navigate = useNavigate();
  const { normalizedRole, user, currentUserData } = useAuth() as any;

  const isClinician = (normalizedRole ?? "").toLowerCase() === "clinician";
  const myUid = safeStr(user?.uid);
  const myPracticeId = safeStr(currentUserData?.practiceId);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [encounters, setEncounters] = useState<EncounterRecord[]>([]);
  const [providerMap, setProviderMap] = useState<Record<string, string>>({});
  const [mode, setMode] = useState<"practiceScoped" | "authorFallback">("practiceScoped");

  const canQuery = useMemo(() => !!patientId && isClinician, [patientId, isClinician]);

  const load = async () => {
    if (!patientId) return;

    if (!isClinician) {
      setLoading(false);
      setError(null);
      setEncounters([]);
      setProviderMap({});
      return;
    }

    setLoading(true);
    setError(null);
    setEncounters([]);
    setProviderMap({});

    try {
      let qBase;

      if (myPracticeId) {
        // ✅ Preferred: constrain by practiceId so the query cannot return foreign docs (prevents whole-query denial)
        qBase = query(
          collection(db, "encounters"),
          where("patientId", "==", patientId),
          where("practiceId", "==", myPracticeId),
          orderBy("createdAt", "desc"),
          limit(100)
        );
        setMode("practiceScoped");
      } else {
        // ✅ Fallback until you migrate users to include practiceId
        qBase = query(
          collection(db, "encounters"),
          where("patientId", "==", patientId),
          where("practitionerId", "==", myUid),
          orderBy("createdAt", "desc"),
          limit(100)
        );
        setMode("authorFallback");
      }

      let snap;
      try {
        snap = await withTimeout(getDocs(qBase), 8000);
      } catch {
        // fallback without orderBy to avoid composite index issues in dev
        if (myPracticeId) {
          snap = await withTimeout(
            getDocs(
              query(
                collection(db, "encounters"),
                where("patientId", "==", patientId),
                where("practiceId", "==", myPracticeId),
                limit(250)
              )
            ),
            8000
          );
        } else {
          snap = await withTimeout(
            getDocs(
              query(
                collection(db, "encounters"),
                where("patientId", "==", patientId),
                where("practitionerId", "==", myUid),
                limit(250)
              )
            ),
            8000
          );
        }
      }

      const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })) as EncounterRecord[];
      setEncounters(items);

      const uids = Array.from(
        new Set(
          items
            .map((e: any) => {
              const uid = safeStr(e?.practitionerId);
              const hasDenorm =
                safeStr(e?.practitionerLabel).length > 0 || safeStr(e?.practitionerDisplayName).length > 0;
              return uid && !hasDenorm ? uid : "";
            })
            .filter(Boolean)
        )
      );

      if (uids.length) {
        const mapped: Record<string, string> = {};
        await Promise.all(
          uids.map(async (uid) => {
            mapped[uid] = await resolveProviderLabel(uid);
          })
        );
        setProviderMap(mapped);
      }
    } catch (e: any) {
      console.error("Failed to load encounters:", e);
      setError(e?.message ?? "Failed to load encounters.");
      setEncounters([]);
      setProviderMap({});
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (canQuery) void load();
    // eslint-disable-next-line
  }, [patientId, refreshToken, canQuery, myPracticeId, myUid]);

  const openEncounter = (encounterId: string) => {
    navigate(`/patients/${patientId}/chart/encounters/${encounterId}`);
  };

  if (!patientId) return <div className="text-sm text-gray-600">Select a patient to view encounters.</div>;
  if (!isClinician) return <EncountersAccessRestricted />;

  if (loading) return <div className="text-sm text-gray-600">Loading encounters…</div>;

  if (error) {
    return (
      <div className="text-sm">
        <div className="text-red-600">{error}</div>
        <button className="mt-2 px-3 py-2 rounded-md border text-sm hover:bg-gray-50" onClick={load}>
          Retry
        </button>
      </div>
    );
  }

  if (encounters.length === 0) {
    return (
      <div className="text-sm text-gray-600">
        No encounters recorded for this patient yet.
        {mode === "authorFallback" ? (
          <div className="text-xs text-amber-700 mt-1">
            Note: you are in “author-only fallback” because your user profile is missing practiceId.
          </div>
        ) : null}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {mode === "authorFallback" ? (
        <div className="text-xs text-amber-700">
          Showing only encounters you authored (fallback). Add users/{`{uid}`}.practiceId to enable shared practice read.
        </div>
      ) : null}

      {encounters.map((enc: any) => {
        const denormLabel = safeStr(enc.practitionerLabel);
        const denormName = safeStr(enc.practitionerDisplayName);
        const uid = safeStr(enc.practitionerId);
        const fallbackResolved = uid ? providerMap[uid] : "";
        const providerName = denormLabel || denormName || fallbackResolved || undefined;

        return (
          <EncounterSummaryCard
            key={enc.id}
            encounter={enc}
            providerName={providerName}
            onOpen={openEncounter}
          />
        );
      })}
    </div>
  );
};

export default EncounterList;