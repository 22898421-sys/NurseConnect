import React from "react";
import { buildJitsiUrl } from "../lib/video";

interface JitsiVideoRoomProps {
  roomName: string;
}

export const JitsiVideoRoom: React.FC<JitsiVideoRoomProps> = ({ roomName }) => {
  const jitsiUrl = buildJitsiUrl(roomName);

  return (
    <iframe
      src={jitsiUrl}
      allow="camera; microphone; fullscreen; display-capture"
      className="w-full h-full"
      title="Video consultation"
    />
  );
};
