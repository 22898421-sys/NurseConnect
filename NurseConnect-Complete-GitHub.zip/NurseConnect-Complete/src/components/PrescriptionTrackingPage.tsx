import React, { useEffect, useMemo, useState } from "react";
import { collection, doc, getDoc, getDocs, limit, orderBy, query } from "firebase/firestore";
import { Link, useParams } from "react-router-dom";
import { db } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { MainLayout } from "./MainLayout";
import { formatToDDMMYYYY } from "../lib/dates";
import { prescriptionTrackingStatusLabel, recordDispenseNotification } from "../lib/prescriptions";
import { logSensitiveAccess } from "../lib/accessAudit";

type PrescriptionRecord = {
  prescriptionId: string;
  patientId: string;
  medication: string;
  strength: string;
  dose: string;
  route: string;
  frequency: string;
  duration: string;
  quantity: string;
  indication: string;
  notes: string;
  originalRepeats: number;
  remainingRepeatsReported: number;
  totalDispenseNotifications: number;
  initialDispenseRecorded: boolean;
  status: string;
  lastDispensedAt?: string | null;
  lastDispensedByPharmacy?: string | null;
  lastVerificationMethod?: string | null;
};

type DispenseRow = {
  id: string;
  pharmacyName: string;
  pharmacistName: string;
  dispenseDate: string;
  quantityDispensed: string;
  dispenseKind: "initial" | "repeat";
  verificationMethod: string;
  notes: string;
  createdAt?: any;
};

function emptyForm() {
  return {
    pharmacyName: "",
    pharmacistName: "",
    dispenseDate: new Date().toISOString().slice(0, 10),
    quantityDispensed: "",
    dispenseKind: "initial" as "initial" | "repeat",
    verificationMethod: "phone_verified" as "phone_verified" | "manual_exception",
    notes: "",
    confirmed: false,
  };
}

const PrescriptionTrackingPage: React.FC = () => {
  const { patientId, prescriptionId } = useParams<{ patientId: string; prescriptionId: string }>();
  const { user, currentUserData, normalizedRole } = useAuth() as any;
  const [patientName, setPatientName] = useState("Patient");
  const [record, setRecord] = useState<PrescriptionRecord | null>(null);
  const [dispenses, setDispenses] = useState<DispenseRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm());

  useEffect(() => {
    if (!patientId || !prescriptionId) {
      setError("Missing patient or prescription ID.");
      setLoading(false);
      return;
    }

    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const [patientSnap, prescriptionSnap, dispenseSnap] = await Promise.all([
          getDoc(doc(db, "patients", patientId)),
          getDoc(doc(db, "prescriptions", prescriptionId)),
          getDocs(query(collection(db, "prescriptions", prescriptionId, "dispenses"), orderBy("createdAt", "desc"), limit(50))),
        ]);

        if (!prescriptionSnap.exists()) {
          throw new Error("Prescription tracking record not found.");
        }

        if (!cancelled) {
          setPatientName(String(patientSnap.data()?.fullName || "Patient"));
          setRecord(prescriptionSnap.data() as PrescriptionRecord);
          setDispenses(dispenseSnap.docs.map((item) => ({ id: item.id, ...(item.data() as any) })));
          setForm((current) => ({
            ...current,
            dispenseKind: (prescriptionSnap.data() as PrescriptionRecord).initialDispenseRecorded ? "repeat" : "initial",
          }));
          if (user?.uid) {
            void logSensitiveAccess({
              actorUid: user.uid,
              role: normalizedRole,
              action: "read_patient_chart",
              resourceType: "prescription_tracking",
              resourceId: prescriptionId,
              patientId,
              practiceId: currentUserData?.practiceId || null,
            });
          }
        }
      } catch (e: any) {
        if (!cancelled) setError(e?.message || "Failed to load prescription tracking.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [currentUserData?.practiceId, normalizedRole, patientId, prescriptionId, user?.uid]);

  const canSubmit = useMemo(() => {
    return !!(
      form.pharmacyName.trim() &&
      form.pharmacistName.trim() &&
      form.dispenseDate.trim() &&
      form.quantityDispensed.trim() &&
      form.confirmed
    );
  }, [form]);

  const save = async () => {
    if (!patientId || !prescriptionId || !user?.uid || !canSubmit) return;
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      await recordDispenseNotification({
        prescriptionId,
        patientId,
        clinicianUid: user.uid,
        pharmacyName: form.pharmacyName,
        pharmacistName: form.pharmacistName,
        dispenseDate: form.dispenseDate,
        quantityDispensed: form.quantityDispensed,
        dispenseKind: form.dispenseKind,
        verificationMethod: form.verificationMethod,
        notes: form.notes,
      });
      setMessage("Dispense notification recorded.");
      setForm(emptyForm());

      const [prescriptionSnap, dispenseSnap] = await Promise.all([
        getDoc(doc(db, "prescriptions", prescriptionId)),
        getDocs(query(collection(db, "prescriptions", prescriptionId, "dispenses"), orderBy("createdAt", "desc"), limit(50))),
      ]);
      setRecord(prescriptionSnap.exists() ? (prescriptionSnap.data() as PrescriptionRecord) : null);
      setDispenses(dispenseSnap.docs.map((item) => ({ id: item.id, ...(item.data() as any) })));
      setForm((current) => ({
        ...emptyForm(),
        dispenseKind: prescriptionSnap.exists() && (prescriptionSnap.data() as PrescriptionRecord).initialDispenseRecorded ? "repeat" : "initial",
      }));
    } catch (e: any) {
      setError(e?.message || "Failed to record dispense notification.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <MainLayout>
      <div className="mx-auto max-w-5xl space-y-4 px-4 py-6">
        <div>
          <div className="text-sm text-gray-600">Clinic-side dispense notifications and reported repeats.</div>
          <div className="text-2xl font-semibold text-gray-900">Prescription Tracking</div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm text-gray-600">Patient</div>
            <div className="text-xl font-semibold text-gray-900">{patientName}</div>
          </div>
          <div className="flex items-center gap-2">
            {patientId ? (
              <Link to={`/patients/${patientId}/chart?tab=escripts`} className="rounded-md border px-3 py-2 text-sm hover:bg-gray-50">
                Back to eScripts
              </Link>
            ) : null}
            {patientId && prescriptionId ? (
              <Link to={`/patients/${patientId}/documents/${prescriptionId}/print`} className="rounded-md border px-3 py-2 text-sm hover:bg-gray-50">
                View patient copy
              </Link>
            ) : null}
          </div>
        </div>

        {loading ? <div className="text-sm text-gray-600">Loading...</div> : null}
        {error ? <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">{error}</div> : null}
        {message ? <div className="rounded-md border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-800">{message}</div> : null}

        {record ? (
          <>
            <div className="grid gap-4 md:grid-cols-[1.15fr_0.85fr]">
              <div className="rounded-xl border bg-white p-4">
                <div className="text-sm font-semibold text-gray-900">Prescription register</div>
                <div className="mt-3 grid gap-2 text-sm text-gray-800 md:grid-cols-2">
                  <div><span className="font-medium">Prescription ID:</span> {record.prescriptionId}</div>
                  <div><span className="font-medium">Status:</span> {prescriptionTrackingStatusLabel(record.status)}</div>
                  <div><span className="font-medium">Medicine:</span> {record.medication}</div>
                  <div><span className="font-medium">Strength:</span> {record.strength || "—"}</div>
                  <div><span className="font-medium">Dose:</span> {record.dose || "—"}</div>
                  <div><span className="font-medium">Route:</span> {record.route || "—"}</div>
                  <div><span className="font-medium">Frequency:</span> {record.frequency || "—"}</div>
                  <div><span className="font-medium">Duration:</span> {record.duration || "—"}</div>
                  <div><span className="font-medium">Quantity:</span> {record.quantity || "—"}</div>
                  <div><span className="font-medium">Indication:</span> {record.indication || "—"}</div>
                </div>
                {record.notes ? (
                  <div className="mt-3 rounded-md border bg-gray-50 px-3 py-2 text-sm text-gray-700">{record.notes}</div>
                ) : null}
              </div>

              <div className="rounded-xl border bg-white p-4">
                <div className="text-sm font-semibold text-gray-900">Reported dispensing status</div>
                <div className="mt-3 space-y-2 text-sm text-gray-800">
                  <div><span className="font-medium">Original repeats:</span> {record.originalRepeats}</div>
                  <div><span className="font-medium">Reported remaining repeats:</span> {record.remainingRepeatsReported}</div>
                  <div><span className="font-medium">Initial dispense recorded:</span> {record.initialDispenseRecorded ? "Yes" : "No"}</div>
                  <div><span className="font-medium">Notifications received:</span> {record.totalDispenseNotifications}</div>
                  <div><span className="font-medium">Last dispense date:</span> {record.lastDispensedAt ? formatToDDMMYYYY(record.lastDispensedAt) : "—"}</div>
                  <div><span className="font-medium">Last pharmacy:</span> {record.lastDispensedByPharmacy || "—"}</div>
                  <div><span className="font-medium">Last verification mode:</span> {record.lastVerificationMethod || "—"}</div>
                </div>
                <div className="mt-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
                  Remaining repeats here reflect dispense notifications reported back to this clinic only. This is not a national live eScript register.
                </div>
              </div>
            </div>

            <div className="rounded-xl border bg-white p-4">
              <div className="text-sm font-semibold text-gray-900">Record a pharmacy notification</div>
              <div className="mt-1 text-xs text-gray-600">
                Use this after the pharmacist has contacted the prescriber or clinic and the dispense has been verified.
              </div>
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <label className="text-sm">
                  <span className="mb-1 block text-xs text-gray-600">Pharmacy name</span>
                  <input className="w-full rounded-md border px-3 py-2" value={form.pharmacyName} onChange={(e) => setForm((p) => ({ ...p, pharmacyName: e.target.value }))} />
                </label>
                <label className="text-sm">
                  <span className="mb-1 block text-xs text-gray-600">Pharmacist name</span>
                  <input className="w-full rounded-md border px-3 py-2" value={form.pharmacistName} onChange={(e) => setForm((p) => ({ ...p, pharmacistName: e.target.value }))} />
                </label>
                <label className="text-sm">
                  <span className="mb-1 block text-xs text-gray-600">Dispense date</span>
                  <input type="date" className="w-full rounded-md border px-3 py-2" value={form.dispenseDate} onChange={(e) => setForm((p) => ({ ...p, dispenseDate: e.target.value }))} />
                </label>
                <label className="text-sm">
                  <span className="mb-1 block text-xs text-gray-600">Quantity dispensed</span>
                  <input className="w-full rounded-md border px-3 py-2" value={form.quantityDispensed} onChange={(e) => setForm((p) => ({ ...p, quantityDispensed: e.target.value }))} />
                </label>
                <label className="text-sm">
                  <span className="mb-1 block text-xs text-gray-600">Dispense type</span>
                  <select className="w-full rounded-md border px-3 py-2" value={form.dispenseKind} onChange={(e) => setForm((p) => ({ ...p, dispenseKind: e.target.value as "initial" | "repeat" }))}>
                    <option value="initial">Initial dispense</option>
                    <option value="repeat">Repeat dispense</option>
                  </select>
                </label>
                <label className="text-sm">
                  <span className="mb-1 block text-xs text-gray-600">Verification method</span>
                  <select className="w-full rounded-md border px-3 py-2" value={form.verificationMethod} onChange={(e) => setForm((p) => ({ ...p, verificationMethod: e.target.value as "phone_verified" | "manual_exception" }))}>
                    <option value="phone_verified">Phone verified with prescriber / clinic</option>
                    <option value="manual_exception">Manual exception logged</option>
                  </select>
                </label>
                <label className="text-sm md:col-span-2">
                  <span className="mb-1 block text-xs text-gray-600">Notes</span>
                  <textarea className="min-h-[88px] w-full rounded-md border px-3 py-2" value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} />
                </label>
              </div>

              <label className="mt-4 flex items-start gap-2 rounded-md border border-teal-200 bg-teal-50 px-3 py-2 text-sm text-teal-900">
                <input type="checkbox" className="mt-1" checked={form.confirmed} onChange={(e) => setForm((p) => ({ ...p, confirmed: e.target.checked }))} />
                <span>I confirm that the pharmacy contacted the prescriber or clinic and this dispense was verified before recording it.</span>
              </label>

              <div className="mt-4 flex items-center justify-end">
                <button
                  type="button"
                  onClick={() => void save()}
                  disabled={!canSubmit || saving}
                  className="rounded-md bg-teal-600 px-4 py-2 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {saving ? "Recording..." : "Record dispense notification"}
                </button>
              </div>
            </div>

            <div className="rounded-xl border bg-white p-4">
              <div className="text-sm font-semibold text-gray-900">Notification history</div>
              {dispenses.length === 0 ? (
                <div className="mt-3 text-sm text-gray-600">No dispense notifications recorded yet.</div>
              ) : (
                <div className="mt-3 space-y-3">
                  {dispenses.map((item) => (
                    <div key={item.id} className="rounded-lg border px-3 py-3 text-sm text-gray-800">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium">{item.pharmacyName}</span>
                        <span className="rounded-full border px-2 py-0.5 text-[11px]">{item.dispenseKind === "repeat" ? "Repeat dispense" : "Initial dispense"}</span>
                        <span className="rounded-full border px-2 py-0.5 text-[11px]">{formatToDDMMYYYY(item.dispenseDate)}</span>
                      </div>
                      <div className="mt-2 grid gap-1 md:grid-cols-2">
                        <div><span className="font-medium">Pharmacist:</span> {item.pharmacistName}</div>
                        <div><span className="font-medium">Quantity:</span> {item.quantityDispensed || "—"}</div>
                        <div><span className="font-medium">Verification:</span> {item.verificationMethod}</div>
                        <div><span className="font-medium">Recorded:</span> {item.createdAt?.toDate ? item.createdAt.toDate().toLocaleString() : "—"}</div>
                      </div>
                      {item.notes ? <div className="mt-2 text-gray-700">{item.notes}</div> : null}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        ) : null}
      </div>
    </MainLayout>
  );
};

export default PrescriptionTrackingPage;
