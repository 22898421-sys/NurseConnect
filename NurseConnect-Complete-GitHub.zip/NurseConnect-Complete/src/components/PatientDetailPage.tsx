// src/components/PatientDetailPage.tsx
import React, { useEffect, useMemo, useState } from "react";
import { collection, doc, getDoc, getDocs, orderBy, query, updateDoc, where, limit } from "firebase/firestore";
import { useParams, Link } from "react-router-dom";
import { db } from "../firebaseConfig";
import { Appointment, Patient } from "../models/emr";
import { formatToDDMMYYYY } from "../lib/dates";
import { MainLayout } from "./MainLayout";
import { useAuth } from "../contexts/AuthContext";
import { logSensitiveAccess } from "../lib/accessAudit";

type PrimaryIdType = "MEDICARE" | "DVA" | "PASSPORT" | "OTHER";

function formatAustralianAddress(patient: Patient | null): string {
  if (!patient) return "Not recorded";
  const parts = [
    patient.addressLine1,
    patient.addressLine2,
    [patient.suburb, patient.state, patient.postcode].filter(Boolean).join(" "),
    patient.country || (patient.addressLine1 || patient.suburb || patient.state || patient.postcode ? "Australia" : ""),
  ]
    .map((value) => String(value || "").trim())
    .filter(Boolean);
  return parts.length ? parts.join(", ") : String(patient.address || "").trim() || "Not recorded";
}

function toDateMaybe(t: any): Date | null {
  try {
    if (!t) return null;
    if (typeof t?.toDate === "function") return t.toDate();
    if (typeof t?.seconds === "number") return new Date(t.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

export const PatientDetailPage: React.FC = () => {
  const { user, normalizedRole, currentUserData } = useAuth() as any;

  const canUse = normalizedRole === "clinician";
  const canEditIdentifiers = false;
  const canEditDemographics = true;

  const { patientId } = useParams<{ patientId: string }>();

  const [patient, setPatient] = useState<Patient | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Identifier editor state
  const [urNumber, setUrNumber] = useState("");
  const [pidType, setPidType] = useState<PrimaryIdType>("MEDICARE");
  const [pidCountry, setPidCountry] = useState("");
  const [pidValue, setPidValue] = useState("");

  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);
  const [savingDemographics, setSavingDemographics] = useState(false);
  const [demographicsMsg, setDemographicsMsg] = useState<string | null>(null);

  const [nextOfKinName, setNextOfKinName] = useState("");
  const [nextOfKinRelationship, setNextOfKinRelationship] = useState("");
  const [nextOfKinPhone, setNextOfKinPhone] = useState("");
  const [emergencyContactName, setEmergencyContactName] = useState("");
  const [emergencyContactRelationship, setEmergencyContactRelationship] = useState("");
  const [emergencyContactPhone, setEmergencyContactPhone] = useState("");
  const [poaName, setPoaName] = useState("");
  const [poaPhone, setPoaPhone] = useState("");
  const [poaEmail, setPoaEmail] = useState("");

  const identifiersDirty = useMemo(() => {
    const p: any = patient || {};
    const curPid = (p.primaryId || {}) as any;
    const curType = (curPid.type || "").toString();
    const curCountry = (curPid.country || "").toString();
    const curValue = (curPid.value || "").toString();

    // NOTE: UR is intentionally immutable and not part of dirty detection.
    return curType !== pidType || curCountry !== pidCountry || curValue !== pidValue;
  }, [patient, pidType, pidCountry, pidValue]);

  const demographicsDirty = useMemo(() => {
    const p: any = patient || {};
    return (
      (p.nextOfKinName || "") !== nextOfKinName ||
      (p.nextOfKinRelationship || "") !== nextOfKinRelationship ||
      (p.nextOfKinPhone || "") !== nextOfKinPhone ||
      (p.emergencyContactName || "") !== emergencyContactName ||
      (p.emergencyContactRelationship || "") !== emergencyContactRelationship ||
      (p.emergencyContactPhone || "") !== emergencyContactPhone ||
      (p.powerOfAttorneyName || "") !== poaName ||
      (p.powerOfAttorneyPhone || "") !== poaPhone ||
      (p.powerOfAttorneyEmail || "") !== poaEmail
    );
  }, [
    patient,
    nextOfKinName,
    nextOfKinRelationship,
    nextOfKinPhone,
    emergencyContactName,
    emergencyContactRelationship,
    emergencyContactPhone,
    poaName,
    poaPhone,
    poaEmail,
  ]);

  useEffect(() => {
    if (!canUse) {
      setLoading(false);
      return;
    }

    if (!patientId) {
      setError("Missing patient ID.");
      setLoading(false);
      return;
    }

    const loadData = async () => {
      setError(null);
      setSaveMsg(null);
      setLoading(true);
      try {
        // Patient
        const patientRef = doc(db, "patients", patientId);
        const patientSnap = await getDoc(patientRef);

        if (!patientSnap.exists()) {
          setError("Client not found.");
          setLoading(false);
          return;
        }

        const patientData = patientSnap.data() as any;
        const p: any = { id: patientSnap.id, ...(patientData as Omit<Patient, "id">) };
        setPatient(p);

        if (user?.uid) {
          void logSensitiveAccess({
            actorUid: user.uid,
            role: normalizedRole,
            action: "read_patient_chart",
            resourceType: "patient_detail",
            resourceId: patientId,
            patientId,
            practiceId: currentUserData?.practiceId || null,
          });
        }

        // Seed identifier editor
        setUrNumber((p.urNumber || "").toString());
        setPidType(((p.primaryId?.type || "MEDICARE") as any) as PrimaryIdType);
        setPidCountry((p.primaryId?.country || "").toString());
        setPidValue((p.primaryId?.value || "").toString());
        setNextOfKinName((p.nextOfKinName || "").toString());
        setNextOfKinRelationship((p.nextOfKinRelationship || "").toString());
        setNextOfKinPhone((p.nextOfKinPhone || "").toString());
        setEmergencyContactName((p.emergencyContactName || "").toString());
        setEmergencyContactRelationship((p.emergencyContactRelationship || "").toString());
        setEmergencyContactPhone((p.emergencyContactPhone || "").toString());
        setPoaName((p.powerOfAttorneyName || "").toString());
        setPoaPhone((p.powerOfAttorneyPhone || "").toString());
        setPoaEmail((p.powerOfAttorneyEmail || "").toString());

        // Appointments for patient:
        // - Admins can read all appointments for the patient.
        // - Clinicians should only read appointments where clinicianId == current clinician
        //   (prevents permission-denied when other clinicians have appointments with the patient).
        const apptQuery =
          normalizedRole === "clinician" && user?.uid
            ? query(
                collection(db, "appointments"),
                where("patientId", "==", patientId),
                where("clinicianId", "==", user.uid),
                orderBy("scheduledAt", "desc"),
                limit(200)
              )
            : query(
                collection(db, "appointments"),
                where("patientId", "==", patientId),
                orderBy("scheduledAt", "desc"),
                limit(200)
              );

        const apptSnap = await getDocs(apptQuery);
        const appts: Appointment[] = apptSnap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
        setAppointments(appts);
      } catch (err: any) {
        console.error("Error loading patient detail:", err);
        setError(err?.message ?? "Failed to load client record.");
      } finally {
        setLoading(false);
      }
    };

    void loadData();
  }, [patientId, canUse, currentUserData?.practiceId, normalizedRole, user?.uid]);

  const saveIdentifiers = async () => {
    if (!canEditIdentifiers) return;
    if (!patientId) return;

    setSaving(true);
    setSaveMsg(null);
    setError(null);

    try {
      const ref = doc(db, "patients", patientId);

      // IMPORTANT: UR is intentionally NOT written here (immutable once allocated).
      await updateDoc(ref, {
        primaryId: {
          type: pidType,
          country: pidCountry.trim() || "",
          value: pidValue.trim() || "",
        },
        updatedAt: new Date(),
      });

      setSaveMsg("Saved.");
      // Update local patient state to reflect changes without reloading (UR unchanged)
      setPatient((prev: any) =>
        prev
          ? {
              ...prev,
              primaryId: { type: pidType, country: pidCountry.trim() || "", value: pidValue.trim() || "" },
            }
          : prev
      );
    } catch (e: any) {
      console.error(e);
      setError(e?.message ?? "Failed to save identifiers.");
    } finally {
      setSaving(false);
    }
  };

  const saveDemographics = async () => {
    if (!canEditDemographics || !patientId) return;
    setSavingDemographics(true);
    setDemographicsMsg(null);
    setError(null);
    try {
      const ref = doc(db, "patients", patientId);
      await updateDoc(ref, {
        nextOfKinName: nextOfKinName.trim() || "",
        nextOfKinRelationship: nextOfKinRelationship.trim() || "",
        nextOfKinPhone: nextOfKinPhone.trim() || "",
        emergencyContactName: emergencyContactName.trim() || "",
        emergencyContactRelationship: emergencyContactRelationship.trim() || "",
        emergencyContactPhone: emergencyContactPhone.trim() || "",
        powerOfAttorneyName: poaName.trim() || "",
        powerOfAttorneyPhone: poaPhone.trim() || "",
        powerOfAttorneyEmail: poaEmail.trim() || "",
        updatedAt: new Date(),
      });
      setPatient((prev: any) =>
        prev
          ? {
              ...prev,
              nextOfKinName: nextOfKinName.trim() || "",
              nextOfKinRelationship: nextOfKinRelationship.trim() || "",
              nextOfKinPhone: nextOfKinPhone.trim() || "",
              emergencyContactName: emergencyContactName.trim() || "",
              emergencyContactRelationship: emergencyContactRelationship.trim() || "",
              emergencyContactPhone: emergencyContactPhone.trim() || "",
              powerOfAttorneyName: poaName.trim() || "",
              powerOfAttorneyPhone: poaPhone.trim() || "",
              powerOfAttorneyEmail: poaEmail.trim() || "",
            }
          : prev
      );
      setDemographicsMsg("Demographics contacts saved.");
    } catch (e: any) {
      console.error(e);
      setError(e?.message ?? "Failed to save demographics contacts.");
    } finally {
      setSavingDemographics(false);
    }
  };

  return (
    <MainLayout>
      {!canUse ? (
        <div className="p-4 text-sm text-red-600">Access denied.</div>
      ) : loading ? (
        <div className="p-4">Loading client record…</div>
      ) : error ? (
        <div className="p-4 text-red-600">
          {error}
          <div className="mt-2">
            <Link to="/patients" className="text-blue-600 hover:underline">
              Back to clients
            </Link>
          </div>
        </div>
      ) : !patient ? (
        <div className="p-4">
          Client not found.
          <div className="mt-2">
            <Link to="/patients" className="text-blue-600 hover:underline">
              Back to clients
            </Link>
          </div>
        </div>
      ) : (
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold">{(patient as any).fullName}</h1>
              <p className="text-sm text-gray-600">
                {(patient as any).email ? <span>{(patient as any).email}</span> : null}
                {(patient as any).email && (patient as any).phone ? <span> · </span> : null}
                {(patient as any).phone ? <span>{(patient as any).phone}</span> : null}
              </p>
            </div>

          </div>

          <div className="border rounded-xl p-4 text-sm space-y-1 bg-white">
            <div>
              <span className="font-medium">DOB:</span>{" "}
              {(patient as any).dateOfBirth ? formatToDDMMYYYY((patient as any).dateOfBirth) : "Not recorded"}
            </div>
            <div>
              <span className="font-medium">Sex:</span> {(patient as any).sex ?? "Not recorded"}
            </div>
            <div>
              <span className="font-medium">Address:</span> {formatAustralianAddress(patient)}
            </div>
            <div>
              <span className="font-medium">Medicare:</span>{" "}
              {(patient as any).medicareCardNumber
                ? `${(patient as any).medicareCardNumber}${(patient as any).medicareReferenceNumber ? ` / ref ${(patient as any).medicareReferenceNumber}` : ""}${(patient as any).medicareExpiry ? ` · exp ${(patient as any).medicareExpiry}` : ""}`
                : "Not recorded"}
            </div>
            <div>
              <span className="font-medium">Billing pathway:</span>{" "}
              {(patient as any).billingType ? String((patient as any).billingType).replace(/_/g, " ") : "Not recorded"}
              {(patient as any).privateHealthFund ? ` · ${(patient as any).privateHealthFund}` : ""}
            </div>
          </div>

          <div className="border rounded-xl p-4 bg-white space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-base font-semibold">Care Contacts</div>
                <div className="text-xs text-gray-600">
                  Next of kin, emergency contact, and power of attorney details.
                </div>
              </div>
              {demographicsMsg ? <div className="text-xs text-gray-700">{demographicsMsg}</div> : null}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-gray-600 mb-1">Next of kin name</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={nextOfKinName} onChange={(e) => setNextOfKinName(e.target.value)} disabled={!canEditDemographics} placeholder="Name" />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Next of kin relationship</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={nextOfKinRelationship} onChange={(e) => setNextOfKinRelationship(e.target.value)} disabled={!canEditDemographics} placeholder="Relationship" />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Next of kin phone</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={nextOfKinPhone} onChange={(e) => setNextOfKinPhone(e.target.value)} disabled={!canEditDemographics} placeholder="+61..." />
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Emergency contact name</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={emergencyContactName} onChange={(e) => setEmergencyContactName(e.target.value)} disabled={!canEditDemographics} placeholder="Name" />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Emergency relationship</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={emergencyContactRelationship} onChange={(e) => setEmergencyContactRelationship(e.target.value)} disabled={!canEditDemographics} placeholder="Relationship" />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Emergency phone</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={emergencyContactPhone} onChange={(e) => setEmergencyContactPhone(e.target.value)} disabled={!canEditDemographics} placeholder="+61..." />
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Power of attorney name</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={poaName} onChange={(e) => setPoaName(e.target.value)} disabled={!canEditDemographics} placeholder="Name" />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Power of attorney phone</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={poaPhone} onChange={(e) => setPoaPhone(e.target.value)} disabled={!canEditDemographics} placeholder="+61..." />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Power of attorney email</label>
                <input className="w-full border rounded px-3 py-2 text-sm" value={poaEmail} onChange={(e) => setPoaEmail(e.target.value)} disabled={!canEditDemographics} placeholder="contact@example.com" />
              </div>
            </div>

            {canEditDemographics ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={saveDemographics}
                  disabled={savingDemographics || !demographicsDirty}
                  className="px-4 py-2 rounded bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-50"
                >
                  {savingDemographics ? "Saving…" : "Save contacts"}
                </button>
                {!demographicsDirty && <span className="text-xs text-gray-500">No changes</span>}
              </div>
            ) : (
              <div className="text-xs text-gray-500">Contacts are read-only for nurses.</div>
            )}
          </div>

          <div className="border rounded-xl p-4 bg-white space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-base font-semibold">Identifiers</div>
                <div className="text-xs text-gray-600">Staff-maintained identifiers for Australian patient registration.</div>
              </div>

              {saveMsg && <div className="text-xs text-gray-700">{saveMsg}</div>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-gray-600 mb-1">UR No.</label>
                {/* UR is display-only (immutable once allocated) */}
                <div className="w-full border rounded px-3 py-2 text-sm font-mono bg-gray-50">
                  {urNumber || "—"}
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Primary ID Type</label>
                <select
                  className="w-full border rounded px-3 py-2 text-sm"
                  value={pidType}
                  onChange={(e) => setPidType(e.target.value as PrimaryIdType)}
                  disabled={!canEditIdentifiers}
                >
                  <option value="MEDICARE">MEDICARE</option>
                  <option value="DVA">DVA</option>
                  <option value="PASSPORT">PASSPORT</option>
                  <option value="OTHER">OTHER</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Country (optional)</label>
                <input
                  className="w-full border rounded px-3 py-2 text-sm"
                  value={pidCountry}
                  onChange={(e) => setPidCountry(e.target.value)}
                  disabled={!canEditIdentifiers}
                  placeholder="e.g. AU"
                />
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Primary ID Value</label>
                <input
                  className="w-full border rounded px-3 py-2 text-sm"
                  value={pidValue}
                  onChange={(e) => setPidValue(e.target.value)}
                  disabled={!canEditIdentifiers}
                  placeholder="Enter as printed"
                />
              </div>
            </div>

            {canEditIdentifiers ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={saveIdentifiers}
                  disabled={saving || !identifiersDirty}
                  className="px-4 py-2 rounded bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-50"
                >
                  {saving ? "Saving…" : "Save identifiers"}
                </button>
                {!identifiersDirty && <span className="text-xs text-gray-500">No changes</span>}
              </div>
            ) : (
              <div className="text-xs text-gray-500">Identifiers are read-only for nurses.</div>
            )}
          </div>

          <div className="space-y-2">
            <h2 className="text-lg font-semibold">Appointment history</h2>

            {appointments.length === 0 ? (
              <div className="text-sm text-gray-600">No appointments recorded for this patient yet.</div>
            ) : (
              <div className="space-y-2">
                {appointments.map((appt) => {
                  const scheduledDate = toDateMaybe((appt as any).scheduledAt);
                  return (
                    <div key={appt.id} className="border rounded-xl p-4 text-sm bg-white">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                        <div>
                          <div className="font-medium">{scheduledDate ? scheduledDate.toLocaleString() : "No date"}</div>
                          <div className="text-xs text-gray-600 mt-1">
                            <span className="uppercase tracking-wide">{(appt as any).status}</span>
                            {(appt as any).mode ? <span className="ml-2">Mode: {(appt as any).mode}</span> : null}
                            {(appt as any).clinicianName ? (
                              <span className="ml-2">Nurse: {(appt as any).clinicianName}</span>
                            ) : null}
                          </div>
                          {(appt as any).reason ? (
                            <div className="text-xs text-gray-600 mt-1">Reason: {(appt as any).reason}</div>
                          ) : null}
                          {/* Clinician-only consultation notes are stored privately and are never shown in the patient chart. */}
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {(appt as any).mode === "video" ? (
                            <Link
                              to={`/call/${appt.id}`}
                              className="px-3 py-2 rounded bg-[#1F9A92] text-white text-xs hover:opacity-95"
                            >
                              Join telehealth
                            </Link>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </MainLayout>
  );
};

export default PatientDetailPage;
