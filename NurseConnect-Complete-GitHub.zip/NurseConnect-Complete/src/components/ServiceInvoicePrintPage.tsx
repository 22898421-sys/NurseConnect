import React, { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { Link, useParams } from "react-router-dom";
import { db } from "../firebaseConfig";
import { formatMoney } from "../lib/billing";
import { downloadInvoicePdf } from "../lib/billingPdf";
import {
  evidencePackPrintPath,
  formatInvoiceStatusLabel,
  formatTaxTreatmentLabel,
  ServiceInvoiceRecord,
} from "../lib/billingFacilitation";

const ServiceInvoicePrintPage: React.FC = () => {
  const { invoiceId } = useParams<{ invoiceId: string }>();
  const [record, setRecord] = useState<ServiceInvoiceRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const load = async () => {
      if (!invoiceId) return;
      const snap = await getDoc(doc(db, "serviceInvoices", invoiceId));
      if (!active) return;
      setRecord(snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as ServiceInvoiceRecord) : null);
      setLoading(false);
    };
    void load();
    return () => {
      active = false;
    };
  }, [invoiceId]);

  if (loading) return <div className="p-6 text-sm text-gray-600">Loading invoice...</div>;
  if (!record) return <div className="p-6 text-sm text-rose-600">Invoice not found.</div>;

  return (
    <div className="mx-auto max-w-4xl p-6 space-y-6">
      <div className="flex items-center justify-between gap-3 print:hidden">
        <Link to="/billing" className="btn-secondary">
          Back to billing
        </Link>
        <div className="flex gap-2">
          <Link to={evidencePackPrintPath(record.id)} className="btn-secondary">
            Evidence pack
          </Link>
          <button className="btn-secondary" onClick={() => downloadInvoicePdf(record)}>
            Download PDF
          </button>
          <button className="btn-primary" onClick={() => window.print()}>
            Print / Save PDF
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-ink-200 bg-white p-8 shadow-soft">
        <div className="flex items-start justify-between gap-6">
          <div>
            <h1 className="text-3xl font-semibold text-ink-900">Invoice</h1>
            <div className="mt-2 text-sm text-ink-600">{record.invoiceNumber}</div>
          </div>
          <div className="text-right text-sm text-ink-700">
            <div className="font-semibold">{record.nurseSnapshot.businessName || record.nurseSnapshot.displayName}</div>
            <div>{record.nurseSnapshot.billingAddress || "Billing address not recorded"}</div>
            <div>{record.nurseSnapshot.billingEmail || "Billing email not recorded"}</div>
            <div>{record.nurseSnapshot.billingPhone || "Billing phone not recorded"}</div>
            <div>ABN: {record.nurseSnapshot.abn || "Not recorded"}</div>
            <div>AHPRA: {record.nurseSnapshot.ahpraRegistrationNumber || "Not recorded"}</div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div>
            <div className="text-xs uppercase tracking-wide text-ink-500">Client</div>
            <div className="mt-1 font-semibold text-ink-900">{record.patientName}</div>
            <div className="mt-1 text-ink-700">Funding pathway: {record.clientFundingSnapshot.pathwayLabel}</div>
            <div className="text-ink-700">Client funding record: {record.clientFundingSnapshot.billingType || "Not recorded"}</div>
            <div className="text-ink-700">Bill to: {record.clientFundingSnapshot.nominatedPayerName || record.patientName}</div>
            {record.clientFundingSnapshot.nominatedPayerEmail ? (
              <div className="text-ink-700">Recipient email: {record.clientFundingSnapshot.nominatedPayerEmail}</div>
            ) : null}
          </div>
          <div>
            <div className="text-xs uppercase tracking-wide text-ink-500">Invoice details</div>
            <div className="mt-1 text-ink-700">Invoice date: {record.invoiceDate || "Not recorded"}</div>
            <div className="text-ink-700">Due date: {record.dueDate || "Not recorded"}</div>
            <div className="mt-1 text-ink-700">Service date: {record.serviceDate}</div>
            <div className="text-ink-700">Start time: {record.serviceStartTime || "Not recorded"}</div>
            <div className="text-ink-700">Duration: {record.durationMinutes} minutes</div>
            <div className="text-ink-700">Status: {formatInvoiceStatusLabel(record.status)}</div>
            <div className="text-ink-700">Tax treatment: {formatTaxTreatmentLabel(record.taxTreatment)}</div>
          </div>
        </div>

        <div className="mt-8 overflow-hidden rounded-2xl border border-ink-200">
          <table className="w-full text-sm">
            <thead className="bg-sand-100">
              <tr className="text-left">
                <th className="px-4 py-3 font-medium text-ink-700">Service</th>
                <th className="px-4 py-3 font-medium text-ink-700">Category</th>
                <th className="px-4 py-3 font-medium text-ink-700">Qty</th>
                <th className="px-4 py-3 font-medium text-ink-700">Unit fee</th>
                <th className="px-4 py-3 font-medium text-ink-700">Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="px-4 py-4 align-top">
                  <div className="font-semibold text-ink-900">{record.serviceTitle}</div>
                  <div className="mt-1 text-xs text-ink-500">{record.serviceCode}</div>
                  <div className="mt-2 text-xs text-ink-600">{record.invoiceDescription || record.serviceSummary}</div>
                </td>
                <td className="px-4 py-4 align-top text-ink-700">{record.serviceCategory}</td>
                <td className="px-4 py-4 align-top text-ink-700">
                  {record.quantity} {record.unitLabel}
                </td>
                <td className="px-4 py-4 align-top text-ink-700">{formatMoney(record.unitPriceCents, record.currency)}</td>
                <td className="px-4 py-4 align-top font-semibold text-ink-900">{formatMoney(record.totalCents, record.currency)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-6 rounded-2xl border border-ink-200 bg-sand-100/60 p-4 text-sm text-ink-700">
          <div className="font-semibold text-ink-900">Declaration summary</div>
          <div className="mt-2">{record.evidencePack.declarationSummary}</div>
        </div>

        {record.auditTrail?.length ? (
          <div className="mt-6 rounded-2xl border border-ink-200 bg-white p-4 text-sm text-ink-700">
            <div className="font-semibold text-ink-900">Audit trail</div>
            <div className="mt-3 space-y-2">
              {record.auditTrail.map((entry, index) => (
                <div key={`${entry.at}-${index}`} className="rounded-xl border border-ink-100 px-3 py-2">
                  <div className="font-medium text-ink-900">{entry.note}</div>
                  <div className="text-xs text-ink-500">{new Date(entry.at).toLocaleString()}</div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <div className="mt-8 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          Nurse declaration: the issuing nurse confirms that the billed service was completed, accurately documented, and aligned to their scope of practice. NurseConnectCare only facilitates document preparation and relay on the nurse's instruction. It does not process payments, approve claims, determine eligibility, or hold funds.
        </div>
      </div>
    </div>
  );
};

export default ServiceInvoicePrintPage;
