import React from "react";

export const VideoCall = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-green-700">Video Call</h1>
      <p className="mt-2 text-gray-700">This is the Video Call component.</p>
    </div>
  );
};