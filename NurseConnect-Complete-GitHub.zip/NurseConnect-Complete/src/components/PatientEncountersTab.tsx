// src/components/PatientEncountersTab.tsx
import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import EncounterList from "./encounters/EncounterList";
import NewEncounterDialog from "./encounters/NewEncounterDialog";

type Props = {
  patientId: string;
  canWrite?: boolean;
};

const EncountersAccessRestricted: React.FC = () => {
  return (
    <div className="border rounded-xl bg-white p-4">
      <div className="text-base font-semibold">Clinical encounters are restricted</div>
      <div className="mt-1 text-sm text-gray-700">
        For privacy and medico-legal reasons, patient encounter notes are only accessible to the treating nurse.
      </div>
      <div className="mt-2 text-sm text-gray-700">
        System and clinic administrators do not have routine access to clinical encounters.
      </div>
    </div>
  );
};

export const PatientEncountersTab: React.FC<Props> = ({ patientId, canWrite }) => {
  const navigate = useNavigate();
  const { normalizedRole, user, currentUserData } = useAuth() as any;

  const roleNorm: string = (normalizedRole ?? "").toLowerCase();
  const isClinician = roleNorm === "clinician";
  const canUse = isClinician;

  const effectiveCanWrite = useMemo(() => {
    if (typeof canWrite === "boolean") return canWrite;
    return isClinician;
  }, [canWrite, isClinician]);

  const practitionerId: string = user?.uid ?? "";

  const [dialogOpen, setDialogOpen] = useState(false);
  const [refreshToken, setRefreshToken] = useState(0);

  const headerSubtitle = useMemo(() => {
    if (!patientId) return "Select a patient to view encounters.";
    return "Create/open encounters; SOAP is completed inside the encounter detail view.";
  }, [patientId]);

  if (!canUse) {
    return <div className="p-4 text-sm text-red-600">Access denied.</div>;
  }

  if (!isClinician) {
    return <EncountersAccessRestricted />;
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
        <div>
          <div className="text-lg font-semibold">Encounters</div>
          <div className="text-xs text-gray-600">{headerSubtitle}</div>
        </div>

        <div className="flex items-center gap-2">
          <button
            className="px-3 py-2 rounded-md bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-60"
            onClick={() => setDialogOpen(true)}
            disabled={!patientId || !effectiveCanWrite || !practitionerId}
            title={
              !patientId
                ? "Select a patient first"
                : !effectiveCanWrite
                ? "You do not have permission to create encounters"
                : !practitionerId
                ? "You must be signed in to create encounters"
                : "Create a new encounter"
            }
          >
            New encounter
          </button>
        </div>
      </div>

      <EncounterList patientId={patientId} refreshToken={refreshToken} />

      <NewEncounterDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        patientId={patientId}
        practitionerId={practitionerId}
        practiceId={currentUserData?.practiceId || null}
        onCreated={(encounterId) => {
          // Refresh list then navigate directly to SOAP entry
          setRefreshToken((v) => v + 1);
          navigate(`/patients/${patientId}/chart/encounters/${encounterId}?edit=1`);
        }}
      />
    </div>
  );
};

export default PatientEncountersTab;
