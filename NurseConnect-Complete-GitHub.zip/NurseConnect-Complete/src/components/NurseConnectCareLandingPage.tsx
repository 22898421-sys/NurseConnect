import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  FiActivity,
  FiArrowRight,
  FiBriefcase,
  FiCheckCircle,
  FiClipboard,
  FiDollarSign,
  FiFileText,
  FiHome,
  FiMenu,
  FiMonitor,
  FiSearch,
  FiShield,
  FiX,
} from "./PublicIcons";
import CareBackgroundVisual from "./CareBackgroundVisual";
import EirenixMark from "./EirenixMark";
import PageMeta from "./PageMeta";
import homeCareVisitImage from "../assets/public-site/home-care-visit.jpeg";
import bloodPressureCheckImage from "../assets/public-site/blood-pressure-check.jpeg";

const careServices = [
  {
    title: "Medication support",
    body: "Medication administration, injections and adherence support.",
    icon: FiActivity,
  },
  {
    title: "Wound and skin care",
    body: "Dressings, wound reviews and skin checks.",
    icon: FiShield,
  },
  {
    title: "Chronic disease management",
    body: "Ongoing monitoring and support for chronic conditions at home.",
    icon: FiCheckCircle,
  },
  {
    title: "Post-hospital care",
    body: "Recovery reviews and short-term support after discharge.",
    icon: FiHome,
  },
];

const trustItems = [
  "NurseConnectCare is a digital connection, workflow and evidence platform.",
  "The platform does not provide nursing care or employ nurses.",
  "Clinical responsibility remains with the independent nurse.",
  "Support at Home approval, care-plan and funding responsibilities stay with the relevant provider, care manager or funder.",
];

const bookingSteps = [
  {
    title: "Describe the care you need",
    body: "Start with service type, location and what support is needed at home.",
  },
  {
    title: "Review nurse options",
    body: "Compare service focus, availability and fit before requesting care.",
  },
  {
    title: "Request care and follow-up",
    body: "Use the client account to request bookings, manage appointments and stay connected.",
  },
];

const accessCards = [
  {
    title: "Find Care",
    body: "Search independent nurse profiles and request care from a client or carer account.",
    cta: "Search nurses",
    to: "/find-care",
    icon: FiSearch,
  },
  {
    title: "Post Request",
    body: "Record provider, care-plan and funding context so suitable nurses can respond.",
    cta: "Provider request",
    to: "/for-organisations/request",
    icon: FiClipboard,
  },
  {
    title: "Nurse Access",
    body: "Create an independent nurse account and move into the secure EIRENIX Care™ workspace.",
    cta: "Register",
    to: "/for-nurses/apply",
    icon: FiBriefcase,
  },
];

const whoWeHelp = [
  "Clients and carers looking for nursing support at home",
  "Registered providers and care managers needing nursing capacity",
  "Independent nurses building visible, self-managed practice workflows",
  "People returning home after hospital care or needing ongoing monitoring",
];

const pathwayWorkflowItems = [
  {
    title: "Service requests",
    body: "Capture need, location, scope and funding context.",
    icon: FiClipboard,
  },
  {
    title: "Care records",
    body: "Keep visit notes and clinical documentation attached to the service trail.",
    icon: FiFileText,
  },
  {
    title: "Telehealth follow-up",
    body: "Support clinically appropriate video or message-based review.",
    icon: FiMonitor,
  },
  {
    title: "Service evidence",
    body: "Hold visit evidence and care outputs for review and reporting.",
    icon: FiCheckCircle,
  },
  {
    title: "Invoice documentation",
    body: "Prepare nurse-owned invoice detail from documented service activity.",
    icon: FiDollarSign,
  },
];

const providerRegistrationItems = [
  {
    title: "Category 5",
    body: "Register for Nursing and transition care before delivering funded nursing services.",
  },
  {
    title: "Category 4",
    body: "Register for Care Management too because Support at Home uses the single-provider model.",
  },
  {
    title: "Provider obligations",
    body: "Clinical governance, care-plan approval and funding responsibilities stay with the provider business.",
  },
];

const platformBoundaryItems = [
  {
    title: "Where the platform helps",
    body: "NurseConnectCare helps keep requests, records, telehealth, evidence and invoice documentation connected.",
  },
  {
    title: "Where responsibility remains",
    body: "NurseConnectCare does not replace AHPRA registration, Commission registration, clinical governance, care-plan approval or funding responsibility.",
  },
];

function SectionEyebrow({ children }: { children: React.ReactNode }) {
  return <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">{children}</p>;
}

export default function NurseConnectCareLandingPage() {
  const year = new Date().getFullYear();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen overflow-x-hidden bg-sand-100 text-ink-900">
      <PageMeta
        title="NurseConnectCare | Care at Home"
        description="NurseConnectCare helps clients, carers and providers request independent nursing support, with secure workflow infrastructure for provider-aware care at home."
      />
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <div className="relative isolate">
        <CareBackgroundVisual />
        <div className="absolute inset-x-0 top-0 -z-10 h-[560px] bg-[radial-gradient(circle_at_top_left,_rgba(155,230,214,0.95),_transparent_38%),radial-gradient(circle_at_top_right,_rgba(14,42,59,0.18),_transparent_34%),linear-gradient(180deg,_#f9f6f1_0%,_#ffffff_72%)]" />
        <div className="absolute inset-x-0 top-0 -z-10 h-[560px] bg-[linear-gradient(rgba(11,31,42,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(11,31,42,0.04)_1px,transparent_1px)] bg-[size:72px_72px] [mask-image:linear-gradient(180deg,rgba(0,0,0,0.95),transparent)]" />

        <header className="sticky top-0 z-50 border-b border-ink-200/70 bg-sand-100/95 backdrop-blur-xl">
          <div className="mx-auto flex min-h-[78px] w-full max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
            <Link to="/" className="flex shrink-0 items-center gap-3">
              <img src="/NurseConnect-logo.png" alt="NurseConnectCare logo" className="h-11 w-11 rounded-2xl object-contain shadow-soft" />
              <div>
                <p className="text-lg font-extrabold leading-none tracking-tight text-ink-900">NurseConnectCare</p>
                <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.18em] text-ink-500">Care at Home</p>
              </div>
            </Link>

            <nav className="hidden items-center gap-5 text-[13px] font-semibold text-ink-700 lg:flex" aria-label="Main public navigation">
              <Link to="/" className="whitespace-nowrap transition hover:text-brand-700">Home</Link>
              <Link to="/services" className="whitespace-nowrap transition hover:text-brand-700">Services</Link>
              <Link to="/about" className="whitespace-nowrap transition hover:text-brand-700">About</Link>
              <Link to="/how-it-works" className="whitespace-nowrap transition hover:text-brand-700">How It Works</Link>
              <Link to="/contact" className="whitespace-nowrap transition hover:text-brand-700">Contact</Link>
            </nav>

            <div className="flex shrink-0 items-center gap-2">
              <button
                type="button"
                aria-expanded={mobileMenuOpen}
                aria-controls="home-mobile-menu"
                aria-label={mobileMenuOpen ? "Close navigation menu" : "Open navigation menu"}
                onClick={() => setMobileMenuOpen((value) => !value)}
                className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-ink-200 bg-white text-ink-900 shadow-soft transition hover:border-brand-500 hover:text-brand-700 lg:hidden"
              >
                {mobileMenuOpen ? <FiX className="h-5 w-5" /> : <FiMenu className="h-5 w-5" />}
              </button>
              <Link
                to="/request-care"
                className="hidden whitespace-nowrap rounded-full bg-brand-700 px-4 py-2.5 text-sm font-bold text-white shadow-soft transition hover:bg-brand-900 sm:inline-flex"
              >
                Request Care
              </Link>
              <Link
                to="/clinician-login?mode=signup"
                className="inline-flex items-center gap-2 whitespace-nowrap rounded-full bg-brand-900 px-4 py-2.5 text-sm font-bold text-white shadow-soft transition hover:bg-ink-700"
              >
                <FiShield className="h-4 w-4" />
                <span className="hidden xl:inline">EIRENIX Care</span>
                <span className="xl:hidden">Clinician</span>
              </Link>
            </div>
          </div>

          {mobileMenuOpen ? (
            <div id="home-mobile-menu" className="mx-auto w-full max-w-7xl px-4 pb-4 sm:px-6 lg:hidden lg:px-8">
              <div className="rounded-[24px] border border-ink-200 bg-white p-4 shadow-lift">
                <nav className="grid gap-1 text-sm font-semibold text-ink-800">
                  <Link to="/" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Home</Link>
                  <Link to="/services" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Services</Link>
                  <Link to="/about" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">About</Link>
                  <Link to="/how-it-works" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">How It Works</Link>
                  <Link to="/contact" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Contact</Link>
                  <div className="my-2 border-t border-ink-200" />
                  <Link to="/request-care" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-brand-50 px-4 py-3 text-brand-900">Request Care</Link>
                  <Link to="/patient-login?mode=signup" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Client / Carer Access</Link>
                  <Link to="/for-organisations/request" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">For Organisations</Link>
                  <Link to="/for-nurses/apply" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">For Nurses</Link>
                  <Link to="/for-nurses/cpd" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Nurses CPD</Link>
                  <a href="#trust" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Trust & Safety</a>
                  <Link to="/clinician-login?mode=signup" onClick={() => setMobileMenuOpen(false)} className="mt-1 rounded-2xl bg-brand-900 px-4 py-3 text-white">EIRENIX Care / Clinician Access</Link>
                </nav>
              </div>
            </div>
          ) : null}
        </header>

        <main id="main-content">
          <section className="mx-auto w-full max-w-7xl px-4 pb-12 pt-2 sm:px-6 lg:px-8 lg:pb-16 lg:pt-6">
            <div className="grid gap-10 lg:grid-cols-[1fr_0.9fr] lg:items-center">
              <div className="max-w-2xl">
                <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-4 py-2 text-sm text-ink-700 shadow-soft backdrop-blur">
                  <FiShield className="h-4 w-4 text-brand-700" />
                  Connector infrastructure for care at home
                </div>

                <h1 className="max-w-3xl text-5xl leading-[1.02] text-ink-900 sm:text-6xl lg:text-[4.25rem]">
                  Connect with <span className="text-brand-700">independent nurses</span> for care at home
                </h1>

                <p className="mt-6 max-w-xl text-lg leading-8 text-ink-700 sm:text-xl">
                  Clients, carers and providers can request home-based nursing support while independent nurses use secure workflow, records and evidence infrastructure to manage services properly.
                </p>

                <p className="mt-4 max-w-xl text-sm leading-7 text-ink-600">
                  NurseConnectCare does not employ nurses or provide care directly. It supports independent nurses, clients, carers and provider-aware workflows for Support at Home aligned nursing, post-hospital recovery, private nursing and clinically appropriate telehealth follow-up.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link to="/request-care" className="inline-flex items-center gap-2 rounded-full bg-brand-700 px-6 py-3 text-sm font-bold text-white shadow-soft transition hover:bg-brand-900">
                    Request Care <FiArrowRight className="h-4 w-4" />
                  </Link>
                  <Link to="/services" className="inline-flex items-center gap-2 rounded-full border border-ink-200 bg-white px-6 py-3 text-sm font-bold text-ink-900 shadow-soft transition hover:border-brand-500">
                    Explore Services
                  </Link>
                </div>
              </div>

              <div className="overflow-hidden rounded-[28px] border border-white/70 bg-white/80 shadow-lift backdrop-blur-sm">
                <img
                  src={homeCareVisitImage}
                  alt="Independent nurse supporting an older client at home"
                  className="h-[420px] w-full object-cover object-center"
                />
              </div>
            </div>
          </section>

          <section className="mx-auto mb-8 w-[calc(100%_-_2rem)] max-w-7xl overflow-hidden rounded-[30px] bg-gradient-to-r from-brand-900 to-brand-700 p-7 text-white shadow-lift sm:p-9">
            <div className="grid gap-7 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
              <div>
                <div className="flex items-center gap-4">
                  <div className="rounded-2xl bg-white p-2 shadow-soft">
                    <img src="/eirenix-care-logo.jpg" alt="EIRENIX Care logo" className="h-12 w-auto object-contain" />
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.22em] text-brand-200">Secure care management platform</p>
                    <h2 className="mt-1 text-3xl font-extrabold text-white">EIRENIX Care</h2>
                  </div>
                </div>
                <p className="mt-5 max-w-3xl text-sm leading-7 text-white/75">
                  EIRENIX Care is the secure clinical and practice-management environment behind NurseConnectCare. Patient and organisation requests can move into EIRENIX Care, where authorised nurses review requests, manage bookings and rosters, maintain patient records, document encounters, support prescribing and billing workflows, and coordinate ongoing care.
                </p>
              </div>
              <div className="flex flex-wrap gap-3 lg:justify-end">
                <Link to="/how-it-works" className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-3 text-sm font-bold text-white">See how it connects</Link>
                <Link to="/clinician-login?mode=signup" className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-bold text-brand-900">
                  <FiShield className="h-4 w-4" /> Clinician Access
                </Link>
              </div>
            </div>
          </section>

          <section className="border-y border-ink-200/70 bg-white/90 py-12 backdrop-blur-sm sm:py-14">
            <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="grid gap-8 lg:grid-cols-[0.86fr_1.14fr] lg:items-start">
                <div className="lg:max-w-xl lg:pt-2">
                  <SectionEyebrow>Support at Home pathway</SectionEyebrow>
                  <h2 className="mt-4 max-w-3xl text-3xl sm:text-4xl">
                    A new pathway for independent nurse-led care
                  </h2>
                  <p className="mt-5 max-w-2xl text-lg leading-8 text-ink-700">
                    Support at Home is creating a clearer pathway for nurse-led businesses to participate in care at
                    home as independent registered providers.
                  </p>
                  <p className="mt-4 max-w-2xl text-sm leading-7 text-ink-600">
                    NurseConnectCare is aimed at independent nurses and nurse-led businesses building their own care-at-home
                    practice infrastructure, not provider organisations replacing systems they already run.
                  </p>

                  <div className="mt-8 grid gap-4">
                    {platformBoundaryItems.map(({ title, body }) => (
                      <article key={title} className="border-l-2 border-brand-500 bg-brand-50/70 p-4">
                        <div className="flex gap-4">
                          <FiShield className="mt-1 h-5 w-5 shrink-0 text-brand-700" />
                          <div className="min-w-0">
                            <h3 className="text-base font-semibold text-ink-900">{title}</h3>
                            <p className="mt-2 text-sm leading-7 text-ink-600">{body}</p>
                          </div>
                        </div>
                      </article>
                    ))}
                  </div>
                </div>

                <article className="overflow-hidden bg-ink-900 text-white shadow-lift">
                  <div className="p-6 sm:p-8">
                    <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">
                      Independent provider route
                    </p>
                    <h3 className="mt-4 text-2xl text-white sm:text-3xl">
                      Operating as the Support at Home registered provider
                    </h3>
                    <p className="mt-4 text-sm leading-7 text-white/75">
                      If a nurse or sole-trader business wants to hold the participant relationship, deliver nursing care
                      and claim Australian Government-funded Support at Home services in its own right, the business must
                      be registered with the Aged Care Quality and Safety Commission.
                    </p>
                    <div className="mt-7 border-t border-white/10 pt-6">
                      <p className="text-sm font-semibold text-white">For nurse-led funded nursing, this means:</p>
                      <div className="mt-5 grid gap-4">
                        {providerRegistrationItems.map(({ title, body }) => (
                          <div key={title} className="flex gap-4 border-t border-white/10 pt-4">
                            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-200/15 text-brand-200">
                              <FiCheckCircle className="h-4 w-4" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-white">{title}</p>
                              <p className="mt-1 text-sm leading-6 text-white/70">{body}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="border-t border-white/10 bg-white/[0.04] px-6 py-5 sm:px-8">
                    <p className="text-sm leading-7 text-white/70">
                      Nurses employed by, or engaged through, an existing registered provider usually work under that
                      provider's participant relationship, service agreement, care management and claiming arrangements.
                    </p>
                  </div>
                </article>
              </div>

              <div className="mt-12 border-t border-ink-200 pt-9">
                <div className="max-w-3xl">
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-brand-700">Connected workflow</p>
                  <h3 className="mt-3 text-2xl text-ink-900 sm:text-3xl">
                    NurseConnectCare keeps the working pieces connected
                  </h3>
                  <p className="mt-3 max-w-2xl text-sm leading-7 text-ink-600">
                    One operational trail for independent nurses, from first request through care documentation and invoice evidence.
                  </p>
                </div>

                <div className="relative mt-8">
                  <div className="absolute left-10 right-10 top-6 hidden h-px bg-brand-200 lg:block" />
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                    {pathwayWorkflowItems.map(({ title, body, icon: Icon }, index) => (
                      <article key={title} className="relative border border-ink-200/80 bg-white p-5 shadow-soft">
                        <div className="flex items-center gap-3">
                          <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-full border border-brand-200 bg-white text-brand-700 shadow-soft">
                            <Icon className="h-5 w-5" />
                          </div>
                          <span className="text-xs font-semibold text-brand-700">
                            {`Step ${String(index + 1).padStart(2, "0")}`}
                          </span>
                        </div>
                        <p className="mt-5 text-base font-semibold text-ink-900">{title}</p>
                        <p className="mt-2 text-sm leading-6 text-ink-600">{body}</p>
                      </article>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-10">
            <div className="grid gap-4 md:grid-cols-3">
              {accessCards.map(({ title, body, cta, to, icon: Icon }) => (
                <article key={title} className="border-t border-ink-200 bg-white/70 p-5 shadow-soft">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-700">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h2 className="mt-4 text-2xl">{title}</h2>
                  <p className="mt-2 min-h-[72px] text-sm leading-6 text-ink-600">{body}</p>
                  <Link
                    to={to}
                    className="mt-5 inline-flex items-center justify-center gap-2 text-sm font-semibold text-brand-700 transition hover:text-ink-900"
                  >
                    {cta}
                    <FiArrowRight className="h-4 w-4" />
                  </Link>
                </article>
              ))}
            </div>
          </section>

          <section className="pb-4">
            <div className="mx-auto w-full max-w-7xl px-4 pb-5 sm:px-6 lg:px-8">
              <div className="grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
                <div className="border-y border-ink-200/80 bg-white/70 p-6 shadow-soft">
                  <SectionEyebrow>Who uses NurseConnectCare</SectionEyebrow>
                  <h2 className="mt-3 text-3xl sm:text-4xl">One platform for care demand, nurse capacity and provider-aware requests.</h2>
                  <div className="mt-6 grid gap-x-6 gap-y-3 md:grid-cols-2">
                    {whoWeHelp.map((item) => (
                      <p key={item} className="border-t border-ink-200 pt-3 text-sm leading-7 text-ink-700">{item}</p>
                    ))}
                  </div>
                </div>
                <div className="overflow-hidden border border-ink-200/80 bg-white/92 shadow-soft">
                  <img
                    src={bloodPressureCheckImage}
                    alt="A home blood pressure check during a nursing visit"
                    className="h-full min-h-[280px] w-full object-cover"
                  />
                </div>
              </div>
            </div>
          </section>

          <section className="border-y border-ink-200/70 bg-white/70 py-14 backdrop-blur-sm">
            <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                <div className="max-w-3xl">
                  <SectionEyebrow>Care at home</SectionEyebrow>
                  <h2 className="mt-4 text-3xl sm:text-4xl">A simpler overview of the care people commonly book.</h2>
                </div>
                <Link to="/find-care" className="text-sm font-medium text-brand-700 transition hover:text-ink-900">
                  View all care options
                </Link>
              </div>

              <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                {careServices.map(({ title, body, icon: Icon }) => (
                  <article key={title} className="border-t border-ink-200 bg-white/75 p-5 shadow-soft">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-50 text-brand-700">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h3 className="mt-4 text-xl">{title}</h3>
                    <p className="mt-2 text-sm leading-7 text-ink-700">{body}</p>
                  </article>
                ))}
              </div>
            </div>
          </section>

          <section className="py-14">
            <div className="mx-auto grid w-full max-w-7xl gap-8 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
              <div>
                <SectionEyebrow>How it works</SectionEyebrow>
                <h2 className="mt-4 text-3xl sm:text-4xl">Request care in three clear steps.</h2>
                <p className="mt-5 text-lg leading-8 text-ink-700">
                  Move from first search to booking and follow-up without unnecessary friction.
                </p>
              </div>
              <div className="grid gap-4">
                {bookingSteps.map((step, index) => (
                  <div key={step.title} className="border-t border-ink-200 bg-white/90 p-5 shadow-soft">
                    <div className="flex gap-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-brand-50 text-sm font-semibold text-brand-700">
                        {index + 1}
                      </div>
                      <div>
                        <p className="text-lg font-semibold text-ink-900">{step.title}</p>
                        <p className="mt-2 text-sm leading-7 text-ink-600">{step.body}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section id="trust" className="bg-ink-900 py-14 text-white">
            <div className="mx-auto grid w-full max-w-7xl gap-8 px-4 sm:px-6 lg:grid-cols-[1fr_0.95fr] lg:px-8">
              <div className="max-w-3xl">
                <SectionEyebrow>Trust and safety</SectionEyebrow>
                <h2 className="mt-4 text-3xl text-white sm:text-4xl">Clear boundaries, less confusion.</h2>
                <p className="mt-5 text-lg leading-8 text-white/75">
                  NurseConnectCare supports the connection and workflow around care. Independent nurses remain responsible for the care they deliver.
                </p>
              </div>

              <div className="grid gap-4">
                {trustItems.map((item) => (
                  <div key={item} className="border-t border-white/10 p-4">
                    <div className="flex gap-3">
                      <FiShield className="mt-1 h-5 w-5 shrink-0 text-brand-200" />
                      <p className="text-sm leading-7 text-white/75">{item}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="pb-16 pt-14">
            <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="overflow-hidden rounded-[36px] border border-ink-200 bg-[linear-gradient(135deg,#0E2A3B_0%,#12546B_48%,#1F9A92_100%)] p-8 text-white shadow-lift sm:p-10">
                <div className="grid gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-end">
                  <div>
                    <SectionEyebrow>Start here</SectionEyebrow>
                    <h2 className="mt-4 text-3xl text-white sm:text-4xl">Choose the path that suits you.</h2>
                    <p className="mt-5 max-w-2xl text-lg leading-8 text-white/80">
                      Clients and carers can explore care options or manage approved bookings. Independent nurses can create an account and move into the secure nurse workspace.
                    </p>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-3 lg:max-w-2xl lg:justify-self-end">
                    <Link
                      to="/request-care"
                      className="inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 py-3 text-sm font-medium text-white transition hover:bg-white/15"
                    >
                      Request Care
                    </Link>
                    <Link
                      to="/for-organisations/request"
                      className="inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 py-3 text-sm font-medium text-white transition hover:bg-white/15"
                    >
                      Provider Request
                    </Link>
                    <Link
                      to="/clinician-login?mode=signup"
                      className="inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 py-3 text-sm font-medium text-white transition hover:bg-white/15"
                    >
                      EIRENIX Care
                    </Link>
                  </div>
                </div>
              </div>

              <footer className="mt-10 flex flex-col gap-6 border-t border-ink-200 pt-8 text-sm text-ink-600 lg:flex-row lg:items-start lg:justify-between">
                <div className="max-w-2xl">
                  <p className="font-semibold text-ink-900">NurseConnectCare</p>
                  <p className="mt-2 leading-7">
                    A connector and infrastructure platform linking care-at-home demand with independent nurses,
                    registered provider workflows and Support at Home aligned evidence.
                  </p>
                  <p className="mt-4 text-xs text-ink-500">{`Copyright © ${year} NurseConnectCare. All rights reserved.`}</p>
                </div>
                <div className="max-w-xl">
                  <div className="leading-7 text-ink-500">
                    NurseConnectCare does not provide nursing services or employ nurses. Clinical responsibility, service
                    approval and funding decisions remain with the relevant nurse, provider, care manager or funder. Nurse
                    login connects to <EirenixMark />, the secure nurse workspace.
                  </div>
                  <p className="mt-3 text-xs leading-6 text-ink-500">
                    Service regions and contacts will expand as the network grows. Do not use NurseConnectCare for emergency care.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
                    <Link to="/privacy" className="text-ink-700 transition hover:text-brand-700">
                      Privacy Policy
                    </Link>
                    <Link to="/terms" className="text-ink-700 transition hover:text-brand-700">
                      Terms of Use
                    </Link>
                    <Link to="/contact" className="text-ink-700 transition hover:text-brand-700">
                      Contact Us
                    </Link>
                  </div>
                </div>
              </footer>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
