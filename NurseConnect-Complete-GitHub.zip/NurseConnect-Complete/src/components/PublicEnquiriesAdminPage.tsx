import React, { useCallback, useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, orderBy, query, updateDoc, doc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { MainLayout } from "./MainLayout";
import { useAuth } from "../contexts/AuthContext";
import { formatOrganisationRole, formatSupportAtHomeCategory } from "../lib/serviceRequests";

type QueueStatus = "new" | "in_review" | "closed";

type ContactEnquiryRow = {
  id: string;
  fullName: string;
  email: string;
  enquiryType: string;
  message: string;
  status: QueueStatus;
  reviewNotes?: string;
  createdAt?: { toDate?: () => Date } | Date | null;
};

type NurseInterestRow = {
  id: string;
  fullName: string;
  email: string;
  primaryRegion: string;
  professionalRole: string;
  nurseType?: string;
  ahpraRegistrationNumber?: string;
  travelRadius?: string;
  visitTypes?: string[];
  fundingModels?: string[];
  serviceFocus: string;
  status: QueueStatus;
  reviewNotes?: string;
  createdAt?: { toDate?: () => Date } | Date | null;
};

type ServiceRequestRow = {
  id: string;
  organisationName: string;
  requesterName: string;
  requesterEmail: string;
  organisationRole?: string;
  registeredProviderName?: string;
  registeredProviderId?: string;
  supportAtHomeCategory?: string;
  clientReference?: string;
  serviceTitle: string;
  suburb: string;
  postcode: string;
  requiredNurseType: string;
  requestType: string;
  status: string;
  responseCount?: number;
  createdAt?: { toDate?: () => Date } | Date | null;
};

function toDateString(value: any) {
  const date =
    value instanceof Date ? value : typeof value?.toDate === "function" ? value.toDate() : null;
  return date ? date.toLocaleString() : "Date unavailable";
}

function statusClasses(status: QueueStatus) {
  if (status === "closed") return "bg-emerald-100 text-emerald-800 border-emerald-200";
  if (status === "in_review") return "bg-amber-100 text-amber-800 border-amber-200";
  return "bg-sky-100 text-sky-800 border-sky-200";
}

const PublicEnquiriesAdminPage: React.FC = () => {
  const { normalizedRole } = useAuth() as any;
  const canUse = normalizedRole === "system_admin";

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [activeQueue, setActiveQueue] = useState<"contact" | "nurses" | "service_requests">("contact");
  const [serviceRequests, setServiceRequests] = useState<ServiceRequestRow[]>([]);
  const [contactEnquiries, setContactEnquiries] = useState<ContactEnquiryRow[]>([]);
  const [nurseInterests, setNurseInterests] = useState<NurseInterestRow[]>([]);
  const [draftNotes, setDraftNotes] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string>("");

  const refreshData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [contactSnap, nurseSnap, serviceSnap] = await Promise.all([
        getDocs(query(collection(db, "publicContactEnquiries"), orderBy("createdAt", "desc"), limit(200))),
        getDocs(query(collection(db, "nurseRegistrationInterests"), orderBy("createdAt", "desc"), limit(200))),
        getDocs(query(collection(db, "serviceRequests"), orderBy("createdAt", "desc"), limit(200))),
      ]);

      setContactEnquiries(
        contactSnap.docs.map((row) => {
          const raw = row.data() as any;
          return {
            id: row.id,
            fullName: String(raw?.fullName || ""),
            email: String(raw?.email || ""),
            enquiryType: String(raw?.enquiryType || ""),
            message: String(raw?.message || ""),
            status: (raw?.status as QueueStatus) || "new",
            reviewNotes: String(raw?.reviewNotes || ""),
            createdAt: raw?.createdAt ?? null,
          };
        })
      );

      setNurseInterests(
        nurseSnap.docs.map((row) => {
          const raw = row.data() as any;
          return {
            id: row.id,
            fullName: String(raw?.fullName || ""),
            email: String(raw?.email || ""),
            primaryRegion: String(raw?.primaryRegion || ""),
            professionalRole: String(raw?.professionalRole || ""),
            nurseType: String(raw?.nurseType || ""),
            ahpraRegistrationNumber: String(raw?.ahpraRegistrationNumber || ""),
            travelRadius: String(raw?.travelRadius || ""),
            visitTypes: Array.isArray(raw?.visitTypes) ? raw.visitTypes.map((item: unknown) => String(item || "")) : [],
            fundingModels: Array.isArray(raw?.fundingModels) ? raw.fundingModels.map((item: unknown) => String(item || "")) : [],
            serviceFocus: String(raw?.serviceFocus || ""),
            status: (raw?.status as QueueStatus) || "new",
            reviewNotes: String(raw?.reviewNotes || ""),
            createdAt: raw?.createdAt ?? null,
          };
        })
      );
      setServiceRequests(
        serviceSnap.docs.map((row) => {
          const raw = row.data() as any;
          return {
            id: row.id,
            organisationName: String(raw?.organisationName || ""),
            requesterName: String(raw?.requesterName || ""),
            requesterEmail: String(raw?.requesterEmail || ""),
            organisationRole: String(raw?.organisationRole || ""),
            registeredProviderName: String(raw?.registeredProviderName || ""),
            registeredProviderId: String(raw?.registeredProviderId || ""),
            supportAtHomeCategory: String(raw?.supportAtHomeCategory || ""),
            clientReference: String(raw?.clientReference || ""),
            serviceTitle: String(raw?.serviceTitle || ""),
            suburb: String(raw?.suburb || ""),
            postcode: String(raw?.postcode || ""),
            requiredNurseType: String(raw?.requiredNurseType || ""),
            requestType: String(raw?.requestType || ""),
            status: String(raw?.status || "open"),
            responseCount: Number(raw?.responseCount || 0),
            createdAt: raw?.createdAt ?? null,
          };
        })
      );
    } catch (e: any) {
      console.error("Failed to load public enquiries queue:", e);
      setError(e?.message || "Failed to load the public enquiries queue.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!canUse) {
      setLoading(false);
      return;
    }
    void refreshData();
  }, [canUse, refreshData]);

  const counts = useMemo(
    () => ({
      contact: contactEnquiries.filter((row) => row.status !== "closed").length,
      nurses: nurseInterests.filter((row) => row.status !== "closed").length,
      serviceRequests: serviceRequests.filter((row) => row.status !== "filled" && row.status !== "withdrawn").length,
    }),
    [contactEnquiries, nurseInterests, serviceRequests]
  );

  async function updateQueueItem(
    queue: "contact" | "nurses",
    id: string,
    status: QueueStatus
  ) {
    const notes = (draftNotes[id] ?? "").trim();
    setSavingId(id);
    setMessage(null);
    setError(null);
    try {
      const collectionName = queue === "contact" ? "publicContactEnquiries" : "nurseRegistrationInterests";
      await updateDoc(doc(db, collectionName, id), {
        status,
        reviewNotes: notes,
        updatedAt: serverTimestamp(),
      });
      setMessage("Queue item updated.");
      await refreshData();
    } catch (e: any) {
      console.error("Failed to update public enquiry:", e);
      setError(e?.message || "Failed to update the queue item.");
    } finally {
      setSavingId("");
    }
  }

  if (!canUse) {
    return (
      <MainLayout>
        <div className="max-w-5xl mx-auto px-4 py-8">
          <div className="card p-6">
            <h1 className="section-title">Public Enquiries</h1>
            <p className="mt-2 text-sm text-ink-600">Only system support admins can access this page.</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
        <div className="card p-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <h1 className="section-title">Public Enquiries</h1>
              <p className="section-subtitle mt-1">
                Review contact enquiries and independent nurse registration interest submitted from the NurseConnectCare public site.
              </p>
            </div>
            <button type="button" className="btn-secondary" onClick={() => void refreshData()} disabled={loading}>
              {loading ? "Refreshing..." : "Refresh queue"}
            </button>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => setActiveQueue("contact")}
              className={activeQueue === "contact" ? "btn-primary" : "btn-secondary"}
            >
              Contact enquiries ({counts.contact})
            </button>
            <button
              type="button"
              onClick={() => setActiveQueue("nurses")}
              className={activeQueue === "nurses" ? "btn-primary" : "btn-secondary"}
            >
              Nurse registrations ({counts.nurses})
            </button>
            <button
              type="button"
              onClick={() => setActiveQueue("service_requests")}
              className={activeQueue === "service_requests" ? "btn-primary" : "btn-secondary"}
            >
              Service requests ({counts.serviceRequests})
            </button>
          </div>

          {message ? <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{message}</div> : null}
          {error ? <div className="mt-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}
        </div>

        {activeQueue === "contact" ? (
          <div className="space-y-4">
            {loading ? (
              <div className="card p-6 text-sm text-ink-500">Loading contact enquiries...</div>
            ) : contactEnquiries.length === 0 ? (
              <div className="card p-6 text-sm text-ink-500">No public contact enquiries found.</div>
            ) : (
              contactEnquiries.map((row) => (
                <div key={row.id} className="card p-6 space-y-4">
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                      <h2 className="text-lg font-semibold text-ink-900">{row.fullName}</h2>
                      <p className="mt-1 text-sm text-ink-600">{row.email}</p>
                      <p className="mt-2 text-sm text-ink-700">{row.enquiryType}</p>
                      <p className="mt-1 text-xs text-ink-500">{toDateString(row.createdAt)}</p>
                    </div>
                    <span className={`chip ${statusClasses(row.status)}`}>{row.status.replace("_", " ")}</span>
                  </div>
                  <div className="rounded-xl bg-sand-100/80 p-4 text-sm leading-7 text-ink-700">{row.message}</div>
                  <div>
                    <label className="label" htmlFor={`contact-note-${row.id}`}>Review notes</label>
                    <textarea
                      id={`contact-note-${row.id}`}
                      className="textarea min-h-[96px]"
                      value={draftNotes[row.id] ?? row.reviewNotes ?? ""}
                      onChange={(event) => setDraftNotes((current) => ({ ...current, [row.id]: event.target.value }))}
                    />
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <button type="button" className="btn-secondary" disabled={savingId === row.id} onClick={() => void updateQueueItem("contact", row.id, "in_review")}>
                      Mark in review
                    </button>
                    <button type="button" className="btn-primary" disabled={savingId === row.id} onClick={() => void updateQueueItem("contact", row.id, "closed")}>
                      Mark closed
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : activeQueue === "nurses" ? (
          <div className="space-y-4">
            {loading ? (
              <div className="card p-6 text-sm text-ink-500">Loading nurse registrations...</div>
            ) : nurseInterests.length === 0 ? (
              <div className="card p-6 text-sm text-ink-500">No nurse registration interest records found.</div>
            ) : (
              nurseInterests.map((row) => (
                <div key={row.id} className="card p-6 space-y-4">
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                      <h2 className="text-lg font-semibold text-ink-900">{row.fullName}</h2>
                      <p className="mt-1 text-sm text-ink-600">{row.email}</p>
                      <p className="mt-2 text-sm text-ink-700">
                        {row.professionalRole}{row.nurseType ? ` (${row.nurseType})` : ""}
                      </p>
                      <p className="mt-1 text-sm text-ink-600">Primary region: {row.primaryRegion}</p>
                      {row.travelRadius ? <p className="mt-1 text-sm text-ink-600">Travel/service coverage: {row.travelRadius}</p> : null}
                      {row.ahpraRegistrationNumber ? (
                        <p className="mt-1 text-sm text-ink-600">AHPRA registration: {row.ahpraRegistrationNumber}</p>
                      ) : null}
                      <p className="mt-1 text-xs text-ink-500">{toDateString(row.createdAt)}</p>
                    </div>
                    <span className={`chip ${statusClasses(row.status)}`}>{row.status.replace("_", " ")}</span>
                  </div>
                  {(row.visitTypes?.length || row.fundingModels?.length) ? (
                    <div className="grid gap-3 md:grid-cols-2">
                      {row.visitTypes?.length ? (
                        <div className="rounded-xl bg-white p-4 text-sm leading-7 text-ink-700 ring-1 ring-ink-200/70">
                          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Visit types</p>
                          <p className="mt-2">{row.visitTypes.join(", ")}</p>
                        </div>
                      ) : null}
                      {row.fundingModels?.length ? (
                        <div className="rounded-xl bg-white p-4 text-sm leading-7 text-ink-700 ring-1 ring-ink-200/70">
                          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-700">Funding pathways</p>
                          <p className="mt-2">{row.fundingModels.join(", ")}</p>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                  <div className="rounded-xl bg-sand-100/80 p-4 text-sm leading-7 text-ink-700">{row.serviceFocus}</div>
                  <div>
                    <label className="label" htmlFor={`nurse-note-${row.id}`}>Review notes</label>
                    <textarea
                      id={`nurse-note-${row.id}`}
                      className="textarea min-h-[96px]"
                      value={draftNotes[row.id] ?? row.reviewNotes ?? ""}
                      onChange={(event) => setDraftNotes((current) => ({ ...current, [row.id]: event.target.value }))}
                    />
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <button type="button" className="btn-secondary" disabled={savingId === row.id} onClick={() => void updateQueueItem("nurses", row.id, "in_review")}>
                      Mark in review
                    </button>
                    <button type="button" className="btn-primary" disabled={savingId === row.id} onClick={() => void updateQueueItem("nurses", row.id, "closed")}>
                      Mark closed
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {loading ? (
              <div className="card p-6 text-sm text-ink-500">Loading service requests...</div>
            ) : serviceRequests.length === 0 ? (
              <div className="card p-6 text-sm text-ink-500">No service requests found.</div>
            ) : (
              serviceRequests.map((row) => (
                <div key={row.id} className="card p-6 space-y-4">
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                      <h2 className="text-lg font-semibold text-ink-900">{row.serviceTitle}</h2>
                      <p className="mt-1 text-sm text-ink-600">{row.organisationName}</p>
                      <p className="mt-1 text-sm text-ink-600">{row.requesterName} · {row.requesterEmail}</p>
                      <p className="mt-2 text-sm text-ink-700">
                        {row.requestType.replace("_", " ")} · {row.requiredNurseType} · {row.suburb} {row.postcode}
                      </p>
                      <p className="mt-1 text-sm text-ink-700">
                        {formatOrganisationRole(row.organisationRole as any)} · {formatSupportAtHomeCategory(row.supportAtHomeCategory as any)}
                      </p>
                      <p className="mt-1 text-sm text-ink-600">
                        Provider: {row.registeredProviderName || "Not supplied"} · Reference: {row.registeredProviderId || row.clientReference || "Not supplied"}
                      </p>
                      <p className="mt-1 text-xs text-ink-500">{toDateString(row.createdAt)}</p>
                    </div>
                    <span className="chip">{row.status.replace("_", " ")}</span>
                  </div>
                  <div className="rounded-xl bg-sand-100/80 p-4 text-sm leading-7 text-ink-700">
                    Nurse responses received: {row.responseCount || 0}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default PublicEnquiriesAdminPage;
