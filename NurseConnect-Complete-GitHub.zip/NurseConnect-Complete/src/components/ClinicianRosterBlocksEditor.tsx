import React from "react";
import {
  AvailabilityDateBlock,
  WEEKDAY_OPTIONS,
  formatDateBlockSummary,
} from "../lib/clinicianAvailability";

type Props = {
  blocks: AvailabilityDateBlock[];
  disabled?: boolean;
  onAddBlock: () => void;
  onRemoveBlock: (blockId: string) => void;
  onChangeBlockField: (
    blockId: string,
    field: "startDate" | "endDate",
    value: string
  ) => void;
  onToggleDay: (blockId: string, dayOfWeek: number, enabled: boolean) => void;
  onChangeWindow: (
    blockId: string,
    windowIndex: number,
    field: "start" | "end",
    value: string
  ) => void;
  onAddWindow: (blockId: string) => void;
  onRemoveWindow: (blockId: string, windowIndex: number) => void;
};

export const ClinicianRosterBlocksEditor: React.FC<Props> = ({
  blocks,
  disabled = false,
  onAddBlock,
  onRemoveBlock,
  onChangeBlockField,
  onToggleDay,
  onChangeWindow,
  onAddWindow,
  onRemoveWindow,
}) => {
  return (
    <div className="space-y-3">
      {blocks.length === 0 ? (
        <div className="rounded-xl border border-dashed border-ink-300 p-4 text-sm text-ink-500">
          No dated roster blocks yet. Add a block to define a date range, the active weekdays, and time windows.
        </div>
      ) : null}

      {blocks.map((block, blockIndex) => (
        <div key={block.id} className="rounded-xl border border-ink-200 p-4 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="font-medium">Roster block {blockIndex + 1}</div>
              <div className="text-xs text-ink-500">{formatDateBlockSummary(block)}</div>
            </div>
            <button
              type="button"
              className="btn-secondary text-xs px-3 py-2"
              disabled={disabled}
              onClick={() => onRemoveBlock(block.id)}
            >
              Remove block
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="label">Start date</label>
              <input
                type="date"
                className="input"
                value={block.startDate}
                disabled={disabled}
                onChange={(e) => onChangeBlockField(block.id, "startDate", e.target.value)}
              />
            </div>
            <div>
              <label className="label">End date</label>
              <input
                type="date"
                className="input"
                value={block.endDate}
                disabled={disabled}
                onChange={(e) => onChangeBlockField(block.id, "endDate", e.target.value)}
              />
            </div>
          </div>

          <div>
            <div className="label">Available weekdays in this date range</div>
            <div className="flex flex-wrap gap-2">
              {WEEKDAY_OPTIONS.map((option) => {
                const active = block.daysOfWeek.includes(option.dayOfWeek);
                return (
                  <label
                    key={`${block.id}-${option.dayOfWeek}`}
                    className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs ${
                      active ? "border-brand-500 bg-brand-50 text-brand-700" : "border-ink-200 text-ink-700"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={active}
                      disabled={disabled}
                      onChange={(e) => onToggleDay(block.id, option.dayOfWeek, e.target.checked)}
                    />
                    {option.label}
                  </label>
                );
              })}
            </div>
          </div>

          <div className="space-y-2">
            <div className="label">Time windows</div>
            {block.windows.map((window, index) => (
              <div key={`${block.id}-${index}`} className="flex flex-wrap items-center gap-2">
                <input
                  type="time"
                  className="input max-w-[160px]"
                  step={300}
                  value={window.start}
                  disabled={disabled}
                  onChange={(e) => onChangeWindow(block.id, index, "start", e.target.value)}
                />
                <span className="text-sm text-ink-500">to</span>
                <input
                  type="time"
                  className="input max-w-[160px]"
                  step={300}
                  value={window.end}
                  disabled={disabled}
                  onChange={(e) => onChangeWindow(block.id, index, "end", e.target.value)}
                />
                <button
                  type="button"
                  className="btn-secondary text-xs px-3 py-2"
                  disabled={disabled}
                  onClick={() => onRemoveWindow(block.id, index)}
                >
                  Remove
                </button>
              </div>
            ))}

            <button
              type="button"
              className="btn-secondary text-xs px-3 py-2"
              disabled={disabled}
              onClick={() => onAddWindow(block.id)}
            >
              Add time window
            </button>
          </div>
        </div>
      ))}

      <button type="button" className="btn-secondary" disabled={disabled} onClick={onAddBlock}>
        Add roster block
      </button>
    </div>
  );
};

export default ClinicianRosterBlocksEditor;
