import React, { useEffect, useMemo, useState } from "react";
import { collection, doc, getDocs, limit, query, serverTimestamp, setDoc } from "firebase/firestore";
import { Link, useSearchParams } from "react-router-dom";
import { FiArrowRight, FiBriefcase, FiClipboard, FiSend } from "./PublicIcons";
import { db } from "../firebaseConfig";
import PublicSiteChrome from "./PublicSiteChrome";
import {
  AU_STATES,
  formatDeliveryModePreference,
  formatFundingPathway,
  formatOrganisationRole,
  formatSupportAtHomeCategory,
  ServiceRequestDoc,
  ServiceRequestDeliveryMode,
  ServiceRequestFundingPathway,
  ServiceRequestOrganisationRole,
  ServiceRequestType,
  SupportAtHomeServiceCategory,
} from "../lib/serviceRequests";

type PublicNurseProfile = {
  id: string;
  displayName: string;
  nurseType?: string | null;
  primaryRegion?: string | null;
  basePostcode?: string | null;
  servicePostcodes?: string[];
  serviceFocusKeywords?: string[];
};

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim());
}

export default function ServiceRequestPage() {
  const [searchParams] = useSearchParams();
  const initialMode = searchParams.get("mode") === "direct" ? "direct_request" : "open_request";
  const initialNurseId = searchParams.get("nurseId") || "";

  const [requestType, setRequestType] = useState<ServiceRequestType>(initialMode);
  const [organisationName, setOrganisationName] = useState("");
  const [requesterName, setRequesterName] = useState("");
  const [requesterEmail, setRequesterEmail] = useState("");
  const [requesterPhone, setRequesterPhone] = useState("");
  const [organisationRole, setOrganisationRole] = useState<ServiceRequestOrganisationRole>("registered_provider");
  const [registeredProviderName, setRegisteredProviderName] = useState("");
  const [registeredProviderId, setRegisteredProviderId] = useState("");
  const [supportAtHomeCategory, setSupportAtHomeCategory] = useState<SupportAtHomeServiceCategory>("clinical_supports");
  const [clientReference, setClientReference] = useState("");
  const [suburb, setSuburb] = useState("");
  const [postcode, setPostcode] = useState("");
  const [stateName, setStateName] = useState<string>(AU_STATES[0]);
  const [requiredNurseType, setRequiredNurseType] = useState("RN");
  const [serviceTitle, setServiceTitle] = useState("");
  const [serviceKeywordsText, setServiceKeywordsText] = useState("");
  const [deliveryModePreference, setDeliveryModePreference] = useState<ServiceRequestDeliveryMode>("in_person");
  const [requestedVisits, setRequestedVisits] = useState("2");
  const [timeframe, setTimeframe] = useState("");
  const [carePlanContext, setCarePlanContext] = useState("");
  const [fundingPathway, setFundingPathway] = useState<ServiceRequestFundingPathway>("support_at_home");
  const [targetNurseUid, setTargetNurseUid] = useState(initialNurseId);
  const [profiles, setProfiles] = useState<PublicNurseProfile[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<{ id: string; type: ServiceRequestType } | null>(null);

  useEffect(() => {
    let active = true;
    async function loadProfiles() {
      try {
        const snap = await getDocs(query(collection(db, "publicNurseProfiles"), limit(100)));
        if (!active) return;
        setProfiles(
          snap.docs.map((row) => {
            const data = row.data() as any;
            return {
              id: row.id,
              displayName: String(data?.displayName || ""),
              nurseType: String(data?.nurseType || ""),
              primaryRegion: String(data?.primaryRegion || ""),
              basePostcode: String(data?.basePostcode || ""),
              servicePostcodes: Array.isArray(data?.servicePostcodes) ? data.servicePostcodes.map((item: unknown) => String(item || "")) : [],
              serviceFocusKeywords: Array.isArray(data?.serviceFocusKeywords)
                ? data.serviceFocusKeywords.map((item: unknown) => String(item || ""))
                : [],
            };
          })
        );
      } catch (e) {
        console.error(e);
      }
    }
    void loadProfiles();
    return () => {
      active = false;
    };
  }, []);

  const selectedNurse = useMemo(
    () => profiles.find((profile) => profile.id === targetNurseUid) || null,
    [profiles, targetNurseUid]
  );

  const submitRequest = async () => {
    setSubmitting(true);
    setError("");
    try {
      if (!organisationName.trim() || !requesterName.trim() || !requesterEmail.trim() || !suburb.trim() || !postcode.trim() || !serviceTitle.trim() || !timeframe.trim() || !carePlanContext.trim()) {
        throw new Error("Complete the required request details before submitting.");
      }
      if (!isValidEmail(requesterEmail)) {
        throw new Error("Enter a valid requester email address.");
      }
      if (requestType === "direct_request" && !selectedNurse) {
        throw new Error("Select the nurse you want to request directly.");
      }

      const requestRef = doc(collection(db, "serviceRequests"));
      const manageUrl = `${window.location.origin}/service-requests/manage/${requestRef.id}`;
      const payload: Omit<ServiceRequestDoc, "id"> = {
        manageToken: requestRef.id,
        manageUrl,
        requestType,
        status: requestType === "direct_request" ? "direct_pending" : "open",
        organisationName: organisationName.trim(),
        requesterName: requesterName.trim(),
        requesterEmail: requesterEmail.trim().toLowerCase(),
        requesterPhone: requesterPhone.trim() || null,
        organisationRole,
        registeredProviderName: registeredProviderName.trim() || null,
        registeredProviderId: registeredProviderId.trim() || null,
        supportAtHomeCategory,
        clientReference: clientReference.trim() || null,
        suburb: suburb.trim(),
        postcode: postcode.replace(/[^\d]/g, "").slice(0, 4),
        state: stateName,
        requiredNurseType,
        serviceTitle: serviceTitle.trim(),
        serviceKeywords: serviceKeywordsText
          .split(",")
          .map((item) => item.trim())
          .filter((item, index, array) => item && array.indexOf(item) === index)
          .slice(0, 12),
        deliveryModePreference,
        requestedVisits: Number(requestedVisits) > 0 ? Number(requestedVisits) : null,
        timeframe: timeframe.trim(),
        carePlanContext: carePlanContext.trim(),
        fundingPathway,
        targetNurseUid: selectedNurse?.id || null,
        targetNurseName: selectedNurse?.displayName || null,
        targetNurseType: selectedNurse?.nurseType || null,
        responses: [],
        responseCount: 0,
        acceptedByNurseUid: null,
        acceptedAt: null,
        filledConfirmedAt: null,
        filledConfirmedBy: null,
        updatedByUid: null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      await setDoc(requestRef, payload);
      setCreated({ id: requestRef.id, type: requestType });
    } catch (e: any) {
      console.error(e);
      setError(e?.message || "Could not submit the service request right now.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <PublicSiteChrome
      ctaLabel="Client/Carer Access"
      ctaTo="/patient-login"
      metaTitle="NurseConnectCare | Service Requests"
      metaDescription="Post provider, care-manager, participant or carer nursing requests through NurseConnectCare infrastructure."
    >
      <section className="mx-auto grid w-full max-w-7xl gap-10 px-4 pb-14 pt-8 sm:px-6 lg:grid-cols-[1fr_0.92fr] lg:px-8 lg:pt-14">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-4 py-2 text-sm text-ink-700 shadow-soft backdrop-blur">
            <FiBriefcase className="h-4 w-4 text-brand-700" />
            Organisation and funder requests
          </div>
          <h1 className="mt-6 text-4xl leading-tight text-ink-900 sm:text-5xl">Request nursing support through NurseConnectCare.</h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-700">
            Registered providers, care managers, funders, participants and carers can record nursing needs and route them
            through NurseConnectCare's infrastructure. Requests preserve the client connection while keeping Support at
            Home approval, care-plan responsibility and service governance with the appropriate provider or independent
            nurse.
          </p>
          <div className="mt-8 grid gap-4 border-y border-ink-200 py-5 sm:grid-cols-2">
            <div>
              <p className="text-sm font-semibold text-ink-900">Open request</p>
              <p className="mt-2 text-sm leading-7 text-ink-700">
                Post a request with visits, skill level, location, timeframe, care-plan context and Support at Home category so suitable independent nurses can express interest.
              </p>
            </div>
            <div>
              <p className="text-sm font-semibold text-ink-900">Direct request</p>
              <p className="mt-2 text-sm leading-7 text-ink-700">
                Identify a nurse already on NurseConnectCare and send a defined invitation. The nurse decides whether to accept within their scope, availability and provider/funder requirements.
              </p>
            </div>
          </div>
        </div>

        <div className="rounded-[28px] border border-ink-200 bg-ink-900 p-6 text-white shadow-lift">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Request workflow</p>
          <div className="mt-4 flex gap-2">
            {[
              { value: "open_request", label: "Open request" },
              { value: "direct_request", label: "Direct request" },
            ].map((item) => (
              <button
                key={item.value}
                type="button"
                onClick={() => setRequestType(item.value as ServiceRequestType)}
                className={`rounded-full px-4 py-2 text-sm font-medium transition ${requestType === item.value ? "bg-white text-ink-900" : "border border-white/20 text-white hover:bg-white/10"}`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {created ? (
            <div className="mt-6 rounded-[24px] bg-white p-5 text-ink-900">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Request submitted</p>
              <p className="mt-3 text-xl font-semibold">Your service request is live.</p>
              <p className="mt-3 text-sm leading-7 text-ink-700">
                Use the management link below to confirm when the request has been filled or withdrawn so nurses stop responding to requests that are no longer available.
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <Link to={`/service-requests/manage/${created.id}`} className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700">
                  Manage request
                  <FiArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          ) : (
            <div className="mt-6 space-y-4">
              {error ? <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div>
                  <label className="label !text-white/70">Organisation</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={organisationName} onChange={(e) => setOrganisationName(e.target.value)} />
                </div>
                <div>
                  <label className="label !text-white/70">Requester role</label>
                  <select className="select !border-white/15 !bg-white !text-ink-900" value={organisationRole} onChange={(e) => setOrganisationRole(e.target.value as ServiceRequestOrganisationRole)}>
                    <option value="registered_provider">Registered Support at Home provider</option>
                    <option value="care_manager_or_funder">Care manager or funder</option>
                    <option value="independent_nurse_provider">Independent nurse provider</option>
                    <option value="participant_or_carer">Participant or carer</option>
                    <option value="other">Other organisation</option>
                  </select>
                </div>
                <div>
                  <label className="label !text-white/70">Requester name</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={requesterName} onChange={(e) => setRequesterName(e.target.value)} />
                </div>
                <div>
                  <label className="label !text-white/70">Requester email</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={requesterEmail} onChange={(e) => setRequesterEmail(e.target.value)} />
                </div>
                <div>
                  <label className="label !text-white/70">Requester phone</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={requesterPhone} onChange={(e) => setRequesterPhone(e.target.value)} />
                </div>
                <div>
                  <label className="label !text-white/70">Registered provider name</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={registeredProviderName} onChange={(e) => setRegisteredProviderName(e.target.value)} placeholder="If applicable" />
                </div>
                <div>
                  <label className="label !text-white/70">Provider registration/reference</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={registeredProviderId} onChange={(e) => setRegisteredProviderId(e.target.value)} placeholder="Optional provider ID or internal reference" />
                </div>
                <div>
                  <label className="label !text-white/70">Client reference</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={clientReference} onChange={(e) => setClientReference(e.target.value)} placeholder="Initials or internal client ID" />
                </div>
                <div>
                  <label className="label !text-white/70">Skill level required</label>
                  <select className="select !border-white/15 !bg-white !text-ink-900" value={requiredNurseType} onChange={(e) => setRequiredNurseType(e.target.value)}>
                    <option value="EN">EN</option>
                    <option value="RN">RN</option>
                    <option value="NP">NP</option>
                  </select>
                </div>
                <div>
                  <label className="label !text-white/70">Suburb</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={suburb} onChange={(e) => setSuburb(e.target.value)} />
                </div>
                <div>
                  <label className="label !text-white/70">Postcode</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={postcode} onChange={(e) => setPostcode(e.target.value.replace(/[^\d]/g, "").slice(0, 4))} />
                </div>
                <div>
                  <label className="label !text-white/70">State or territory</label>
                  <select className="select !border-white/15 !bg-white !text-ink-900" value={stateName} onChange={(e) => setStateName(e.target.value)}>
                    {AU_STATES.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label !text-white/70">Funding pathway</label>
                  <select className="select !border-white/15 !bg-white !text-ink-900" value={fundingPathway} onChange={(e) => setFundingPathway(e.target.value as ServiceRequestFundingPathway)}>
                    <option value="support_at_home">Support at Home</option>
                    <option value="private_pay">Private pay</option>
                    <option value="mixed">Mixed funding</option>
                    <option value="to_be_confirmed">To be confirmed</option>
                  </select>
                </div>
                <div>
                  <label className="label !text-white/70">Support at Home category</label>
                  <select className="select !border-white/15 !bg-white !text-ink-900" value={supportAtHomeCategory} onChange={(e) => setSupportAtHomeCategory(e.target.value as SupportAtHomeServiceCategory)}>
                    <option value="clinical_supports">Clinical supports</option>
                    <option value="independence_services">Independence services</option>
                    <option value="everyday_living_services">Everyday living services</option>
                    <option value="not_sure">Not sure</option>
                    <option value="not_applicable">Not applicable</option>
                  </select>
                </div>
                <div>
                  <label className="label !text-white/70">Requested service</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={serviceTitle} onChange={(e) => setServiceTitle(e.target.value)} placeholder="e.g. wound review, post-discharge nursing" />
                </div>
                <div>
                  <label className="label !text-white/70">Delivery mode</label>
                  <select className="select !border-white/15 !bg-white !text-ink-900" value={deliveryModePreference} onChange={(e) => setDeliveryModePreference(e.target.value as ServiceRequestDeliveryMode)}>
                    <option value="in_person">In person</option>
                    <option value="telehealth">Telehealth</option>
                    <option value="hybrid">Hybrid</option>
                  </select>
                </div>
                <div>
                  <label className="label !text-white/70">Visit count</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={requestedVisits} onChange={(e) => setRequestedVisits(e.target.value.replace(/[^\d]/g, "").slice(0, 2))} />
                </div>
                <div className="md:col-span-2">
                  <label className="label !text-white/70">Timeframe</label>
                  <input className="input !border-white/15 !bg-white !text-ink-900" value={timeframe} onChange={(e) => setTimeframe(e.target.value)} placeholder="e.g. within 48 hours, next week, Mondays and Thursdays for 2 weeks" />
                </div>
                {requestType === "direct_request" ? (
                  <div className="md:col-span-2">
                    <label className="label !text-white/70">Select nurse</label>
                    <select className="select !border-white/15 !bg-white !text-ink-900" value={targetNurseUid} onChange={(e) => setTargetNurseUid(e.target.value)}>
                      <option value="">Choose a nurse</option>
                      {profiles.map((profile) => (
                        <option key={profile.id} value={profile.id}>
                          {profile.displayName} · {profile.nurseType || "Nurse"} · {profile.primaryRegion || "Region not listed"}
                        </option>
                      ))}
                    </select>
                  </div>
                ) : null}
                <div className="md:col-span-2">
                  <label className="label !text-white/70">Service keywords</label>
                  <input
                    className="input !border-white/15 !bg-white !text-ink-900"
                    value={serviceKeywordsText}
                    onChange={(e) => setServiceKeywordsText(e.target.value)}
                    placeholder="e.g. wound care, dressing change, post-discharge"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="label !text-white/70">Care-plan context</label>
                  <textarea className="input min-h-[120px] !border-white/15 !bg-white !text-ink-900" value={carePlanContext} onChange={(e) => setCarePlanContext(e.target.value)} placeholder="Summarise the care plan context, visit purpose, and anything a nurse should understand before responding." />
                </div>
              </div>

              <div className="rounded-[24px] bg-white p-5 text-ink-900">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <FiClipboard className="h-4 w-4 text-brand-700" />
                  Request summary
                </div>
                <p className="mt-3 text-sm leading-7 text-ink-700">
                  {requestType === "direct_request" ? "Direct request" : "Open request"} · {formatOrganisationRole(organisationRole)} · {requiredNurseType} · {suburb || "Suburb"} {postcode || "Postcode"} · {serviceTitle || "Service"} · {formatFundingPathway(fundingPathway)} · {formatSupportAtHomeCategory(supportAtHomeCategory)} · {formatDeliveryModePreference(deliveryModePreference)}
                </p>
                {selectedNurse ? (
                  <p className="mt-2 text-sm leading-7 text-ink-700">
                    Directing to: {selectedNurse.displayName} ({selectedNurse.nurseType || "Nurse"})
                  </p>
                ) : null}
                <button type="button" onClick={() => void submitRequest()} disabled={submitting} className="mt-5 inline-flex items-center gap-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700">
                  {submitting ? "Submitting..." : "Submit service request"}
                  <FiSend className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    </PublicSiteChrome>
  );
}
