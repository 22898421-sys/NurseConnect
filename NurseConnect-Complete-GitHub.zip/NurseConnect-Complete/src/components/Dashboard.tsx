// src/components/Dashboard.tsx
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "./MainLayout";
import { useAuth } from "../contexts/AuthContext";

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { normalizedRole, loading, user } = useAuth() as any;

  useEffect(() => {
    if (loading) return;

    if (!user) {
      navigate("/", { replace: true });
      return;
    }

    // Deterministic role routing
    if (normalizedRole === "system_admin") navigate("/system-admin", { replace: true });
    else if (normalizedRole === "clinician") navigate("/schedule", { replace: true });
    else if (normalizedRole === "patient") navigate("/patient", { replace: true });
    else navigate("/", { replace: true });
  }, [loading, user, normalizedRole, navigate]);

  return (
    <MainLayout>
      <div className="text-center mt-10">
        <h1 className="text-2xl text-gray-700">Redirecting…</h1>
        <p className="text-sm text-gray-500 mt-2">Please wait a moment.</p>
      </div>
    </MainLayout>
  );
};

export default Dashboard;
