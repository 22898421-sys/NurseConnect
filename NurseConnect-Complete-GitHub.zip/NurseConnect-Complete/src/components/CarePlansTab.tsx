import React, { useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, query, where } from "firebase/firestore";
import { Link } from "react-router-dom";
import { db } from "../firebaseConfig";
import { getCarePlanTemplate, formatCarePlanStatus, CarePlanPayload } from "../lib/carePlans";
import { toPlainLanguageOutcomeMessage } from "../lib/plainLanguage";
import CarePlanLauncher from "./CarePlanLauncher";

type CarePlanRow = {
  id: string;
  patientId: string;
  practiceId: string;
  tool: string;
  status: string;
  integrationMode?: string | null;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  authoredByDisplayName?: string | null;
  completedAt?: any;
  createdAt?: any;
  templateKey?: string | null;
  resultSummary?: {
    templateKey?: string | null;
    status?: string | null;
    goalSummary?: string | null;
    outcomeTargets?: string | null;
    reviewTimeframe?: string | null;
    agreedServiceDays?: string | null;
    evaluationPlan?: string | null;
    agreedWithPatientOrRepresentative?: boolean | null;
    agreementName?: string | null;
  } | null;
  planPayload?: CarePlanPayload | null;
  printableSummary?: string | null;
  reportStatus?: string | null;
};

function toDateMaybe(value: any): Date | null {
  try {
    if (!value) return null;
    if (typeof value?.toDate === "function") return value.toDate();
    if (typeof value?.seconds === "number") return new Date(value.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

type Props = {
  patientId: string;
  practiceId: string;
  clinicianUid: string;
  clinicianDisplayName?: string | null;
  chartBasePath: string;
};

const CarePlansTab: React.FC<Props> = ({
  patientId,
  practiceId,
  clinicianUid,
  clinicianDisplayName,
  chartBasePath,
}) => {
  const [items, setItems] = useState<CarePlanRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setErr(null);
      try {
        const snap = await getDocs(
          query(
            collection(db, "carePlans"),
            where("patientId", "==", patientId),
            where("practiceId", "==", practiceId),
            limit(100)
          )
        );
        if (cancelled) return;
        const rows: CarePlanRow[] = snap.docs
          .map((row) => ({ id: row.id, ...(row.data() as any) }))
          .sort((a, b) => {
            const aMs = toDateMaybe(a.completedAt || a.createdAt)?.getTime() || 0;
            const bMs = toDateMaybe(b.completedAt || b.createdAt)?.getTime() || 0;
            return bMs - aMs;
          });
        setItems(rows);
      } catch (e: any) {
        console.error(e);
        if (!cancelled) setErr(toPlainLanguageOutcomeMessage(e, "We could not load care plans right now."));
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, [patientId, practiceId, reloadKey]);

  const latest = items[0] || null;
  const latestDate = useMemo(() => toDateMaybe(latest?.completedAt || latest?.createdAt), [latest]);

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-ink-200 bg-white p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="section-title">Care plans</div>
            <div className="section-subtitle">
              Clinician-only nursing care-plan forms aligned to assessment findings, agreed goals, risks, interventions, monitoring, and review.
            </div>
          </div>
          <CarePlanLauncher
            patientId={patientId}
            practiceId={practiceId}
            clinicianUid={clinicianUid}
            clinicianDisplayName={clinicianDisplayName}
            chartBasePath={chartBasePath}
            buttonLabel="New care plan"
            onCarePlanCreated={() => setReloadKey((value) => value + 1)}
          />
        </div>

        {latest ? (
          <div className="rounded-lg border border-teal-200 bg-teal-50 px-3 py-3">
            <div className="text-xs font-medium text-teal-900">Latest care plan</div>
            <div className="mt-1 text-sm text-teal-950">
              {latest.resultSummary?.templateKey
                ? `${getCarePlanTemplate(latest.resultSummary.templateKey as any).label} · `
                : ""}
              {latest.resultSummary?.goalSummary || "Goal summary pending"}
            </div>
            <div className="mt-1 text-xs text-teal-900">
              {latestDate ? latestDate.toLocaleString() : "Date unavailable"}
              {latest.resultSummary?.reviewTimeframe ? ` · ${latest.resultSummary.reviewTimeframe}` : ""}
              {latest.authoredByDisplayName ? ` · ${latest.authoredByDisplayName}` : ""}
              {latest.resultSummary?.status ? ` · ${formatCarePlanStatus(latest.resultSummary.status as any)}` : ""}
            </div>
          </div>
        ) : (
          <div className="rounded-lg border border-ink-200 bg-ink-50 px-3 py-3 text-sm text-ink-500">
            No care plans recorded yet.
          </div>
        )}
      </div>

      <div className="rounded-xl border border-ink-200 bg-white p-4 space-y-3">
        <div className="text-sm font-semibold">Care-plan history</div>
        {loading ? (
          <div className="text-sm text-ink-500">Loading care plans…</div>
        ) : err ? (
          <div className="text-sm text-rose-600">{err}</div>
        ) : items.length === 0 ? (
          <div className="text-sm text-ink-500">No care plans recorded yet.</div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => {
              const completedAt = toDateMaybe(item.completedAt || item.createdAt);
              const plan = item.planPayload;
              return (
                <details key={item.id} className="rounded-lg border border-ink-200 p-3">
                  <summary className="cursor-pointer list-none">
                    <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
                      <div>
                        <div className="text-sm font-medium">
                          {item.resultSummary?.templateKey
                            ? getCarePlanTemplate(item.resultSummary.templateKey as any).label
                            : "Care plan"}
                          {item.resultSummary?.status
                            ? ` · ${formatCarePlanStatus(item.resultSummary.status as any)}`
                            : ""}
                        </div>
                        <div className="mt-1 text-xs text-ink-500">
                          {completedAt ? completedAt.toLocaleString() : "Date unavailable"}
                          {item.resultSummary?.reviewTimeframe ? ` · ${item.resultSummary.reviewTimeframe}` : ""}
                          {item.integrationMode ? ` · ${item.integrationMode}` : ""}
                        </div>
                      </div>
                      <div className="text-xs text-ink-500">
                        {item.reportStatus ? `Report: ${item.reportStatus}` : "Report pending"}
                      </div>
                    </div>
                  </summary>

                  <div className="mt-3 space-y-3">
                    {item.resultSummary?.goalSummary ? (
                      <div className="text-sm text-ink-800">{item.resultSummary.goalSummary}</div>
                    ) : null}

                    {item.resultSummary?.outcomeTargets ? (
                      <div className="rounded-md border border-ink-200 bg-sand-50 px-3 py-2 text-sm text-ink-800">
                        Outcome targets: {item.resultSummary.outcomeTargets}
                      </div>
                    ) : null}

                    {item.printableSummary ? (
                      <div className="rounded-md border border-ink-200 bg-sand-50 px-3 py-2 text-sm whitespace-pre-wrap">
                        {item.printableSummary}
                      </div>
                    ) : null}

                    {plan ? (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                        <DetailBlock title="Assessment and needs" rows={[
                          plan.visitContext ? `Visit context: ${plan.visitContext}` : "",
                          plan.personalPreferences ? `Preferences: ${plan.personalPreferences}` : "",
                          plan.clinicalAssessmentSummary ? `Assessment: ${plan.clinicalAssessmentSummary}` : "",
                          plan.clinicalNeeds ? `Clinical needs: ${plan.clinicalNeeds}` : "",
                          plan.personalCareNeeds ? `Personal care needs: ${plan.personalCareNeeds}` : "",
                          plan.identifiedRisks ? `Risks: ${plan.identifiedRisks}` : "",
                        ]} />
                        <DetailBlock title="Goals and delivery" rows={[
                          plan.shortTermGoals ? `Short-term goals: ${plan.shortTermGoals}` : "",
                          plan.longTermGoals ? `Long-term goals: ${plan.longTermGoals}` : "",
                          plan.nursingInterventions ? `Nursing interventions: ${plan.nursingInterventions}` : "",
                          plan.personalCareInterventions ? `Personal care interventions: ${plan.personalCareInterventions}` : "",
                          plan.visitSchedule ? `Visit schedule: ${plan.visitSchedule}` : "",
                          plan.monitoringParameters ? `Monitoring: ${plan.monitoringParameters}` : "",
                        ]} />
                        <DetailBlock title="Resources and coordination" rows={[
                          plan.equipmentRequirements ? `Equipment: ${plan.equipmentRequirements}` : "",
                          plan.delegationPlan ? `Delegation: ${plan.delegationPlan}` : "",
                          plan.referralsAndTeam ? `People/referrals: ${plan.referralsAndTeam}` : "",
                          plan.escalationTriggers ? `Escalation: ${plan.escalationTriggers}` : "",
                          plan.transitionConsiderations ? `Transition/discharge: ${plan.transitionConsiderations}` : "",
                        ]} />
                        <DetailBlock title="Review and agreement" rows={[
                          item.resultSummary?.agreedServiceDays ? `Agreed service days: ${item.resultSummary.agreedServiceDays}` : "",
                          item.resultSummary?.evaluationPlan ? `Evaluation plan: ${item.resultSummary.evaluationPlan}` : "",
                          typeof item.resultSummary?.agreedWithPatientOrRepresentative === "boolean"
                            ? `Agreement: ${item.resultSummary.agreedWithPatientOrRepresentative ? "Agreed with patient/representative" : "Pending agreement"}`
                            : "",
                          item.resultSummary?.agreementName ? `Agreement name: ${item.resultSummary.agreementName}` : "",
                        ]} />
                      </div>
                    ) : null}

                    <div className="flex flex-wrap gap-3 text-xs text-ink-500">
                      <span>
                        Care-plan ID: <span className="font-mono">{item.id}</span>
                      </span>
                      {item.sourceEncounterId ? (
                        <Link to={`${chartBasePath}/encounters/${item.sourceEncounterId}`} className="text-brand-500 hover:underline">
                          Open linked encounter
                        </Link>
                      ) : null}
                      <Link to={`${chartBasePath}?tab=documents`} className="text-brand-500 hover:underline">
                        Open Documents tab
                      </Link>
                    </div>
                  </div>
                </details>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

function DetailBlock(props: { title: string; rows: string[] }) {
  const rows = props.rows.filter(Boolean);
  if (!rows.length) return null;

  return (
    <div className="rounded-md border border-ink-200 bg-white px-3 py-3 space-y-2">
      <div className="text-xs font-medium text-ink-700">{props.title}</div>
      {rows.map((row) => (
        <div key={`${props.title}-${row}`} className="text-sm text-ink-800 whitespace-pre-wrap">
          {row}
        </div>
      ))}
    </div>
  );
}

export default CarePlansTab;
