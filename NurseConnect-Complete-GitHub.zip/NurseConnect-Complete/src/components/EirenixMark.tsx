import React from "react";

type EirenixMarkProps = {
  className?: string;
};

export default function EirenixMark({ className = "" }: EirenixMarkProps) {
  return (
    <span className={`inline-flex items-baseline ${className}`.trim()}>
      <span>EIRENIX Care</span>
      <sup className="ml-0.5 text-[0.55em] font-semibold align-super">TM</sup>
    </span>
  );
}
