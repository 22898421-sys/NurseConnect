import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { collection, getDocs, limit, query, serverTimestamp, updateDoc, where, doc } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import MainLayout from "./MainLayout";

type NurseVerificationRow = {
  uid: string;
  displayName: string;
  email: string;
  nurseType: string;
  ahpraRegistrationNumber: string;
  publicPrimaryRegion: string;
  publicProfileEnabled: boolean;
  ahpraVerified: boolean;
  ahpraVerifiedAt?: { toDate?: () => Date } | Date | null;
  ahpraVerificationNotes?: string | null;
};

const supportCards = [
  {
    title: "Public enquiries",
    body: "Review website contact submissions and nurse registration enquiries without opening clinical records.",
    to: "/public-enquiries",
    cta: "Open enquiries",
  },
  {
    title: "Bootstrap and access support",
    body: "Handle first-run setup and technical access issues without taking ownership of clinician or patient administration.",
    to: "/bootstrap/setup",
    cta: "Open bootstrap tools",
  },
];

function toDateString(value: any) {
  const date = value instanceof Date ? value : typeof value?.toDate === "function" ? value.toDate() : null;
  return date ? date.toLocaleString() : "Not yet verified";
}

export default function SupportAdminPage() {
  const { user } = useAuth() as any;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [items, setItems] = useState<NurseVerificationRow[]>([]);
  const [savingUid, setSavingUid] = useState("");
  const [draftNotes, setDraftNotes] = useState<Record<string, string>>({});

  const refreshQueue = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const snap = await getDocs(
        query(collection(db, "users"), where("role", "==", "clinician"), limit(200))
      );
      setItems(
        snap.docs.map((row) => {
          const raw = row.data() as any;
          return {
            uid: row.id,
            displayName: String(raw?.displayName || raw?.email || row.id),
            email: String(raw?.email || ""),
            nurseType: String(raw?.nurseType || raw?.designation || ""),
            ahpraRegistrationNumber: String(raw?.ahpraRegistrationNumber || ""),
            publicPrimaryRegion: String(raw?.publicPrimaryRegion || raw?.practiceName || ""),
            publicProfileEnabled: raw?.publicProfileEnabled === true,
            ahpraVerified: raw?.ahpraVerified === true,
            ahpraVerifiedAt: raw?.ahpraVerifiedAt ?? null,
            ahpraVerificationNotes: String(raw?.ahpraVerificationNotes || ""),
          };
        }).sort((a, b) => a.displayName.localeCompare(b.displayName))
      );
    } catch (e: any) {
      console.error("Failed to load nurse verification queue", e);
      setError(e?.message || "Could not load the nurse verification queue.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshQueue();
  }, [refreshQueue]);

  const pendingCount = useMemo(() => items.filter((item) => item.ahpraRegistrationNumber && !item.ahpraVerified).length, [items]);

  async function setVerification(uid: string, verified: boolean) {
    if (!user?.uid) return;
    setSavingUid(uid);
    setMessage(null);
    setError(null);
    try {
      await updateDoc(doc(db, "users", uid), {
        ahpraVerified: verified,
        ahpraVerifiedAt: verified ? serverTimestamp() : null,
        ahpraVerifiedByUid: verified ? user.uid : null,
        ahpraVerificationNotes: (draftNotes[uid] || "").trim() || null,
        updatedAt: serverTimestamp(),
      });
      setMessage(verified ? "AHPRA verification recorded." : "AHPRA verification cleared.");
      await refreshQueue();
    } catch (e: any) {
      console.error("Failed to update nurse verification", e);
      setError(e?.message || "Could not update AHPRA verification.");
    } finally {
      setSavingUid("");
    }
  }

  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
        <div className="card p-6">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">System support</p>
          <h1 className="section-title mt-2">Technical support console</h1>
          <p className="section-subtitle mt-2">
            Support access is limited to operational tooling. Nurse AHPRA verification is recorded here after a manual
            check against the public register outside the platform.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {supportCards.map((card) => (
            <div key={card.title} className="card p-6 space-y-4">
              <h2 className="text-xl font-semibold text-ink-900">{card.title}</h2>
              <p className="text-sm leading-7 text-ink-700">{card.body}</p>
              <Link to={card.to} className="btn-secondary inline-flex">
                {card.cta}
              </Link>
            </div>
          ))}
        </div>

        <div className="card p-6 space-y-4">
          <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Nurse verification</p>
              <h2 className="mt-2 text-2xl font-semibold text-ink-900">AHPRA manual verification queue</h2>
              <p className="mt-2 text-sm leading-7 text-ink-700">
                Check the public AHPRA register, then mark the nurse as verified here. Only manually verified nurses
                should show an AHPRA verified badge on the public service profile.
              </p>
            </div>
            <div className="rounded-full border border-brand-200 bg-brand-50 px-4 py-2 text-sm text-ink-800">
              Pending verification: {pendingCount}
            </div>
          </div>

          {message ? <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{message}</div> : null}
          {error ? <div className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

          {loading ? (
            <div className="text-sm text-ink-500">Loading nurse verification queue...</div>
          ) : items.length === 0 ? (
            <div className="text-sm text-ink-500">No nurse accounts found yet.</div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div key={item.uid} className="rounded-[24px] border border-ink-200 bg-white p-5 shadow-soft">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-ink-900">{item.displayName}</h3>
                      <p className="mt-1 text-sm text-ink-600">{item.email || "No email recorded"}</p>
                      <div className="mt-3 grid gap-1 text-sm text-ink-700">
                        <p>AHPRA registration: {item.ahpraRegistrationNumber || "Not provided"}</p>
                        <p>Nurse type/designation: {item.nurseType || "Not specified"}</p>
                        <p>Public region: {item.publicPrimaryRegion || "Not specified"}</p>
                        <p>Marketplace profile: {item.publicProfileEnabled ? "Enabled" : "Disabled"}</p>
                        <p>Verification status: {item.ahpraVerified ? "Verified" : "Pending"}</p>
                        <p>Last verified: {toDateString(item.ahpraVerifiedAt)}</p>
                      </div>
                    </div>

                    <div className="w-full max-w-md space-y-3">
                      <label className="label">Verification notes</label>
                      <textarea
                        className="input min-h-[96px]"
                        value={draftNotes[item.uid] ?? item.ahpraVerificationNotes ?? ""}
                        onChange={(event) => setDraftNotes((current) => ({ ...current, [item.uid]: event.target.value }))}
                        placeholder="For example: Checked public AHPRA register on 8 April 2026. Registration active."
                      />
                      <div className="flex flex-wrap gap-3">
                        <button
                          type="button"
                          className="btn-primary"
                          disabled={!item.ahpraRegistrationNumber || savingUid === item.uid}
                          onClick={() => void setVerification(item.uid, true)}
                        >
                          {savingUid === item.uid ? "Saving..." : "Mark verified"}
                        </button>
                        <button
                          type="button"
                          className="btn-secondary"
                          disabled={savingUid === item.uid}
                          onClick={() => void setVerification(item.uid, false)}
                        >
                          Clear verification
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold text-ink-900">Break-glass model</h2>
          <p className="mt-3 text-sm leading-7 text-ink-700">
            Break-glass access should be automated, tightly scoped, and fully audited. This environment assumes support
            users do not open patient records as part of routine administration.
          </p>
        </div>
      </div>
    </MainLayout>
  );
}
