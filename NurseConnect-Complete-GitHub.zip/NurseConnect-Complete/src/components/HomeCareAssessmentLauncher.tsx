import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  buildTemplateDomains,
  createManualRiskAssessment,
  formatConcernLevel,
  getHomeCareAssessmentTemplate,
  HOME_CARE_ASSESSMENT_TEMPLATES,
  HomeCareAssessmentDomain,
  HomeCareAssessmentTemplateKey,
  HomeCareConcernLevel,
} from "../lib/homeCareAssessments";
import { toPlainLanguageOutcomeMessage } from "../lib/plainLanguage";

type Props = {
  patientId: string;
  practiceId: string;
  clinicianUid: string;
  clinicianDisplayName?: string | null;
  sourceEncounterId?: string | null;
  sourceAppointmentId?: string | null;
  chartBasePath?: string;
  buttonLabel?: string;
  buttonClassName?: string;
  compact?: boolean;
  onAssessmentCreated?: (payload: {
    assessmentId: string;
    planLine: string;
    documentEntryTitle: string;
  }) => void;
};

type DomainDraft = HomeCareAssessmentDomain;

function concernOptions(): HomeCareConcernLevel[] {
  return ["low", "moderate", "high", "urgent"];
}

const HomeCareAssessmentLauncher: React.FC<Props> = ({
  patientId,
  practiceId,
  clinicianUid,
  clinicianDisplayName,
  sourceEncounterId = null,
  sourceAppointmentId = null,
  chartBasePath,
  buttonLabel = "Run home-care assessment",
  buttonClassName = "btn-secondary text-sm px-3 py-2",
  compact = false,
  onAssessmentCreated,
}) => {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [latestAssessmentId, setLatestAssessmentId] = useState<string | null>(null);
  const [templateKey, setTemplateKey] = useState<HomeCareAssessmentTemplateKey>("initial_home_visit");
  const [visitContext, setVisitContext] = useState(getHomeCareAssessmentTemplate("initial_home_visit").suggestedVisitContext);
  const [overallConcernLevel, setOverallConcernLevel] = useState<HomeCareConcernLevel>("low");
  const [reviewTimeframe, setReviewTimeframe] = useState(getHomeCareAssessmentTemplate("initial_home_visit").defaultReviewTimeframe);
  const [carePrioritySummary, setCarePrioritySummary] = useState("");
  const [escalationAction, setEscalationAction] = useState("");
  const [printableSummary, setPrintableSummary] = useState("");
  const [domains, setDomains] = useState<DomainDraft[]>(buildTemplateDomains("initial_home_visit"));

  const chartRiskPath = useMemo(() => (chartBasePath ? `${chartBasePath}?tab=risk` : ""), [chartBasePath]);
  const selectedTemplate = useMemo(() => getHomeCareAssessmentTemplate(templateKey), [templateKey]);

  const resetDraft = () => {
    const nextTemplate = getHomeCareAssessmentTemplate("initial_home_visit");
    setTemplateKey(nextTemplate.key);
    setVisitContext(nextTemplate.suggestedVisitContext);
    setOverallConcernLevel("low");
    setReviewTimeframe(nextTemplate.defaultReviewTimeframe);
    setCarePrioritySummary("");
    setEscalationAction("");
    setPrintableSummary("");
    setDomains(buildTemplateDomains(nextTemplate.key));
  };

  const updateDomain = (index: number, next: Partial<DomainDraft>) => {
    setDomains((current) => current.map((item, itemIndex) => (itemIndex === index ? { ...item, ...next } : item)));
  };

  const applyTemplate = (nextTemplateKey: HomeCareAssessmentTemplateKey) => {
    const nextTemplate = getHomeCareAssessmentTemplate(nextTemplateKey);
    setTemplateKey(nextTemplateKey);
    setVisitContext(nextTemplate.suggestedVisitContext);
    setReviewTimeframe(nextTemplate.defaultReviewTimeframe);
    setPrintableSummary("");
    setDomains(buildTemplateDomains(nextTemplateKey));
  };

  const handleSave = async () => {
    setBusy(true);
    setErr(null);
    setMsg(null);

    const populatedDomains = domains.filter((domain) => domain.summary.trim());
    if (populatedDomains.length === 0) {
      setErr("Add at least one completed assessment domain before saving.");
      setBusy(false);
      return;
    }
    if (!carePrioritySummary.trim()) {
      setErr("Add a nursing priority summary before saving.");
      setBusy(false);
      return;
    }

    try {
      const highConcernCount = populatedDomains.filter((item) => item.concernLevel === "high").length;
      const urgentConcernCount = populatedDomains.filter((item) => item.concernLevel === "urgent").length;

      const result = await createManualRiskAssessment({
        templateKey,
        patientId,
        practiceId,
        clinicianUid,
        clinicianDisplayName,
        sourceEncounterId,
        sourceAppointmentId,
        questionnairePayload: {
          visitContext: visitContext.trim() || null,
          domains: populatedDomains,
        },
        scorePayload: {
          domainCount: populatedDomains.length,
          highConcernCount,
          urgentConcernCount,
        },
        resultSummary: {
          templateKey,
          overallConcernLevel,
          reviewTimeframe: reviewTimeframe.trim() || null,
          carePrioritySummary: carePrioritySummary.trim() || null,
          escalationAction: escalationAction.trim() || null,
        },
        printableSummary:
          printableSummary.trim() ||
          [
            `Assessment template: ${selectedTemplate.label}`,
            `Overall concern: ${formatConcernLevel(overallConcernLevel)}`,
            reviewTimeframe.trim() ? `Review timeframe: ${reviewTimeframe.trim()}` : "",
            carePrioritySummary.trim() ? `Priority summary: ${carePrioritySummary.trim()}` : "",
            escalationAction.trim() ? `Escalation action: ${escalationAction.trim()}` : "",
          ]
            .filter(Boolean)
            .join("\n"),
      });

      setLatestAssessmentId(result.assessmentId);
      setMsg("Home-care assessment saved.");
      onAssessmentCreated?.(result);
      resetDraft();
      setOpen(false);
    } catch (e: any) {
      console.error(e);
      setErr(toPlainLanguageOutcomeMessage(e, "We could not save that home-care assessment just now."));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className={compact ? "space-y-2" : "rounded-xl border border-ink-200 bg-white p-4 space-y-3"}>
      {!compact ? (
        <div>
          <div className="section-title">Home-care assessment</div>
          <div className="section-subtitle">Structured nurse-led assessment for safety, support, and escalation planning in the home.</div>
        </div>
      ) : null}

      {msg ? <div className="text-xs text-emerald-700">{msg}</div> : null}
      {err ? <div className="text-xs text-rose-600">{err}</div> : null}

      <div className="flex flex-wrap items-center gap-2">
        <button type="button" className={buttonClassName} onClick={() => setOpen(true)} disabled={busy}>
          {busy ? "Saving…" : buttonLabel}
        </button>
        {chartRiskPath ? (
          <Link to={chartRiskPath} className="text-xs text-brand-500 hover:underline">
            Open Home-Care Assessments tab
          </Link>
        ) : null}
        {latestAssessmentId ? <span className="text-xs text-ink-500">Latest ID: <span className="font-mono">{latestAssessmentId}</span></span> : null}
      </div>

      {open ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4">
          <div className="w-full max-w-4xl rounded-xl border border-ink-200 bg-white p-4 shadow-lift space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="section-title">Home-Care Assessment</div>
                <div className="text-xs text-ink-500">Capture the main in-home nursing concerns, support priorities, and escalation actions for this visit.</div>
              </div>
              <button type="button" className="btn-secondary" onClick={() => setOpen(false)} disabled={busy}>
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="label">Assessment template</label>
                <select className="input" value={templateKey} onChange={(e) => applyTemplate(e.target.value as HomeCareAssessmentTemplateKey)}>
                  {HOME_CARE_ASSESSMENT_TEMPLATES.map((template) => (
                    <option key={template.key} value={template.key}>
                      {template.label}
                    </option>
                  ))}
                </select>
                <p className="mt-2 text-xs text-ink-500">{selectedTemplate.description}</p>
              </div>
              <div>
                <label className="label">Visit context</label>
                <input className="input" value={visitContext} onChange={(e) => setVisitContext(e.target.value)} placeholder="e.g. post-discharge review, wound follow-up, palliative support visit" />
              </div>
              <div>
                <label className="label">Overall concern level</label>
                <select className="input" value={overallConcernLevel} onChange={(e) => setOverallConcernLevel(e.target.value as HomeCareConcernLevel)}>
                  {concernOptions().map((option) => (
                    <option key={option} value={option}>
                      {formatConcernLevel(option)}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Recommended review timeframe</label>
                <input className="input" value={reviewTimeframe} onChange={(e) => setReviewTimeframe(e.target.value)} placeholder="e.g. Within 48 hours, next scheduled visit, urgent escalation today" />
              </div>
              <div>
                <label className="label">Escalation action</label>
                <input className="input" value={escalationAction} onChange={(e) => setEscalationAction(e.target.value)} placeholder="e.g. GP review requested, family updated, urgent escalation to ED" />
              </div>
            </div>

            <div>
              <label className="label">Nursing priority summary</label>
              <textarea className="input min-h-[96px]" value={carePrioritySummary} onChange={(e) => setCarePrioritySummary(e.target.value)} placeholder="Main priorities for ongoing nursing care, monitoring, or support after this assessment." />
            </div>

            <div className="space-y-3">
              <div className="text-sm font-semibold text-ink-900">Assessment domains</div>
              {domains.map((domain, index) => (
                <div key={domain.key} className="rounded-lg border border-ink-200 p-3 space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-[1fr_180px] gap-3">
                    <div className="text-sm font-medium text-ink-900">{domain.title}</div>
                    <div>
                      <label className="label">Concern level</label>
                      <select className="input" value={domain.concernLevel} onChange={(e) => updateDomain(index, { concernLevel: e.target.value as HomeCareConcernLevel })}>
                        {concernOptions().map((option) => (
                          <option key={option} value={option}>
                            {formatConcernLevel(option)}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="label">Assessment note</label>
                    <textarea className="input min-h-[88px]" value={domain.summary} onChange={(e) => updateDomain(index, { summary: e.target.value })} placeholder={`Document what was identified for ${domain.title.toLowerCase()}, what nursing support was provided, and what follow-up is needed.`} />
                  </div>
                </div>
              ))}
            </div>

            <div>
              <label className="label">Printable summary text</label>
              <textarea className="input min-h-[120px]" value={printableSummary} onChange={(e) => setPrintableSummary(e.target.value)} placeholder="Optional narrative summary for the assessment record and future printable care summary." />
            </div>

            <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
              This creates a clinician-only home-care assessment record and mirrors a summary entry into the patient chart Documents section. PDF generation remains pending until a later report-generation workflow is added.
            </div>

            <div className="flex items-center justify-end gap-2">
              <button type="button" className="btn-secondary" onClick={() => setOpen(false)} disabled={busy}>
                Cancel
              </button>
              <button type="button" className="btn-primary" onClick={() => void handleSave()} disabled={busy}>
                {busy ? "Saving…" : "Save assessment"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default HomeCareAssessmentLauncher;
