import React, { useCallback, useEffect, useMemo, useState } from "react";
import { addDoc, collection, doc, getDocs, limit, orderBy, query, serverTimestamp, updateDoc, where } from "firebase/firestore";
import { Link } from "react-router-dom";
import { db } from "../firebaseConfig";
import { useAuth } from "../contexts/AuthContext";
import { MainLayout } from "./MainLayout";
import { formatMoney, getDefaultCurrency } from "../lib/billing";
import { downloadEvidencePackPdf, downloadInvoicePdf } from "../lib/billingPdf";
import {
  buildServiceInvoiceNumber,
  evidencePackPrintPath,
  formatFundingPathwayLabel,
  formatInvoiceStatusLabel,
  formatTaxTreatmentLabel,
  FundingPathway,
  getServiceItemById,
  InvoiceStatus,
  isValidAbn,
  invoicePrintPath,
  RecipientType,
  ServiceInvoiceRecord,
  SUPPORT_AT_HOME_SERVICE_CATALOGUE,
  TaxTreatment,
} from "../lib/billingFacilitation";

type PatientLite = {
  id: string;
  fullName: string;
  billingType?: string | null;
};

type AppointmentLite = {
  id: string;
  patientId: string;
  patientName?: string | null;
  scheduledAt?: any;
  durationMinutes?: number | null;
  status?: string | null;
};

function todayDateInput() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

function nowTimeInput() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function addDays(dateInput: string, days: number) {
  const date = new Date(`${dateInput}T00:00:00`);
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

function isValidEmail(input: string) {
  const value = String(input || "").trim();
  if (!value) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function toDateMaybe(value: any): Date | null {
  try {
    if (!value) return null;
    if (typeof value?.toDate === "function") return value.toDate();
    if (typeof value?.seconds === "number") return new Date(value.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

const NurseBillingPage: React.FC = () => {
  const { user, currentUserData, normalizedRole } = useAuth() as any;
  const canUse = normalizedRole === "clinician";
  const [patients, setPatients] = useState<PatientLite[]>([]);
  const [appointments, setAppointments] = useState<AppointmentLite[]>([]);
  const [records, setRecords] = useState<ServiceInvoiceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const [patientId, setPatientId] = useState("");
  const [appointmentId, setAppointmentId] = useState("");
  const [fundingPathway, setFundingPathway] = useState<FundingPathway>("support_at_home");
  const [serviceGroupFilter, setServiceGroupFilter] = useState("all");
  const [serviceFundingFilter, setServiceFundingFilter] = useState("all");
  const [favouritesOnly, setFavouritesOnly] = useState(false);
  const [serviceItemId, setServiceItemId] = useState(SUPPORT_AT_HOME_SERVICE_CATALOGUE[0].id);
  const [serviceDate, setServiceDate] = useState(todayDateInput());
  const [serviceStartTime, setServiceStartTime] = useState(nowTimeInput());
  const [durationMinutes, setDurationMinutes] = useState(String(SUPPORT_AT_HOME_SERVICE_CATALOGUE[0].defaultDurationMinutes));
  const [quantity, setQuantity] = useState("1");
  const [unitPriceDollars, setUnitPriceDollars] = useState("0.00");
  const [invoiceDate, setInvoiceDate] = useState(todayDateInput());
  const [dueDate, setDueDate] = useState(addDays(todayDateInput(), 7));
  const [taxTreatment, setTaxTreatment] = useState<TaxTreatment>("tax_to_be_confirmed");
  const [invoiceDescription, setInvoiceDescription] = useState("");
  const [clinicalServiceNotes, setClinicalServiceNotes] = useState("");
  const [confirmationMethod, setConfirmationMethod] = useState("Visit completed and confirmed by nurse");
  const [recipientName, setRecipientName] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [recipientType, setRecipientType] = useState<RecipientType>("care_manager");
  const [selectedRecipientPresetId, setSelectedRecipientPresetId] = useState("");
  const [billingAccuracyConfirmed, setBillingAccuracyConfirmed] = useState(false);
  const [scopeAlignmentConfirmed, setScopeAlignmentConfirmed] = useState(false);
  const [boundaryAcknowledged, setBoundaryAcknowledged] = useState(false);

  const selectedPatient = useMemo(() => patients.find((row) => row.id === patientId) || null, [patientId, patients]);
  const selectedService = useMemo(() => getServiceItemById(serviceItemId), [serviceItemId]);
  const favouriteServiceIds = useMemo(
    () => (Array.isArray(currentUserData?.billingFavouriteServiceItemIds) ? currentUserData.billingFavouriteServiceItemIds : []),
    [currentUserData?.billingFavouriteServiceItemIds]
  );
  const recipientPresets = useMemo(
    () => (Array.isArray(currentUserData?.billingRecipientPresets) ? currentUserData.billingRecipientPresets : []),
    [currentUserData?.billingRecipientPresets]
  );
  const serviceGroupOptions = useMemo(
    () =>
      Array.from(new Set(SUPPORT_AT_HOME_SERVICE_CATALOGUE.map((item) => `${item.groupCode}|${item.groupTitle}`))).map((value) => {
        const [groupCode, groupTitle] = value.split("|");
        return { groupCode, groupTitle };
      }),
    []
  );
  const serviceFundingOptions = useMemo(
    () => Array.from(new Set(SUPPORT_AT_HOME_SERVICE_CATALOGUE.map((item) => item.fundingGuidance))),
    []
  );
  const visibleServices = useMemo(
    () =>
      SUPPORT_AT_HOME_SERVICE_CATALOGUE.filter((item) => {
        if (serviceGroupFilter !== "all" && item.groupCode !== serviceGroupFilter) return false;
        if (serviceFundingFilter !== "all" && item.fundingGuidance !== serviceFundingFilter) return false;
        if (favouritesOnly && !favouriteServiceIds.includes(item.id)) return false;
        return true;
      }),
    [favouriteServiceIds, favouritesOnly, serviceFundingFilter, serviceGroupFilter]
  );
  const filteredAppointments = useMemo(
    () => appointments.filter((row) => row.patientId === patientId && row.status === "completed"),
    [appointments, patientId]
  );
  const billingReadiness = useMemo(() => {
    const missing: string[] = [];
    if (!currentUserData?.billingBusinessName?.trim()) missing.push("business or trading name");
    if (!currentUserData?.billingAbn?.trim()) missing.push("ABN");
    else if (!isValidAbn(currentUserData.billingAbn)) missing.push("valid ABN");
    if (!currentUserData?.billingEmail?.trim() || !isValidEmail(currentUserData.billingEmail)) missing.push("valid billing email");
    if (!currentUserData?.billingAddress?.trim()) missing.push("billing address");
    if (!currentUserData?.ahpraRegistrationNumber?.trim()) missing.push("AHPRA registration number");
    return missing;
  }, [currentUserData]);

  const refresh = useCallback(async () => {
    if (!canUse || !user?.uid) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setErr(null);
    try {
      const practiceId = String(currentUserData?.practiceId || "").trim();
      const patientQuery = practiceId
        ? query(collection(db, "patients"), where("practiceId", "==", practiceId), limit(500))
        : query(collection(db, "patients"), where("practiceId", "==", "__missing_practice__"), limit(1));
      const [patientSnap, appointmentSnap, invoiceSnap] = await Promise.all([
        getDocs(patientQuery),
        getDocs(query(collection(db, "appointments"), where("clinicianId", "==", user.uid), orderBy("scheduledAt", "desc"), limit(200))),
        getDocs(query(collection(db, "serviceInvoices"), where("nurseUid", "==", user.uid), orderBy("createdAt", "desc"), limit(200))),
      ]);

      const nextPatients = patientSnap.docs
        .map((d) => ({
          id: d.id,
          fullName: String((d.data() as any)?.fullName || "Unnamed"),
          billingType: (d.data() as any)?.billingType ?? null,
        }))
        .sort((a, b) => a.fullName.localeCompare(b.fullName));
      setPatients(nextPatients);
      if (!patientId && nextPatients[0]) setPatientId(nextPatients[0].id);

      setAppointments(
        appointmentSnap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        })) as AppointmentLite[]
      );
      setRecords(
        invoiceSnap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        })) as ServiceInvoiceRecord[]
      );
    } catch (e: any) {
      console.error(e);
      setErr(e?.message || "Failed to load billing facilitation data.");
    } finally {
      setLoading(false);
    }
  }, [canUse, currentUserData?.practiceId, user?.uid, patientId]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  useEffect(() => {
    if (!selectedService) return;
    setDurationMinutes(String(selectedService.defaultDurationMinutes));
    setInvoiceDescription((current) => (current.trim() ? current : selectedService.invoiceDescriptionGuidance));
    setClinicalServiceNotes((current) => (current.trim() ? current : selectedService.nurseSummaryHint));
  }, [selectedService]);

  useEffect(() => {
    if (!visibleServices.length) return;
    if (!visibleServices.some((item) => item.id === serviceItemId)) {
      setServiceItemId(visibleServices[0].id);
    }
  }, [serviceItemId, visibleServices]);

  useEffect(() => {
    setDueDate((current) => {
      if (!current) return addDays(invoiceDate, 7);
      return current;
    });
  }, [invoiceDate]);

  const createInvoice = async () => {
    if (!user?.uid || !selectedPatient || !selectedService) return;
    setBusy(true);
    setErr(null);
    setMsg(null);

    const unitPriceCents = Math.round(Number(unitPriceDollars || "0") * 100);
    const quantityNumber = Math.max(1, Number(quantity || "1"));
    const durationNumber = Math.max(1, Number(durationMinutes || String(selectedService.defaultDurationMinutes)));

    if (billingReadiness.length > 0) {
      setErr(`Complete your billing profile before creating invoices: ${billingReadiness.join(", ")}.`);
      setBusy(false);
      return;
    }
    if (unitPriceCents <= 0) {
      setErr("Enter a valid service fee.");
      setBusy(false);
      return;
    }
    if (!invoiceDescription.trim()) {
      setErr("Enter an invoice description for the invoice and evidence pack.");
      setBusy(false);
      return;
    }
    if (!clinicalServiceNotes.trim()) {
      setErr("Enter a clinical documentation note for the service record.");
      setBusy(false);
      return;
    }
    if (recipientEmail.trim() && !isValidEmail(recipientEmail)) {
      setErr("Enter a valid relay recipient email address.");
      setBusy(false);
      return;
    }
    if (!billingAccuracyConfirmed || !scopeAlignmentConfirmed || !boundaryAcknowledged) {
      setErr("All nurse declarations and the platform-boundary acknowledgement must be confirmed before creating an invoice.");
      setBusy(false);
      return;
    }

    const appointment = filteredAppointments.find((row) => row.id === appointmentId) || null;
    const invoiceNumber = buildServiceInvoiceNumber();
    const totalCents = unitPriceCents * quantityNumber;
    const createdIso = new Date().toISOString();
    const pathwayLabel = formatFundingPathwayLabel(fundingPathway);
    const bookingSummary = appointment
      ? `Completed booking ${appointment.id} for ${selectedPatient.fullName} on ${toDateMaybe(appointment.scheduledAt)?.toLocaleString() || serviceDate}.`
      : `Service logged directly against ${selectedPatient.fullName} for ${serviceDate}${serviceStartTime ? ` at ${serviceStartTime}` : ""}.`;

    const payload = {
      invoiceNumber,
      nurseUid: user.uid,
      practiceId: currentUserData?.practiceId || null,
      patientId: selectedPatient.id,
      patientName: selectedPatient.fullName,
      appointmentId: appointment?.id || null,
      status: "ready_to_issue",
      fundingPathway,
      currency: getDefaultCurrency(),
      invoiceDate,
      dueDate: dueDate || null,
      taxTreatment,
      serviceItemId: selectedService.id,
      serviceCode: selectedService.code,
      serviceTitle: selectedService.title,
      serviceCategory: selectedService.category,
      serviceDate,
      serviceStartTime: serviceStartTime || null,
      durationMinutes: durationNumber,
      quantity: quantityNumber,
      unitLabel: selectedService.unitLabel,
      unitPriceCents,
      totalCents,
      invoiceDescription: invoiceDescription.trim(),
      clinicalServiceNotes: clinicalServiceNotes.trim(),
      serviceSummary: invoiceDescription.trim(),
      visitConfirmation: {
        confirmed: true,
        confirmationMethod: confirmationMethod.trim() || "Visit completed and confirmed by nurse",
        confirmedAt: createdIso,
      },
      nurseSnapshot: {
        displayName: currentUserData?.displayName || currentUserData?.email || user.email || "Nurse",
        designation: currentUserData?.designation || null,
        nurseType: currentUserData?.nurseType || null,
        ahpraRegistrationNumber: currentUserData?.ahpraRegistrationNumber || null,
        businessName: currentUserData?.billingBusinessName || null,
        abn: currentUserData?.billingAbn || null,
        billingEmail: currentUserData?.billingEmail || currentUserData?.email || null,
        billingPhone: currentUserData?.billingPhone || currentUserData?.phoneNumber || null,
        billingAddress: currentUserData?.billingAddress || null,
      },
      clientFundingSnapshot: {
        billingType: selectedPatient.billingType || null,
        pathwayLabel,
        nominatedPayerName: recipientName.trim() || null,
        nominatedPayerEmail: recipientEmail.trim().toLowerCase() || null,
        recipientType,
      },
      evidencePack: {
        bookingRecordSummary: bookingSummary,
        credentialsSummary: `${currentUserData?.displayName || "Nurse"} · ${currentUserData?.designation || currentUserData?.nurseType || "Nurse"} · AHPRA ${currentUserData?.ahpraRegistrationNumber || "Not recorded"} · ABN ${currentUserData?.billingAbn || "Not recorded"}`,
        visitConfirmationSummary: `Service confirmed by nurse. ${confirmationMethod.trim() || "Visit completed and confirmed by nurse"}.`,
        serviceSummary: invoiceDescription.trim(),
        documentationNoteSummary: clinicalServiceNotes.trim(),
        declarationSummary:
          "The issuing nurse confirms that the service was completed, documented accurately, aligned with scope of practice, and prepared for billing by the nurse's own authority.",
      },
      declarations: {
        billingAccuracyConfirmed: true,
        scopeAlignmentConfirmed: true,
        boundaryAcknowledged: true,
        declaredAt: createdIso,
      },
      relay: recipientEmail.trim()
        ? {
            recipientName: recipientName.trim() || null,
            recipientEmail: recipientEmail.trim().toLowerCase(),
            recipientType,
            channel: "email",
            lastRelayedAt: null,
            relayCount: 0,
          }
        : null,
      auditTrail: [
        {
          type: "created",
          at: createdIso,
          actorUid: user.uid,
          note: "Invoice record created and marked ready to issue.",
        },
      ],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    try {
      await addDoc(collection(db, "serviceInvoices"), payload);
      setMsg("Provider-ready invoice and evidence pack created.");
      setRecipientName("");
      setRecipientEmail("");
      setBillingAccuracyConfirmed(false);
      setScopeAlignmentConfirmed(false);
      setBoundaryAcknowledged(false);
      setInvoiceDescription(selectedService.invoiceDescriptionGuidance);
      setClinicalServiceNotes(selectedService.nurseSummaryHint);
      await refresh();
    } catch (e: any) {
      console.error(e);
      setErr(e?.message || "Failed to create invoice.");
    } finally {
      setBusy(false);
    }
  };

  const relayInvoice = async (record: ServiceInvoiceRecord) => {
    setErr(null);
    setMsg(null);
    const invoiceUrl = `${window.location.origin}${invoicePrintPath(record.id)}`;
    const evidenceUrl = `${window.location.origin}${evidencePackPrintPath(record.id)}`;
    const recipient = record.relay?.recipientEmail || "";
    if (!recipient) {
      setErr("Add a relay recipient email before sending.");
      return;
    }
    const subject = encodeURIComponent(`NurseConnectCare invoice ${record.invoiceNumber}`);
    const body = encodeURIComponent(
      [
        `Please find the invoice and evidence pack links below for ${record.patientName}.`,
        "",
        `Invoice: ${invoiceUrl}`,
        `Evidence pack: ${evidenceUrl}`,
        "",
        "NurseConnectCare is acting only as a delivery conduit on the nurse's instruction. It is not processing a claim, holding funds, or determining eligibility.",
      ].join("\n")
    );

    try {
      const relayedAt = new Date().toISOString();
      await updateDoc(doc(db, "serviceInvoices", record.id), {
        relay: {
          ...(record.relay || {}),
          lastRelayedAt: relayedAt,
          channel: "email",
          relayCount: Number(record.relay?.relayCount || 0) + 1,
        },
        status: "relayed",
        auditTrail: [
          ...((record.auditTrail || []) as any[]),
          {
            type: "relayed",
            at: relayedAt,
            actorUid: user?.uid || "",
            note: `Invoice relay prepared for ${record.relay?.recipientEmail || "recipient"}.`,
          },
        ],
        updatedAt: serverTimestamp(),
      });
      window.open(`mailto:${recipient}?subject=${subject}&body=${body}`, "_blank");
      setMsg("Relay email prepared. NurseConnectCare only relayed the invoice and evidence links on your instruction.");
      await refresh();
    } catch (e: any) {
      console.error(e);
      setErr(e?.message || "Failed to prepare relay action.");
    }
  };

  const updateInvoiceStatus = async (record: ServiceInvoiceRecord, status: InvoiceStatus, note: string) => {
    setErr(null);
    setMsg(null);
    try {
      await updateDoc(doc(db, "serviceInvoices", record.id), {
        status,
        auditTrail: [
          ...((record.auditTrail || []) as any[]),
          {
            type: "status_changed",
            at: new Date().toISOString(),
            actorUid: user?.uid || "",
            note,
          },
        ],
        updatedAt: serverTimestamp(),
      });
      setMsg(`Invoice marked ${formatInvoiceStatusLabel(status).toLowerCase()}.`);
      await refresh();
    } catch (e: any) {
      console.error(e);
      setErr(e?.message || "Failed to update invoice status.");
    }
  };

  const toggleFavouriteService = async (serviceId: string) => {
    if (!user?.uid) return;
    setErr(null);
    setMsg(null);
    const next = favouriteServiceIds.includes(serviceId)
      ? favouriteServiceIds.filter((id: string) => id !== serviceId)
      : [...favouriteServiceIds, serviceId];
    try {
      await updateDoc(doc(db, "users", user.uid), {
        billingFavouriteServiceItemIds: next,
        updatedAt: serverTimestamp(),
      });
      setMsg(favouriteServiceIds.includes(serviceId) ? "Service removed from favourites." : "Service saved to favourites.");
    } catch (e: any) {
      console.error(e);
      setErr(e?.message || "Failed to update favourites.");
    }
  };

  const applyRecipientPreset = (presetId: string) => {
    setSelectedRecipientPresetId(presetId);
    const preset = recipientPresets.find((item: any) => item.id === presetId);
    if (!preset) return;
    setRecipientName(String(preset.recipientName || ""));
    setRecipientEmail(String(preset.recipientEmail || ""));
    setRecipientType((preset.recipientType || "care_manager") as RecipientType);
  };

  const saveRecipientPreset = async () => {
    if (!user?.uid) return;
    if (!recipientName.trim() || !recipientEmail.trim() || !isValidEmail(recipientEmail)) {
      setErr("Enter a valid recipient name and email before saving a preset.");
      return;
    }
    setErr(null);
    setMsg(null);
    const presetId = `${recipientType}-${recipientEmail.trim().toLowerCase()}`;
    const nextPreset = {
      id: presetId,
      label: recipientName.trim(),
      recipientName: recipientName.trim(),
      recipientEmail: recipientEmail.trim().toLowerCase(),
      recipientType,
    };
    const next = [
      ...recipientPresets.filter((item: any) => item.id !== presetId),
      nextPreset,
    ].slice(-20);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        billingRecipientPresets: next,
        updatedAt: serverTimestamp(),
      });
      setSelectedRecipientPresetId(presetId);
      setMsg("Recipient preset saved.");
    } catch (e: any) {
      console.error(e);
      setErr(e?.message || "Failed to save recipient preset.");
    }
  };

  const deleteRecipientPreset = async (presetId: string) => {
    if (!user?.uid) return;
    setErr(null);
    setMsg(null);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        billingRecipientPresets: recipientPresets.filter((item: any) => item.id !== presetId),
        updatedAt: serverTimestamp(),
      });
      if (selectedRecipientPresetId === presetId) setSelectedRecipientPresetId("");
      setMsg("Recipient preset removed.");
    } catch (e: any) {
      console.error(e);
      setErr(e?.message || "Failed to remove recipient preset.");
    }
  };

  if (!canUse) {
    return (
      <MainLayout>
        <div className="text-sm text-rose-600">Access denied.</div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">Billing facilitation</h1>
            <p className="section-subtitle">
              Create nurse-owned invoices and evidence packs for Support at Home and private-pay services. NurseConnectCare does not process payments, submit claims, approve eligibility, or handle funds.
            </p>
          </div>
          <Link to="/profile" className="btn-secondary">
            Billing profile
          </Link>
        </div>

        {err ? <div className="text-sm text-rose-600">{err}</div> : null}
        {msg ? <div className="text-sm text-emerald-700">{msg}</div> : null}

        <div className={`rounded-2xl border p-4 ${billingReadiness.length === 0 ? "border-emerald-200 bg-emerald-50" : "border-amber-200 bg-amber-50"}`}>
          <div className="text-sm font-semibold text-ink-900">Billing readiness</div>
          {billingReadiness.length === 0 ? (
            <div className="mt-1 text-sm text-emerald-800">
              Your billing profile is ready for provider-facing invoices and evidence packs.
            </div>
          ) : (
            <div className="mt-1 text-sm text-amber-900">
              Complete your profile before issuing invoices: {billingReadiness.join(", ")}.
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-[1.05fr_0.95fr] gap-4">
          <div className="card p-4 space-y-4">
            <div>
              <div className="section-title">Log completed service</div>
              <div className="section-subtitle">Capture the completed service, funding pathway, and nurse declarations before generating an invoice.</div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="label">Client</label>
                <select className="input" value={patientId} onChange={(e) => setPatientId(e.target.value)}>
                  {patients.map((patient) => (
                    <option key={patient.id} value={patient.id}>
                      {patient.fullName}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Funding pathway</label>
                <select className="input" value={fundingPathway} onChange={(e) => setFundingPathway(e.target.value as FundingPathway)}>
                  <option value="support_at_home">Support at Home</option>
                  <option value="private_pay">Private pay</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="label">Service group</label>
                <select className="input" value={serviceGroupFilter} onChange={(e) => setServiceGroupFilter(e.target.value)}>
                  <option value="all">All groups</option>
                  {serviceGroupOptions.map((item) => (
                    <option key={item.groupCode} value={item.groupCode}>
                      {item.groupCode} · {item.groupTitle}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Funding guidance</label>
                <select className="input" value={serviceFundingFilter} onChange={(e) => setServiceFundingFilter(e.target.value)}>
                  <option value="all">All guidance</option>
                  {serviceFundingOptions.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <label className="flex items-center gap-3 text-sm text-ink-700">
              <input type="checkbox" checked={favouritesOnly} onChange={(e) => setFavouritesOnly(e.target.checked)} />
              <span>Show favourite services only</span>
            </label>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="label">Service</label>
                <select className="input" value={serviceItemId} onChange={(e) => setServiceItemId(e.target.value)}>
                  {visibleServices.length ? (
                    visibleServices.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.code} · {item.title}
                      </option>
                    ))
                  ) : (
                    <option value="">No services match the current filters</option>
                  )}
                </select>
              </div>
              <div>
                <label className="label">Link completed booking</label>
                <select className="input" value={appointmentId} onChange={(e) => setAppointmentId(e.target.value)}>
                  <option value="">No booking linked</option>
                  {filteredAppointments.map((appointment) => (
                    <option key={appointment.id} value={appointment.id}>
                      {appointment.id} · {toDateMaybe(appointment.scheduledAt)?.toLocaleString() || "Completed visit"}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {selectedService ? (
              <div className="rounded-2xl border border-sky-200 bg-sky-50 p-4 space-y-3">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-ink-900">
                      {selectedService.groupCode} · {selectedService.groupTitle}
                    </div>
                    <div className="text-xs text-ink-600">
                      {selectedService.code} · {selectedService.category}
                    </div>
                  </div>
                  <div className="rounded-full bg-white px-3 py-1 text-xs font-medium text-sky-800">
                    Funding guidance: {selectedService.fundingGuidance}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    className="btn-secondary text-xs px-3 py-2"
                    onClick={() => void toggleFavouriteService(selectedService.id)}
                  >
                    {favouriteServiceIds.includes(selectedService.id) ? "Remove favourite" : "Save as favourite"}
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-ink-700">
                  <div>
                    <div className="font-medium text-ink-900">Who can provide this</div>
                    <div className="mt-1">{selectedService.eligibleNurseTypes.join(", ")}</div>
                  </div>
                  <div>
                    <div className="font-medium text-ink-900">Delivery modes</div>
                    <div className="mt-1">{selectedService.deliveryModes.join(", ")}</div>
                  </div>
                </div>
                <div className="text-sm text-ink-700">
                  <div className="font-medium text-ink-900">Invoice description guidance</div>
                  <div className="mt-1">{selectedService.invoiceDescriptionGuidance}</div>
                </div>
                <div className="text-sm text-ink-700">
                  <div className="font-medium text-ink-900">Documentation prompt</div>
                  <div className="mt-1">{selectedService.nurseSummaryHint}</div>
                </div>
              </div>
            ) : null}

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <label className="label">Service date</label>
                <input type="date" className="input" value={serviceDate} onChange={(e) => setServiceDate(e.target.value)} />
              </div>
              <div>
                <label className="label">Start time</label>
                <input type="time" className="input" value={serviceStartTime} onChange={(e) => setServiceStartTime(e.target.value)} />
              </div>
              <div>
                <label className="label">Duration (minutes)</label>
                <input className="input" value={durationMinutes} onChange={(e) => setDurationMinutes(e.target.value.replace(/[^\d]/g, "").slice(0, 3))} />
              </div>
              <div>
                <label className="label">Quantity</label>
                <input className="input" value={quantity} onChange={(e) => setQuantity(e.target.value.replace(/[^\d]/g, "").slice(0, 2) || "1")} />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="label">Fee (AUD)</label>
                <input className="input" value={unitPriceDollars} onChange={(e) => setUnitPriceDollars(e.target.value.replace(/[^\d.]/g, ""))} placeholder="0.00" />
              </div>
              <div>
                <label className="label">Visit confirmation method</label>
                <input className="input" value={confirmationMethod} onChange={(e) => setConfirmationMethod(e.target.value)} />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="label">Invoice date</label>
                <input type="date" className="input" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
              </div>
              <div>
                <label className="label">Due date</label>
                <input type="date" className="input" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
              <div>
                <label className="label">Tax treatment</label>
                <select className="input" value={taxTreatment} onChange={(e) => setTaxTreatment(e.target.value as TaxTreatment)}>
                  <option value="tax_to_be_confirmed">Tax treatment to be confirmed</option>
                  <option value="gst_free">GST-free healthcare service</option>
                  <option value="gst_included">GST included</option>
                </select>
              </div>
            </div>

            <div>
              <label className="label">Invoice description</label>
              {selectedService ? (
                <div className="mb-2 text-xs text-ink-500">
                  Start with the invoice description guidance, then add the specific service details that were actually delivered.
                </div>
              ) : null}
              <textarea className="input min-h-[120px]" value={invoiceDescription} onChange={(e) => setInvoiceDescription(e.target.value)} />
            </div>

            <div>
              <label className="label">Clinical documentation note</label>
              {selectedService ? (
                <div className="mb-2 text-xs text-ink-500">
                  Use this area for nurse-facing documentation detail such as observations, education, interventions, and follow-up actions.
                </div>
              ) : null}
              <textarea className="input min-h-[120px]" value={clinicalServiceNotes} onChange={(e) => setClinicalServiceNotes(e.target.value)} />
            </div>

            <div className="rounded-2xl border border-ink-200 bg-sand-100/70 p-4 space-y-3">
              <div className="text-sm font-semibold">Relay recipient</div>
              <div className="text-xs text-ink-600">
                NurseConnectCare only relays invoice and evidence links on your instruction. It does not process claims, pay invoices, or act as a funding intermediary.
              </div>
              <div>
                <label className="label">Saved recipient preset</label>
                <select className="input" value={selectedRecipientPresetId} onChange={(e) => applyRecipientPreset(e.target.value)}>
                  <option value="">No preset selected</option>
                  {recipientPresets.map((preset: any) => (
                    <option key={preset.id} value={preset.id}>
                      {preset.label} · {preset.recipientEmail}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="label">Recipient type</label>
                  <select className="input" value={recipientType} onChange={(e) => setRecipientType(e.target.value as RecipientType)}>
                    <option value="care_manager">Care package manager</option>
                    <option value="provider_finance">Provider finance inbox</option>
                    <option value="xero">Xero address</option>
                    <option value="client">Client / carer</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="label">Recipient name</label>
                  <input className="input" value={recipientName} onChange={(e) => setRecipientName(e.target.value)} />
                </div>
                <div>
                  <label className="label">Recipient email</label>
                  <input className="input" value={recipientEmail} onChange={(e) => setRecipientEmail(e.target.value)} placeholder="finance@example.com" />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <button type="button" className="btn-secondary text-xs px-3 py-2" onClick={() => void saveRecipientPreset()}>
                  Save recipient preset
                </button>
                {selectedRecipientPresetId ? (
                  <button
                    type="button"
                    className="btn-secondary text-xs px-3 py-2"
                    onClick={() => void deleteRecipientPreset(selectedRecipientPresetId)}
                  >
                    Remove selected preset
                  </button>
                ) : null}
              </div>
            </div>

            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 space-y-3">
              <div className="text-sm font-semibold text-amber-900">Nurse declarations</div>
              <label className="flex items-start gap-3 text-sm text-amber-900">
                <input type="checkbox" checked={billingAccuracyConfirmed} onChange={(e) => setBillingAccuracyConfirmed(e.target.checked)} />
                <span>I confirm that the invoice details accurately reflect the service completed and that I am responsible for billing accuracy.</span>
              </label>
              <label className="flex items-start gap-3 text-sm text-amber-900">
                <input type="checkbox" checked={scopeAlignmentConfirmed} onChange={(e) => setScopeAlignmentConfirmed(e.target.checked)} />
                <span>I confirm that the service invoiced was delivered within my scope of practice and professional responsibilities.</span>
              </label>
              <label className="flex items-start gap-3 text-sm text-amber-900">
                <input type="checkbox" checked={boundaryAcknowledged} onChange={(e) => setBoundaryAcknowledged(e.target.checked)} />
                <span>I understand that NurseConnectCare only prepares and relays billing documents on my instruction. It does not process payments, approve claims, or determine funding eligibility.</span>
              </label>
            </div>

            <div className="flex items-center justify-between gap-3">
              <div className="text-sm text-ink-600">
                Total preview: <span className="font-semibold text-ink-900">{formatMoney(Math.round(Number(unitPriceDollars || "0") * 100) * Math.max(1, Number(quantity || "1")), getDefaultCurrency())}</span>
              </div>
              <button className="btn-primary" onClick={() => void createInvoice()} disabled={busy}>
                {busy ? "Creating..." : "Create invoice and evidence pack"}
              </button>
            </div>
          </div>

          <div className="card p-4 space-y-4">
            <div>
              <div className="section-title">Created invoices</div>
              <div className="section-subtitle">Download, print, or relay provider-ready invoices and evidence packs.</div>
            </div>

            {loading ? (
              <div className="text-sm text-ink-500">Loading billing facilitation records...</div>
            ) : records.length === 0 ? (
              <div className="text-sm text-ink-500">No service invoices created yet.</div>
            ) : (
              <div className="space-y-3">
                {records.map((record) => (
                  <div key={record.id} className="rounded-2xl border border-ink-200 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="text-sm font-semibold">{record.invoiceNumber}</div>
                        <div className="mt-1 text-xs text-ink-500">
                          {record.patientName} · {record.serviceTitle} · {record.serviceDate}
                        </div>
                        <div className="mt-1 text-xs text-ink-500">
                          {formatFundingPathwayLabel(record.fundingPathway)} · {formatMoney(record.totalCents, record.currency)}
                        </div>
                        <div className="mt-1 text-xs text-ink-500">
                          {record.serviceCode} · {record.serviceCategory}
                        </div>
                      </div>
                      <span className="chip">{formatInvoiceStatusLabel(record.status)}</span>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      <Link to={invoicePrintPath(record.id)} className="btn-secondary text-xs px-3 py-2">
                        Invoice
                      </Link>
                      <button className="btn-secondary text-xs px-3 py-2" onClick={() => downloadInvoicePdf(record)}>
                        Download invoice PDF
                      </button>
                      <Link to={evidencePackPrintPath(record.id)} className="btn-secondary text-xs px-3 py-2">
                        Evidence pack
                      </Link>
                      <button className="btn-secondary text-xs px-3 py-2" onClick={() => downloadEvidencePackPdf(record)}>
                        Download evidence PDF
                      </button>
                      <button className="btn-secondary text-xs px-3 py-2" onClick={() => void relayInvoice(record)}>
                        Relay by email
                      </button>
                      {record.status === "ready_to_issue" || record.status === "draft" ? (
                        <button
                          className="btn-secondary text-xs px-3 py-2"
                          onClick={() => void updateInvoiceStatus(record, "issued", "Invoice marked issued by nurse.")}
                        >
                          Mark issued
                        </button>
                      ) : null}
                      {record.status !== "paid" && record.status !== "cancelled" ? (
                        <button
                          className="btn-secondary text-xs px-3 py-2"
                          onClick={() => void updateInvoiceStatus(record, "paid", "Invoice marked paid manually by nurse.")}
                        >
                          Mark paid
                        </button>
                      ) : null}
                      {record.status !== "cancelled" ? (
                        <button
                          className="btn-secondary text-xs px-3 py-2"
                          onClick={() => void updateInvoiceStatus(record, "cancelled", "Invoice cancelled by nurse.")}
                        >
                          Cancel
                        </button>
                      ) : null}
                    </div>

                    {record.relay?.recipientEmail ? (
                      <div className="mt-3 text-xs text-ink-500">
                        Relay target: {record.relay.recipientName ? `${record.relay.recipientName} · ` : ""}
                        {record.relay.recipientEmail}
                        {record.relay.lastRelayedAt ? ` · Last relayed ${new Date(record.relay.lastRelayedAt).toLocaleString()}` : ""}
                        {record.relay.relayCount ? ` · Relayed ${record.relay.relayCount} time${record.relay.relayCount === 1 ? "" : "s"}` : ""}
                      </div>
                    ) : null}
                    <div className="mt-2 text-xs text-ink-500">
                      Tax treatment: {formatTaxTreatmentLabel(record.taxTreatment)}{record.dueDate ? ` · Due ${record.dueDate}` : ""}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default NurseBillingPage;
