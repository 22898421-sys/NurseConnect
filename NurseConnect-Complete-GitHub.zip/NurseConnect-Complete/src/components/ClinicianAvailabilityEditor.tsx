import React from "react";
import { AvailabilityDay, WEEKDAY_OPTIONS, formatDayAvailability } from "../lib/clinicianAvailability";

type Props = {
  availability: AvailabilityDay[];
  disabled?: boolean;
  onToggleDay: (dayOfWeek: number, enabled: boolean) => void;
  onChangeWindow: (
    dayOfWeek: number,
    windowIndex: number,
    field: "start" | "end",
    value: string
  ) => void;
  onAddWindow: (dayOfWeek: number) => void;
  onRemoveWindow: (dayOfWeek: number, windowIndex: number) => void;
};

export const ClinicianAvailabilityEditor: React.FC<Props> = ({
  availability,
  disabled = false,
  onToggleDay,
  onChangeWindow,
  onAddWindow,
  onRemoveWindow,
}) => {
  return (
    <div className="space-y-3">
      {WEEKDAY_OPTIONS.map((option) => {
        const day = availability.find((entry) => entry.dayOfWeek === option.dayOfWeek) || {
          dayOfWeek: option.dayOfWeek,
          enabled: false,
          windows: [],
        };

        return (
          <div key={option.dayOfWeek} className="rounded-xl border border-ink-200 p-3 space-y-2">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="font-medium">{option.label}</div>
                <div className="text-xs text-ink-500">{formatDayAvailability(day)}</div>
              </div>
              <label className="flex items-center gap-2 text-sm text-ink-700">
                <input
                  type="checkbox"
                  checked={day.enabled}
                  disabled={disabled}
                  onChange={(e) => onToggleDay(option.dayOfWeek, e.target.checked)}
                />
                Available
              </label>
            </div>

            {day.windows.map((window, index) => (
              <div key={`${option.dayOfWeek}-${index}`} className="flex flex-wrap items-center gap-2">
                <input
                  type="time"
                  className="input max-w-[160px]"
                  step={300}
                  value={window.start}
                  disabled={disabled}
                  onChange={(e) => onChangeWindow(option.dayOfWeek, index, "start", e.target.value)}
                />
                <span className="text-sm text-ink-500">to</span>
                <input
                  type="time"
                  className="input max-w-[160px]"
                  step={300}
                  value={window.end}
                  disabled={disabled}
                  onChange={(e) => onChangeWindow(option.dayOfWeek, index, "end", e.target.value)}
                />
                <button
                  type="button"
                  className="btn-secondary text-xs px-3 py-2"
                  disabled={disabled}
                  onClick={() => onRemoveWindow(option.dayOfWeek, index)}
                >
                  Remove
                </button>
              </div>
            ))}

            <button
              type="button"
              className="btn-secondary text-xs px-3 py-2"
              disabled={disabled}
              onClick={() => onAddWindow(option.dayOfWeek)}
            >
              Add time window
            </button>
          </div>
        );
      })}
    </div>
  );
};

export default ClinicianAvailabilityEditor;
