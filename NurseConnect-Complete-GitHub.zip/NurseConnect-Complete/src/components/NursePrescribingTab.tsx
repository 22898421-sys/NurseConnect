import React, { useCallback, useEffect, useMemo, useState } from "react";
import { collection, getDocs, limit, orderBy, query, where } from "firebase/firestore";
import { Link } from "react-router-dom";
import { db } from "../firebaseConfig";
import { createPrescriptionFromDraft } from "../lib/prescribing";
import {
  NP_MEDICATION_CATALOGUE,
  NP_MEDICATION_CATALOGUE_COUNT,
  NP_MEDICATION_CATALOGUE_GENERATED_AT,
  NP_MEDICATION_CATALOGUE_SOURCE,
  NP_PBS_BROWSE_INITIALS,
} from "../lib/npMedicationCatalogue";
import { prescriptionTrackingStatusLabel, PrescriptionRecord } from "../lib/prescriptions";

type Props = {
  patientId: string;
  practiceId: string;
  prescriberUid: string;
  prescriberLabel: string;
  sourceEncounterId?: string | null;
};

const emptyForm = {
  medicationId: "",
  medication: "",
  strength: "",
  dose: "",
  route: "",
  frequency: "",
  duration: "",
  quantity: "",
  repeats: "0",
  indication: "",
  notes: "",
};

const NursePrescribingTab: React.FC<Props> = ({ patientId, practiceId, prescriberUid, prescriberLabel, sourceEncounterId = null }) => {
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [records, setRecords] = useState<Array<PrescriptionRecord & { id: string }>>([]);

  const selectedMedication = useMemo(() => NP_MEDICATION_CATALOGUE.find((item) => item.id === form.medicationId) || null, [form.medicationId]);

  const loadRecords = useCallback(async () => {
    setLoading(true);
    try {
      const snap = await getDocs(
        query(collection(db, "prescriptions"), where("patientId", "==", patientId), orderBy("updatedAt", "desc"), limit(50))
      );
      setRecords(snap.docs.map((item) => ({ id: item.id, ...(item.data() as any) })));
    } catch (e: any) {
      setError(e?.message || "Failed to load prescriptions.");
    } finally {
      setLoading(false);
    }
  }, [patientId]);

  useEffect(() => {
    void loadRecords();
  }, [loadRecords]);

  const onSelectMedication = (id: string) => {
    const item = NP_MEDICATION_CATALOGUE.find((candidate) => candidate.id === id) || null;
    setForm((current) => ({
      ...current,
      medicationId: id,
      medication: item?.medicationName || current.medication,
      strength: item?.strength || current.strength,
      route: item?.route || current.route,
      frequency: item?.defaultFrequency || current.frequency,
      notes: item?.notes || current.notes,
    }));
  };

  const save = async () => {
    if (!form.medication.trim()) {
      setError("Medication name is required.");
      return;
    }
    if (!form.quantity.trim()) {
      setError("Quantity is required.");
      return;
    }
    if (!form.indication.trim()) {
      setError("Clinical indication is required.");
      return;
    }
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      const created = await createPrescriptionFromDraft({
        patientId,
        practiceId,
        prescriberUid,
        prescriberLabel,
        medication: form.medication,
        strength: form.strength,
        dose: form.dose,
        route: form.route,
        frequency: form.frequency,
        duration: form.duration,
        quantity: form.quantity,
        repeats: form.repeats,
        indication: form.indication,
        notes: form.notes,
        sourceEncounterId,
      });
      setForm(emptyForm);
      setMessage(`Prescription recorded for ${created.record.medication}.`);
      await loadRecords();
    } catch (e: any) {
      setError(e?.message || "Failed to record prescription.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-white p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-sm font-semibold">Nurse practitioner prescribing</div>
            <div className="mt-1 text-xs text-gray-600">
              Prescribing is available only to nurse practitioners and should be used within current scope-of-practice, jurisdictional rules, and PBS nurse practitioner eligibility.
            </div>
          </div>
          <a
            href={NP_MEDICATION_CATALOGUE_SOURCE.browseUrl}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-blue-700 hover:underline"
          >
            Open official PBS source
          </a>
        </div>
        <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
          {NP_MEDICATION_CATALOGUE_SOURCE.disclaimer}
        </div>
        <div className="mt-3 text-xs text-gray-600">
          This prescribing screen now relies on the official PBS nurse practitioner listing as the source of truth. The built-in list is intentionally not hard-coded to a guessed medication set.
        </div>
        <div className="mt-2 text-xs text-gray-500">
          Cached catalogue items: {NP_MEDICATION_CATALOGUE_COUNT}
          {NP_MEDICATION_CATALOGUE_GENERATED_AT ? ` · updated ${new Date(NP_MEDICATION_CATALOGUE_GENERATED_AT).toLocaleString()}` : " · no local PBS cache loaded yet"}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {NP_PBS_BROWSE_INITIALS.map((item) => (
            <a
              key={item.initial}
              href={item.url}
              target="_blank"
              rel="noreferrer"
              className="rounded-full border px-2 py-1 text-[11px] text-blue-700 hover:bg-blue-50"
            >
              {item.initial}
            </a>
          ))}
        </div>
      </div>

      <div className="rounded-xl border bg-white p-4 space-y-3">
        <div className="text-sm font-semibold">Create prescription</div>
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <label className="block text-xs text-gray-600 mb-1">Medication catalogue</label>
            {NP_MEDICATION_CATALOGUE.length > 0 ? (
              <>
                <select className="w-full border rounded px-3 py-2 text-sm" value={form.medicationId} onChange={(e) => onSelectMedication(e.target.value)}>
                  <option value="">Select a medication</option>
                  {NP_MEDICATION_CATALOGUE.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.medicationName}{item.strength ? ` ${item.strength}` : ""}
                    </option>
                  ))}
                </select>
                {selectedMedication ? <div className="mt-1 text-xs text-gray-500">{selectedMedication.notes}</div> : null}
              </>
            ) : (
              <div className="rounded-lg border border-dashed px-3 py-3 text-xs text-gray-600">
                No local PBS cache is loaded. Run <code>npm run pbs:import:np -- &lt;pbs-export.json|pbs-export.csv&gt;</code> with an official PBS export, or use the browse links above and enter the medicine details below.
              </div>
            )}
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Medication name</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.medication} onChange={(e) => setForm((p) => ({ ...p, medication: e.target.value }))} />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Strength</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.strength} onChange={(e) => setForm((p) => ({ ...p, strength: e.target.value }))} />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Dose</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.dose} onChange={(e) => setForm((p) => ({ ...p, dose: e.target.value }))} placeholder="e.g. 1 tablet" />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Route</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.route} onChange={(e) => setForm((p) => ({ ...p, route: e.target.value }))} placeholder="e.g. Oral" />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Frequency</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.frequency} onChange={(e) => setForm((p) => ({ ...p, frequency: e.target.value }))} placeholder="e.g. Twice daily" />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Duration</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.duration} onChange={(e) => setForm((p) => ({ ...p, duration: e.target.value }))} placeholder="e.g. 7 days" />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Quantity</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.quantity} onChange={(e) => setForm((p) => ({ ...p, quantity: e.target.value }))} />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Repeats</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.repeats} onChange={(e) => setForm((p) => ({ ...p, repeats: e.target.value }))} />
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs text-gray-600 mb-1">Clinical indication</label>
            <input className="w-full border rounded px-3 py-2 text-sm" value={form.indication} onChange={(e) => setForm((p) => ({ ...p, indication: e.target.value }))} />
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs text-gray-600 mb-1">Additional notes</label>
            <textarea className="w-full border rounded px-3 py-2 text-sm min-h-[96px]" value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} />
          </div>
        </div>
        {error ? <div className="text-sm text-red-600">{error}</div> : null}
        {message ? <div className="text-sm text-emerald-600">{message}</div> : null}
        <button className="btn-primary text-sm" onClick={() => void save()} disabled={saving}>
          {saving ? "Saving…" : "Record prescription"}
        </button>
      </div>

      <div className="rounded-xl border bg-white p-4 space-y-3">
        <div className="text-sm font-semibold">Prescription register</div>
        {loading ? (
          <div className="text-sm text-gray-500">Loading…</div>
        ) : records.length === 0 ? (
          <div className="text-sm text-gray-500">No prescriptions recorded for this patient yet.</div>
        ) : (
          <div className="space-y-2">
            {records.map((record) => (
              <div key={record.id} className="rounded-lg border px-3 py-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-gray-900">{record.medication}</div>
                    <div className="mt-1 text-xs text-gray-600">
                      {record.strength || "Strength not recorded"} · {record.dose || "Dose not recorded"} · {record.frequency || "Frequency not recorded"}
                    </div>
                    <div className="mt-1 text-xs text-gray-500">
                      Status: {prescriptionTrackingStatusLabel(record.status)} · Quantity {record.quantity || "—"} · Repeats remaining {record.remainingRepeatsReported}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Link to={`/patients/${patientId}/documents/${record.id}/print`} className="text-xs text-blue-700 hover:underline">
                      Patient copy
                    </Link>
                    <Link to={`/patients/${patientId}/prescriptions/${record.id}`} className="text-xs text-blue-700 hover:underline">
                      Tracking
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NursePrescribingTab;
