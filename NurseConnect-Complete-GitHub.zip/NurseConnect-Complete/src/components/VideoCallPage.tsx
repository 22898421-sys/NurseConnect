// src/components/VideoCallPage.tsx
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  writeBatch,
  where,
} from "firebase/firestore";
import { db } from "../firebaseConfig";
import { Appointment, Patient } from "../models/emr";
import { useAuth } from "../contexts/AuthContext";
import { buildEncounterHeader } from "../lib/encounterHeaders";
import { formatDateTimeInZone, getClinicTimeZone, getLocalTimeZone } from "../lib/time";
import { resolveProvider, resolveProviderLabel } from "../lib/provider";
import { formatToDDMMYYYY } from "../lib/dates";
import CarePlanLauncher from "./CarePlanLauncher";
import HomeCareAssessmentLauncher from "./HomeCareAssessmentLauncher";
import { buildJitsiRoomName, buildJitsiUrl, VIDEO_PROVIDER } from "../lib/video";
const AUTOSAVE_DEBOUNCE_MS = 1200;
const AUTOSAVE_HEARTBEAT_MS = 10000;

type NoteStyle = "soap" | "free";

const SOAP_TEMPLATE = `SUBJECTIVE
- Presenting complaint:
- History of presenting complaint:
- Relevant PMHx/PSHx:
- Medications:
- Allergies:
- Social history:
- Review of systems:

OBJECTIVE
- Vitals:
- Examination:
- Investigations / results:

ASSESSMENT
- Working diagnosis:
- Differentials:
- Clinical reasoning / impression:

PLAN
- Management:
- Medications:
- Investigations:
- Follow-up:
- Safety-netting / red flags:
`;

function hasSoapHeadings(text: string) {
  return (
    text.includes("SUBJECTIVE") &&
    text.includes("OBJECTIVE") &&
    text.includes("ASSESSMENT") &&
    text.includes("PLAN")
  );
}

function parseSoapFromText(text: string): {
  subjective: string;
  objective: string;
  assessment: string;
  plan: string;
} | null {
  const lines = String(text || "").split(/\r?\n/);
  const sections: Record<string, string[]> = {
    subjective: [],
    objective: [],
    assessment: [],
    plan: [],
  };

  let current: keyof typeof sections | null = null;
  const headingRegex = /^(SUBJECTIVE|OBJECTIVE|ASSESSMENT|PLAN)\s*:?\s*$/i;

  for (const raw of lines) {
    const line = raw.trimEnd();
    const match = line.match(headingRegex);
    if (match) {
      const key = match[1].toLowerCase() as keyof typeof sections;
      current = key;
      continue;
    }
    if (current) sections[current].push(raw);
  }

  const out = {
    subjective: sections.subjective.join("\n").trim(),
    objective: sections.objective.join("\n").trim(),
    assessment: sections.assessment.join("\n").trim(),
    plan: sections.plan.join("\n").trim(),
  };

  if (!out.subjective && !out.objective && !out.assessment && !out.plan) return null;
  return out;
}

function appendPlanLineToSoapText(text: string, planLine: string): string {
  const line = String(planLine || "").trim();
  if (!line) return text;

  const parsed = parseSoapFromText(text);
  if (!parsed) {
    return `${SOAP_TEMPLATE.trim()}\n- ${line}`.trim();
  }

  const nextPlan = [parsed.plan.trim(), `- ${line}`].filter(Boolean).join("\n");
  return [
    "SUBJECTIVE",
    parsed.subjective,
    "",
    "OBJECTIVE",
    parsed.objective,
    "",
    "ASSESSMENT",
    parsed.assessment,
    "",
    "PLAN",
    nextPlan,
  ].join("\n").trim();
}

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function formatDDMMYYYY(d: Date) {
  return `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()}`;
}

function toISODateString(ddmmyyyy: string): string {
  const raw = (ddmmyyyy ?? "").trim();
  const m = raw.match(/^([0-3]?\d)-([0-1]?\d)-(\d{4})$/);
  if (!m) return "";
  const dd = Number(m[1]);
  const mm = Number(m[2]);
  const yyyy = Number(m[3]);
  if (!yyyy || mm < 1 || mm > 12 || dd < 1 || dd > 31) return "";
  const dt = new Date(yyyy, mm - 1, dd);
  if (dt.getFullYear() !== yyyy || dt.getMonth() !== mm - 1 || dt.getDate() !== dd) return "";
  return `${String(yyyy).padStart(4, "0")}-${pad2(mm)}-${pad2(dd)}`;
}

function isPermissionDenied(e: any): boolean {
  const code = e?.code || e?.error?.code;
  if (code === "permission-denied") return true;
  const msg = String(e?.message || "").toLowerCase();
  return msg.includes("permission") && msg.includes("denied");
}

function toPhoneNumber(raw?: string | null): string {
  const digits = String(raw || "").replace(/[^\d]/g, "");
  if (!digits) return "";
  if (digits.startsWith("0")) return "";
  return digits;
}

function getConsultJoinUrl(appointmentId: string): string {
  if (typeof window === "undefined") return `/call/${appointmentId}`;
  return `${window.location.origin}/call/${appointmentId}`;
}

function toDateMaybe(t: any): Date | null {
  try {
    if (!t) return null;
    if (typeof t?.toDate === "function") return t.toDate();
    if (typeof t?.seconds === "number") return new Date(t.seconds * 1000);
    return null;
  } catch {
    return null;
  }
}

export const VideoCallPage: React.FC = () => {
  const { appointmentId } = useParams<{ appointmentId?: string }>();
  const navigate = useNavigate();

  const { normalizedRole, user, currentUserData } = useAuth() as any;

  const isPatient = normalizedRole === "patient";
  const isClinicianSide = normalizedRole === "clinician";

  const [apptInput, setApptInput] = useState("");
  const [quickAppts, setQuickAppts] = useState<Appointment[]>([]);
  const [quickLoading, setQuickLoading] = useState(false);
  const [quickError, setQuickError] = useState<string | null>(null);

  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [patient, setPatient] = useState<Patient | null>(null);

  const [loading, setLoading] = useState(false);
  const [pageError, setPageError] = useState<string | null>(null);

  const [consultationNotes, setConsultationNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const [noteStyle, setNoteStyle] = useState<NoteStyle>("soap");
  const [contactError, setContactError] = useState<string | null>(null);
  const [contactStatus, setContactStatus] = useState<string | null>(null);
  const [encounterBusy, setEncounterBusy] = useState(false);
  const [encounterMsg, setEncounterMsg] = useState<string | null>(null);
  const [encounterErr, setEncounterErr] = useState<string | null>(null);
  const [createdEncounterId, setCreatedEncounterId] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const notesRef = useRef<string>("");
  const dirtyRef = useRef<boolean>(false);
  const savingRef = useRef<boolean>(false);

  const debounceTimerRef = useRef<number | null>(null);
  const heartbeatTimerRef = useRef<number | null>(null);

  const roomName = useMemo(() => {
    return buildJitsiRoomName(appointmentId || "unknown");
  }, [appointmentId]);
  const existingEncounterId = String((appointment as any)?.encounterId || "");
  const effectiveEncounterId = String(createdEncounterId || existingEncounterId || "");
  const canCreateEncounter = !!appointment?.patientId && !existingEncounterId && !createdEncounterId;
  const localTz = useMemo(() => getLocalTimeZone(), []);
  const clinicTz = useMemo(
    () => getClinicTimeZone(currentUserData?.practiceTimeZone, currentUserData?.timeZone),
    [currentUserData]
  );

  const canAutoJoin = isPatient || normalizedRole === "clinician";

  useEffect(() => {
    notesRef.current = consultationNotes;
  }, [consultationNotes]);

  useEffect(() => {
    if (appointmentId) return;
    if (!canAutoJoin) return;
    if (!user?.uid) return;

    const loadQuick = async () => {
      setQuickLoading(true);
      setQuickError(null);
      try {
        const q = query(
          collection(db, "appointments"),
          where(isPatient ? "patientId" : "clinicianId", "==", user.uid),
          orderBy("scheduledAt", "asc"),
          limit(20)
        );
        const snap = await getDocs(q);
        const now = new Date();
        const windowStart = new Date(now);
        windowStart.setHours(0, 0, 0, 0);
        const windowEnd = new Date(now);
        windowEnd.setHours(23, 59, 59, 999);

        const rows: Appointment[] = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as any) }))
          .filter((a: any) => a?.mode === "video")
          .filter((a: any) => a?.status === "scheduled" || a?.status === "in_progress")
          .filter((a: any) => {
            const dt = toDateMaybe(a?.scheduledAt);
            if (!dt) return false;
            const ts = dt.getTime();
            return ts >= windowStart.getTime() && ts <= windowEnd.getTime();
          });

        setQuickAppts(rows);

        if (rows.length === 1) {
          navigate(`/call/${rows[0].id}`, { replace: true });
        }
      } catch (e: any) {
        console.error(e);
        setQuickError(e?.message ?? "Failed to load upcoming appointments.");
      } finally {
        setQuickLoading(false);
      }
    };

    void loadQuick();
  }, [appointmentId, canAutoJoin, isPatient, navigate, user?.uid]);

  const saveNotes = useCallback(
    async (opts?: { force?: boolean }) => {
      if (!isClinicianSide) return;

      const id = appointmentId;
      if (!id) return;
      if (!dirtyRef.current && !opts?.force) return;
      if (savingRef.current) return;

      savingRef.current = true;
      setSaving(true);
      setSaveError(null);

      try {
        // Notes are clinician-only and stored in a private subcollection so they
        // are never readable by patients (Firestore rules cannot redact fields).
        const notesDocRef = doc(db, "appointments", id, "clinicianNotes", "private");

        await setDoc(
          notesDocRef,
          {
            notes: notesRef.current,
            updatedAt: serverTimestamp(),
            updatedBy: user?.uid || null,
          },
          { merge: true }
        );

        dirtyRef.current = false;
        setLastSavedAt(new Date());
      } catch (err: any) {
        console.error("Autosave failed:", err);

        if (isPermissionDenied(err)) {
          setSaveError(
            "Autosave blocked by Firestore security rules (permission-denied). " +
              "Confirm /appointments/{id}/clinicianNotes rules allow the appointment clinician to write notes."
          );
        } else {
          setSaveError("Autosave failed. Your notes are still on-screen; try again or use Save now.");
        }
      } finally {
        savingRef.current = false;
        setSaving(false);
      }
    },
    [appointmentId, isClinicianSide, user?.uid]
  );

  const onNotesChange = useCallback(
    (value: string) => {
      if (!isClinicianSide) return;

      setConsultationNotes(value);
      notesRef.current = value;
      dirtyRef.current = true;

      if (debounceTimerRef.current) window.clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = window.setTimeout(() => {
        void saveNotes();
      }, AUTOSAVE_DEBOUNCE_MS);
    },
    [isClinicianSide, saveNotes]
  );

  const syncEncounterFromSoap = useCallback(async (): Promise<string | null> => {
    if (!isClinicianSide) return null;
    if (!appointment || !user?.uid) return null;
    setEncounterErr(null);
    setEncounterMsg(null);

    const practiceId = currentUserData?.practiceId;
    if (!practiceId) {
      setEncounterErr("Your profile is missing practiceId. Set users/{uid}.practiceId to enable encounter creation.");
      return null;
    }

    if (!appointment.patientId) {
      setEncounterErr("Appointment is missing patientId. Cannot create encounter.");
      return null;
    }

    const soap = parseSoapFromText(consultationNotes);
    if (!soap) {
      setEncounterErr("SOAP headings not found. Ensure notes use SUBJECTIVE/OBJECTIVE/ASSESSMENT/PLAN headings.");
      return null;
    }

    setEncounterBusy(true);
    try {
      const when = toDateMaybe((appointment as any).scheduledAt) || new Date();
      const encounterDate = formatDDMMYYYY(when);
      const encounterDateISO = toISODateString(encounterDate);
      const reason = appointment.reason || "Telehealth consultation";

      const ident = await resolveProvider(user.uid);
      const practitionerDisplayName = ident.displayName || user.uid;
      const practitionerLabel = await resolveProviderLabel(user.uid, { includeRole: true });

      const now = serverTimestamp();
      const targetEncounterId = effectiveEncounterId;

      if (!targetEncounterId) {
        const encounterRef = doc(collection(db, "encounters"));
        const encounterPayload = {
          patientId: appointment.patientId,
          practitionerId: user.uid,
          practiceId,

          practitionerDisplayName,
          practitionerLabel,

          encounterDate,
          encounterDateISO,
          type: "consultation",
          reason,

          soap,
          notes: consultationNotes?.trim() ? consultationNotes.trim() : "",

          status: "draft",
          breakGlass: { enabled: false },

          appointmentId: appointment.id,
          createdAt: now,
          createdBy: user.uid,
          updatedAt: now,
          updatedBy: user.uid,
        };
        const batch = writeBatch(db);
        batch.set(encounterRef, encounterPayload);
        batch.set(
          doc(db, "encounterHeaders", encounterRef.id),
          buildEncounterHeader({
            ...encounterPayload,
            status: "draft",
          })
        );
        batch.update(doc(db, "appointments", appointment.id), {
          encounterId: encounterRef.id,
          updatedAt: now,
          updatedBy: user.uid,
        });
        await batch.commit();

        setCreatedEncounterId(encounterRef.id);
        setEncounterMsg("Encounter created from SOAP notes.");
        return encounterRef.id;
      }

      const encounterRef = doc(db, "encounters", targetEncounterId);
      const encounterHeaderRef = doc(db, "encounterHeaders", targetEncounterId);
      await runTransaction(db, async (tx) => {
        const encSnap = await tx.get(encounterRef);
        if (!encSnap.exists()) throw new Error("Linked encounter was not found.");

        const encData = encSnap.data() as any;
        if ((encData?.status ?? "draft") === "completed") {
          throw new Error("Encounter is already signed. Use break-glass/addendum flows instead of telehealth sync.");
        }
        if ((encData?.practitionerId ?? "") !== user.uid) {
          throw new Error("Only the responsible clinician can sync this encounter.");
        }
        if ((encData?.patientId ?? "") !== appointment.patientId) {
          throw new Error("Encounter patient does not match the appointment.");
        }

        const currentVersion = typeof encData.currentSoapVersion === "number" ? encData.currentSoapVersion : 0;
        const nextVersion = currentVersion + 1;
        const nextNotes = consultationNotes?.trim() ? consultationNotes.trim() : "";

        const versionRef = doc(collection(db, "encounters", targetEncounterId, "soapVersions"));
        tx.set(versionRef, {
          version: nextVersion,
          soap,
          authorUid: user.uid,
          authorDisplayName: practitionerDisplayName,
          createdAt: serverTimestamp(),
          reason: "Telehealth SOAP sync",
        } as any);

        const revisionRef = doc(collection(db, "encounters", targetEncounterId, "soapRevisions"));
        tx.set(revisionRef, {
          encounterId: targetEncounterId,
          editorId: user.uid,
          editorDisplayName: practitionerDisplayName,
          editorRole: "clinician",
          editedAt: serverTimestamp(),
          mode: "telehealth_sync",
          previous: {
            soap: encData?.soap ?? {},
            notes: typeof encData?.notes === "string" ? encData.notes : "",
          },
          next: {
            soap,
            notes: nextNotes,
          },
          sourceAppointmentId: appointment.id,
        } as any);

        tx.update(encounterRef, {
          soap,
          notes: nextNotes,
          currentSoapVersion: nextVersion,
          lastEditedAt: serverTimestamp(),
          lastEditedByUid: user.uid,
          updatedAt: serverTimestamp(),
          updatedBy: user.uid,
        } as any);

        tx.set(
          encounterHeaderRef,
          {
            updatedAt: serverTimestamp(),
            updatedBy: user.uid,
          },
          { merge: true }
        );
      });

      setCreatedEncounterId(targetEncounterId);
      setEncounterMsg("Encounter draft synced from SOAP notes.");
      return targetEncounterId;
    } catch (e: any) {
      console.error(e);
      setEncounterErr(e?.message ?? "Failed to sync encounter from SOAP notes.");
      return null;
    } finally {
      setEncounterBusy(false);
    }
  }, [appointment, consultationNotes, currentUserData?.practiceId, effectiveEncounterId, isClinicianSide, user?.uid]);

  const loadData = useCallback(
    async (id: string, clinicianSide: boolean) => {
      setLoading(true);
      setPageError(null);

      try {
        const apptRef = doc(db, "appointments", id);
        const apptSnap = await getDoc(apptRef);

        if (!apptSnap.exists()) {
          setPageError("Appointment not found.");
          setLoading(false);
          return;
        }

        const apptData = apptSnap.data() as Omit<Appointment, "id">;
        const appt: Appointment = { id: apptSnap.id, ...apptData };
        setAppointment(appt);

        if (clinicianSide) {
          // Load clinician-only notes from private subcollection
          const notesDocRef = doc(db, "appointments", id, "clinicianNotes", "private");
          const notesSnap = await getDoc(notesDocRef);
          const existingNotes = notesSnap.exists() ? String((notesSnap.data() as any)?.notes || "") : "";

          setConsultationNotes(existingNotes);
          notesRef.current = existingNotes;
          dirtyRef.current = false;
          setNoteStyle(hasSoapHeadings(existingNotes) ? "soap" : "free");
        } else {
          setConsultationNotes("");
          notesRef.current = "";
          dirtyRef.current = false;
        }

        if (appt.patientId) {
          const patientRef = doc(db, "patients", appt.patientId);
          const patientSnap = await getDoc(patientRef);

          if (patientSnap.exists()) {
            const pData = patientSnap.data() as Omit<Patient, "id">;
            setPatient({ id: patientSnap.id, ...pData });
          } else {
            setPatient(null);
          }
        } else {
          setPatient(null);
        }
      } catch (err) {
        console.error("Error loading consultation:", err);
        setPageError("Failed to load consultation.");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    if (debounceTimerRef.current) window.clearTimeout(debounceTimerRef.current);
    if (heartbeatTimerRef.current) window.clearInterval(heartbeatTimerRef.current);

    if (!appointmentId) {
      setAppointment(null);
      setPatient(null);
      setConsultationNotes("");
      setLoading(false);
      setPageError(null);
      return;
    }

    void loadData(appointmentId, isClinicianSide);

    return () => {
      if (debounceTimerRef.current) window.clearTimeout(debounceTimerRef.current);
      if (heartbeatTimerRef.current) window.clearInterval(heartbeatTimerRef.current);
    };
  }, [appointmentId, isClinicianSide, loadData]);

  useEffect(() => {
    if (!appointmentId) return;

    if (heartbeatTimerRef.current) window.clearInterval(heartbeatTimerRef.current);

    if (isClinicianSide) {
      heartbeatTimerRef.current = window.setInterval(() => {
        if (dirtyRef.current) void saveNotes();
      }, AUTOSAVE_HEARTBEAT_MS);
    }

    return () => {
      if (heartbeatTimerRef.current) window.clearInterval(heartbeatTimerRef.current);
    };
  }, [appointmentId, isClinicianSide, saveNotes]);

  const insertTemplateIfEmpty = useCallback(() => {
    if (!isClinicianSide) return;
    const current = notesRef.current || "";
    if (current.trim().length > 0) return;

    const template = noteStyle === "soap" ? SOAP_TEMPLATE : "";
    if (!template) return;

    onNotesChange(template);

    setTimeout(() => {
      textareaRef.current?.focus();
      textareaRef.current?.setSelectionRange(0, 0);
    }, 0);
  }, [isClinicianSide, noteStyle, onNotesChange]);

  const forceInsertSoapTemplate = useCallback(() => {
    if (!isClinicianSide) return;

    const current = notesRef.current || "";
    if (current.trim().length === 0) {
      onNotesChange(SOAP_TEMPLATE);
    } else if (!hasSoapHeadings(current)) {
      onNotesChange(`${SOAP_TEMPLATE}\n${current}`);
    }
    setNoteStyle("soap");
    setTimeout(() => textareaRef.current?.focus(), 0);
  }, [isClinicianSide, onNotesChange]);

  const clearNotes = useCallback(() => {
    if (!isClinicianSide) return;
    onNotesChange("");
    setTimeout(() => textareaRef.current?.focus(), 0);
  }, [isClinicianSide, onNotesChange]);

  const copyNotes = useCallback(async () => {
    if (!isClinicianSide) return;
    try {
      await navigator.clipboard.writeText(notesRef.current || "");
    } catch (e) {
      console.error("Copy failed:", e);
    }
  }, [isClinicianSide]);

  const appendActionPlanToConsultationNotes = useCallback(
    async (planLine: string) => {
      if (!isClinicianSide) return;
      const nextText = appendPlanLineToSoapText(notesRef.current || consultationNotes || "", planLine);
      setConsultationNotes(nextText);
      notesRef.current = nextText;
      dirtyRef.current = true;
      await saveNotes({ force: true });
    },
    [consultationNotes, isClinicianSide, saveNotes]
  );

  const handleEndConsultation = useCallback(async () => {
    if (!isClinicianSide) return;
    if (!appointmentId) return;

    setSaveError(null);
    setSaving(true);

    try {
      if (canCreateEncounter) {
        const encId = await syncEncounterFromSoap();
        if (!encId) {
          setSaveError("Create the SOAP encounter before ending the consultation.");
          return;
        }
      } else if (effectiveEncounterId) {
        const encId = await syncEncounterFromSoap();
        if (!encId) {
          setSaveError("Failed to sync the encounter draft from the latest SOAP notes.");
          return;
        }
      }

      const apptRef = doc(db, "appointments", appointmentId);

      await updateDoc(apptRef, {
        consultationNotes: notesRef.current,
        status: "completed",
        completedAt: Timestamp.fromDate(new Date()),
        updatedAt: serverTimestamp(),
        updatedBy: user?.uid || null,
      });

      dirtyRef.current = false;
      setLastSavedAt(new Date());

      navigate("/schedule");
    } catch (err: any) {
      console.error("End consultation failed:", err);

      if (isPermissionDenied(err)) {
        setSaveError(
          "End consultation blocked by Firestore security rules (permission-denied). " +
            "Confirm appointments update allows clinicians to write consultationNotes/status/completedAt on their own appointment."
        );
      } else {
        setSaveError("Failed to end consultation. Please try again.");
      }
    } finally {
      setSaving(false);
    }
  }, [appointmentId, canCreateEncounter, effectiveEncounterId, isClinicianSide, navigate, syncEncounterFromSoap, user?.uid]);

  const sendSmsJoinLink = useCallback(async () => {
    if (!appointmentId) return;
    const number = toPhoneNumber(patient?.phone);
    if (!number) {
      setContactError(
        "Patient phone is missing or not in international format. Save phone in E.164 format (for example +614...)."
      );
      return;
    }
    setContactError(null);
    setContactStatus(null);
    try {
      const joinUrl = getConsultJoinUrl(appointmentId);
      const patientName = patient?.fullName || "Patient";
      const message =
        `Hi ${patientName}, your telehealth consultation is ready. ` +
        `Join now: ${joinUrl} ` +
        `(Appointment ID: ${appointmentId})`;
      window.open(`sms:+${number}?body=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
      setContactStatus("SMS app opened.");
    } catch (e: any) {
      setContactError(e?.message || "Failed to open SMS.");
    }
  }, [appointmentId, patient?.fullName, patient?.phone]);

  const openEmailJoinLink = useCallback(() => {
    if (!appointmentId) return;
    const email = String(patient?.email || "").trim();
    if (!email) {
      setContactError("Patient email is not recorded.");
      return;
    }
    setContactError(null);
    const joinUrl = getConsultJoinUrl(appointmentId);
    const patientName = patient?.fullName || "Patient";
    const subject = encodeURIComponent("Telehealth consultation join link");
    const body = encodeURIComponent(
      `Hi ${patientName}, your telehealth consultation is ready.\n\nJoin now: ${joinUrl}\n\nAppointment ID: ${appointmentId}`
    );
    window.open(`mailto:${email}?subject=${subject}&body=${body}`, "_blank", "noopener,noreferrer");
    setContactStatus("Email client opened.");
  }, [appointmentId, patient?.email, patient?.fullName]);

  const renderVideo = () => {
    if (VIDEO_PROVIDER === "twilio") {
      return (
        <div className="border rounded-md p-4 bg-gray-50 text-sm">
          Twilio provider selected, but Twilio client is not implemented yet. Switch back to Jitsi by setting
          REACT_APP_VIDEO_PROVIDER=jitsi.
        </div>
      );
    }

    const jitsiUrl = buildJitsiUrl(roomName);

    return (
      <div className="w-full h-[520px] border rounded-md overflow-hidden bg-black">
        <iframe
          title="Jitsi Video Call"
          src={jitsiUrl}
          allow="camera; microphone; fullscreen; display-capture"
          className="w-full h-full"
        />
      </div>
    );
  };

  useEffect(() => {
    if (!appointmentId) return;
    if (!isClinicianSide) return;
    if (loading) return;
    insertTemplateIfEmpty();
  }, [appointmentId, isClinicianSide, loading, insertTemplateIfEmpty]);

  if (!appointmentId) {
    return (
      <div className="p-4">
        <div className="mb-4">
          <h1 className="text-xl font-semibold">Telehealth</h1>
          <p className="text-sm text-gray-600">
            Join a scheduled telehealth consultation from your appointment, or enter an appointment ID to join directly.
          </p>
        </div>

        <div className="max-w-md border rounded-md bg-white p-4 space-y-3">
          {canAutoJoin && (
            <>
              {quickLoading ? (
                <div className="text-sm text-gray-600">Checking upcoming appointments…</div>
              ) : quickError ? (
                <div className="text-sm text-red-600">{quickError}</div>
              ) : quickAppts.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs text-gray-600">Upcoming video appointments (next 24h)</div>
                  {quickAppts.map((a: any) => {
                    const dt = toDateMaybe(a?.scheduledAt);
                    const effectiveClinicTz = clinicTz || localTz;
                    const whenLocal = dt ? formatDateTimeInZone(dt, localTz) : "—";
                    const whenClinic = dt ? formatDateTimeInZone(dt, effectiveClinicTz) : "—";
                    return (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => navigate(`/call/${a.id}`)}
                        className="w-full text-left px-3 py-2 rounded border text-sm hover:bg-gray-50"
                      >
                        <div className="font-medium">{whenLocal}</div>
                        <div className="text-xs text-gray-600">
                          Local ({localTz}) · Clinic ({effectiveClinicTz}) · {whenClinic}
                        </div>
                        <div className="text-xs text-gray-600">
                          {a.reason ? `${a.reason} · ` : ""}Appointment {a.id}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="text-sm text-gray-600">No upcoming video appointments found.</div>
              )}

              <div className="border-t pt-3" />
            </>
          )}

          <label className="block text-sm">
            <div className="text-xs text-gray-600 mb-1">Appointment ID</div>
            <input
              value={apptInput}
              onChange={(e) => setApptInput(e.target.value)}
              className="w-full border rounded px-3 py-2 text-sm"
              placeholder="e.g. 8Gv3... (Firestore doc id)"
            />
          </label>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                const id = (apptInput || "").trim();
                if (id) navigate(`/call/${id}`);
              }}
              className="px-4 py-2 rounded bg-[#1F9A92] text-white text-sm hover:opacity-95"
            >
              Join
            </button>
          </div>

          <div className="text-xs text-gray-500">Patients should normally join from the Patient Portal appointment list.</div>
        </div>
      </div>
    );
  }

  if (loading) return <div className="p-4">Loading consultation…</div>;

  if (pageError) {
    return (
      <div className="p-4 text-red-600">
        {pageError}
      </div>
    );
  }

  if (!appointment) {
    return (
      <div className="p-4">
        Consultation not found.
      </div>
    );
  }

  if (isPatient) {
    return (
      <div className="p-4">
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-semibold">Telehealth Consultation</h1>
            <div className="text-sm text-gray-600">
              Appointment: <span className="font-medium">{appointment.id}</span>
              {appointment.status && <span className="ml-2 uppercase tracking-wide text-xs">{appointment.status}</span>}
            </div>
            <div className="text-xs text-gray-600 mt-1">
              Nurse: {appointment.clinicianName || appointment.clinicianId || "—"}
              {appointment.reason ? ` · Reason: ${appointment.reason}` : ""}
            </div>
          </div>

          <Link to="/patient" className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50">
            Back to portal
          </Link>
        </div>

        <div className="space-y-3">
          {renderVideo()}
          <div className="text-xs text-gray-600">
            Room: <span className="font-mono">{roomName}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Telehealth Consultation</h1>
          <div className="text-sm text-gray-600">
            Appointment: <span className="font-medium">{appointment.id}</span>
            {appointment.status && <span className="ml-2 uppercase tracking-wide text-xs">{appointment.status}</span>}
          </div>
        </div>

        <button
          onClick={handleEndConsultation}
          disabled={saving || canCreateEncounter}
          className="px-4 py-2 rounded bg-red-600 text-white text-sm disabled:opacity-60"
          title={canCreateEncounter ? "Create the SOAP encounter before ending the consultation." : ""}
        >
          {saving ? "Saving…" : "End Consultation"}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-3">
          {renderVideo()}
          <div className="text-xs text-gray-600">
            Room: <span className="font-mono">{roomName}</span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="border rounded-md p-3 bg-white">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Patient summary</h2>
              {patient?.id && (
                <Link to={`/patients/${patient.id}`} className="text-sm text-blue-600 hover:underline">
                  Open EMR
                </Link>
              )}
            </div>

            <div className="mt-2 text-sm text-gray-700 space-y-1">
              <div>
                <span className="font-medium">Name:</span>{" "}
                {patient?.fullName || (appointment as any).patientName || "Not recorded"}
              </div>
              <div>
                <span className="font-medium">Email:</span>{" "}
                {patient?.email || (appointment as any).patientEmail || "Not recorded"}
              </div>
              <div>
                <span className="font-medium">Phone:</span> {patient?.phone || "Not recorded"}
              </div>
              <div>
                <span className="font-medium">DOB:</span>{" "}
                {(patient as any)?.dateOfBirth ? formatToDDMMYYYY((patient as any).dateOfBirth) : "Not recorded"}
              </div>
              <div>
                <span className="font-medium">Sex:</span> {(patient as any)?.sex || "Not recorded"}
              </div>
              <div>
                <span className="font-medium">Address:</span> {(patient as any)?.address || "Not recorded"}
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => void sendSmsJoinLink()}
                className="px-3 py-1.5 rounded border text-sm hover:bg-gray-50"
              >
                Send SMS Join Link
              </button>
              <button
                type="button"
                onClick={openEmailJoinLink}
                className="px-3 py-1.5 rounded border text-sm hover:bg-gray-50"
              >
                Send Email Join Link
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!appointmentId) return;
                  navigator.clipboard
                    .writeText(getConsultJoinUrl(appointmentId))
                    .catch(() => {});
                }}
                className="px-3 py-1.5 rounded border text-sm hover:bg-gray-50"
              >
                Copy Join Link
              </button>
            </div>
            <div className="mt-2 text-xs text-gray-600">
              Contact options in NurseConnectCare are limited to SMS, email, and phone.
            </div>
            {contactError ? <div className="mt-2 text-xs text-red-600">{contactError}</div> : null}
            {contactStatus ? <div className="mt-2 text-xs text-green-700">{contactStatus}</div> : null}
          </div>

          <div className="border rounded-md p-3 bg-white">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Consultation notes</h2>
              <div className="text-xs text-gray-600">
                {saveError ? (
                  <span className="text-red-600">{saveError}</span>
                ) : saving ? (
                  <span>Saving…</span>
                ) : lastSavedAt ? (
                  <span>Saved {lastSavedAt.toLocaleTimeString()}</span>
                ) : (
                  <span>Not saved yet</span>
                )}
              </div>
            </div>

            <div className="mt-2 flex flex-wrap gap-2 items-center">
              <label className="text-xs text-gray-600">
                Note style
                <select
                  name="noteStyle"
                  value={noteStyle}
                  onChange={(e) => setNoteStyle(e.target.value as NoteStyle)}
                  className="ml-2 border rounded px-2 py-1 text-xs"
                >
                  <option value="soap">SOAP</option>
                  <option value="free">Free text</option>
                </select>
              </label>

              <button
                type="button"
                onClick={forceInsertSoapTemplate}
                className="px-3 py-1.5 rounded bg-gray-100 text-sm border"
              >
                Insert SOAP
              </button>

              <button
                type="button"
                onClick={copyNotes}
                className="px-3 py-1.5 rounded bg-gray-100 text-sm border"
              >
                Copy
              </button>

              <button
                type="button"
                onClick={clearNotes}
                className="px-3 py-1.5 rounded bg-white text-sm border text-red-600"
              >
                Clear
              </button>

              <button
                type="button"
                onClick={() => void saveNotes({ force: true })}
                disabled={saving}
                className="px-3 py-1.5 rounded bg-gray-900 text-white text-sm disabled:opacity-60"
              >
                {saving ? "Saving…" : "Save now"}
              </button>
            </div>

            <textarea
              ref={textareaRef}
              value={consultationNotes}
              onChange={(e) => onNotesChange(e.target.value)}
              rows={14}
              className="mt-2 w-full border rounded px-2 py-2 text-sm"
              placeholder="Document the history, assessment, plan…"
            />
          </div>

          <div className="border rounded-md p-3 bg-white">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Encounter</h2>
              {appointment?.patientId && (existingEncounterId || createdEncounterId) ? (
                <Link
                  to={`/patients/${appointment.patientId}/chart/encounters/${effectiveEncounterId}?edit=1`}
                  className="text-sm text-blue-600 hover:underline"
                >
                  Open encounter
                </Link>
              ) : null}
            </div>

            <div className="text-xs text-gray-600 mt-1">
              Create a draft encounter using the current SOAP notes to avoid retyping.
            </div>

            {encounterErr ? <div className="mt-2 text-xs text-red-600">{encounterErr}</div> : null}
            {encounterMsg ? <div className="mt-2 text-xs text-green-700">{encounterMsg}</div> : null}

            <div className="mt-3 flex items-center gap-2">
              <button
                type="button"
                onClick={() => void syncEncounterFromSoap()}
                disabled={encounterBusy}
                className="px-3 py-2 rounded bg-[#1F9A92] text-white text-sm hover:opacity-95 disabled:opacity-60"
              >
                {encounterBusy ? "Syncing…" : effectiveEncounterId ? "Sync encounter from SOAP" : "Create encounter from SOAP"}
              </button>
            </div>
          </div>

          {appointment?.patientId && currentUserData?.practiceId && user?.uid ? (
            <div className="space-y-4">
              <CarePlanLauncher
                patientId={appointment.patientId}
                practiceId={currentUserData.practiceId}
                clinicianUid={user.uid}
                clinicianDisplayName={currentUserData?.displayName || currentUserData?.email || user?.email || null}
                sourceAppointmentId={appointment.id}
                sourceEncounterId={effectiveEncounterId || null}
                chartBasePath={`/patients/${appointment.patientId}/chart`}
                buttonLabel="Create care plan during consult"
                onCarePlanCreated={({ planLine }) => appendActionPlanToConsultationNotes(planLine)}
              />
              <HomeCareAssessmentLauncher
                patientId={appointment.patientId}
                practiceId={currentUserData.practiceId}
                clinicianUid={user.uid}
                clinicianDisplayName={currentUserData?.displayName || currentUserData?.email || user?.email || null}
                sourceAppointmentId={appointment.id}
                sourceEncounterId={effectiveEncounterId || null}
                chartBasePath={`/patients/${appointment.patientId}/chart`}
                buttonLabel="Run home-care assessment during consult"
                onAssessmentCreated={({ planLine }) => appendActionPlanToConsultationNotes(planLine)}
              />
            </div>
          ) : null}

        </div>
      </div>
    </div>
  );
};

export default VideoCallPage;
