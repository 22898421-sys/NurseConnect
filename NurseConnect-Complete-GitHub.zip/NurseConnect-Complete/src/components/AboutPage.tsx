import React from "react";
import { Link } from "react-router-dom";
import { FiArrowRight, FiCheckCircle, FiShield } from "./PublicIcons";
import EirenixMark from "./EirenixMark";
import PublicSiteChrome from "./PublicSiteChrome";
import nursePortraitImage from "../assets/public-site/nurse-portrait.jpeg";

const whatWeAre = [
  "A connector and infrastructure platform",
  "A technology enabler for independent nursing practice",
  "A discovery, request-routing and booking environment for care at home",
];

const whatWeAreNot = [
  "An aged care provider",
  "An employer or labour-hire agency",
  "A substitute for clinical judgement or professional responsibility",
];

const faqSections = [
  {
    title: "For People Seeking Care",
    items: [
      {
        question: "What is NurseConnectCare?",
        answer:
          "NurseConnectCare is a digital platform that helps people, carers, independent nurses and providers connect around care-at-home needs. It provides technology for discovery, request routing, communication, bookings and records support. It does not provide nursing services itself.",
      },
      {
        question: "What kinds of care can I find on NurseConnectCare?",
        answer:
          "Independent nurses on the platform may provide medication support, injections, wound care, chronic disease management, post-hospital recovery care, continence and catheter care, palliative nursing, health assessments, monitoring, and telehealth follow-up where appropriate. Availability depends on the nurse’s qualifications, scope of practice and location.",
      },
      {
        question: "Do you only work with Registered Nurses?",
        answer:
          "No. NurseConnectCare includes Registered Nurses, Enrolled Nurses and Nurse Practitioners. Each nurse is responsible for working within their professional scope of practice, and services are matched accordingly.",
      },
      {
        question: "Can care be funded through Support at Home?",
        answer:
          "Some nursing services arranged through NurseConnectCare may be funded under the Australian Government’s Support at Home program where they align with a person’s assessed needs and the relevant provider, care manager or funder approves the service. Some people also choose to pay privately for services.",
      },
      {
        question: "How does booking work?",
        answer:
          "People can search for nurses by location, skills and service type, review nurse profiles and submit care requests. Requests may be managed through a client account, by an independent nurse, or by a registered provider, care manager or funder depending on the funding and care-plan context.",
      },
      {
        question: "Does NurseConnectCare employ or supervise nurses?",
        answer:
          "No. Nurses using NurseConnectCare are independent practitioners. They are not employees, contractors or agents of NurseConnectCare.",
      },
      {
        question: "Is NurseConnectCare a registered aged care provider?",
        answer:
          "No. NurseConnectCare is technology and workflow infrastructure, not an aged care provider. Independent nurses remain responsible for clinical delivery and professional standards, and registered providers remain responsible for provider obligations where Support at Home services are involved.",
      },
      {
        question: "How does NurseConnectCare check that nurses are qualified?",
        answer:
          "Nurses on NurseConnectCare are required to hold current AHPRA registration, declare their qualifications and endorsements, maintain appropriate insurance, and practise within their scope. AHPRA verification is recorded after a manual check of the public register.",
      },
      {
        question: "Can I use NurseConnectCare if I have a carer or live with others?",
        answer:
          "Yes. Family members, carers and representatives can help search for care and submit requests, with the person receiving care involved wherever possible and provider or funder approval captured where required.",
      },
    ],
  },
  {
    title: "For Nurses",
    items: [
      {
        question: "Who can sign up to NurseConnectCare as a nurse?",
        answer:
          "NurseConnectCare is open to Registered Nurses, Enrolled Nurses and Nurse Practitioners. Nurses must hold current AHPRA registration and appropriate insurance.",
      },
      {
        question: "Am I employed by NurseConnectCare?",
        answer:
          "No. Nurses remain fully independent. NurseConnectCare does not employ nurses, roster them, or direct their work.",
      },
      {
        question: "What services can I offer through NurseConnectCare?",
        answer:
          "Nurses can offer services that are within their professional scope of practice, aligned with Support at Home or private care, and consistent with their qualifications, experience, endorsements and insurance. Each nurse chooses which services to list and which requests to accept.",
      },
      {
        question: "How do payment arrangements work?",
        answer:
          "Payment arrangements are agreed between the nurse and the client, registered provider, care manager, funder or other paying party. NurseConnectCare does not employ nurses, process payments, approve claims or determine funding eligibility.",
      },
      {
        question: "Can Enrolled Nurses provide Support at Home services?",
        answer:
          "Yes. Enrolled Nurses may deliver nursing services under Support at Home within their scope of practice, including medication support, wound care, monitoring and follow-up nursing.",
      },
      {
        question: "Does NurseConnectCare provide clinical oversight or supervision?",
        answer:
          "No. Clinical responsibility rests with the individual nurse. NurseConnectCare provides infrastructure and tools, not clinical supervision.",
      },
      {
        question: "Do I need my own insurance?",
        answer:
          "Yes. Nurses must maintain appropriate professional indemnity and public liability insurance relevant to their practice.",
      },
      {
        question: "What tools does NurseConnectCare provide for nurses?",
        answer:
          "The platform provides professional profiles and discovery, secure messaging, booking and scheduling tools, billing-facilitation tools, and optional integration with a clinical and practice management platform. Clinical documentation occurs within the nurse’s chosen clinical system.",
      },
      {
        question: "Does NurseConnectCare help nurses with invoicing and billing?",
        answer:
          "Yes. NurseConnectCare provides tools that help nurses document completed services, generate invoices, and prepare supporting information for clients, care package managers, or other funders. These tools are designed to reduce administrative burden and support timely payment. NurseConnectCare does not approve invoices, determine eligibility, or process payments.",
      },
      {
        question: "Can NurseConnectCare send invoices to care package managers or funders on my behalf?",
        answer:
          "Yes, at the nurse’s direction. Nurses choose the recipient and initiate each transmission. NurseConnectCare acts only as a secure delivery platform and does not submit claims, negotiate payments, or act as a billing agent.",
      },
    ],
  },
  {
    title: "Safety, Governance and Privacy",
    items: [
      {
        question: "Who is responsible for the quality and safety of care?",
        answer:
          "The nurse providing the care is responsible for clinical decision-making, scope-appropriate practice, documentation, and professional standards. Where a registered provider arranges or funds the service, that provider retains its own legal and governance responsibilities. NurseConnectCare does not direct or deliver care.",
      },
      {
        question: "What if something goes wrong?",
        answer:
          "Clinical concerns should be raised with the nurse providing care and, where relevant, the registered provider, care manager or funder responsible for the care arrangement. Professional matters may also be addressed through established health and regulatory pathways.",
      },
      {
        question: "How is my information protected?",
        answer:
          "NurseConnectCare uses secure systems and is intended to comply with Australian privacy requirements. Information is shared only as needed to support connections and service delivery.",
      },
      {
        question: "Does NurseConnectCare handle payments or hold funds?",
        answer:
          "No. NurseConnectCare does not receive, hold, or process funds, and does not manage payments between nurses, clients, or care funders. All payment arrangements, including timing and amount, remain directly between the nurse and the paying party, such as the client or a Support at Home provider.",
      },
      {
        question: "Will NurseConnectCare check whether a service is eligible for Support at Home funding?",
        answer:
          "No. NurseConnectCare does not assess funding eligibility or approve services. The platform may help nurses describe services using language aligned with Support at Home service categories, but responsibility for ensuring services are appropriate, billable, and within scope remains with the nurse and the funding provider.",
      },
      {
        question: "Is electronic invoice submission the same as claiming funding?",
        answer:
          "No. Electronic invoice submission through NurseConnectCare is a documentation and delivery function only. It is equivalent to securely sending an invoice and supporting information. NurseConnectCare does not lodge claims, interact with government systems, or make decisions about payment.",
      },
    ],
  },
];

export default function AboutPage() {
  return (
    <PublicSiteChrome
      ctaLabel="Contact Us"
      ctaTo="/contact"
      metaTitle="NurseConnectCare | About"
      metaDescription="Learn what NurseConnectCare is, how the model works, and how the platform supports independent nursing practice."
    >
      <section className="mx-auto grid w-full max-w-7xl gap-10 px-4 pb-14 pt-8 sm:px-6 lg:grid-cols-[1fr_0.92fr] lg:px-8 lg:pt-14">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-4 py-2 text-sm text-ink-700 shadow-soft backdrop-blur">
            <FiShield className="h-4 w-4 text-brand-700" />
            About NurseConnectCare
          </div>
          <h1 className="mt-6 text-4xl leading-tight text-ink-900 sm:text-5xl">A clearer model for care at home.</h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-700">
            NurseConnectCare is designed to connect people, carers, independent nurses and providers around care needs
            while giving nurses the digital infrastructure to run a modern care-at-home practice.
          </p>
          <p className="mt-4 max-w-2xl text-lg leading-8 text-ink-700">
            The platform supports discovery, request routing, booking and connected operations, while care delivery,
            approval and funding responsibilities remain with the appropriate nurse, provider, care manager or funder.
          </p>
        </div>

        <div className="overflow-hidden rounded-[32px] border border-ink-200 bg-ink-900 text-white shadow-lift">
          <img
            src={nursePortraitImage}
            alt="Professional nurse portrait in a clinical setting"
            className="h-[300px] w-full object-cover"
          />
          <div className="p-6">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Core model</p>
            <h2 className="mt-3 text-3xl text-white">Infrastructure, not provider.</h2>
            <p className="mt-4 text-sm leading-7 text-white/70">
              NurseConnectCare gives visibility, request workflows and a secure clinician pathway into the connected{" "}
              <EirenixMark /> environment. It does not provide nursing services itself.
            </p>
            <div className="mt-6 border-t border-white/10 bg-white p-5 text-ink-900">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">Connected systems</p>
              <p className="mt-3 text-xl font-semibold leading-8">Secure clinician access remains available.</p>
              <p className="mt-2 text-sm leading-6 text-ink-600">
                Nurses can move from the public website into the secure <EirenixMark />-connected clinical and practice workspace.
              </p>
              <Link to="/clinician-login" className="mt-5 inline-flex items-center gap-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700">
                Nurse Login
                <FiArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-ink-200/80 bg-white/80 py-14">
        <div className="mx-auto grid w-full max-w-7xl gap-8 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div className="border-t border-ink-200 bg-white p-7 shadow-soft">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">What we are</p>
            <ul className="mt-5 space-y-4 text-sm leading-7 text-ink-700">
              {whatWeAre.map((item) => (
                <li key={item} className="flex gap-3">
                  <FiCheckCircle className="mt-1 h-5 w-5 shrink-0 text-brand-700" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="border-t border-ink-700 bg-ink-900 p-7 text-white shadow-lift">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-200">What we are not</p>
            <ul className="mt-5 space-y-4 text-sm leading-7 text-white/75">
              {whatWeAreNot.map((item) => (
                <li key={item} className="flex gap-3">
                  <FiArrowRight className="mt-1 h-5 w-5 shrink-0 text-brand-200" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="mx-auto w-full max-w-7xl px-4 pb-12 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">Frequently asked questions</p>
            <h2 className="mt-3 text-3xl sm:text-4xl">Common questions from clients, carers and nurses.</h2>
            <p className="mt-5 text-lg leading-8 text-ink-700">
              This FAQ brings the practical operating model into one place so people can understand how NurseConnectCare works before they request care, post a provider request or create a nurse account.
            </p>
          </div>

          <div className="mt-10 grid gap-8 lg:grid-cols-3">
            {faqSections.map((section) => (
              <div key={section.title} className="space-y-4">
                <h3 className="text-xl font-semibold text-ink-900">{section.title}</h3>
                <div className="space-y-3">
                  {section.items.map((item) => (
                    <details key={item.question} className="border-t border-ink-200 bg-white p-5 shadow-soft">
                      <summary className="cursor-pointer list-none text-sm font-semibold leading-7 text-ink-900">
                        {item.question}
                      </summary>
                      <p className="mt-3 text-sm leading-7 text-ink-700">{item.answer}</p>
                    </details>
                  ))}
                </div>
              </div>
            ))}
          </div>

        </div>

        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="overflow-hidden rounded-[34px] border border-ink-200 bg-[linear-gradient(135deg,#0E2A3B_0%,#12546B_48%,#1F9A92_100%)] p-8 text-white shadow-lift">
            <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-200">Next step</p>
                <h2 className="mt-3 text-3xl text-white sm:text-4xl">Need to talk to us?</h2>
                <p className="mt-4 max-w-2xl text-lg leading-8 text-white/80">
                  Use the contact page for patient, carer and nurse enquiries while the platform continues to develop.
                </p>
              </div>
              <Link to="/contact" className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-medium text-ink-900 transition hover:bg-sand-100">
                Contact Us
                <FiArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PublicSiteChrome>
  );
}
