import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FiArrowRight, FiMenu, FiShield, FiX } from "./PublicIcons";
import PageMeta from "./PageMeta";

type PublicSiteChromeProps = {
  children: React.ReactNode;
  ctaLabel?: string;
  ctaTo?: string;
  metaTitle?: string;
  metaDescription?: string;
};

export default function PublicSiteChrome({
  children,
  ctaLabel = "Request Care",
  ctaTo = "/request-care",
  metaTitle = "NurseConnectCare",
  metaDescription = "NurseConnectCare connects clients, carers and organisations with independent nursing support and a secure EIRENIX Care workflow.",
}: PublicSiteChromeProps) {
  const year = new Date().getFullYear();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const closeMenu = () => setMobileMenuOpen(false);

  return (
    <div className="min-h-screen overflow-x-hidden bg-sand-100 text-ink-900">
      <PageMeta title={metaTitle} description={metaDescription} />
      <a href="#main-content" className="skip-link">Skip to content</a>

      <header className="sticky top-0 z-50 border-b border-ink-200/70 bg-sand-100/95 backdrop-blur-xl">
        <div className="mx-auto flex min-h-[78px] w-full max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
          <Link to="/" className="flex shrink-0 items-center gap-3">
            <img src="/NurseConnect-logo.png" alt="NurseConnectCare logo" className="h-11 w-11 rounded-2xl object-contain shadow-soft" />
            <div>
              <p className="text-lg font-extrabold leading-none tracking-tight text-ink-900">NurseConnectCare</p>
              <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.18em] text-ink-500">Care at Home</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-5 text-[13px] font-semibold text-ink-700 lg:flex" aria-label="Main public navigation">
            <Link to="/" className="whitespace-nowrap transition hover:text-brand-700">Home</Link>
            <Link to="/services" className="whitespace-nowrap transition hover:text-brand-700">Services</Link>
            <Link to="/about" className="whitespace-nowrap transition hover:text-brand-700">About</Link>
            <Link to="/how-it-works" className="whitespace-nowrap transition hover:text-brand-700">How It Works</Link>
            <Link to="/contact" className="whitespace-nowrap transition hover:text-brand-700">Contact</Link>
          </nav>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              aria-expanded={mobileMenuOpen}
              aria-controls="public-mobile-menu"
              aria-label={mobileMenuOpen ? "Close navigation menu" : "Open navigation menu"}
              onClick={() => setMobileMenuOpen((value) => !value)}
              className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-ink-200 bg-white text-ink-900 shadow-soft transition hover:border-brand-500 hover:text-brand-700 lg:hidden"
            >
              {mobileMenuOpen ? <FiX className="h-5 w-5" /> : <FiMenu className="h-5 w-5" />}
            </button>

            <Link
              to={ctaTo}
              className="hidden items-center gap-2 whitespace-nowrap rounded-full bg-brand-700 px-4 py-2.5 text-sm font-bold text-white shadow-soft transition hover:bg-brand-900 sm:inline-flex"
            >
              {ctaLabel}
              <FiArrowRight className="h-4 w-4" />
            </Link>

            <Link
              to="/clinician-login?mode=signup"
              className="inline-flex items-center gap-2 whitespace-nowrap rounded-full bg-brand-900 px-4 py-2.5 text-sm font-bold text-white shadow-soft transition hover:bg-ink-700"
            >
              <FiShield className="h-4 w-4" />
              <span className="hidden xl:inline">EIRENIX Care</span>
              <span className="xl:hidden">Clinician</span>
            </Link>
          </div>
        </div>

        {mobileMenuOpen ? (
          <div id="public-mobile-menu" className="mx-auto w-full max-w-7xl px-4 pb-4 sm:px-6 lg:hidden lg:px-8">
            <div className="rounded-[24px] border border-ink-200 bg-white p-4 shadow-lift">
              <nav className="grid gap-1 text-sm font-semibold text-ink-800">
                <Link to="/" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Home</Link>
                <Link to="/services" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Services</Link>
                <Link to="/about" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">About</Link>
                <Link to="/how-it-works" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">How It Works</Link>
                <Link to="/contact" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Contact</Link>
                <div className="my-2 border-t border-ink-200" />
                <Link to="/request-care" onClick={closeMenu} className="rounded-2xl bg-brand-50 px-4 py-3 text-brand-900">Request Care</Link>
                <Link to="/patient-login?mode=signup" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Client / Carer Access</Link>
                <Link to="/for-organisations/request" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">For Organisations</Link>
                <Link to="/for-nurses/apply" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">For Nurses</Link>
                <Link to="/for-nurses/cpd" onClick={closeMenu} className="rounded-2xl px-4 py-3 hover:bg-sand-200">Nurses CPD</Link>
                <Link to="/clinician-login?mode=signup" onClick={closeMenu} className="mt-1 rounded-2xl bg-brand-900 px-4 py-3 text-white">EIRENIX Care / Clinician Access</Link>
              </nav>
            </div>
          </div>
        ) : null}
      </header>

      <main id="main-content">{children}</main>

      <section className="mx-auto my-8 grid w-[calc(100%_-_2rem)] max-w-7xl gap-6 rounded-[30px] bg-brand-900 p-7 text-white shadow-lift sm:p-9 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.22em] text-brand-200">Connected secure platform</p>
          <h2 className="mt-2 text-2xl font-extrabold text-white sm:text-3xl">EIRENIX Care</h2>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-white/75">
            The secure clinical and practice-management environment behind NurseConnectCare. Authorised nurses use EIRENIX Care for care requests, bookings, patient records, service evidence, billing workflows and ongoing care coordination.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 lg:justify-end">
          <Link to="/clinician-login?mode=signup" className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-bold text-brand-900">
            <FiShield className="h-4 w-4" /> Clinician Access
          </Link>
          <Link to="/for-nurses/apply" className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-3 text-sm font-bold text-white">
            Nurse registration <FiArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <footer className="bg-brand-900 text-white">
        <div className="mx-auto w-full max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <div className="flex items-center gap-3">
                <img src="/NurseConnect-logo.png" alt="" className="h-10 w-10 rounded-xl object-contain" />
                <div>
                  <p className="font-extrabold">NurseConnectCare</p>
                  <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/55">Care at Home</p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-7 text-white/65">
                A connector and workflow platform for clients, carers, independent nurses and provider-aware care at home.
              </p>
            </div>

            <div>
              <p className="text-sm font-bold">Explore</p>
              <div className="mt-4 grid gap-2 text-sm text-white/65">
                <Link to="/services" className="hover:text-white">Services</Link>
                <Link to="/about" className="hover:text-white">About</Link>
                <Link to="/how-it-works" className="hover:text-white">How It Works</Link>
                <Link to="/contact" className="hover:text-white">Contact</Link>
                <Link to="/privacy" className="hover:text-white">Privacy Policy</Link>
                <Link to="/terms" className="hover:text-white">Terms of Use</Link>
              </div>
            </div>

            <div>
              <p className="text-sm font-bold">Care pathways</p>
              <div className="mt-4 grid gap-2 text-sm text-white/65">
                <Link to="/request-care" className="hover:text-white">Request Care</Link>
                <Link to="/patient-login?mode=signup" className="hover:text-white">Client / Carer Access</Link>
                <Link to="/for-organisations/request" className="hover:text-white">Organisation Request</Link>
                <Link to="/for-nurses/apply" className="hover:text-white">Nurse Registration</Link>
                <Link to="/for-nurses/cpd" className="hover:text-white">Nurses CPD</Link>
              </div>
            </div>

            <div>
              <p className="text-sm font-bold">EIRENIX Care</p>
              <p className="mt-4 text-sm leading-7 text-white/65">
                Secure records, bookings, clinical workflows and care-management access for authorised staff.
              </p>
              <Link to="/clinician-login?mode=signup" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-brand-200 hover:text-white">
                <FiShield className="h-4 w-4" /> Clinician Portal <FiArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <div className="mt-10 flex flex-col gap-3 border-t border-white/10 pt-6 text-xs leading-6 text-white/50 lg:flex-row lg:justify-between">
            <span>{`Copyright © ${year} NurseConnectCare. All rights reserved.`}</span>
            <span>NurseConnectCare does not provide nursing services or employ nurses. For urgent or emergency care, call 000.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
