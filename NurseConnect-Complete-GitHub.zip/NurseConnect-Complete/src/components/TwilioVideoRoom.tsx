import React from "react";

interface TwilioVideoRoomProps {
  roomName: string;
  appointmentId: string;
}

/**
 * Placeholder Twilio video room component.
 *
 * This keeps the "video provider" abstraction in place so that
 * you can switch from Jitsi to Twilio later by:
 *   1) Implementing the real Twilio client logic here, and
 *   2) Changing VIDEO_PROVIDER in VideoCallPage.tsx to "twilio".
 */
export const TwilioVideoRoom: React.FC<TwilioVideoRoomProps> = ({
  roomName,
  appointmentId,
}) => {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gray-900 text-gray-100 text-sm">
      <div className="max-w-sm text-center space-y-2 px-4">
        <p className="font-semibold">Twilio Video (coming soon)</p>
        <p>
          Room: <span className="font-mono break-all">{roomName}</span>
        </p>
        <p className="text-xs text-gray-300">
          When you&apos;re ready to integrate Twilio, replace this placeholder with
          the real Twilio Video client. The appointment ID for this session is{" "}
          <span className="font-mono">{appointmentId}</span>.
        </p>
      </div>
    </div>
  );
};
