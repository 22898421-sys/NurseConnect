// src/models/emr.ts
import { Timestamp } from "firebase/firestore";
import { AppointmentTriageSnapshot, TriageUrgencyTier } from "./triage";

export type Sex = "male" | "female" | "other" | "unknown";
export type AustralianStateOrTerritory = "ACT" | "NSW" | "NT" | "QLD" | "SA" | "TAS" | "VIC" | "WA";
export type PatientBillingType = "medicare" | "private_pay" | "private_health" | "mixed";

export type AppointmentStatus = "scheduled" | "in_progress" | "completed" | "cancelled";
export type AppointmentMode = "video" | "phone" | "in_person";

export type UserRole = "patient" | "clinician" | "system_admin";
export type NormalizedUserRole = UserRole;

export function normalizeRole(role: string | null | undefined): NormalizedUserRole | null {
  const r = String(role || "").trim().toLowerCase();
  if (!r) return null;
  if (r === "patient" || r === "clinician" || r === "system_admin") return r;
  return null;
}

export interface Patient {
  id: string;
  fullName: string;
  lastName?: string | null;
  email?: string | null;
  phone?: string | null;
  phoneNumber?: string | null;
  dateOfBirth?: string | null; // YYYY-MM-DD
  urNumber?: string | null;
  omang?: string | null;
  idNumber?: string | null;
  medicareCardNumber?: string | null;
  medicareReferenceNumber?: string | null;
  medicareExpiry?: string | null; // MM/YYYY
  billingType?: PatientBillingType | null;
  privateHealthFund?: string | null;
  privateHealthMembershipNumber?: string | null;
  nextOfKinName?: string | null;
  nextOfKinRelationship?: string | null;
  nextOfKinPhone?: string | null;
  emergencyContactName?: string | null;
  emergencyContactRelationship?: string | null;
  emergencyContactPhone?: string | null;
  powerOfAttorneyName?: string | null;
  powerOfAttorneyPhone?: string | null;
  powerOfAttorneyEmail?: string | null;
  sex?: Sex | null;
  address?: string | null;
  addressLine1?: string | null;
  addressLine2?: string | null;
  suburb?: string | null;
  state?: AustralianStateOrTerritory | null;
  postcode?: string | null;
  country?: string | null;
  userId?: string | null; // linked auth uid (optional)
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface Appointment {
  id: string;

  // Linking
  patientId: string;
  patientName?: string | null;

  // Added to satisfy existing VideoCallPage usage
  patientEmail?: string | null;

  clinicianId: string; // clinician user's auth uid
  clinicianName?: string | null;

  // Scheduling
  scheduledAt: Timestamp;
  durationMinutes?: number | null;
  telehealthGraceMinutesOverride?: number | null;
  paymentMethod?: "cash" | "card" | null;
  paymentStatus?: "unpaid" | "paid" | null;
  paidAt?: Timestamp;

  mode: AppointmentMode;
  status: AppointmentStatus;

  reason?: string | null;
  consultationNotes?: string | null;
  practiceId?: string | null;
  triageSessionId?: string | null;
  triageStatus?: "not_started" | "active" | "completed" | "escalated" | null;
  triageUrgency?: TriageUrgencyTier | null;
  triageCallbackBy?: Timestamp | null;
  triageLastUpdatedAt?: Timestamp | null;
  triageSnapshot?: AppointmentTriageSnapshot | null;

  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}
