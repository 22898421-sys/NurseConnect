export type TriageChannel = "portal";
export type TriageStatus = "active" | "completed" | "escalated" | "abandoned";
export type TriageUrgencyTier = "routine" | "priority_review" | "urgent_callback" | "emergency_now";

export type TriageQuestionOption = {
  value: string;
  label: string;
};

export type TriageQuestion = {
  id: string;
  text: string;
  inputType: "free_text" | "single_select" | "yes_no";
  fieldKey: string;
  required: boolean;
  options?: TriageQuestionOption[];
};

export type TriageProgress = {
  answered: number;
  totalEstimated: number;
};

export type TriageOutcome = {
  urgencyTier: TriageUrgencyTier;
  patientMessage: string;
  callbackBy?: string | null;
  createdTaskId?: string | null;
  clinicianSnapshot?: {
    symptomDomain: string | null;
    summary: string;
    redFlagCodes: string[];
  };
};

export type TriageSessionStartResult = {
  triageSessionId: string;
  status: TriageStatus | "active";
  question: TriageQuestion | null;
  progress: TriageProgress;
  outcome?: {
    urgencyTier: TriageUrgencyTier | null;
    patientMessage: string | null;
  };
};

export type TriageAnswerResult = {
  status: "active" | "completed" | "escalated";
  nextQuestion?: TriageQuestion | null;
  progress?: TriageProgress;
  urgencyPreview?: TriageUrgencyTier | null;
};

export type AppointmentTriageSnapshot = {
  symptomDomain?: string | null;
  urgencyTier?: TriageUrgencyTier | null;
  summary?: string | null;
  redFlagCodes?: string[];
};
