// src/models/encounter.ts
import { Timestamp } from "firebase/firestore";

export type EncounterType = "consultation" | "follow_up" | "procedure";
export type EncounterStatus = "draft" | "completed";

export type SoapFields = {
  subjective?: string;
  objective?: string;
  assessment?: string;
  plan?: string;
};

export type BreakGlassState = {
  enabled?: boolean;
  enabledBy?: string;
  enabledAt?: Timestamp;

  reason?: string;

  resolvedBy?: string;
  resolvedAt?: Timestamp;
  correctionReason?: string;
};

export interface Encounter {
  id: string;

  patientId: string;
  practitionerId: string;
  practiceId?: string | null;

  encounterDate: string; // DD-MM-YYYY
  encounterDateISO?: string; // YYYY-MM-DD (optional for ordering)

  type: EncounterType;
  reason: string;

  status?: EncounterStatus; // default draft if missing
  breakGlass?: BreakGlassState;

  soap?: SoapFields;
  notes?: string;

  // Draft-only versioning pointers
  currentSoapVersion?: number;
  lastEditedAt?: Timestamp;
  lastEditedByUid?: string;

  createdAt?: Timestamp;
  createdBy?: string;
  updatedAt?: Timestamp;
  updatedBy?: string;
}