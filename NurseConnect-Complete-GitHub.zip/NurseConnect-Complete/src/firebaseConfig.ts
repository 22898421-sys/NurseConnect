// src/firebaseConfig.ts
import { initializeApp, getApps } from "firebase/app";
import { getAuth, connectAuthEmulator } from "firebase/auth";
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore";
import { getFunctions, connectFunctionsEmulator } from "firebase/functions";
import { getStorage, connectStorageEmulator } from "firebase/storage";

// Default this workspace to the isolated NurseConnectCare local project.
const projectId = process.env.REACT_APP_FIREBASE_PROJECT_ID || "nurseconnectcare-local";
const isProduction = process.env.NODE_ENV === "production";

// Use real Firebase web config in production, demo defaults only for local emulator use.
const firebaseConfig = {
  apiKey:
    process.env.REACT_APP_FIREBASE_API_KEY ||
    (isProduction ? "" : "demo-key"),
  authDomain:
    process.env.REACT_APP_FIREBASE_AUTH_DOMAIN ||
    (isProduction ? "" : "localhost"),
  projectId,
  storageBucket:
    process.env.REACT_APP_FIREBASE_STORAGE_BUCKET ||
    `${projectId}.appspot.com`,
  messagingSenderId:
    process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID || "0",
  appId: process.env.REACT_APP_FIREBASE_APP_ID || "demo-app",
};

// Avoid double-initialization in fast refresh
export const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const functions = getFunctions(app, "australia-southeast1");
export const storage = getStorage(app);

// Ports (match your firebase.json)
const AUTH_PORT = Number(process.env.REACT_APP_FIREBASE_AUTH_PORT || 9399);
const FIRESTORE_PORT = Number(process.env.REACT_APP_FIREBASE_FIRESTORE_PORT || 8380);
const FUNCTIONS_PORT = Number(process.env.REACT_APP_FIREBASE_FUNCTIONS_PORT || 5005);
const STORAGE_PORT = Number(process.env.REACT_APP_FIREBASE_STORAGE_PORT || 9298);
const IS_PRODUCTION = process.env.NODE_ENV === "production";
// Default to emulator mode on localhost unless explicitly disabled.
const USE_EMULATORS = process.env.REACT_APP_USE_EMULATORS !== "false";

function isLocalhost() {
  if (typeof window === "undefined") return false;
  const h = window.location.hostname;
  return h === "localhost" || h === "127.0.0.1";
}

/**
 * IMPORTANT:
 * - CRA sometimes sets NODE_ENV as expected, but relying on it can break emulator linkage.
 * - This makes emulator linkage deterministic whenever you run the UI on localhost.
 */
if (isLocalhost() && !IS_PRODUCTION && USE_EMULATORS) {
  // Prevent "already called" errors in dev reloads by checking internal settings
  const anyDb = db as any;
  // Auth emulator
  try {
    // connectAuthEmulator throws if called twice; guard by checking internal config if present
    const authEmu = (auth as any)?._delegate?._config?.emulator;
    if (!authEmu) {
      connectAuthEmulator(auth, `http://127.0.0.1:${AUTH_PORT}`, { disableWarnings: true });
    }
  } catch {
    // ignore double-connect
  }

  // Firestore emulator
  try {
    const host = anyDb?._settings?.host as string | undefined;
    if (!host || !host.includes(`127.0.0.1:${FIRESTORE_PORT}`)) {
      connectFirestoreEmulator(db, "127.0.0.1", FIRESTORE_PORT);
    }
  } catch {
    // ignore double-connect
  }

  // Functions emulator
  try {
    // No reliable internal guard across versions; just try/catch
    connectFunctionsEmulator(functions, "127.0.0.1", FUNCTIONS_PORT);
  } catch {
    // ignore double-connect
  }

  // Storage emulator
  try {
    const host = (storage as any)?._host as string | undefined;
    if (!host || !host.includes(`127.0.0.1:${STORAGE_PORT}`)) {
      connectStorageEmulator(storage, "127.0.0.1", STORAGE_PORT);
    }
  } catch {
    // ignore double-connect
  }

  // Helpful console output for debugging
  // eslint-disable-next-line no-console
  if (!IS_PRODUCTION) {
    // eslint-disable-next-line no-console
    console.log("[firebaseConfig] Using emulators:", {
      projectId,
      auth: `127.0.0.1:${AUTH_PORT}`,
      firestore: `127.0.0.1:${FIRESTORE_PORT}`,
      functions: `127.0.0.1:${FUNCTIONS_PORT}`,
      storage: `127.0.0.1:${STORAGE_PORT}`,
    });
  }
} else if (!IS_PRODUCTION) {
  // eslint-disable-next-line no-console
  console.log("[firebaseConfig] Emulator mode disabled.", {
    projectId,
    localhost: isLocalhost(),
    useEmulators: USE_EMULATORS,
  });
}
