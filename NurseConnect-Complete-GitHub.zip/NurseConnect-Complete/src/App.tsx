// src/App.tsx
import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Routes, Route, Outlet, Navigate, useLocation } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";

const NurseConnectCareLandingPage = lazy(() => import("./components/NurseConnectCareLandingPage"));
const AboutPage = lazy(() => import("./components/AboutPage"));
const ServicesPage = lazy(() => import("./components/ServicesPage"));
const HowItWorksPage = lazy(() => import("./components/HowItWorksPage"));
const ContactPage = lazy(() => import("./components/ContactPage"));
const PrivacyPolicyPage = lazy(() => import("./components/PrivacyPolicyPage"));
const TermsPage = lazy(() => import("./components/TermsPage"));
const PatientBookingPage = lazy(() => import("./components/PatientBookingPage"));
const ServiceRequestPage = lazy(() => import("./components/ServiceRequestPage"));
const ServiceRequestManagePage = lazy(() => import("./components/ServiceRequestManagePage"));
const NurseApplicationPage = lazy(() => import("./components/NurseApplicationPage"));
const NurseCpdPage = lazy(() => import("./components/NurseCpdPage"));
const BootstrapSetupPage = lazy(() => import("./components/BootstrapSetupPage"));
const Login = lazy(() => import("./components/AccessPage"));
const SupportAdminPage = lazy(() => import("./components/AdminSupportConsole"));
const Dashboard = lazy(() => import("./components/Dashboard"));
const PatientPortal = lazy(() => import("./components/PatientPortal"));
const ClinicianPortal = lazy(() => import("./components/ClinicianPortal"));
const ClinicianRosterPage = lazy(() => import("./components/ClinicianRosterPage"));
const NurseSubscriptionPage = lazy(() => import("./components/NurseSubscriptionPage"));
const NurseBillingPage = lazy(() => import("./components/NurseBillingPage"));
const ServiceRequestsInboxPage = lazy(() => import("./components/ServiceRequestsInboxPage"));
const ServiceInvoicePrintPage = lazy(() => import("./components/ServiceInvoicePrintPage"));
const ServiceEvidencePackPage = lazy(() => import("./components/ServiceEvidencePackPage"));
const PatientListPage = lazy(() => import("./components/PatientListPage"));
const PatientDetailPage = lazy(() => import("./components/PatientDetailPage"));
const PatientChartPage = lazy(() => import("./components/PatientChartPage"));
const PrescriptionTrackingPage = lazy(() => import("./components/PrescriptionTrackingPage"));
const PublicEnquiriesAdminPage = lazy(() => import("./components/PublicEnquiriesAdminPage"));
const ComplianceConsolePage = lazy(() => import("./components/ComplianceConsolePage"));
const SupportAccessPage = lazy(() => import("./components/SupportAccessPage"));
const EncounterDetailPage = lazy(() => import("./components/EncounterDetailPage"));
const EncounterPrintPage = lazy(() => import("./components/EncounterPrintPage"));
const ClinicalActionPrintPage = lazy(() => import("./components/ClinicalActionPrintPage"));
const ProtectedRoute = lazy(() => import("./components/ProtectedRoute"));
const NavBar = lazy(() => import("./components/NavBar"));
const VideoCallPage = lazy(() => import("./components/VideoCallPage"));
const ProfileSettingsPage = lazy(() => import("./components/ProfileSettingsPage"));

const AppShell: React.FC = () => {
  const location = useLocation();
  const hideNavBar =
    /\/patients\/[^/]+\/documents\/[^/]+\/print$/.test(location.pathname) ||
    /\/encounters\/[^/]+\/print$/.test(location.pathname) ||
    /\/billing\/service-invoices\/[^/]+\/(print|evidence)$/.test(location.pathname);

  return (
    <div className="min-h-screen flex flex-col">
      {!hideNavBar ? <NavBar /> : null}
      <main className="flex-1">
        <Outlet />
      </main>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Suspense fallback={<div className="p-6 text-sm text-gray-600">Loading...</div>}>
          <Routes>
            <Route path="/" element={<NurseConnectCareLandingPage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/how-it-works" element={<HowItWorksPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/find-care" element={<PatientBookingPage />} />
            <Route path="/request-care" element={<PatientBookingPage />} />
            <Route path="/for-organisations/request" element={<ServiceRequestPage />} />
            <Route path="/service-requests/manage/:requestId" element={<ServiceRequestManagePage />} />
            <Route path="/for-nurses/apply" element={<NurseApplicationPage />} />
            <Route path="/for-nurses/cpd" element={<NurseCpdPage />} />
            <Route path="/bootstrap/setup" element={<BootstrapSetupPage />} />
            <Route path="/patient-login" element={<Login />} />
            <Route path="/nurse-login" element={<Navigate to="/clinician-login" replace />} />
            <Route path="/clinician-login" element={<Login />} />
            <Route path="/login" element={<Navigate to="/clinician-login" replace />} />

            <Route
              element={
                <ProtectedRoute allowedRoles={["patient", "clinician", "system_admin"]}>
                  <AppShell />
                </ProtectedRoute>
              }
            >
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/profile" element={<ProfileSettingsPage />} />

              <Route
                path="/patient"
                element={
                  <ProtectedRoute allowedRoles={["patient"]}>
                    <PatientPortal />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/schedule"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <ClinicianPortal />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/my-roster"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <ClinicianRosterPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/nurse-subscription"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <NurseSubscriptionPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/service-requests"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <ServiceRequestsInboxPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/billing"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <NurseBillingPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/billing/service-invoices/:invoiceId/print"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <ServiceInvoicePrintPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/billing/service-invoices/:invoiceId/evidence"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <ServiceEvidencePackPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/admin"
                element={<Navigate to="/dashboard" replace />}
              />

              <Route
                path="/system-admin"
                element={
                  <ProtectedRoute allowedRoles={["system_admin"]}>
                    <SupportAdminPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/patients"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <PatientListPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/patients/:patientId"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <PatientDetailPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/patients/:patientId/chart"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <PatientChartPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/patients/:patientId/chart/encounters/:encounterId"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <EncounterDetailPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/patients/:patientId/chart/encounters/:encounterId/print"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <EncounterPrintPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/patients/:patientId/documents/:docId/print"
                element={
                  <ProtectedRoute allowedRoles={["patient", "clinician"]}>
                    <ClinicalActionPrintPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/patients/:patientId/prescriptions/:prescriptionId"
                element={
                  <ProtectedRoute allowedRoles={["clinician"]}>
                    <PrescriptionTrackingPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/appointments"
                element={<Navigate to="/dashboard" replace />}
              />

              <Route
                path="/rosters"
                element={<Navigate to="/dashboard" replace />}
              />

              <Route
                path="/public-enquiries"
                element={
                  <ProtectedRoute allowedRoles={["system_admin"]}>
                    <PublicEnquiriesAdminPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/compliance"
                element={
                  <ProtectedRoute allowedRoles={["system_admin"]}>
                    <ComplianceConsolePage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/support-access"
                element={
                  <ProtectedRoute allowedRoles={["clinician", "system_admin"]}>
                    <SupportAccessPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/call"
                element={
                  <ProtectedRoute allowedRoles={["patient", "clinician"]}>
                    <VideoCallPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/call/:appointmentId"
                element={
                  <ProtectedRoute allowedRoles={["patient", "clinician"]}>
                    <VideoCallPage />
                  </ProtectedRoute>
                }
              />
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </Router>
    </AuthProvider>
  );
}

export default App;
