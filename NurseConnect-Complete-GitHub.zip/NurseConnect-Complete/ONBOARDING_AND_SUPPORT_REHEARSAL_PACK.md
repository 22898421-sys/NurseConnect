# Onboarding and Support Rehearsal Pack

Date: 2026-06-18

This pack prepares the final Compliance Operations human-readiness checks. It desk-checks the written flows against the current runtime surface and defines the live rehearsal required before production sign-off.

## Covered Tracker Items

This pack supports progress on:

- `T057` - Validate written nurse onboarding flow
- `T059` - Confirm support/admin response readiness

These items are not fully complete until a real nurse/operator and a named support/admin user complete the rehearsal steps and record outcomes.

## T057 Desk-Check: Written Nurse Onboarding Flow

Current status: desk-check complete; live nurse/operator validation pending.

Runtime surfaces checked:

- `/for-nurses/apply` - nurse registration interest and pre-onboarding profile capture
- `/clinician-login?mode=signup` - nurse account creation
- `/nurse-subscription` - subscription/trial cycle and billing setup
- `/profile` - professional profile, AHPRA, public service profile, billing details
- `/system-admin` - AHPRA manual verification queue
- `/service-requests` - provider/client request inbox
- `/schedule`, `/my-roster`, `/patients`, `/billing`, `/support-access` - restricted nurse workspace surfaces

Written flow to rehearse:

1. Nurse reviews public registration page and confirms they understand NurseConnectCare is infrastructure, not employment.
2. Nurse submits registration interest with:
   - name
   - email
   - service region
   - nurse type
   - AHPRA registration number
   - travel radius
   - visit types
   - funding models
   - service focus
3. Nurse creates secure account from nurse access.
4. Nurse selects nurse type and enters AHPRA details.
5. Nurse starts the subscription/trial path.
6. Nurse completes profile and billing profile fields.
7. System admin reviews AHPRA details in the manual verification queue.
8. Nurse confirms they can access core restricted workspace areas.
9. Nurse confirms they can view service requests and understands independent-provider responsibility.
10. Nurse confirms they can prepare billing/evidence pack records without NurseConnectCare holding funds or submitting claims.

Evidence to capture during live validation:

- test nurse name or identifier
- date/time of rehearsal
- account creation result
- profile/billing readiness result
- AHPRA verification queue result
- service request inbox result
- billing/evidence pack navigation result
- any defects or unclear wording
- sign-off owner

## T059 Desk-Check: Support/Admin Response Readiness

Current status: desk-check complete; named support/admin rehearsal pending.

Runtime surfaces checked:

- `/system-admin` - technical support console and nurse verification queue
- `/public-enquiries` - public contact, nurse-registration interest, and service-request review
- `/compliance` - provider, credential, associated-provider, incident/complaint, and audit dashboard
- `/support-access` - request-based, time-limited, audited client-record troubleshooting
- `COMPLIANCE_OPERATIONS_RUNBOOK.md` - admin runbook, triage matrix, escalation contacts, known-issues register
- `G002_SUPPORT_ACCESS_SIGNOFF.md` - audited support access gate evidence

Written support/admin response flow to rehearse:

1. System admin logs in and opens `/system-admin`.
2. System admin reviews nurse verification queue and records an AHPRA verification note.
3. System admin opens `/public-enquiries` and reviews contact, nurse registration, and service request queues.
4. System admin opens `/compliance` and checks:
   - provider onboarding
   - credential expiry
   - associated-provider status
   - incident/complaint records
   - audit dashboard
5. System admin opens `/support-access` and reviews a provider/clinician support request.
6. Clinician/provider user creates a support access request with client ID, reason, scope, and urgency.
7. System admin approves a 4-hour grant only for the assigned admin.
8. System admin logs and loads the client record through the support workflow.
9. System admin revokes or closes the grant after troubleshooting.
10. Support/admin user updates the known-issues register or incident/complaint record if needed.

Evidence to capture during live validation:

- named support/admin tester
- date/time of rehearsal
- system-admin login result
- public enquiry queue result
- compliance dashboard result
- support access request ID
- support grant creation result
- access audit log confirmation
- grant revocation/closure result
- known issue or incident update if applicable
- unresolved defects or gaps
- sign-off owner

## Current Readiness Assessment

| Area | Desk-check result | Remaining gate |
|---|---|---|
| Nurse onboarding written flow | Ready for live rehearsal | actual nurse/operator test |
| Support/admin response path | Ready for live rehearsal | named support/admin test |
| AHPRA verification queue | Runtime surface present | manual verification exercise |
| Support access audit | Automated evidence passed via G002 | live support/admin rehearsal |
| Public/support inbox | Runtime surface validated | named admin response exercise |
| Compliance console | Runtime surface and rules validated | named admin response exercise |

## Residual Scope

Do not mark `T057` or `T059` as `Done` until the live rehearsal evidence above is recorded.

This pack does not sign off:

- legal/privacy review
- clinical governance review
- live pilot
- production release decision

