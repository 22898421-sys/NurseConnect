# Local Development (Firebase Emulator Suite)

Use this app fully locally without cloud deployment.

## 1) Install dependencies

```bash
npm install
npm --prefix functions install
```

Optional currency default:

```bash
export REACT_APP_DEFAULT_CURRENCY=AUD
```

Optional telehealth settings:

```bash
export REACT_APP_VIDEO_PROVIDER=jitsi
export REACT_APP_JITSI_DOMAIN=meet.jit.si
export REACT_APP_JITSI_ROOM_PREFIX=healthful
```

Optional nurse subscription settings:

```bash
export REACT_APP_SUBSCRIPTION_GATEWAY=demo
export REACT_APP_ENABLE_DEMO_BILLING=true
export ENABLE_DEMO_BILLING=true
```

## 2) Run locally (recommended: two terminals)

Terminal A:

```bash
npm run emulators
```

Terminal B:

```bash
npm run start:local
```

App URL: `http://localhost:3000`  
Emulator UI URL: `http://127.0.0.1:4005`

## 3) Single-command local run (optional)

```bash
npm run dev:local
```

## Notes

- `start:local` sets `REACT_APP_USE_EMULATORS=true`, so frontend uses local Auth/Firestore/Functions/Storage emulators.
- Jitsi telehealth uses `meet.jit.si` by default, but you can override it with `REACT_APP_JITSI_DOMAIN`.
- Nurse subscriptions can run in demo mode locally. In that mode, the nurse chooses cadence and payment method, then uses a controlled placeholder activation flow instead of a real card charge.
- This NurseConnectCare local environment is intentionally unseeded. Start from an empty emulator unless you create your own local fixtures.
- `emulators`, `emulators:export`, and `emulators:fresh` all set `PUBLIC_APP_URL=http://localhost:3000` so service-request management links resolve correctly in local notifications.
- For a clean emulator state, use:

```bash
npm run emulators:fresh
```

## WhatsApp API (optional, Twilio)

The `Send WhatsApp (API)` button in telehealth uses a Firebase callable function.
`Refresh WA Status` queries Twilio for the latest delivery state and stores it on the appointment.

If Twilio env vars are missing, the function runs in **stub mode** (no real message sent).

Set these before starting emulators to send real WhatsApp messages:

```bash
export TWILIO_ACCOUNT_SID=...
export TWILIO_AUTH_TOKEN=...
export TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
```

Then start emulators as normal:

```bash
npm run emulators
```

## Service Request Email Notifications (optional, Resend)

Service-request notifications now create auditable records in:
- `serviceRequestNotifications`
- `serviceRequestNotificationDeliveries`

If email provider settings are missing, the workflow stays active but deliveries are recorded as `stub`.

To enable real email delivery locally:

1. Copy the example env file:

```bash
cp functions/.env.local.example functions/.env.local
```

2. Fill in:

```bash
RESEND_API_KEY=...
NOTIFICATION_FROM_EMAIL=NurseConnectCare <notifications@yourdomain.example>
PUBLIC_APP_URL=http://localhost:3000
```

3. Restart the emulators:

```bash
npm run emulators
```

For deployed functions, use the values in `functions/.env.example` as the production template.

## Nurse Subscription Placeholder (pre-Stripe)

Before you create a Stripe account, the safest approach for demos and deployment testing is:

- keep `REACT_APP_SUBSCRIPTION_GATEWAY=demo`
- keep `REACT_APP_ENABLE_DEMO_BILLING=true`
- keep `ENABLE_DEMO_BILLING=true`
- use the `Run demo checkout` action on the nurse subscription page

This marks the nurse subscription active without collecting card details or processing funds.

Recommended rollout path:

1. Local and staging: demo placeholder mode
2. Pre-live UAT: still demo placeholder mode, with real subscription wording and flows
3. Production: replace the placeholder activation with Stripe Checkout for new subscriptions and Stripe Billing Portal for self-service updates

Do not collect real card details until the Stripe account, webhook handling, and production billing flows are properly configured.
