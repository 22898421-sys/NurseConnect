# G004/G005 Compliance Operations Sign-off Evidence

Date: 2026-06-18

This evidence note supports sign-off for the compliance operations decision gates that are ready based on documented workflows and emulator-backed access validation.

## Gate Outcomes

| Gate | Decision rule | Outcome | Evidence |
| --- | --- | --- | --- |
| G004 | Incident and complaint workflows are documented and tested | Passed | `COMPLIANCE_OPERATIONS_RUNBOOK.md`, `COMPLIANCE_WORKFLOW_VALIDATION.md`, `scripts/testComplianceWorkspaceRules.mjs`, `LEGAL_PRIVACY_DRAFT_PACK.md` |
| G005 | Credential and provider verification workflows are documented | Passed | `COMPLIANCE_OPERATIONS_RUNBOOK.md`, `COMPLIANCE_WORKFLOW_VALIDATION.md`, `scripts/testComplianceWorkspaceRules.mjs` |

## G004 Evidence Basis

The incident and complaint workflow is documented in `COMPLIANCE_OPERATIONS_RUNBOOK.md` through the triage matrix, response targets, owner roles, status model, and escalation expectations.

The workflow is tested in `COMPLIANCE_WORKFLOW_VALIDATION.md` using `scripts/testComplianceWorkspaceRules.mjs`. The test suite validates that:

- Platform admins can create, list, read, and update incident and complaint records.
- Invalid incident or complaint status and severity values are denied.
- Non-admin clinicians cannot access the compliance workspace.
- Compliance records cannot be deleted by the test roles.

The draft legal/privacy pack also includes a draft incident and complaint SOP. That draft still requires external legal/privacy review and does not close G003.

## G005 Evidence Basis

Provider onboarding, credential verification, credential expiry tracking, and associated-provider compliance workflows are documented in `COMPLIANCE_OPERATIONS_RUNBOOK.md`.

The associated rules and data access behaviour are tested in `COMPLIANCE_WORKFLOW_VALIDATION.md` using `scripts/testComplianceWorkspaceRules.mjs`. The test suite validates that:

- Platform admins can create and update compliance provider records.
- Platform admins can create and update credential records, including expiry and verification metadata.
- Platform admins can create and update associated-provider records.
- Non-admin clinicians are denied access to the compliance workspace.
- Invalid status values are denied.
- Deletes are denied for compliance records.

## Residual Scope

This sign-off does not approve:

- G003 legal/privacy review completion.
- G006 pilot readiness or live pilot execution.
- G007 final no-critical/high issue review.
- Production deployment or live operating release.
- External legal approval of website, privacy, consent, subscription, incident, or complaint wording.

The evidence is sufficient to move G004 and G005 to `Passed` because their decision rules are limited to documented and tested operational workflows.
