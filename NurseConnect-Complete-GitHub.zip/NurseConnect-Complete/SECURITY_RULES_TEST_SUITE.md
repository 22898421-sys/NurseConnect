# Security Rules Test Suite Evidence

Date: 2026-06-18

Tracker item: `T015` - Build automated Firestore rules test suite.

## Result

Passed.

The launch-critical automated Firestore rules suite is now represented by a single command:

```bash
npm run test:rules
```

For a manually started local Firestore emulator on port `8380`, use:

```bash
npm run test:rules:local
```

## Included Test Coverage

The suite runs:

- `scripts/testG001RoleAccessRules.mjs`
- `scripts/testG002SupportAccessRules.mjs`

Together these tests validate:

- unauthenticated users cannot read restricted patient, clinical, encounter, summary, or compliance records
- client/carer users can access only their own client-facing records and cannot read clinician-only clinical chart internals
- clinicians/nurses can access patient, clinical, summary, portal document, and encounter records only within their practice scope
- clinicians cannot run unscoped patient collection queries
- clinicians cannot update patients outside their practice or change the patient `practiceId`
- system admins cannot browse client records, clinical records, patient summaries, or encounters by default
- system admins can access system-admin governance collections such as compliance provider records
- clinicians cannot access system-admin compliance provider records
- clinician/provider users can create support access requests for specific client records and reasons
- system-admin support grants must be request-linked, assigned to the acting admin, and time-limited
- active support grants permit access only while valid
- expired or revoked support grants deny access
- support access creates an append-only `accessAuditLogs` entry using action `support_patient_record_access`

## Evidence Commands

Latest verification command:

```bash
npm run test:rules:local
```

Expected terminal evidence:

```text
G001 role-based access rules validation passed.
G002 support-access rules validation passed.
```

## Files

- `package.json`
- `firestore.rules`
- `scripts/testG001RoleAccessRules.mjs`
- `scripts/testG002SupportAccessRules.mjs`
- `G001_ROLE_ACCESS_SIGNOFF.md`
- `G002_SUPPORT_ACCESS_SIGNOFF.md`
- `ROLE_PERMISSION_MATRIX.md`

## Residual Scope

This evidence closes the launch-critical automated rules suite for the current role model and support-access privacy controls. It does not sign off:

- final Terms of Use or Privacy Policy
- incident/complaint SOP readiness
- credential/provider verification SOP readiness
- controlled pilot completion
- final production cutover

Future hardening can add more granular rules tests for every collection listed in `PRODUCT_SCOPE_EVIDENCE_PACK.md`, but the production decision gates `G001` and `G002` are already covered by executable emulator tests.
