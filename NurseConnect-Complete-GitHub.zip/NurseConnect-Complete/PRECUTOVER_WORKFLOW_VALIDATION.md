# Pre-Cutover Workflow Validation Evidence

Date: 2026-06-18

This evidence supports focused production-cutover readiness checks for public contact/service request workflows and restricted compliance console access. It is not a substitute for final live smoke testing after deployment.

## Covered Tracker Items

This document supports:

- `T092` - Confirm contact forms and service requests work
- `T093` - Confirm compliance console is restricted to system admins

## T092 Contact Forms and Service Requests

Validated surfaces:

- `src/components/ContactPage.tsx`
- `src/components/NurseApplicationPage.tsx`
- `src/lib/publicSubmissions.ts`
- `functions/index.js`
- `src/components/ServiceRequestPage.tsx`
- `src/components/ServiceRequestsInboxPage.tsx`
- `src/components/ServiceRequestManagePage.tsx`
- `src/components/PublicEnquiriesAdminPage.tsx`
- `firestore.rules`

Validation evidence:

1. Public contact enquiries use callable function `submitPublicContactEnquiry`.
2. The function sanitises and validates full name, email, enquiry type, and message length.
3. Valid contact submissions create `publicContactEnquiries` records with `status: "new"`.
4. Nurse registration interest submissions use callable function `submitNurseRegistrationInterest`.
5. The function validates nurse identity, email, region, professional role, nurse type, AHPRA registration, visit types, funding models, and service focus.
6. Valid nurse registration interest submissions create `nurseRegistrationInterests` records with `status: "new"`.
7. Direct browser writes to public contact and nurse registration collections are denied by Firestore rules.
8. System-admin users can review and update public contact and nurse registration queues from `/public-enquiries`.
9. Public organisation/provider service requests are created from `/for-organisations/request`.
10. Service requests capture organisation, requester, provider/reference, Support at Home category, location, nurse type, care-plan context, funding pathway, and request type.
11. Service requests generate a management link using the request document ID as manage token.
12. Clinician/nurse users can review and respond to matching requests from `/service-requests`.
13. Requesters can mark service requests as filled or withdrawn from `/service-requests/manage/:requestId`.
14. System-admin users can review service requests from `/public-enquiries`.

Remaining cutover check:

- Run a live deployed smoke test after final deployment to confirm callable function configuration, Firebase project wiring, and public form submission in the live environment.

## T093 Compliance Console Restriction

Validated surfaces:

- `src/App.tsx`
- `src/components/ComplianceConsolePage.tsx`
- `src/lib/compliance.ts`
- `firestore.rules`
- `scripts/testG001RoleAccessRules.mjs`
- `scripts/testComplianceWorkspaceRules.mjs`

Validation evidence:

1. `/compliance` is wrapped in `ProtectedRoute` with `allowedRoles={["system_admin"]}`.
2. `ComplianceConsolePage` denies rendering unless `normalizedRole === "system_admin"`.
3. Firestore rules restrict the following collections to support/system-admin access:
   - `complianceProviders`
   - `complianceCredentials`
   - `associatedProviders`
   - `incidentComplaints`
   - `complianceReports`
   - `retentionRuns`
4. Deletes are blocked for compliance provider, credential, associated-provider, and incident/complaint records.
5. `G001_ROLE_ACCESS_SIGNOFF.md` confirms clinicians cannot access compliance provider records and system admins can access system-admin governance collections.
6. `COMPLIANCE_WORKFLOW_VALIDATION.md` confirms clinician, patient, and unauthenticated users cannot read compliance workflow records.
7. `npm run test:rules:local` includes the compliance workspace rules test.

Remaining cutover check:

- Run live role-login smoke tests after final deployment for patient, clinician, and system-admin accounts.

## Verification Commands

Latest verification:

```bash
npm run build
npm --prefix functions run build
npm run test:rules:local
```

Expected evidence:

```text
Compiled successfully.
functions/index.js syntax check passes.
G001 role-based access rules validation passed.
G002 support-access rules validation passed.
Compliance workspace rules validation passed.
```

## Residual Scope

This validation does not complete:

- final live public route smoke tests
- final live restricted route smoke tests
- login testing for every role in the deployed environment
- legal/privacy sign-off
- pilot completion
- production release decision

