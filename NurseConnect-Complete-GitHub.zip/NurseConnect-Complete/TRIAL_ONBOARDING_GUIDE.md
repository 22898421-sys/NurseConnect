# EIRENIX Trial Onboarding Guide

Date: 09-03-2026

This document is for temporary trial users of EIRENIX.

It covers onboarding for:

- Practice Admin
- Clinician
- Patient

## 1. Before You Start

Please have these ready:

- the EIRENIX web link: https://eirenix-project.web.app
- your login email and password, or your invite code
- a phone number in international format if you are using phone-based invite acceptance

Important:

- This trial environment is for testing and evaluation.
- Do not use real emergency cases.
- Avoid entering real patient information unless the environment has been explicitly approved for that purpose.

## 2. How Sign-In Works

EIRENIX currently supports two ways to get into the system:

1. Standard sign-in
- Use your email and password on the login page.

2. Invite acceptance
- Use the invite code provided to you.
- Email invite acceptance requires:
  - invite code
  - email
  - password
- Phone invite acceptance requires:
  - invite code
  - phone number
  - OTP sent to your phone

After sign-in, EIRENIX automatically sends you to the correct workspace for your role.

## 3. Practice Admin Onboarding

### 3.1 What a Practice Admin Does

The Practice Admin manages the practice setup and operational workflows, including:

- practice details
- patient and clinician invites
- appointments
- rosters
- billing
- practice switch request review

### 3.2 First Login Steps

After login, the Practice Admin should:

1. Open the Admin workspace.
2. Confirm the practice details are correct:
- practice name
- address
- phone number
- fax
- email
3. Save any missing or incorrect practice details.
4. Confirm the practice users are linked to the correct practice.

### 3.3 Key Trial Tasks for Practice Admin

Recommended test flow:

1. Review and update practice details.
2. Create a clinician invite.
3. Create a patient invite.
4. Open the appointments page and review bookings.
5. Open the rosters page and check clinician availability.
6. Open billing and review invoice visibility.

### 3.4 What to Check

The Practice Admin should confirm:

- the correct practice name is shown
- invites are created successfully
- appointments display correctly
- clinician rosters are visible
- billing pages load
- users are not obviously linked to the wrong practice

## 4. Clinician Onboarding

### 4.1 What a Clinician Does

The Clinician uses EIRENIX for:

- schedule review
- telehealth consultation
- patient chart review
- encounter documentation
- SOAP notes
- structured clinical actions

Structured clinical actions currently include:

- lab orders
- imaging orders
- referrals
- prescriptions
- medical certificates

### 4.2 First Login Steps

After login, the Clinician should:

1. Confirm they land on the Schedule page.
2. Review upcoming appointments.
3. Check that their roster or availability is present if relevant.
4. Open a patient chart.
5. Confirm the patient chart tabs load correctly.

### 4.3 Key Trial Tasks for Clinician

Recommended test flow:

1. Open the schedule.
2. Open a patient chart.
3. Start or review an encounter.
4. Enter SOAP notes.
5. Add one or more structured actions:
- lab order
- imaging order
- referral
- prescription
- medical certificate
6. Sign the encounter.
7. Open the print views for the resulting documents.
8. If telehealth is part of the trial, open a video consultation and test the join-link workflow.

### 4.4 What to Check

The Clinician should confirm:

- SOAP notes save correctly
- structured actions do not overwrite notes
- document print views are readable
- clinician name and practice name appear correctly on documents
- telehealth loads if used
- WhatsApp join-link flow behaves as expected if configured

## 5. Patient Onboarding

### 5.1 What a Patient Does

The Patient uses EIRENIX for:

- profile review
- appointment review
- self-booking
- billing visibility
- consent review
- clinical document access

### 5.2 First Login Steps

After login, the Patient should:

1. Confirm they land on the Patient Portal.
2. Review their profile details.
3. Check upcoming appointments.
4. Open the clinical documents area.

### 5.3 Key Trial Tasks for Patient

Recommended test flow:

1. Review existing appointments.
2. Attempt to book a new appointment if self-booking is enabled.
3. Open any available clinical documents.
4. Print or save a patient-facing document.
5. Review billing visibility.

### 5.4 What to Check

The Patient should confirm:

- the portal loads without errors
- clinician names display correctly when booking
- appointment booking works for available slots
- patient-facing documents are readable and not cluttered with internal admin metadata
- billing and consent sections load if those records exist

## 6. Patient-Facing Documents in the Trial

Current patient/external-facing print documents may include:

- prescription
- lab order
- imaging order
- referral
- medical certificate

These print views are intentionally simplified for patient or external-party use.

## 7. If You See a Problem

When reporting a problem, include:

- your role
- the page you were on
- what you were trying to do
- the exact error message if there was one
- whether anything appeared to save anyway
- a screenshot if possible

Useful examples:

- "As a clinician, I signed an encounter and the SOAP note was blank."
- "As a patient, booking returned 'internal'."
- "As a practice admin, the clinician invite was created but messaging did not send."

## 8. Trial Close-Out Checklist

At the end of the trial, ask each role to confirm:

- what worked
- what was confusing
- what failed
- what they would need before using it in a real practice setting

## 9. Summary by Role

Practice Admin:

- maintain practice details
- create invites
- manage operational workflows

Clinician:

- manage consults
- document SOAP
- create clinical actions

Patient:

- use the patient portal
- view documents
- review or request appointments

