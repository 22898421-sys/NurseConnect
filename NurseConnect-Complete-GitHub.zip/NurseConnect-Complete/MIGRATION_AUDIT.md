# NurseConnectCare → NurseConnect Complete Migration Audit

## Purpose

This project is the complete merge of:

- **NurseConnectCare-main** — the supervisor/reference application containing the full public website, patient/client workflows, organisation request workflows, nurse onboarding, and the secure EIRENIX Care clinical/operations platform.
- **NurseConnect** — the approved cleaner public-facing visual direction.

The merge uses the original full React/Firebase application as the technical base so that existing functionality is not lost. The public presentation has been updated to the approved NurseConnect teal/mint/cream aesthetic and EIRENIX Care is now made explicit as the secure platform behind NurseConnectCare.

## File-level verification

- Reference application files checked: **181**
- Reference application files missing from this merged project: **0**
- New components added: **2**
  - `src/components/ServicesPage.tsx`
  - `src/components/HowItWorksPage.tsx`
- Existing route/component/link syntax checked after the merge.
- All static internal `<Link to="...">` destinations currently resolve to a configured route.
- TypeScript/TSX syntax scan completed across the source tree with no syntax errors.

## Public-facing website cross-check

| Reference capability/content | Previous location | Complete merged site | Status |
|---|---|---|---|
| Public homepage | `/` | `/` | Preserved + restyled |
| Independent nurse care-at-home positioning | Landing page | Landing page | Preserved |
| Support at Home pathway explanation | Landing page | Landing page | Preserved |
| Category 5 / Category 4 provider registration explanation | Landing page | Landing page | Preserved |
| Platform boundary / responsibility statements | Landing page | Landing + services + footer | Preserved |
| Connected workflow: request → records → telehealth → evidence → invoice documentation | Landing page | Landing page | Preserved |
| Find Care / nurse discovery | `/find-care` | `/find-care` and `/request-care` | Preserved + alias added |
| Public service information | Landing + Find Care | `/services` + existing pages | Expanded |
| Medication support | Landing / Find Care | `/services`, `/find-care` | Preserved |
| Wound and skin care | Landing / Find Care | `/services`, `/find-care` | Preserved |
| Chronic disease management | Landing / Find Care | `/services`, `/find-care` | Preserved |
| Post-hospital care | Landing / Find Care | `/services`, `/find-care` | Preserved |
| Continence and catheter care | Find Care | `/services`, `/find-care` | Preserved |
| Palliative support | Find Care | `/services`, `/find-care` | Preserved |
| Telehealth where appropriate | Landing / Find Care | `/services`, `/find-care`, secure call routes | Preserved |
| About page | `/about` | `/about` | Preserved |
| Full FAQs | About page | `/about` | Preserved |
| “What we are / are not” model | About page | `/about` | Preserved |
| Contact form | `/contact` | `/contact` | Preserved |
| Public enquiry submission to backend | Contact page | `/contact` | Preserved |
| Contact email and phone | Contact page | `/contact` | Preserved |
| Privacy | `/privacy` | `/privacy` | Preserved |
| Terms | `/terms` | `/terms` | Preserved |
| New visual “How It Works” page | Not standalone | `/how-it-works` | Added |
| Approved-style Services page | Not standalone | `/services` | Added |
| Visible EIRENIX Care co-branding | Limited | Homepage + public chrome/footer | Expanded |
| Clear public vs secure split | Distributed | Explicit throughout | Expanded |

## Client / patient workflow cross-check

| Capability | Route / implementation | Status |
|---|---|---|
| Client/patient account entry | `/patient-login` | Preserved |
| Patient sign-up and login | `AccessPage.tsx`, `AuthContext.tsx` | Preserved |
| Password reset | `AccessPage.tsx` | Preserved |
| Phone OTP login support | `AccessPage.tsx` | Preserved |
| Find nurse by service type | `/find-care` | Preserved |
| Find nurse by postcode | `/find-care` | Preserved |
| Radius-based matching | `/find-care`, `geoMatching.ts` | Preserved |
| Current-location matching | `/find-care` | Preserved |
| State/territory filtering | `/find-care` | Preserved |
| Home visit / telehealth / hybrid care modes | `/find-care` | Preserved |
| Public nurse profile discovery | Firestore `publicNurseProfiles` | Preserved |
| Patient portal | `/patient` | Preserved |
| Patient chart/document access where authorised | protected routes | Preserved |
| Request Care public alias | `/request-care` | Added; maps to full existing Find Care workflow |

## Organisation / provider workflow cross-check

| Capability | Route / implementation | Status |
|---|---|---|
| Organisation service request | `/for-organisations/request` | Preserved |
| Open/direct request modes | `ServiceRequestPage.tsx` | Preserved |
| Provider/funding/care-plan context | service-request workflow | Preserved |
| Manage service request | `/service-requests/manage/:requestId` | Preserved |
| Clinician request inbox | `/service-requests` | Preserved |
| Service request libraries / Firestore helpers | `src/lib/serviceRequests.ts` | Preserved |

## Nurse onboarding and professional workflow cross-check

| Capability | Route / implementation | Status |
|---|---|---|
| Nurse application | `/for-nurses/apply` | Preserved |
| Nurse self-sign-up preparation | `NurseApplicationPage.tsx` | Preserved |
| AHPRA-related onboarding fields | auth/onboarding code | Preserved |
| Nurse type handling | auth/onboarding code | Preserved |
| Subscription billing cycle selection | auth/onboarding | Preserved |
| CPD public page | `/for-nurses/cpd` | Preserved |
| Support at Home / independent practice CPD topics | CPD page | Preserved |
| Clinical governance/documentation/risk CPD | CPD page | Preserved |
| Financial/practice setup CPD topics | CPD page | Preserved |

## EIRENIX Care secure platform cross-check

EIRENIX Care is no longer only an external-looking button. The complete secure workspace from the reference project is retained inside this merged application.

| Secure capability | Route / file | Status |
|---|---|---|
| EIRENIX clinician login/signup | `/clinician-login` | Preserved + more visible branding |
| Dashboard | `/dashboard` | Preserved |
| Profile settings | `/profile` | Preserved |
| Clinician schedule | `/schedule` | Preserved |
| Nurse roster | `/my-roster` | Preserved |
| Availability editor | `ClinicianAvailabilityEditor.tsx` | Preserved |
| Roster blocks editor | `ClinicianRosterBlocksEditor.tsx` | Preserved |
| Nurse subscription | `/nurse-subscription` | Preserved |
| Service request inbox | `/service-requests` | Preserved |
| Billing workspace | `/billing` | Preserved |
| Invoice print | `/billing/service-invoices/:invoiceId/print` | Preserved |
| Evidence pack | `/billing/service-invoices/:invoiceId/evidence` | Preserved |
| Patient list | `/patients` | Preserved |
| Patient detail | `/patients/:patientId` | Preserved |
| Patient chart | `/patients/:patientId/chart` | Preserved |
| Encounters | chart/encounter routes | Preserved |
| Encounter print | encounter print route | Preserved |
| Clinical document print | document print route | Preserved |
| Prescription tracking | prescription route | Preserved |
| Care plans | `CarePlansTab.tsx`, `carePlans.ts` | Preserved |
| Home care assessments | assessment components/lib | Preserved |
| Risk assessments | risk components/lib | Preserved |
| Nurse prescribing | `NursePrescribingTab.tsx`, prescribing libs | Preserved |
| Medication catalogue | `npMedicationCatalogue.json` + helpers | Preserved |
| Lab panels | `labPanels.ts` | Preserved |
| Imaging studies/playbook | imaging data files | Preserved |
| Video calls / telehealth | `/call`, `/call/:appointmentId` | Preserved |
| Jitsi/Twilio support | video components/lib | Preserved |

## Administration, security and compliance cross-check

| Capability | Route / files | Status |
|---|---|---|
| System admin | `/system-admin` | Preserved |
| Public enquiries admin | `/public-enquiries` | Preserved |
| Compliance console | `/compliance` | Preserved |
| Support access | `/support-access` | Preserved |
| Role-based protected routes | `ProtectedRoute.tsx` | Preserved |
| Auth context | `AuthContext.tsx` | Preserved |
| Access audit | `accessAudit.ts` | Preserved |
| Support access libraries | `supportAccess.ts` | Preserved |
| Firestore security rules | `firestore.rules` | Preserved |
| Storage security rules | `storage.rules` | Preserved |
| Firestore indexes | `firestore.indexes.json` | Preserved |
| Security rules test suite | scripts + validation docs | Preserved |
| Compliance reports / retention dry run | scripts | Preserved |
| Production readiness / cutover documentation | root documentation | Preserved |

## Backend / Firebase / triage cross-check

| Capability | Location | Status |
|---|---|---|
| Firebase Hosting config | `firebase.json` | Preserved |
| Firebase project config example | `.firebaserc`, env examples | Preserved |
| Cloud Functions | `functions/` | Preserved |
| Triage LLM integration | `functions/triage/llm.js` | Preserved |
| Triage session handling | `functions/triage/session.js` | Preserved |
| Triage rules | `functions/triage/rules.js` | Preserved |
| Triage SLA logic | `functions/triage/sla.js` | Preserved |
| General triage question bank | `functions/triage/questionBanks/general.json` | Preserved |
| Abdominal pain question bank | question bank JSON | Preserved |
| Chest pain question bank | question bank JSON | Preserved |
| Headache/neuro question bank | question bank JSON | Preserved |
| Shortness-of-breath question bank | question bank JSON | Preserved |
| Public submission helpers | `src/lib/publicSubmissions.ts` | Preserved |
| Service-request helpers | `src/lib/serviceRequests.ts` | Preserved |
| Billing helpers | billing libraries | Preserved |
| FHIR export | `fhirExport.ts` | Preserved |

## Design changes applied

The merged project keeps the full application but updates the public-facing presentation to match the approved NurseConnect visual direction:

- teal / dark teal / mint / cream palette;
- clearer sticky public navigation;
- dedicated **Request Care** CTA;
- dedicated dark **EIRENIX Care / Clinician** CTA;
- explicit EIRENIX Care branding panel;
- new Services and How It Works pages;
- complete public footer with client, organisation, nurse, legal and EIRENIX pathways;
- all public pages continue to use one shared `PublicSiteChrome` so the approved visual language is consistent.

## Important deployment notes

1. **Do not publish Firebase secrets to GitHub.** Keep real values in local/hosting environment variables. The repository contains example environment files only.
2. This is a React/Firebase application, not a simple GitHub Pages-only static website. GitHub can store the source code, but production hosting should use the existing Firebase Hosting setup (or another host that supports the React/Firebase build).
3. The secure EIRENIX Care workflows rely on Firebase Auth, Firestore, Storage and Cloud Functions. They will not become functional merely by uploading source files to GitHub Pages.
4. Before production cutover, use the existing deployment/readiness and security validation documentation retained in this repository.

## Final migration conclusion

**No source file from the supervisor/reference NurseConnectCare project was omitted from this merged project.** The complete application functionality is retained, while the public interface has been brought toward the approved NurseConnect aesthetic and the NurseConnectCare ↔ EIRENIX Care relationship has been made explicit.
