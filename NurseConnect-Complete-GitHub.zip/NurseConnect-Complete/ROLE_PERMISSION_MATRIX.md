# NurseConnectCare Role And Permission Matrix

Date: 2026-06-16

This matrix records the production role boundary used for the current NurseConnectCare and EIRENIX Care restricted environment.

## Roles

| Role | Purpose | Primary Access Boundary |
| --- | --- | --- |
| Public / unauthenticated user | Browse public website and submit public-facing enquiries or service requests | No access to restricted Firestore clinical, patient, compliance, encounter, or audit collections |
| Client / carer (`patient`) | Manage own account, booking context, communications, visible summaries and documents | Own client record only, based on auth UID or linked `patientId` |
| Clinician / nurse (`clinician`) | Independent nurse workspace for rosters, charting, encounters, evidence, billing facilitation and provider-aware workflows | Records attached to the clinician's own `practiceId`, with author-only controls where required |
| System admin (`system_admin`) | Platform support, public enquiry review, compliance administration, and audited troubleshooting | Compliance/support administration by default; no ordinary client-record browsing |

## Permission Summary

| Area | Public | Client / carer | Clinician / nurse | System admin |
| --- | --- | --- | --- | --- |
| Public marketing pages | Read | Read | Read | Read |
| Public enquiries and service requests | Create public request | Create own request where applicable | Review/respond where workflow allows | Review public enquiry/service request queues |
| Client demographic record | No access | Own record only | Own-practice records only | No default access; support grant required |
| Client clinical chart | No access | No clinician chart access | Own-practice clinical records only | No default access; support grant required |
| Patient-facing summaries/documents | No access | Own visible summaries/documents only | Own-practice records only | No default access; support grant required |
| Encounters | No access | No direct clinical encounter access | Own-practice or author-scoped encounter access | No default access; support grant required |
| Compliance provider records | No access | No access | No access | System-admin only |
| Credential and associated-provider compliance records | No access | No access | No access | System-admin only |
| Incident/complaint records | No access | No access | No access | System-admin only |
| Support access requests | No access | No access | Create and view own support requests | Review, approve, decline and close support requests |
| Support access grants | No access | No access | No direct grant access | Time-limited grant for assigned admin and specific client record |
| Access audit logs | No access | No access | Own actor logs where allowed | System-admin audit review |

## Signed-Off Evidence

- `G001_ROLE_ACCESS_SIGNOFF.md` validates role-based access for public, client/carer, clinician/nurse and system-admin users.
- `G002_SUPPORT_ACCESS_SIGNOFF.md` validates request-based, time-limited and audited system-admin support access to client records.

## Operating Notes

- NurseConnectCare does not employ nurses, provide clinical care, approve Support at Home eligibility, submit claims, process payments or hold client funds.
- Independent nurses remain responsible for clinical practice, documentation and professional obligations.
- Registered providers, care managers or funders retain their own Support at Home approval, care-plan, funding and provider-governance responsibilities where applicable.
- System-admin troubleshooting access to client records must be provider/clinician requested, time-limited and auditable.
