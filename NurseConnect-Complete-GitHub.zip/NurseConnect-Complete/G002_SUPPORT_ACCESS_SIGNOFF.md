# G002 Support Access Sign-Off Evidence

Date: 2026-06-16

Gate: `G002` - Admin access to client records is request-based, time-limited, and audited.

## Result

Passed.

## Evidence

Command run:

```bash
npm run test:g002:local
```

Result:

```text
G002 support-access rules validation passed.
```

The script validates the following Firestore rules behaviour:

- a `system_admin` cannot read a client record by default
- a `system_admin` cannot read a client encounter by default
- a clinician/provider user can create a support access request for a specific client record and reason
- another admin cannot create a grant on behalf of the assigned admin
- the assigned admin can create a time-limited support access grant linked to the request
- the assigned admin can read the client record only while the grant is active
- the assigned admin can read the client encounter only while the grant is active
- the assigned admin can write an `accessAuditLogs` entry with action `support_patient_record_access`
- an expired grant denies client record access
- a revoked grant denies client record access

## Files

- `scripts/testG002SupportAccessRules.mjs`
- `firestore.rules`
- `src/components/SupportAccessPage.tsx`
- `src/lib/supportAccess.ts`

## Residual Scope

This gate covers the support-access privacy control. It does not sign off the full role-based access model, legal/privacy review, incident/complaint SOPs, credential/provider verification SOPs, or pilot readiness.
