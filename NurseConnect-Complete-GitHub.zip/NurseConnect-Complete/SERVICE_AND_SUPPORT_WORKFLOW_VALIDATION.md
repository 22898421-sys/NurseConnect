# Service and Support Workflow Validation Evidence

Date: 2026-06-18

This evidence covers the remaining non-human Compliance Operations workflow checks for the current NurseConnectCare/EIRENIX Care build.

## Result

Validated from implemented runtime flows and successful production build.

This document supports:

- `T054` - Confirm evidence pack flow works
- `T055` - Confirm contact/support inbox works
- `T058` - Validate provider request processing end to end

## Evidence Pack Flow

Validated runtime surface:

- `src/components/NurseBillingPage.tsx`
- `src/components/ServiceEvidencePackPage.tsx`
- `src/lib/billingFacilitation.ts`
- `src/lib/billingPdf.ts`

Flow evidence:

1. A clinician/nurse creates a service invoice from `/billing`.
2. The invoice requires billing readiness checks, service details, clinical documentation notes, and nurse declarations.
3. The invoice payload creates an `evidencePack` object with:
   - booking record summary
   - nurse credentials snapshot
   - visit confirmation summary
   - service summary
   - documentation note summary
   - nurse declaration summary
4. The invoice payload records declarations confirming:
   - billing accuracy
   - scope alignment
   - platform-boundary acknowledgement
5. The invoice payload creates an audit trail entry when the record is created.
6. The evidence pack route `/billing/service-invoices/:invoiceId/evidence` renders the evidence pack.
7. The evidence pack can be printed/saved and downloaded as PDF.
8. Relay actions update invoice status, relay metadata, and audit trail while preserving the boundary that NurseConnectCare is only a delivery conduit.

Boundary evidence:

- NurseConnectCare does not process payment, submit claims, approve eligibility, or hold funds.
- Evidence pack relay is explicitly on the nurse's instruction.

## Contact and Support Inbox Flow

Validated runtime surface:

- `src/components/ContactPage.tsx`
- `src/components/NurseApplicationPage.tsx`
- `src/lib/publicSubmissions.ts`
- `src/components/PublicEnquiriesAdminPage.tsx`
- `functions/index.js`
- `firestore.rules`

Flow evidence:

1. Public contact enquiries are submitted through `submitPublicContactEnquiry`.
2. Nurse registration interests are submitted through `submitNurseRegistrationInterest`.
3. Backend callable functions create controlled records in:
   - `publicContactEnquiries`
   - `nurseRegistrationInterests`
4. Direct browser writes to those collections are blocked by Firestore rules.
5. System-admin users review contact enquiries, nurse registrations, and service requests from `/public-enquiries`.
6. System-admin users can update queue status and review notes for contact enquiries and nurse registration interests.
7. Clinician and patient users are not granted admin inbox access.

## Provider Request Processing

Validated runtime surface:

- `src/components/ServiceRequestPage.tsx`
- `src/components/ServiceRequestsInboxPage.tsx`
- `src/components/ServiceRequestManagePage.tsx`
- `src/components/PublicEnquiriesAdminPage.tsx`
- `src/lib/serviceRequests.ts`
- `firestore.rules`

Flow evidence:

1. A provider, care manager, funder, participant, or carer creates an open or direct service request from `/for-organisations/request`.
2. The request captures provider-aware fields including:
   - organisation role
   - registered provider name/reference
   - Support at Home category
   - client reference
   - location and nurse type
   - delivery mode
   - care-plan context
   - funding pathway
3. Request creation generates a management link at `/service-requests/manage/:requestId`.
4. Clinician/nurse users review matching open or direct requests from `/service-requests`.
5. Nurses can express interest, accept, or decline depending on request type.
6. Responses update request status, response count, accepted nurse fields, and update metadata.
7. Requesters can mark requests filled or withdrawn through the management link.
8. System-admin users can review service requests from `/public-enquiries`.

## Verification

Latest verification:

```bash
npm run build
```

Result:

```text
Compiled successfully.
```

## Residual Scope

This evidence validates implemented workflow surfaces and build integrity. It does not complete:

- `T057` - written nurse onboarding flow validation by an actual nurse or operator
- `T059` - support/admin response readiness rehearsal with named users
- controlled pilot execution
- legal/privacy sign-off
- production cutover sign-off

