# Compliance Operations Runbook

Date: 2026-06-18

This runbook supports NurseConnectCare/EIRENIX Care restricted operations for independent nurse workflows, provider-aware service requests, Support at Home-aligned evidence, compliance records, and audited troubleshooting.

NurseConnectCare provides connector and workflow infrastructure. It does not employ nurses, act as the care provider, approve Support at Home eligibility, process claims, or hold client funds.

## Covered Tracker Items

This document supports:

- `T042` - Create Admin runbook
- `T043` - Create Nurse onboarding checklist
- `T044` - Create Provider onboarding checklist
- `T045` - Create Credential verification checklist
- `T046` - Create Associated-provider checklist
- `T047` - Create Incident/complaint triage matrix
- `T048` - Create Support escalation contacts
- `T049` - Create Known-issues register

## Admin Runbook

### Daily checks

1. Review `/public-enquiries` for new public contacts, nurse-registration interests, and service requests.
2. Review `/compliance` audit dashboard for expired/expiring credentials, escalated incidents, pending associated providers, and provider onboarding records.
3. Review `/support-access` for provider/clinician support access requests.
4. Confirm no support access grants remain active after the troubleshooting purpose is complete.
5. Record critical/high issues in the Known-Issues Register section of this document.

### Weekly checks

1. Review open compliance provider records and update status.
2. Review credential expiry records due within 30 days.
3. Review associated-provider agreement, screening, and insurance status.
4. Review incident/complaint records for owner, due date, severity, and escalation status.
5. Export or preserve evidence required for governance review.

### Access rules

- `system_admin` users may review public enquiries, compliance records, and support access queues.
- `system_admin` users must not browse client records by default.
- Client-record troubleshooting access requires a provider/clinician support request, time-limited grant, and audit log entry.
- Deletes are blocked for compliance records, support grants, support requests, and audit logs.

### Admin closure criteria

An admin item can be closed only when:

- responsible owner is recorded
- status is updated
- evidence reference or notes are recorded where applicable
- any client-record access occurred through the support-access workflow
- follow-up date or closure reason is recorded

## Nurse Onboarding Checklist

Use this checklist for independent nurses joining the platform.

| Step | Evidence |
|---|---|
| Confirm nurse identity and contact details | profile record |
| Confirm role is `clinician` | user role record |
| Confirm AHPRA registration number and nurse type | profile/credential evidence |
| Confirm ABN and billing profile where relevant | billing profile |
| Confirm service region, travel radius, service focus, funding models, and response expectations | public profile fields |
| Confirm subscription/trial cycle has started | subscription record |
| Confirm nurse understands independent-provider position | participation terms acknowledgement when available |
| Confirm privacy, recordkeeping, support access, and incident responsibilities | onboarding acknowledgement when available |
| Confirm first workflow test: login, profile update, patient/service request review, and billing/evidence pack navigation | onboarding test note |

Nurse onboarding is not complete until legal participation terms and privacy notices are final.

## Provider Onboarding Checklist

Use this checklist for registered providers, care managers, or organisations requesting workflows through the platform.

| Step | Evidence |
|---|---|
| Create provider onboarding record in `/compliance` | `complianceProviders` record |
| Record provider name, reference/registration ID, contact name, and contact email | provider record |
| Record relevant service categories | provider record |
| Confirm provider relationship to client/request | service request or provider notes |
| Confirm provider understands NurseConnectCare is platform infrastructure only | provider communication note |
| Confirm request pathway and care-plan context | service request record |
| Confirm evidence pack or communication requirements | provider notes |
| Update provider status to onboarding, active, paused, or closed | provider status |

Provider onboarding is not complete until provider participation terms and operating responsibilities are final.

## Credential Verification Checklist

Use this checklist for nurses, associated providers, and suppliers.

| Step | Evidence |
|---|---|
| Create credential record in `/compliance` | `complianceCredentials` record |
| Record subject name and subject type | credential record |
| Record credential type | credential record |
| Record provider/context where applicable | credential record |
| Record expiry date | credential record |
| Record evidence reference | external check, document ID, or storage reference |
| Set status to pending, verified, expiring, expired, or rejected | credential status |
| Review expiring credentials within 30 days | audit dashboard |
| Escalate expired/rejected credentials | known issue or incident record |

Credential status is operational evidence only; it does not replace external professional registration or legal verification.

## Associated-Provider Checklist

Use this checklist where a provider, supplier, contractor, or other associated organisation is relevant to a workflow.

| Step | Evidence |
|---|---|
| Create associated-provider record in `/compliance` | `associatedProviders` record |
| Record organisation name | associated-provider record |
| Record registered-provider context | associated-provider record |
| Record service category | associated-provider record |
| Record contact email | associated-provider record |
| Record agreement status | pending, approved, suspended, or ended |
| Record insurance expiry where relevant | associated-provider record |
| Record screening status where relevant | associated-provider record |
| Escalate suspended/expired/high-risk records | known issue or incident record |

## Incident/Complaint Triage Matrix

| Severity | Examples | Initial target | Owner | Escalation |
|---|---|---|---|---|
| Critical | privacy breach, suspected client harm, unauthorised client-record access, serious complaint, regulatory notification risk | same day | Support/Admin Lead plus Founder | legal/privacy advisor and clinical governance lead |
| High | credential expired while active, provider dispute, unresolved complaint, failed support access audit, evidence integrity issue | 1 business day | Support/Admin Lead | Founder and relevant advisor |
| Medium | delayed response, incomplete evidence pack, workflow confusion, non-urgent complaint | 3 business days | Operations Lead | Support/Admin Lead |
| Low | typo, minor profile issue, non-urgent process improvement | 5 business days | assigned admin | Operations Lead if repeated |

Minimum incident/complaint record fields:

- type: incident or complaint
- title
- provider context where applicable
- participant reference where applicable
- severity
- status
- owner
- due date
- summary

Closure criteria:

- owner recorded
- outcome or remediation recorded
- affected parties contacted where required
- legal/privacy or clinical escalation completed if required
- known issue updated if systemic

## Support Escalation Contacts

Replace placeholder owners with named people before production launch.

| Escalation area | Primary owner | Backup | Trigger |
|---|---|---|---|
| Platform support/admin | Support/Admin Lead | Founder | support access request, public enquiry issue, workflow failure |
| Privacy/legal | Legal/Privacy Advisor | Founder | privacy complaint, data access concern, breach concern |
| Clinical governance | Clinical Governance Lead | Founder | clinical safety concern, serious incident, pilot clinical issue |
| Operations | Operations Lead | Support/Admin Lead | provider onboarding, credential review, associated-provider issue |
| Engineering | Engineering | Founder | rules failure, build/deployment issue, data workflow defect |

## Known-Issues Register

| ID | Issue | Severity | Owner | Status | Next action |
|---|---|---|---|---|---|
| KI-001 | Legal/privacy review not yet complete | Critical | Legal/Privacy Advisor | Open | obtain external review and update G003 |
| KI-002 | Admin/support SOPs need operational rehearsal | High | Support/Admin Lead | Open | run support/admin response scenario |
| KI-003 | Pilot users not yet recruited | Critical | Clinical Governance Lead | Open | confirm nurse and provider/care-manager pilot participants |
| KI-004 | Spreadsheet dropdown metadata is degraded in current tracker file | Medium | Product/Founder | Open | restore workbook validations after next major tracker update |

New issues should include:

- unique ID
- concise description
- severity
- owner
- status
- next action
- date raised
- closure note when resolved

## Residual Scope

This runbook does not sign off:

- final Terms of Use or Privacy Policy
- external legal/privacy review
- pilot completion
- production release decision
- actual named owner availability
- live support/admin response rehearsal

