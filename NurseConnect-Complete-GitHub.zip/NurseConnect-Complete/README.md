# NurseConnectCare + EIRENIX Care

Complete NurseConnectCare application with the approved public-facing NurseConnect visual direction and the full secure EIRENIX Care workflow retained from the reference application.

## What this repository contains

- Public NurseConnectCare website
- Services, About, How It Works, Contact, Privacy and Terms
- Patient/client care discovery and request workflow
- Organisation/provider service requests
- Nurse registration and CPD
- EIRENIX Care clinician authentication
- Patient records, encounters, care plans and assessments
- Scheduling, rosters and clinician availability
- Prescribing and prescription tracking
- Billing, invoices and evidence packs
- Telehealth/video workflows
- System administration, support access and compliance tooling
- Firebase Auth, Firestore, Storage, Hosting and Cloud Functions configuration
- Triage functions and question banks
- Security, compliance, onboarding and production-readiness documentation

See **[MIGRATION_AUDIT.md](./MIGRATION_AUDIT.md)** for the detailed old-to-new cross-verification.

## Public routes

- `/` — Home
- `/services` — Services
- `/about` — About + FAQs
- `/how-it-works` — Public-to-EIRENIX workflow
- `/contact` — Contact/enquiry form
- `/request-care` — Request Care (full nurse-discovery/request workflow)
- `/find-care` — Existing Find Care route
- `/for-organisations/request` — Organisation/provider request
- `/for-nurses/apply` — Nurse registration
- `/for-nurses/cpd` — Nurses CPD
- `/patient-login` — Client/carer access
- `/clinician-login` — EIRENIX Care clinician access
- `/privacy` and `/terms`

## Local setup

```bash
npm install
npm start
```

The public site runs through the React app. Secure functions require the correct Firebase environment configuration.

## Build

```bash
npm run build
```

## Firebase deployment

Review the existing deployment documentation and environment examples before deployment:

- `LOCAL_DEV.md`
- `PRODUCTION_CUTOVER_RUNBOOK.md`
- `PRODUCTION_READINESS_PIPELINE.md`
- `SECURITY_RULES_TEST_SUITE.md`

Do not commit real credentials or secret environment values.
