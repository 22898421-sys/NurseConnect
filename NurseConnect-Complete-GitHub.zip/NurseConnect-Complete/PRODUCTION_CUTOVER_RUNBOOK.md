# Production Cutover Runbook

Date: 2026-06-18

This runbook prepares NurseConnectCare/EIRENIX Care for a controlled production release decision. It does not approve production launch by itself.

## Covered Tracker Items

This document supports:

- `T079` - Prepare Production launch checklist
- `T080` - Prepare Release decision note
- `T081` - Prepare Monitoring and alerting checklist
- `T082` - Prepare Backup/export approach
- `T083` - Prepare Final deployment record

## Production Launch Checklist

Do not proceed to public production launch until all required gates are either passed or explicitly accepted as launch exceptions by the founder.

### Required evidence before launch

| Area | Required evidence | Status source |
|---|---|---|
| Product scope | launch scope, route review, data inventory, sensitive collection map | `PRODUCT_SCOPE_EVIDENCE_PACK.md` |
| Role access | role-based access tests passed | `G001_ROLE_ACCESS_SIGNOFF.md` |
| Support access | audited, request-based support access tests passed | `G002_SUPPORT_ACCESS_SIGNOFF.md` |
| Security rules | consolidated rules suite passed | `SECURITY_RULES_TEST_SUITE.md` |
| Compliance console | provider, credential, associated-provider, incident/complaint flows validated | `COMPLIANCE_WORKFLOW_VALIDATION.md` |
| Compliance operations | runbook, checklists, triage, escalation, known issues | `COMPLIANCE_OPERATIONS_RUNBOOK.md` |
| Service/support workflows | evidence pack, inbox, provider request flow validation | `SERVICE_AND_SUPPORT_WORKFLOW_VALIDATION.md` |
| Nurse/admin rehearsal | onboarding/support desk-check and live rehearsal plan | `ONBOARDING_AND_SUPPORT_REHEARSAL_PACK.md` |
| Legal/privacy | draft pack plus external review | `LEGAL_PRIVACY_DRAFT_PACK.md` and review notes |
| Pilot | controlled pilot issue log and exit note | pilot evidence |

### Pre-release technical checks

1. Confirm `main` branch is clean and pushed.
2. Run `npm run build`.
3. Run `npm run test:rules:local` against the local emulator.
4. Run deployment readiness checks where configured.
5. Confirm Firestore rules are deployed only after tests pass.
6. Confirm hosting build points at the intended Firebase project.
7. Confirm no placeholder legal/privacy copy is being treated as final.
8. Confirm support/admin users cannot browse client records by default.
9. Confirm public enquiries and service requests can be reviewed by `system_admin`.
10. Confirm clinician/nurse users can access their restricted workspace.

### Pre-release operational checks

1. Confirm named support/admin owner.
2. Confirm named privacy/legal escalation owner.
3. Confirm named clinical governance owner.
4. Confirm pilot nurse/operator and provider/care-manager contacts.
5. Confirm support inbox response expectations.
6. Confirm incident/complaint triage owners and target times.
7. Confirm known-issues register is current.
8. Confirm no critical/high privacy, security, or clinical-governance defects remain open.

## Release Decision Note Template

Use this template for the final production go/no-go decision.

```text
Release decision date:
Decision owner:
Firebase project:
Hosting URL:
Git commit:
Build command/result:
Rules test command/result:
Deployment command/result:

Decision:
[ ] Go
[ ] No-go
[ ] Conditional go with exceptions

Passed gates:
- G001:
- G002:
- G003:
- G004:
- G005:
- G006:
- G007:

Open critical/high issues:

Accepted exceptions:

Legal/privacy review status:

Pilot status:

Named operational owners:

Rollback plan:

Decision notes:
```

## Monitoring and Alerting Checklist

Minimum monitoring before launch:

- Firebase Hosting deploy status reviewed after release.
- Firebase Functions logs reviewed after release.
- Firestore rules/log-related errors reviewed after release.
- Public contact form submission path checked.
- Nurse registration interest path checked.
- Service request creation path checked.
- Restricted login path checked for patient, clinician, and system admin.
- Support access audit log path checked.
- Compliance console load checked.
- Known-issues register updated after smoke test.

Suggested first 48-hour monitoring cadence:

| Timing | Check |
|---|---|
| Immediately after deploy | hosting page loads, login loads, no obvious console/runtime failure |
| Within 1 hour | public forms, service request flow, restricted dashboard smoke checks |
| Same day | Firebase function logs, support inbox, compliance console |
| Next day | issue register review, pilot feedback, support access/audit check |
| 48 hours | release decision review and go-forward/rollback confirmation |

## Backup and Export Approach

Minimum pre-launch approach:

1. Confirm Firebase project and environment before any production operation.
2. Preserve Git commit hash for every release.
3. Preserve deployment command and Firebase deployment output.
4. Keep tracker/workplan backup before major status changes.
5. Use Firebase/Google Cloud export tooling for Firestore backup before broad production data migration or destructive maintenance.
6. Do not manually delete client, compliance, support access, or audit records.
7. Use documented retention/dry-run scripts before any retention operation.

Relevant scripts:

- `scripts/retentionDryRun.js`
- `scripts/complianceReport.js`

Data categories requiring particular care:

- client/patient records
- clinical records and encounters
- patient summaries and portal documents
- service invoices and evidence packs
- support access requests, grants, and audit logs
- compliance provider, credential, associated-provider, incident, and complaint records

## Final Deployment Record Template

```text
Deployment date/time:
Operator:
Git commit:
Branch:
Firebase project:
Deployment target:
Command:
Build result:
Rules test result:
Firebase deploy output:
Hosting URL:

Smoke tests:
[ ] Public home page
[ ] Public contact page
[ ] Nurse registration page
[ ] Organisation service request page
[ ] Patient/client login
[ ] Nurse/clinician login
[ ] System-admin login
[ ] Public enquiries admin
[ ] Compliance console
[ ] Support access page
[ ] Billing/evidence pack route

Issues found:

Rollback action if required:

Final release note:
```

## Residual Scope

This runbook does not complete:

- final hosting/rules/functions deployment
- public/restricted smoke tests
- legal/privacy sign-off
- pilot completion
- production release decision

