# NurseConnectCare Product Scope Evidence Pack

Date: 2026-06-18

This evidence pack supports Week 1 Product Scope tracker items for the NurseConnectCare-aligned EIRENIX Care build. It records the current first-release scope, route surface, Firebase environments, data inventory, and sensitive collection map.

## Result

Product scope evidence is complete for the current launch-readiness baseline.

This pack supports moving these tracker items to `Done`:

- `T003` - Complete data inventory
- `T006` - Confirm live and preview Firebase environments
- `T007` - Review all public routes
- `T008` - Review all restricted routes
- `T010` - Identify sensitive Firestore collections
- `T012` - Agree written launch scope

## Launch Scope Decision

NurseConnectCare is positioned as connector and workflow infrastructure for independent nurses and registered provider/care-manager workflows. It does not employ nurses, provide nursing care, approve Support at Home eligibility, process claims, or hold patient/client funds.

The current first-release scope is:

- public NurseConnectCare website and enquiry/request flows
- nurse self sign-up and clinician workspace access
- client/carer portal access
- independent nurse workflow tools for schedule, roster, patient records, encounters, billing facilitation, and evidence packs
- provider-aware service request workflow
- system-admin public enquiry review
- system-admin compliance console for provider onboarding, credentials, associated-provider records, incidents and complaints
- request-based, time-limited, audited support access to client records

The current first-release exclusions are:

- NurseConnectCare acting as nurse employer or registered care provider
- final legal/privacy sign-off
- final incident/complaint SOP sign-off
- controlled pilot completion
- production cutover sign-off

## Firebase Environment Confirmation

Configured Firebase environments:

| Environment | Evidence | Current value |
|---|---|---|
| Live hosting / production Firebase project | `.firebaserc`, `.env.production` | `nurseconnect-project` |
| Local emulator project | `.firebaserc`, `.env.local.example`, `firebase.json` | `nurseconnectcare-local` |
| Legacy/alternate project alias retained in config | `.firebaserc` | `eirenix-project` |

Firebase hosting is configured in `firebase.json` to serve the React build from `build`, use SPA rewrites to `index.html`, and apply no-cache headers for `index.html` and `asset-manifest.json`.

Local emulator ports are configured in `firebase.json`:

- Auth: `9399`
- Firestore: `8380`
- Functions: `5005`
- Storage: `9298`
- Hosting: `5006`
- Emulator UI: `4005`

## Public Route Review

Public routes are defined in `src/App.tsx` outside the authenticated route group:

| Route | Purpose |
|---|---|
| `/` | public NurseConnectCare landing page |
| `/about` | public about page |
| `/contact` | public contact page |
| `/privacy` | public privacy page |
| `/terms` | public terms page |
| `/find-care` | public care discovery/request entry |
| `/for-organisations/request` | organisation/provider-aware service request form |
| `/service-requests/manage/:requestId` | token-style service request management route |
| `/for-nurses/apply` | nurse application/interest route |
| `/bootstrap/setup` | bootstrap setup route |
| `/patient-login` | patient/client login route |
| `/nurse-login` | redirect to clinician login |
| `/clinician-login` | nurse/clinician login route |
| `/login` | redirect to clinician login |
| `*` | fallback redirect to `/` |

Public Firestore access is limited. `publicNurseProfiles` allows public reads with a query limit. `serviceRequests` allows structured public creation using the manage token as document ID. Public contact and nurse registration interest collections are not directly writable by browser Firestore rules; they are handled through controlled backend submission paths.

## Restricted Route Review

Restricted routes are defined in `src/App.tsx` under `ProtectedRoute` and role-specific nested protection.

| Route | Allowed roles | Purpose |
|---|---|---|
| `/dashboard` | patient, clinician, system_admin | authenticated landing/dashboard |
| `/profile` | patient, clinician, system_admin | user profile/settings |
| `/patient` | patient | patient/client portal |
| `/schedule` | clinician | clinician workspace |
| `/my-roster` | clinician | clinician roster |
| `/nurse-subscription` | clinician | nurse subscription/trial cycle |
| `/service-requests` | clinician | service request inbox |
| `/billing` | clinician | billing facilitation |
| `/billing/service-invoices/:invoiceId/print` | clinician | invoice print |
| `/billing/service-invoices/:invoiceId/evidence` | clinician | service evidence pack |
| `/system-admin` | system_admin | support/admin console |
| `/patients` | clinician | patient list |
| `/patients/:patientId` | clinician | patient detail |
| `/patients/:patientId/chart` | clinician | patient chart |
| `/patients/:patientId/chart/encounters/:encounterId` | clinician | encounter detail |
| `/patients/:patientId/chart/encounters/:encounterId/print` | clinician | encounter print |
| `/patients/:patientId/documents/:docId/print` | patient, clinician | clinical action print |
| `/patients/:patientId/prescriptions/:prescriptionId` | clinician | prescription tracking |
| `/public-enquiries` | system_admin | public enquiry and service request review |
| `/compliance` | system_admin | compliance console |
| `/support-access` | clinician, system_admin | provider/clinician-requested support access |
| `/call` and `/call/:appointmentId` | patient, clinician | video call route |

The legacy `/admin`, `/appointments`, and `/rosters` routes redirect to authenticated dashboard routes rather than exposing standalone admin pages.

## Data Inventory

Current Firestore data categories identified from the application code and rules:

| Category | Collections / paths | Primary sensitivity |
|---|---|---|
| Identity and roles | `users`, `practices` | personal, role, practice affiliation |
| Patient/client records | `patients`, `patientClinicalRecords`, `patientSummaries`, `patients/{patientId}/uploads`, `patients/{patientId}/portalDocuments`, `patients/{patientId}/consents`, `patients/{patientId}/consents/{consentId}/events` | health, personal, consent, clinical documents |
| Clinical workflows | `appointments`, `encounters`, `encounterHeaders`, `encounters/{encounterId}/soapVersions`, `encounters/{encounterId}/soapRevisions`, `riskAssessments`, `carePlans`, `prescriptions`, `prescriptions/{prescriptionId}/dispenses` | health and clinical records |
| Billing and evidence | `invoices`, `serviceInvoices` | billing, service evidence, patient/provider context |
| Public/service workflows | `publicNurseProfiles`, `serviceRequests`, `serviceRequestNotifications`, `serviceRequestNotificationDeliveries`, `publicContactEnquiries`, `nurseRegistrationInterests` | contact details, service needs, provider/request context |
| Compliance operations | `complianceProviders`, `complianceCredentials`, `associatedProviders`, `incidentComplaints`, `complianceReports`, `retentionRuns` | provider, credential, incident/complaint, governance records |
| Support access and audit | `supportAccessRequests`, `supportAccessGrants`, `accessAuditLogs` | troubleshooting requests, time-limited grants, audit logs |
| Configuration and operations | `config`, `clinicianAvailability`, `practiceTasks` | system config and operational scheduling |

## Sensitive Collection Map

The following collections are sensitive and require least-privilege controls:

| Collection / path | Sensitive data type | Current control summary |
|---|---|---|
| `patients` | client identity, demographic and care context | clinician scoped by `practiceId`; patient scoped to own record; system admin only through active support grant |
| `patientClinicalRecords` | clinical chart content | clinician scoped by related patient/practice; audited revisions; no default system-admin browsing |
| `patientSummaries` | plain-language health summaries | clinician/patient scoped; no default system-admin browsing |
| `encounters` and subcollections | encounter notes, SOAP versions, revisions | clinician scoped by patient/practice; support access requires active grant |
| `patients/{patientId}/portalDocuments` | patient-visible clinical documents | clinician/patient scoped |
| `patients/{patientId}/consents` and `events` | consent state and consent audit events | clinician/patient scoped; append-only event design |
| `prescriptions` and `dispenses` | prescribing and dispense data | clinician scoped; NP capability gated in app/domain logic |
| `riskAssessments`, `carePlans` | health assessments and care planning | clinician scoped; clinical record revisions written |
| `invoices`, `serviceInvoices` | billing and evidence records | clinician/nurse workflow records; includes patient/provider context |
| `supportAccessRequests` | provider/clinician support request reasons | clinician requester or system admin |
| `supportAccessGrants` | support access grants and expiry | system admin only; time-limited and request-linked |
| `accessAuditLogs` | client record access audit trail | system admin review; actor can access own log where allowed; append-only |
| `complianceProviders` | registered provider onboarding records | system admin only |
| `complianceCredentials` | credential verification/expiry records | system admin only |
| `associatedProviders` | associated-provider compliance records | system admin only |
| `incidentComplaints` | incident and complaint records | system admin only |
| `publicContactEnquiries`, `nurseRegistrationInterests`, `serviceRequests` | contact details and service needs | public creation is constrained; admin/clinician review scoped by rules |

## Evidence Files

- `src/App.tsx` - public and restricted route definitions
- `firestore.rules` - role and collection-level access boundaries
- `firebase.json` - hosting, emulator, rules, storage and functions configuration
- `.firebaserc` - Firebase project aliases
- `.env.production` - production Firebase project configuration
- `.env.local.example` - local emulator project configuration
- `BUILD_DOCUMENTATION.md` - current product positioning and runtime surface
- `ROLE_PERMISSION_MATRIX.md` - role and permission model
- `G001_ROLE_ACCESS_SIGNOFF.md` - role-based access evidence
- `G002_SUPPORT_ACCESS_SIGNOFF.md` - audited support access evidence

## Residual Scope

This pack does not sign off:

- final Terms of Use or Privacy Policy
- Australian privacy lawyer review
- aged-care/Support at Home regulatory review
- incident and complaint SOP readiness
- credential/provider verification SOP readiness
- pilot completion
- final production cutover

